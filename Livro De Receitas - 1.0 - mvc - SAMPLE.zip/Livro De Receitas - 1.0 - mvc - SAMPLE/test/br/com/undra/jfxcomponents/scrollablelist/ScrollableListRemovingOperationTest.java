package br.com.undra.jfxcomponents.scrollablelist;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexandre
 */
public class ScrollableListRemovingOperationTest {

    public ScrollableListRemovingOperationTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_EMPTY() {
        System.err.println("removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_EMPTY test");

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:7
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 7);

        sl.removeAndUpdateVisibleElements(3);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:6
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getChangefulModel().size(), 6);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_NOT_EMPTY() {

        System.err.println("removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_NOT_EMPTY test");

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 10);

        sl.removeAndUpdateVisibleElements(3);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:9
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getChangefulModel().size(), 9);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_lesserThan_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_EMPTY() {
        System.err.println("removeAndUpdateVisibleElements_REMOVE_BEFORE_VISIBLE_SIZE_lesserThan_VISIBLE_ELEMENTS_MAX_NUM_and_BOTTOM_STACK_EMPTY test");

        //TOP STACK:3,16,28         
        //VISIBLE:39,211,250,350       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:7
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.scrollUp();
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 7);

        sl.removeAndUpdateVisibleElements(3);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:6 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        assertEquals(sl.getChangefulModel().size(), 6);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_AFTER() {

        System.err.println("removeAndUpdateVisibleElements_REMOVE_AFTER test");

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 10);

        sl.removeAndUpdateVisibleElements(390);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:9
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(380));
        assertEquals(sl.getChangefulModel().size(), 9);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_EMPTY() {
        System.err.println("removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_EMPTY test");

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        //MODEL.SIZE:5
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 5);

        sl.removeAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:       
        //VISIBLE:3,16,28,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        //MODEL.SIZE:4
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(211));
        assertEquals(sl.getChangefulModel().size(), 4);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_FULL() {

        System.err.println("removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_equals_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_FULL test");

        //TOP STACK:3,16,28       
        //VISIBLE:39,211,250,350,380       
        //BOTTOM STACK:400,390
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 10);

        sl.removeAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

//        TOP STACK:3,16,28       
//        VISIBLE:211,250,350,380,390       
//        BOTTOM STACK:400
//        VISIBLE_ELEMENTS_MAX_NUM:5 
//        MODEL.SIZE:9
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(211));
        assertEquals(sl.getVisibleElements().get(1), new Integer(250));
        assertEquals(sl.getVisibleElements().get(2), new Integer(350));
        assertEquals(sl.getVisibleElements().get(3), new Integer(380));
        assertEquals(sl.getVisibleElements().get(4), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getChangefulModel().size(), 9);

    }

    @Test
    public void removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_lesserThan_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_EMPTY() {
        System.err.println("removeAndUpdateVisibleElements_REMOVE_IN_BETWEEN_VISIBLE_SIZE_lesserThan_VISIBLE_ELEMENTS_MAX_NUM_and_TOP_AND_BOTTOM_STACK_EMPTY test");

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39      
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        //MODEL.SIZE:4
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getChangefulModel().size(), 4);

        sl.removeAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //e=39
        //TOP STACK:       
        //VISIBLE: 3,16,28      
        //BOTTOM STACK:
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:3
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getChangefulModel().size(), 3);

    }
}
