package br.com.undra.jfxcomponents.scrollablelist;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexandre
 */
public class ScrollableListAddingOperationTest {

    public ScrollableListAddingOperationTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void addBefore_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition() {
        System.err.println("addBefore_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition test");
        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(1);

        //TOP STACK:empty         
        //VISIBLE:1,3,16,28,39       
        //BOTTOM STACK:400,390,380,350,250,211
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));

        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().get(5), new Integer(211));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(2);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(0), new Integer(2));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));

        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().get(5), new Integer(211));

    }

    @Test
    public void addBefore_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPositionAtTopStack() {
        System.err.println("addBefore_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPositionAtTopStack test");
        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:empty       
        //VISIBLE:3,16,28,39,211     
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(4), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(1);

        //TOP STACK:empty       
        //VISIBLE:1,3,16,28,39     
        //BOTTOM STACK:400,390,380,350,250,211
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:11
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().get(5), new Integer(211));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(0);

        //TOP STACK:empty       
        //VISIBLE:0,1,3,16,28     
        //BOTTOM STACK:400,390,380,350,250,211,39
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:12
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(0));
        assertEquals(sl.getVisibleElements().get(1), new Integer(1));
        assertEquals(sl.getVisibleElements().get(2), new Integer(3));
        assertEquals(sl.getVisibleElements().get(3), new Integer(16));
        assertEquals(sl.getVisibleElements().get(4), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().get(5), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(6), new Integer(39));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addBefore_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addBefore_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:5
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);

        assertEquals(sl.getInvisibleTopStack().size(), 4);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(0), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(1);

        //TOP STACK:empty       
        //VISIBLE:1,3,16,28,39     
        //BOTTOM STACK:211
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:6
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(211));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(2);

        //TOP STACK:1       
        //VISIBLE:2,3,16,28,39     
        //BOTTOM STACK:211
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:6
        assertEquals(sl.getInvisibleTopStack().size(), 1);
        assertEquals(sl.getVisibleElements().get(0), new Integer(2));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(211));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addBefore_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addBefore_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:8
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);

        //TOP STACK:3,16,28,39,211,250,350   
        //VISIBLE:380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getVisibleElements().get(1), new Integer(211));
        assertEquals(sl.getVisibleElements().get(2), new Integer(250));
        assertEquals(sl.getVisibleElements().get(3), new Integer(350));
        assertEquals(sl.getVisibleElements().get(4), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(30);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3,16,28    
        //VISIBLE:30,39,211,250,350
        //BOTTOM STACK:380
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(30));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 1);

        sl.addAndUpdateVisibleElements(17);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3,16    
        //VISIBLE:17,28,30,39,211
        //BOTTOM STACK:380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(17));
        assertEquals(sl.getVisibleElements().get(1), new Integer(28));
        assertEquals(sl.getVisibleElements().get(2), new Integer(30));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(4), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().size(), 3);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addBefore_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addBefore_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);


        //TOP STACK:3,16
        //VISIBLE:28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(1);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:empty         
        //VISIBLE:1,3,16,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(1);

        //TOP STACK:empty         
        //VISIBLE:1,3,16,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(1));
        assertEquals(sl.getVisibleElements().get(1), new Integer(3));
        assertEquals(sl.getVisibleElements().get(2), new Integer(16));
        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(0);

        //TOP STACK:empty         
        //VISIBLE:0,1,3,16,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(0));
        assertEquals(sl.getVisibleElements().get(1), new Integer(1));
        assertEquals(sl.getVisibleElements().get(2), new Integer(3));
        assertEquals(sl.getVisibleElements().get(3), new Integer(16));
        assertEquals(sl.getVisibleElements().get(4), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addBefore_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addBefore_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:8
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);

        //TOP STACK:3,16,28,39,211,250,350   
        //VISIBLE:380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();
        sl.scrollUp();
        sl.scrollUp();
        sl.scrollUp();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,28 
        //VISIBLE:39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(211));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(250));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(350));
//        assertEquals(sl.getVisibleElements().get(4), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(30);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3,16,28 
        //VISIBLE:30,39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(30));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
//        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(20);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3,16 
        //VISIBLE:20,28,30,39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(20));
        assertEquals(sl.getVisibleElements().get(1), new Integer(28));
        assertEquals(sl.getVisibleElements().get(2), new Integer(30));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(17);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3,16 
        //VISIBLE:17,20,28,30,39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(17));
        assertEquals(sl.getVisibleElements().get(1), new Integer(20));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(30));
        assertEquals(sl.getVisibleElements().get(4), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(15);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        //TOP STACK:3 
        //VISIBLE:15,16,17,20,28
        //BOTTOM STACK:39,30
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(0), new Integer(15));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(17));
        assertEquals(sl.getVisibleElements().get(3), new Integer(20));
        assertEquals(sl.getVisibleElements().get(4), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(30));
        assertEquals(sl.getInvisibleBottomStack().size(), 2);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        System.err.println(sl.getInvisibleBottomStack());

    }

//<<<<<<<<<<<<<<<<<<<<<<<<<<ADD AFTER SECTION
    @Test
    public void addAfter_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition test");
        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(360);

        //TOP STACK:3,16,28,39,211,250,350         
        //VISIBLE:360,380,390,400       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 7);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(350));

        assertEquals(sl.getVisibleElements().get(0), new Integer(360));
        assertEquals(sl.getVisibleElements().get(1), new Integer(380));
        assertEquals(sl.getVisibleElements().get(2), new Integer(390));
        assertEquals(sl.getVisibleElements().get(3), new Integer(400));

        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(401);

        //TOP STACK:3,16,28,39,211,250,350,360,380,390,400         
        //VISIBLE:401       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getInvisibleTopStack().size(), 11);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(350));
        assertEquals(sl.getInvisibleTopStack().get(7), new Integer(360));
        assertEquals(sl.getInvisibleTopStack().get(8), new Integer(380));
        assertEquals(sl.getInvisibleTopStack().get(9), new Integer(390));
        assertEquals(sl.getInvisibleTopStack().get(10), new Integer(400));

        assertEquals(sl.getVisibleElements().get(0), new Integer(401));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

    }

    @Test
    public void addAfter_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPosition test");

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(4), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        sl.addAndUpdateVisibleElements(360);

        //TOP STACK:3,16,28,39,211,250,350         
        //VISIBLE:360,380,390,400       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 7);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(350));

        assertEquals(sl.getVisibleElements().get(0), new Integer(360));
        assertEquals(sl.getVisibleElements().get(1), new Integer(380));
        assertEquals(sl.getVisibleElements().get(2), new Integer(390));
        assertEquals(sl.getVisibleElements().get(3), new Integer(400));

        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(4), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(360));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(5), new Integer(250));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,360,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        sl.addAndUpdateVisibleElements(401);

        //TOP STACK:3,16,28,39,211,250,350,360,380,390,400         
        //VISIBLE:401       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getInvisibleTopStack().size(), 11);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(350));
        assertEquals(sl.getInvisibleTopStack().get(7), new Integer(360));
        assertEquals(sl.getInvisibleTopStack().get(8), new Integer(380));
        assertEquals(sl.getInvisibleTopStack().get(9), new Integer(390));
        assertEquals(sl.getInvisibleTopStack().get(10), new Integer(400));

        assertEquals(sl.getVisibleElements().get(0), new Integer(401));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addAfter_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:5
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);

        assertEquals(sl.getInvisibleTopStack().size(), 4);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(0), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:5  
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(250);

        //TOP STACK:3,16,28,39,211       
        //VISIBLE:250
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 5);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));

        assertEquals(sl.getVisibleElements().get(0), new Integer(250));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addAfter_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:8
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);

        //TOP STACK:3,16,28,39,211,250,350   
        //VISIBLE:380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getVisibleElements().get(1), new Integer(211));
        assertEquals(sl.getVisibleElements().get(2), new Integer(250));
        assertEquals(sl.getVisibleElements().get(3), new Integer(350));
        assertEquals(sl.getVisibleElements().get(4), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(401);

        //TOP STACK:3,16,28,39,211,250,350,380        
        //VISIBLE:401       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getInvisibleTopStack().size(), 8);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(350));
        assertEquals(sl.getInvisibleTopStack().get(7), new Integer(380));
        assertEquals(sl.getVisibleElements().get(0), new Integer(401));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

    }

    @Test
    public void addAfter_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        //TOP STACK:3,16         
        //VISIBLE:28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,28,39       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        //TOP STACK:3,16,28         
        //VISIBLE:39       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(39);

        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,28,39       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        //TOP STACK:3,16,28         
        //VISIBLE:39       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(211);

        //TOP STACK:3,16,28,39         
        //VISIBLE:211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        assertEquals(sl.getInvisibleTopStack().size(), 4);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(0), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addAfter_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addAfter_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);

        //TOP STACK:3    
        //VISIBLE:16
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5  
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3 
        //VISIBLE:16
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(0), new Integer(16));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(20);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty 
        //VISIBLE:3,16,20
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(20));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
//        
        //TOP STACK:3,16 
        //VISIBLE:20
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(20));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();
        sl.scrollUp();

        //TOP STACK:3,16 
        //VISIBLE:20
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(28);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty
        //VISIBLE:3,16,20,28
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(20));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        
        //TOP STACK:3,16,20
        //VISIBLE:28
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(20));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(39);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,20,28         
        //VISIBLE:39       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        assertEquals(sl.getInvisibleTopStack().size(), 4);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(20));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addInBetween_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListFull_TopAndDownStacksFull_MustInsertedInRigthPosition test");
        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:3,16         
        //VISIBLE:28,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:10
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(260);

        //TOP STACK:3,16,28,39,211,250       
        //VISIBLE:260,350 ,380,390,400       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 6);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));

        assertEquals(sl.getVisibleElements().get(0), new Integer(260));
        assertEquals(sl.getVisibleElements().get(1), new Integer(350));
        assertEquals(sl.getVisibleElements().get(2), new Integer(380));
        assertEquals(sl.getVisibleElements().get(3), new Integer(390));
        assertEquals(sl.getVisibleElements().get(4), new Integer(400));

        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,28,39,211,250       
        //VISIBLE:260,350,380,390,400       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        sl.addAndUpdateVisibleElements(370);

        //TOP STACK:3,16,28,39,211,250,260,350   
        //VISIBLE:370,380,390,400       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        assertEquals(sl.getInvisibleTopStack().size(), 8);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));
        assertEquals(sl.getInvisibleTopStack().get(6), new Integer(260));
        assertEquals(sl.getInvisibleTopStack().get(7), new Integer(350));
        assertEquals(sl.getVisibleElements().get(0), new Integer(370));
        assertEquals(sl.getVisibleElements().get(1), new Integer(380));
        assertEquals(sl.getVisibleElements().get(2), new Integer(390));
        assertEquals(sl.getVisibleElements().get(3), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

    }

    @Test
    public void addInBetween_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListFull_TopStackEmptyAndDownStacksFull_MustInsertedInRigthPosition test");

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);
        sl.addAndUpdateVisibleElements(390);
        sl.addAndUpdateVisibleElements(400);

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 0);
        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(4), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().get(3), new Integer(350));
        assertEquals(sl.getInvisibleBottomStack().get(4), new Integer(250));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:400,390,380,350,250
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        sl.addAndUpdateVisibleElements(35);

        //TOP STACK:3,16,28         
        //VISIBLE:35,39,211,250,350       
        //BOTTOM STACK:400,390,380
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));

        assertEquals(sl.getVisibleElements().get(0), new Integer(35));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getVisibleElements().get(3), new Integer(250));
        assertEquals(sl.getVisibleElements().get(4), new Integer(350));

        assertEquals(sl.getInvisibleBottomStack().size(), 3);
        assertEquals(sl.getInvisibleBottomStack().get(0), new Integer(400));
        assertEquals(sl.getInvisibleBottomStack().get(1), new Integer(390));
        assertEquals(sl.getInvisibleBottomStack().get(2), new Integer(380));

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addInBetween_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:5
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);

        assertEquals(sl.getInvisibleTopStack().size(), 4);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getVisibleElements().get(0), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        //TOP STACK:empty         
        //VISIBLE:3,16,28,39,211       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:5  
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(35);

        //TOP STACK:3,16,28       
        //VISIBLE:35,39,211
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));

        assertEquals(sl.getVisibleElements().get(0), new Integer(35));
        assertEquals(sl.getVisibleElements().get(1), new Integer(39));
        assertEquals(sl.getVisibleElements().get(2), new Integer(211));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addInBetween_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        //MODEL.SIZE:8
        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);
        sl.addAndUpdateVisibleElements(39);
        sl.addAndUpdateVisibleElements(211);
        sl.addAndUpdateVisibleElements(250);
        sl.addAndUpdateVisibleElements(350);
        sl.addAndUpdateVisibleElements(380);

        //TOP STACK:3,16,28,39,211,250,350   
        //VISIBLE:380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();
        sl.scrollDown();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16,28    
        //VISIBLE:39,211,250,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getVisibleElements().get(0), new Integer(39));
        assertEquals(sl.getVisibleElements().get(1), new Integer(211));
        assertEquals(sl.getVisibleElements().get(2), new Integer(250));
        assertEquals(sl.getVisibleElements().get(3), new Integer(350));
        assertEquals(sl.getVisibleElements().get(4), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(260);

        //TOP STACK:3,16,28,39,211,250    
        //VISIBLE:260,350,380
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        assertEquals(sl.getInvisibleTopStack().size(), 6);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(28));
        assertEquals(sl.getInvisibleTopStack().get(3), new Integer(39));
        assertEquals(sl.getInvisibleTopStack().get(4), new Integer(211));
        assertEquals(sl.getInvisibleTopStack().get(5), new Integer(250));

        assertEquals(sl.getVisibleElements().get(0), new Integer(260));
        assertEquals(sl.getVisibleElements().get(1), new Integer(350));
        assertEquals(sl.getVisibleElements().get(2), new Integer(380));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

    }

    @Test
    public void addInBetween_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListNOTFull_TopStackEmptyAndDownStackEmpty_MustInsertedInRigthPosition test");

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);
        sl.addAndUpdateVisibleElements(28);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        //TOP STACK:3,16         
        //VISIBLE:28   
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(20);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty         
        //VISIBLE:3,16,20,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(20));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        //TOP STACK:3,16         
        //VISIBLE:20,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(20));
        assertEquals(sl.getVisibleElements().get(1), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3,16         
        //VISIBLE:20,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        sl.addAndUpdateVisibleElements(25);

        //TOP STACK:3,16,20         
        //VISIBLE:25,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(20));
        assertEquals(sl.getVisibleElements().get(0), new Integer(25));
        assertEquals(sl.getVisibleElements().get(1), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

    @Test
    public void addInBetween_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition() {
        System.err.println("addInBetween_WithVisibleListNOTFull_TopStackFullAndDownStacksEmpty_MustInsertedInRigthPosition test");
        //TOP STACK:3,16,28    
        //VISIBLE:39
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        ScrollableList<Integer> sl = new ScrollableList<>();
        sl.setVisibleElementsMaxNum(5);
        sl.addAndUpdateVisibleElements(3);
        sl.addAndUpdateVisibleElements(16);

        //TOP STACK:3    
        //VISIBLE:16
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5  
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        //TOP STACK:3 
        //VISIBLE:16
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getVisibleElements().get(0), new Integer(16));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        sl.addAndUpdateVisibleElements(20);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
//se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
//        //TOP STACK:empty 
//        //VISIBLE:3,16,20
//        //BOTTOM STACK:empty
//        //VISIBLE_ELEMENTS_MAX_NUM:5 
//
//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(20));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        //TOP STACK:3,16 
        //VISIBLE:20
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().size(), 2);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getVisibleElements().get(0), new Integer(20));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();
        sl.scrollUp();

        //TOP STACK:3,16 
        //VISIBLE:20
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(28);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());
        
        //se quiser testar com topmost apenas caso quantidade de elementos no model for maior que max visible elements
        //TOP STACK:empty
        //VISIBLE:3,16,20,28
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

//        assertEquals(sl.getInvisibleTopStack().size(), 0);
//        assertEquals(sl.getVisibleElements().get(0), new Integer(3));
//        assertEquals(sl.getVisibleElements().get(1), new Integer(16));
//        assertEquals(sl.getVisibleElements().get(2), new Integer(20));
//        assertEquals(sl.getVisibleElements().get(3), new Integer(28));
//        assertEquals(sl.getInvisibleBottomStack().size(), 0);
        
        //TOP STACK:3,16,20
        //VISIBLE:28
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 

        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(20));
        assertEquals(sl.getVisibleElements().get(0), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.scrollUp();
        sl.scrollUp();
        
        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

        sl.addAndUpdateVisibleElements(25);

        //TOP STACK:3,16,20         
        //VISIBLE:25,28       
        //BOTTOM STACK:empty
        //VISIBLE_ELEMENTS_MAX_NUM:5 
        assertEquals(sl.getInvisibleTopStack().size(), 3);
        assertEquals(sl.getInvisibleTopStack().get(0), new Integer(3));
        assertEquals(sl.getInvisibleTopStack().get(1), new Integer(16));
        assertEquals(sl.getInvisibleTopStack().get(2), new Integer(20));
        assertEquals(sl.getVisibleElements().get(0), new Integer(25));
        assertEquals(sl.getVisibleElements().get(1), new Integer(28));
        assertEquals(sl.getInvisibleBottomStack().size(), 0);

        System.err.print(sl.getInvisibleTopStack());
        System.err.print(sl.getVisibleElements());
        System.err.println(sl.getInvisibleBottomStack());

    }

}
