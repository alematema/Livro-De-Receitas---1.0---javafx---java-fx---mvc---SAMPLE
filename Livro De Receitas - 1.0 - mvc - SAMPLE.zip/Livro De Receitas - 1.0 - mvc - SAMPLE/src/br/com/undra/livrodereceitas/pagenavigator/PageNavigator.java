package br.com.undra.livrodereceitas.pagenavigator;

import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.paginas.ConfirmarSalvar;
import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.NenhumaReceitaSelecionada;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.paginas.Page;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * A page navigator.
 *
 * @author alexandre
 */
public class PageNavigator {
    
    private volatile static Page lastPage;

    public synchronized static void goToPage(AppContainer container, Page newPage) {
       
        
        if (container.getCurrentPage().equals(newPage)) {
            return;
        }

        container.setIsChangingPage(true);

        container.getCurrentPage().closeMenu();
        
        lastPage = container.getCurrentPage();
        
        container.getCurrentPage().getChildren().remove(Menu.getInstance(container));
        
        container.setCurrentPage(newPage);

        Platform.runLater(() -> {
            
            container.getPageWrapper().setContent(newPage);
            container.setCurrentPage(newPage);

            newPage.setUp(container.getListaDeReceitas());

            doFocusRequestings(newPage);

            Stage stage = container.getStage();
            stage.setWidth(stage.getWidth() + 1);
            stage.setWidth(stage.getWidth() - 1);
            stage.setHeight(stage.getHeight() + 1);
            stage.setHeight(stage.getHeight() - 1);

            container.setIsChangingPage(false);

        });

    }

    public static synchronized void goToPageSmoothly(AppContainer container, Page newPage) {

        if (container.getCurrentPage().equals(newPage)) {
            return;
        }

        container.setIsChangingPage(true);
        
        container.getCurrentPage().closeMenu();
        
        lastPage = container.getCurrentPage();
        
        container.getCurrentPage().getChildren().remove(Menu.getInstance(container));

        Platform.runLater(() -> {

            FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.5), container.getCurrentPage());
            fadeTransition.setFromValue(1);
            fadeTransition.setToValue(0);
            fadeTransition.setOnFinished((event) -> {

                container.getCurrentPage().setVisible(false);
                container.setCurrentPage(newPage);
                container.getPageWrapper().setContent(newPage);
                newPage.setOpacity(0);

                newPage.setUp(container.getListaDeReceitas());

                Stage stage = container.getStage();
                stage.setWidth(stage.getWidth() + 1);
                stage.setWidth(stage.getWidth() - 1);
                stage.setHeight(stage.getHeight() + 1);
                stage.setHeight(stage.getHeight() - 1);

                FadeTransition ft = new FadeTransition(Duration.seconds(0.5), newPage);
                ft.setFromValue(0);
                ft.setToValue(1);
                ft.setOnFinished((e) -> {

                    newPage.setOpacity(1);
                    newPage.setVisible(true);
                    doFocusRequestings(newPage);

                });
                ft.play();
                container.setIsChangingPage(false);

            });

            fadeTransition.play();

        });

    }

    private static void doFocusRequestings(Page newPage) {
        
        try {
            ((DetalhesReceita) newPage).getAppContainer();
        } catch (Exception ex) {
        }
        try {
            ((NovaReceita) newPage).getNomeReceita().requestFocus();
        } catch (Exception ex) {
        }
        try {
            ((ConfirmarSalvar) newPage).requestFocus();
        } catch (Exception ex) {
        }
        try {
            ((NenhumaReceitaSelecionada) newPage).requestFocus();
        } catch (Exception ex) {
        }
    }

    public static Page getLastPage() {
        return lastPage;
    }
    
}
