package br.com.undra.livrodereceitas;

import java.io.OutputStream;

/**
 *
 * @author alexandre
 */
public interface Output {
    void write(Object o) throws Exception;
    void write(String s) throws Exception;
    void write(OutputStream os) throws Exception;
    void write(Object... o) throws Exception;
    void write(String... s) throws Exception;
    void write(OutputStream... os) throws Exception;
}
