package br.com.undra.livrodereceitas.tmp;

import javafx.scene.layout.Pane;

/**
 * Uma view do modelo receita culinaria.
 * @author alexandre
 */
public class ReceitaContainer extends Pane {
    
    
    
    
    
}
