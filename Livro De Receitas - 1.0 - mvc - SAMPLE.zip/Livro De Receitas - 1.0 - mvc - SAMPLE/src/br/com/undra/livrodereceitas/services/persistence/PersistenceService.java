package br.com.undra.livrodereceitas.services.persistence;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.LookAndFeel;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoReceita;
import java.util.Collection;

/**
 * A persistence service.
 * @author alexandre
 * @param <T>
 */
public interface PersistenceService<T extends Receita> {
    
    void createTipoReceita(TipoReceita tipoReceita) throws Exception;
    void createTiposReceita(Collection<TipoReceita> tiposReceita) throws Exception;
    void updateTipoReceita(TipoReceita oldValue, TipoReceita newValue) throws Exception;
    void deleteTipoReceita(TipoReceita tipoReceita) throws Exception;
    void deleteTiposReceitaByIds(String[] ids, Class aClass) throws Exception;
    TipoReceita getTipoReceitaById(Class clazz, String nome) throws Exception;
    Collection<TipoReceita> getAllTiposReceitas(Class clazz) throws Exception;
    Collection<String> getNomesReceitasAssociadas(String nome,Class clazz) throws Exception;
    
    Collection<T> getAll() throws Exception;
    void create(T object) throws Exception;
    void createObjects(Collection<T> objects) throws Exception;
    void update(T old, T newValue) throws Exception;
    void delete(T o) throws Exception;
    void deleteById(String name) throws Exception; 
    public void deleteBulk(Collection<T> bulk) throws Exception;
    public void deleteBulk(String... ids) throws Exception;
    T getById(String nome) throws Exception;
    Collection<T> getObjectsById(String... ids) throws Exception;

    boolean getShowWelcomePageAtInitialization() throws Exception;
    boolean getShowPronoumChooserAtInitialization() throws Exception;
    void updateShowWelcomePageAtInitialization(boolean newValue) throws Exception;
    void updateShowPronoumChooserAtInitialization(boolean newValue) throws Exception;
    
    String getWelcomePronoum() throws Exception;
    void updateWelcomePronoum(String newValue) throws Exception;

    void saveOrUpdateLookAndFeel(LookAndFeel lookAndFeel)throws Exception;;
    LookAndFeel getLookAndFeel(String id)throws Exception;;
    
}
