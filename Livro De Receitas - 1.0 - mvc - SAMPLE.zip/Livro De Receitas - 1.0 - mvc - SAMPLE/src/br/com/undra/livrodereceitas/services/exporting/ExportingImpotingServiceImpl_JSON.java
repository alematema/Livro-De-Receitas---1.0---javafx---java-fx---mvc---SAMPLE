package br.com.undra.livrodereceitas.services.exporting;

import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.util.JsonUtil;
import java.io.File;
import java.io.PrintWriter;
import java.util.Collection;

/**
 * An exporting/importing service implementation that uses <b>JSON</b>. 
 *
 * @author alexandre
 */
public class ExportingImpotingServiceImpl_JSON implements ExportingImportingService<Receita> {

    /**
     * Exports the collection of <code>objects</code> to <code>a json file</code>.
     * @param objects
     * @param file
     * @throws Exception 
     */
    @Override
    public void export(Collection<Receita> objects, File file) throws Exception {
        
        String receitasJson = JsonUtil.toJson(objects);

        file.createNewFile();
        
        try (PrintWriter printWriter = new PrintWriter(file)) {
            printWriter.print(receitasJson);
        }

    }

    /**
     * Imports from <code>json source</code> and parses to a <code>Collection of Receita objects</code>.
     * @param source
     * @return
     * @throws Exception 
     */
    @Override
    public Collection<Receita> imporT(File source) throws Exception {
        return JsonUtil.toReceitas(JsonUtil.getJson(source));
    }

}
