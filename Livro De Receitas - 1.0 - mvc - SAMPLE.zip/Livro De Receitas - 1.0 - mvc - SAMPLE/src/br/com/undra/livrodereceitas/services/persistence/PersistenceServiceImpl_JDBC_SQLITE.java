package br.com.undra.livrodereceitas.services.persistence;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.LookAndFeel;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.paginas.WelcomePage;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoCaloria;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoReceita;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;

/**
 * Implementation that uses JDBC AND SQLITE.
 *
 * @author alexandre
 */
public class PersistenceServiceImpl_JDBC_SQLITE implements PersistenceService<Receita> {

    private static PersistenceServiceImpl_JDBC_SQLITE instance;

    public static PersistenceServiceImpl_JDBC_SQLITE getInstace() {
        if (instance == null) {
            instance = new PersistenceServiceImpl_JDBC_SQLITE();
        }
        return instance;
    }

    private PersistenceServiceImpl_JDBC_SQLITE() {
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.home") + "/db/" +"LivroDeReceitas.db");
    }

    @Override
    public synchronized void createTipoReceita(TipoReceita tipoReceita) throws Exception {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("insert into " + tipoReceita.getClass().getSimpleName() + " (nome) values (?)")) {

            preparedStatement.setString(1, tipoReceita.getNome());
            preparedStatement.execute();

        } catch (Exception e) {
            throw e;
        }

    }

    @Override
    public void createTiposReceita(Collection<TipoReceita> tiposReceita) throws Exception {

        String tipoCaloriaQuery = "insert into TipoCaloria  (nome) values (?)";
        String tipoComidaQuery = "insert into  TipoComida (nome) values (?)";
        String tipoBebidaQuery = "insert into  TipoBebida (nome) values (?)";

        try (Connection tipoCaloriasConnection = getConnection(); Connection tipoComidasConnection = getConnection(); Connection tipoBebidasConnection = getConnection(); PreparedStatement tiposCaloriasPpstm = tipoCaloriasConnection.prepareStatement(tipoCaloriaQuery); PreparedStatement tiposComidasPpstm = tipoComidasConnection.prepareStatement(tipoComidaQuery); PreparedStatement tiposBebidasPpstm = tipoBebidasConnection.prepareStatement(tipoBebidaQuery)) {

            tipoCaloriasConnection.setAutoCommit(false);
            tipoComidasConnection.setAutoCommit(false);
            tipoBebidasConnection.setAutoCommit(false);

            for (TipoReceita tr : tiposReceita) {
                if (tr instanceof TipoCaloria) {
                    tiposCaloriasPpstm.setString(1, tr.getNome());
                    tiposCaloriasPpstm.addBatch();
                } else if (tr instanceof TipoComida) {
                    tiposComidasPpstm.setString(1, tr.getNome());
                    tiposComidasPpstm.addBatch();
                } else if (tr instanceof TipoBebida) {
                    tiposBebidasPpstm.setString(1, tr.getNome());
                    tiposBebidasPpstm.addBatch();
                }
            }

            tiposCaloriasPpstm.executeBatch();
            tipoCaloriasConnection.commit();
            tiposComidasPpstm.executeBatch();
            tipoComidasConnection.commit();
            tiposBebidasPpstm.executeBatch();
            tipoBebidasConnection.commit();

        } catch (Exception e) {
            throw e;
        }

    }

    @Override
    public synchronized void updateTipoReceita(TipoReceita oldValue, TipoReceita newValue) throws Exception {

        String tipo = oldValue.getClass().getSimpleName();

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("update " + tipo + " set nome=? where nome=?")) {
            preparedStatement.setString(1, newValue.getNome());
            preparedStatement.setString(2, oldValue.getNome());
            preparedStatement.execute();
        } catch (Exception e) {
            throw e;
        }

    }

    @Override
    public synchronized void deleteTipoReceita(TipoReceita tipoReceita) throws Exception {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("delete from " + tipoReceita.getClass().getSimpleName() + " where nome=?")) {
            preparedStatement.setString(1, tipoReceita.getNome());
            preparedStatement.execute();
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public void deleteTiposReceitaByIds(String[] ids, Class aClass) throws Exception {
        for (String id : ids) {
            deleteTipoReceita(getTipoReceitaById(aClass, id));
        }
    }

    @Override
    public synchronized TipoReceita getTipoReceitaById(Class clazz, String nome) throws Exception {

        TipoReceita tipoReceita = null;

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from " + clazz.getSimpleName() + " where nome=?")) {

            preparedStatement.setString(1, nome);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                tipoReceita = createAndFillTipoReceita(clazz, rs);
            }

        } catch (Exception e) {
            throw e;
        }

        return tipoReceita;

    }

    @Override
    public synchronized Collection<TipoReceita> getAllTiposReceitas(Class clazz) throws Exception {

        Collection<TipoReceita> tipos = new ArrayList<>();

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from " + clazz.getSimpleName())) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                tipos.add(createAndFillTipoReceita(clazz, rs));
            }

        } catch (Exception e) {
            throw e;
        }

        return tipos;
    }

    private TipoReceita createAndFillTipoReceita(Class clazz, ResultSet rs) throws SQLException, InstantiationException, IllegalAccessException {

        TipoReceita tr = (TipoReceita) clazz.newInstance();
        //fills tr
        tr.setNome(rs.getString("nome"));

        return tr;

    }

    @Override
    public Collection<String> getNomesReceitasAssociadas(String nome, Class clazz) throws Exception {

        Collection<String> nomes = new ArrayList<>();

        if (!(clazz.newInstance() instanceof TipoCaloria)) {

            String query = "select nome_receita from Receita_" + clazz.getSimpleName() + " where nome_tipoComida=?";

            if (clazz.newInstance() instanceof TipoBebida) {
                query = "select nome_receita from Receita_" + clazz.getSimpleName() + " where nome_tipoBebida=?";
            }

            try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setString(1, nome);

                ResultSet rs = preparedStatement.executeQuery();

                while (rs.next()) {
                    nomes.add(rs.getString("nome_receita"));
                }

            } catch (Exception e) {
                throw e;
            }

        } else {

            String query = "select nome from Receita where tipoCaloria=?";

            try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setString(1, nome);

                ResultSet rs = preparedStatement.executeQuery();

                while (rs.next()) {
                    nomes.add(rs.getString("nome"));
                }

            } catch (Exception e) {
                throw e;
            }

        }

        return nomes;
    }

    @Override
    public synchronized Collection<Receita> getAll() throws Exception {

        Collection<Receita> receitas = new ArrayList<>();

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select nome from Receita")) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                receitas.add(new Receita(rs.getString("nome")));
            }

        } catch (Exception e) {
            throw e;
        }

        return receitas;

    }

    Connection receitaConn;
    Connection comidaConn;
    Connection bebidaConn;

    @Override
    public synchronized void create(Receita receita) throws Exception {

        String sqlQuery = "insert into " + Receita.class.getSimpleName() + " (nome,ingredientes,modoPreparo,tipoCaloria,tipoReceita) values (?,?,?,?,?)";
        String tipoComidasSqlQuery = "insert into  Receita_TipoComida (nome_receita,nome_tipoComida) values (?,?)";
        String tipoBebidasSqlQuery = "insert into  Receita_TipoBebida (nome_receita,nome_tipoBebida) values (?,?)";

        try (Connection connection = getConnection(); Connection comidasConnection = getConnection(); Connection bebidasConnection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery); PreparedStatement tiposComidasPpstm = comidasConnection.prepareStatement(tipoComidasSqlQuery); PreparedStatement tiposBebidasPpstm = bebidasConnection.prepareStatement(tipoBebidasSqlQuery)) {

            receitaConn = connection;
            comidaConn = comidasConnection;
            bebidaConn = bebidasConnection;
//            connection.setAutoCommit(false);
            comidasConnection.setAutoCommit(false);
            bebidasConnection.setAutoCommit(false);
            preparedStatement.setString(1, receita.getNome());
            preparedStatement.setString(2, receita.getIngredientes());
            preparedStatement.setString(3, receita.getModoPreparo());
            if (receita.getTipoCaloria() != null) {
                preparedStatement.setString(4, receita.getTipoCaloria().getNome());
            } else {
                preparedStatement.setString(4, null);
            }
            preparedStatement.setString(5, receita.getTipoReceita());

            preparedStatement.execute();

            if (receita.getTiposComida() != null && !receita.getTiposComida().isEmpty()) {

                for (TipoComida tc : receita.getTiposComida()) {
                    tiposComidasPpstm.setString(1, receita.getNome());
                    tiposComidasPpstm.setString(2, tc.getNome());
                    tiposComidasPpstm.addBatch();
                }

            }

            if (receita.getTiposBebida() != null && !receita.getTiposBebida().isEmpty()) {

                for (TipoBebida tb : receita.getTiposBebida()) {
                    tiposBebidasPpstm.setString(1, receita.getNome());
                    tiposBebidasPpstm.setString(2, tb.getNome());
                    tiposBebidasPpstm.addBatch();
                }

            }

//            preparedStatement.executeBatch();
//            connection.commit();
            tiposComidasPpstm.executeBatch();
            comidasConnection.commit();
            tiposBebidasPpstm.executeBatch();
            bebidasConnection.commit();

        } catch (Exception e) {
//            receitaConn.rollback();
//            comidaConn.rollback();
//            bebidaConn.rollback();
            throw e;
        }
    }

    Connection receitasConn = null;
    Connection comidasConn = null;
    Connection bebidasConn = null;

    @Override
    public synchronized void createObjects(Collection<Receita> receitas) throws Exception {

        String sqlQuery = "insert into " + Receita.class.getSimpleName() + " (nome,ingredientes,modoPreparo,tipoCaloria,tipoReceita) values (?,?,?,?,?)";
        String tipoComidasSqlQuery = "insert into  Receita_TipoComida (nome_receita,nome_tipoComida) values (?,?)";
        String tipoBebidasSqlQuery = "insert into  Receita_TipoBebida (nome_receita,nome_tipoBebida) values (?,?)";

        try (Connection connection = getConnection(); Connection comidasConnection = getConnection(); Connection bebidasConnection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery); PreparedStatement tiposComidasPpstm = comidasConnection.prepareStatement(tipoComidasSqlQuery); PreparedStatement tiposBebidasPpstm = bebidasConnection.prepareStatement(tipoBebidasSqlQuery)) {

            receitasConn = connection;
            comidasConn = comidasConnection;
            bebidasConn = bebidasConnection;

            connection.setAutoCommit(false);
            comidasConnection.setAutoCommit(false);
            bebidasConnection.setAutoCommit(false);

            for (Receita receita : receitas) {
                preparedStatement.setString(1, receita.getNome());
                preparedStatement.setString(2, receita.getIngredientes());
                preparedStatement.setString(3, receita.getModoPreparo());
                if (receita.getTipoCaloria() != null) {
                    preparedStatement.setString(4, receita.getTipoCaloria().getNome());
                } else {
                    preparedStatement.setString(4, null);
                }
                preparedStatement.setString(5, receita.getTipoReceita());

                preparedStatement.addBatch();

                if (receita.getTiposComida() != null && !receita.getTiposComida().isEmpty()) {

                    for (TipoComida tc : receita.getTiposComida()) {

                        tiposComidasPpstm.setString(1, receita.getNome());
                        tiposComidasPpstm.setString(2, tc.getNome());

                        tiposComidasPpstm.addBatch();
                    }

                }

                if (receita.getTiposBebida() != null && !receita.getTiposBebida().isEmpty()) {

                    for (TipoBebida tb : receita.getTiposBebida()) {

                        tiposBebidasPpstm.setString(1, receita.getNome());
                        tiposBebidasPpstm.setString(2, tb.getNome());

                        tiposBebidasPpstm.addBatch();
                    }

                }
            }

            preparedStatement.executeBatch();
            connection.commit();
            tiposComidasPpstm.executeBatch();
            comidasConnection.commit();
            tiposBebidasPpstm.executeBatch();
            bebidasConnection.commit();

        } catch (Exception e) {
//            receitasConn.rollback();
//            comidasConn.rollback();
//            bebidasConn.rollback();
            throw e;
        }

    }

    @Override
    public synchronized void update(Receita oldReceita, Receita newReceita) throws Exception {
        delete(oldReceita);
        create(newReceita);
    }

    Connection receitaDeleteConn;
    Connection comidaDeleteConn;
    Connection bebidaDeleteConn;

    @Override
    public synchronized void delete(Receita receita) throws Exception {

        String sqlQuery = "delete from " + Receita.class.getSimpleName() + " where nome=?";
        String tipoComidasSqlQuery = "delete from  Receita_TipoComida where nome_receita=? AND nome_tipoComida=?";
        String tipoBebidasSqlQuery = "delete from  Receita_TipoBebida where nome_receita=? AND nome_tipoBebida=?";

        try (Connection connection = getConnection(); Connection comidasConnection = getConnection(); Connection bebidasConnection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery); PreparedStatement tiposComidasPpstm = comidasConnection.prepareStatement(tipoComidasSqlQuery); PreparedStatement tiposBebidasPpstm = bebidasConnection.prepareStatement(tipoBebidasSqlQuery)) {

            receitaDeleteConn = connection;
            comidaDeleteConn = comidasConnection;
            bebidaDeleteConn = bebidasConnection;
            connection.setAutoCommit(false);
            comidasConnection.setAutoCommit(false);
            bebidasConnection.setAutoCommit(false);

            if (receita.getTiposComida() != null && !receita.getTiposComida().isEmpty()) {

                for (TipoComida tc : receita.getTiposComida()) {

                    tiposComidasPpstm.setString(1, receita.getNome());
                    tiposComidasPpstm.setString(2, tc.getNome());
                    tiposComidasPpstm.addBatch();
                }

            }

            if (receita.getTiposBebida() != null && !receita.getTiposBebida().isEmpty()) {

                for (TipoBebida tb : receita.getTiposBebida()) {
                    tiposBebidasPpstm.setString(1, receita.getNome());
                    tiposBebidasPpstm.setString(2, tb.getNome());
                    tiposBebidasPpstm.addBatch();
                }

            }

            preparedStatement.setString(1, receita.getNome());

            preparedStatement.addBatch();

            tiposComidasPpstm.executeBatch();
            comidasConnection.commit();
            tiposBebidasPpstm.executeBatch();
            bebidasConnection.commit();
            preparedStatement.executeBatch();
            connection.commit();

        } catch (Exception e) {
//            receitaDeleteConn.rollback();
//            comidaDeleteConn.rollback();
//            bebidaDeleteConn.rollback();
            throw e;
        }
    }

    Connection receitasBulkDeleteConn;
    Connection comidasBulkDeleteConn;
    Connection bebidasBulkDeleteConn;

    @Override
    public synchronized void deleteBulk(Collection<Receita> bulk) throws Exception {
        String sqlQuery = "delete from " + Receita.class.getSimpleName() + " where nome=?";
        String tipoComidasSqlQuery = "delete from  Receita_TipoComida where nome_receita=? AND nome_tipoComida=?";
        String tipoBebidasSqlQuery = "delete from  Receita_TipoBebida where nome_receita=? AND nome_tipoBebida=?";

        try (Connection connection = getConnection(); Connection comidasConnection = getConnection(); Connection bebidasConnection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery); PreparedStatement tiposComidasPpstm = comidasConnection.prepareStatement(tipoComidasSqlQuery); PreparedStatement tiposBebidasPpstm = bebidasConnection.prepareStatement(tipoBebidasSqlQuery)) {

            receitasBulkDeleteConn = connection;
            comidasBulkDeleteConn = comidasConnection;
            bebidasBulkDeleteConn = bebidasConnection;
            connection.setAutoCommit(false);
            comidasConnection.setAutoCommit(false);
            bebidasConnection.setAutoCommit(false);

            for (Receita receita : bulk) {

                if (receita.getTiposComida() != null && !receita.getTiposComida().isEmpty()) {

                    for (TipoComida tc : receita.getTiposComida()) {

                        tiposComidasPpstm.setString(1, receita.getNome());
                        tiposComidasPpstm.setString(2, tc.getNome());
                        tiposComidasPpstm.addBatch();
                    }

                }

                if (receita.getTiposBebida() != null && !receita.getTiposBebida().isEmpty()) {

                    for (TipoBebida tb : receita.getTiposBebida()) {
                        tiposBebidasPpstm.setString(1, receita.getNome());
                        tiposBebidasPpstm.setString(2, tb.getNome());
                        tiposBebidasPpstm.addBatch();
                    }

                }

                preparedStatement.setString(1, receita.getNome());

                preparedStatement.addBatch();

            }

            tiposComidasPpstm.executeBatch();
            comidasConnection.commit();
            tiposBebidasPpstm.executeBatch();
            bebidasConnection.commit();
            preparedStatement.executeBatch();
            connection.commit();

        } catch (Exception e) {
//            receitasBulkDeleteConn.rollback();
//            comidasBulkDeleteConn.rollback();
//            bebidasBulkDeleteConn.rollback();
            throw e;
        }
    }

    @Override
    public synchronized void deleteBulk(String... ids) throws Exception {
        deleteBulk(getObjectsById(ids));
    }

    @Override
    public synchronized void deleteById(String name) throws Exception {
        delete(getById(name));
    }

    Connection receitasByIdConn;
    Connection comidasByIdConn;
    Connection bebidasByIdConn;

    @Override
    public synchronized Collection<Receita> getObjectsById(String... ids) throws Exception {

        Collection<Receita> receitasById = new ArrayList<>();

        StringBuilder inClause = new StringBuilder();
        boolean firstValue = true;
        for (int i = 0; i < ids.length; i++) {
            if (i < ids.length - 1) {
                inClause.append('?');
                inClause.append(',');
            } else {
                inClause.append('?');
            }

        }

        String sqlQuery = "select * from Receita where nome in (" + inClause.toString() + ")";

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

            int i = 1;
            for (String id : ids) {
                preparedStatement.setString(i++, id);
            }

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                receitasById.add(createAndFillReceita(rs));
            }

        } catch (Exception e) {
            throw e;
        }

        inClause = new StringBuilder();
        firstValue = true;
        for (int i = 0; i < receitasById.size(); i++) {
            if (i < ids.length - 1) {
                inClause.append('?');
                inClause.append(',');
            } else {
                inClause.append('?');
            }
        }

        String tipoComidasSqlQuery = "select * from  Receita_TipoComida where nome_receita in (" + inClause.toString() + ")";
        String tipoBebidasSqlQuery = "select * from  Receita_TipoBebida where nome_receita in (" + inClause.toString() + ")";

        try (Connection bebidasConnection = getConnection(); Connection comidasConnection = getConnection(); PreparedStatement tiposComidasPpstm = comidasConnection.prepareStatement(tipoComidasSqlQuery); PreparedStatement tiposBebidasPpstm = bebidasConnection.prepareStatement(tipoBebidasSqlQuery)) {

            int i = 1;
            for (Receita receita : receitasById) {

                tiposComidasPpstm.setString(i, receita.getNome());
                tiposBebidasPpstm.setString(i, receita.getNome());
                i++;
            }

            ResultSet comidasRs = tiposComidasPpstm.executeQuery();
            ResultSet bebidasRs = tiposBebidasPpstm.executeQuery();

            while (comidasRs.next()) {
                setTiposComida(receitasById, comidasRs);
            }

            while (bebidasRs.next()) {
                setTiposBebida(receitasById, bebidasRs);
            }

        } catch (Exception e) {
            throw e;
        }
        return receitasById;

    }

    @Override
    public synchronized Receita getById(String nome) throws Exception {

        Receita receita;

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from Receita where nome=?")) {

            preparedStatement.setString(1, nome);
            ResultSet rs = preparedStatement.executeQuery();

            receita = createAndFillReceita(rs);

        } catch (Exception e) {
            throw e;
        }

        //POPULA TIPO RECEITA : COMIDA OU BEBIDA
        if (receita.getTipoReceita().equals(Receita.TIPO_COMIDA)) {
            setTiposComida(receita);
        } else if (receita.getTipoReceita().equals(Receita.TIPO_BEBIDA)) {
            setTiposBebida(receita);
        }

        return receita;
    }

    private Receita createAndFillReceita(ResultSet rs) throws SQLException {

        Receita receita = new Receita(rs.getString("nome"));
        receita.setIngredientes(rs.getString("ingredientes"));
        receita.setModoPreparo(rs.getString("modoPreparo"));
        if (rs.getString("tipoCaloria") != null) {
            receita.setTipoCaloria(new TipoCaloria(rs.getString("tipoCaloria")));
        }
        receita.setTipoReceita(rs.getString("tipoReceita"));

        return receita;
    }

    private void setTiposComida(Receita receita) throws SQLException {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from Receita_TipoComida where nome_receita=?")) {

            preparedStatement.setString(1, receita.getNome());
            ResultSet rs = preparedStatement.executeQuery();

            List<TipoComida> tiposComida = new ArrayList<>();

            while (rs.next()) {
                tiposComida.add(new TipoComida(rs.getString("nome_tipoComida")));
            }

            receita.setTiposComida(tiposComida);

        } catch (Exception e) {
            throw e;
        }

    }

    private void setTiposComida(Collection<Receita> receitas, ResultSet rsComida) throws SQLException {
        String receitaNome = rsComida.getString("nome_receita");
        String nome_tipoComida = rsComida.getString("nome_tipoComida");

        for (Receita receita : receitas) {
            if (receita.getNome().equals(receitaNome)) {
                if (receita.getTiposComida() == null) {
                    receita.setTiposComida(new ArrayList<>());
                }
                receita.getTiposComida().add(new TipoComida(nome_tipoComida));
                break;
            }
        }

    }

    private void setTiposBebida(Collection<Receita> receitas, ResultSet rsBebida) throws SQLException {

        String receitaNome = rsBebida.getString("nome_receita");
        String nome_tipoBebida = rsBebida.getString("nome_tipoBebida");

        for (Receita receita : receitas) {
            if (receita.getNome().equals(receitaNome)) {
                if (receita.getTiposBebida() == null) {
                    receita.setTiposBebida(new ArrayList<>());
                }
                receita.getTiposBebida().add(new TipoBebida(nome_tipoBebida));
                break;
            }
        }
    }

    private void setTiposBebida(Receita receita) throws SQLException {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from Receita_TipoBebida where nome_receita=?")) {

            preparedStatement.setString(1, receita.getNome());
            ResultSet rs = preparedStatement.executeQuery();

            List<TipoBebida> tiposBebida = new ArrayList<>();

            while (rs.next()) {
                tiposBebida.add(new TipoBebida(rs.getString("nome_tipoBebida")));
            }

            receita.setTiposBebida(tiposBebida);

        } catch (Exception e) {
            throw e;
        }

    }

    public List<Receita> getMass(int n) {

        List<Receita> receitas = new ArrayList<>();

        int idsCount = n;
        int[] ids = new int[idsCount];

        TipoCaloria[] tiposCaloria = {TipoCaloria.CALORICA, TipoCaloria.HIPER_CALÓRICA, TipoCaloria.MUITO_CALÓRICA, TipoCaloria.POUCO_CALORIA, TipoCaloria.ZERO_CALORIA};
        List<List<TipoComida>> tiposComida = new ArrayList<>();
        tiposComida.add(Arrays.asList(TipoComida.BOLO, TipoComida.SOBREMESA));
        tiposComida.add(Arrays.asList(TipoComida.GRÃOS, TipoComida.VEGETARIANA));
        tiposComida.add(Arrays.asList(TipoComida.CARNE));
        tiposComida.add(Arrays.asList(TipoComida.PEIXE));
        tiposComida.add(Arrays.asList(TipoComida.SALADA, TipoComida.VEGETARIANA));

        List<List<TipoBebida>> tiposBebida = new ArrayList<>();
        tiposBebida.add(Arrays.asList(TipoBebida.ALCOOLICA));
        tiposBebida.add(Arrays.asList(TipoBebida.SUCO_NATURAL));
        tiposBebida.add(Arrays.asList(TipoBebida.ALCOOLICA, TipoBebida.APERITIVO));

        String[] tiposReceita = {Receita.TIPO_BEBIDA, Receita.TIPO_COMIDA};

        Random random = new Random();

        for (int i = 0; i < idsCount; i++) {
            ids[i] = i;
            Receita r = new Receita("RECEITA " + i);
            String tipoReceita = tiposReceita[random.nextInt(tiposReceita.length)];
            r.setTipoReceita(tipoReceita);

            if (tipoReceita.equals(Receita.TIPO_BEBIDA)) {

                r.setTiposBebida(tiposBebida.get(random.nextInt(tiposBebida.size())));

            } else {

                r.setTiposComida(tiposComida.get(random.nextInt(tiposComida.size())));
                r.setTipoCaloria(tiposCaloria[random.nextInt(tiposCaloria.length)]);
            }

            receitas.add(r);

        }

        return receitas;

    }

    public Collection<List<Receita>> batch(List<Receita> receitas, int batchSize) {
//        return Util.batch(receitas, batchSize);
        Collection<List<Receita>> batchedReceitas = new ArrayList<>();

        int iterations = receitas.size() / batchSize;
        int modulus = receitas.size() % batchSize;
        int it = 0;
        for (it = 0; it < iterations; it++) {

            List<Receita> batch = new ArrayList<>();

            //33 receitas.size
            //10 batchSize
            //iterations 3
            //modulus 3
            // batch it 0 : 0...9 
            // batch it 1 : 10...19 
            // batch it 2 : 20...29
            // batch mod  : (it+1) ... (it+1)+modulus
            for (int i = 0; i < batchSize; i++) {
                batch.add(receitas.get(it * batchSize + i));
            }

            batchedReceitas.add(batch);

        }

        if (modulus != 0) {

            List<Receita> batch = new ArrayList<>();
            for (int i = 0; i < modulus; i++) {
                batch.add(receitas.get(it * batchSize + i));
            }

            batchedReceitas.add(batch);
        }

        return batchedReceitas;
    }

    @Override
    public boolean getShowWelcomePageAtInitialization() throws Exception {

        boolean showWelcomePageAtInitialization;

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select mostrar_pagina_boas_vindas from MostrarNaInicializacao")) {

            ResultSet rs = preparedStatement.executeQuery();

            rs.next();

            showWelcomePageAtInitialization = rs.getBoolean("mostrar_pagina_boas_vindas");

        } catch (Exception e) {
            throw e;
        }

        return showWelcomePageAtInitialization;

    }

    @Override
    public boolean getShowPronoumChooserAtInitialization() throws Exception {

        boolean showPronoumChooserAtInitialization;

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select mostrar_trocador_de_pronome from MostrarNaInicializacao")) {

            ResultSet rs = preparedStatement.executeQuery();

            rs.next();

            showPronoumChooserAtInitialization = rs.getBoolean("mostrar_trocador_de_pronome");

        } catch (Exception e) {
            throw e;
        }

        return showPronoumChooserAtInitialization;
    }

    @Override
    public void updateShowWelcomePageAtInitialization(boolean newValue) throws Exception {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("update MostrarNaInicializacao set mostrar_pagina_boas_vindas=?")) {

            preparedStatement.setBoolean(1, newValue);
            preparedStatement.execute();

        } catch (Exception e) {
            throw e;
        }

    }

    @Override
    public void updateShowPronoumChooserAtInitialization(boolean newValue) throws Exception {

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("update MostrarNaInicializacao set mostrar_trocador_de_pronome=?")) {

            preparedStatement.setBoolean(1, newValue);
            preparedStatement.execute();

        } catch (Exception e) {
            throw e;
        }

    }

    @Override
    public String getWelcomePronoum() throws Exception {

        String welcomePronoum = "";

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select pronome_boas_vindas from PronomeBoasVindas")) {

            ResultSet rs = preparedStatement.executeQuery();

            rs.next();

            welcomePronoum = rs.getString("pronome_boas_vindas");

        } catch (Exception e) {
            throw e;
        }

        return welcomePronoum;

    }

    @Override
    public void updateWelcomePronoum(String newValue) throws Exception {
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("update PronomeBoasVindas set pronome_boas_vindas=?")) {

            preparedStatement.setString(1, newValue);
            preparedStatement.execute();

        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public void saveOrUpdateLookAndFeel(LookAndFeel lookAndFeel) throws Exception {

        if (lookAndFeel == null) {
            return;
        }

        if (getLookAndFeel(lookAndFeel.getId()) == null) {//new look and feel

            String sqlQuery = "insert into " + LookAndFeel.class.getSimpleName() + " (id,cssTheme,compactList,roundCorner) values (?,?,?,?)";

            try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                preparedStatement.setString(1, lookAndFeel.getId());
                preparedStatement.setString(2, lookAndFeel.getCssTheme());
                preparedStatement.setBoolean(3, lookAndFeel.isCompactList());
                preparedStatement.setBoolean(4, lookAndFeel.isRoundCorner());

                preparedStatement.execute();

            } catch (Exception e) {
                throw e;
            }
        } else {//updates look and feel

            String sqlQuery = "update " + LookAndFeel.class.getSimpleName() + " set id=? , cssTheme=? , compactList=? , roundCorner=? where id=?";

            try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                preparedStatement.setString(1, lookAndFeel.getId());
                preparedStatement.setString(2, lookAndFeel.getCssTheme());
                preparedStatement.setBoolean(3, lookAndFeel.isCompactList());
                preparedStatement.setBoolean(4, lookAndFeel.isRoundCorner());
                preparedStatement.setString(5, lookAndFeel.getId());

                preparedStatement.execute();

            } catch (Exception e) {
                throw e;
            }

        }

    }

    @Override
    public LookAndFeel getLookAndFeel(String id) throws Exception {

        LookAndFeel lookAndFeel = null;

        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("select * from LookAndFeel where id=?")) {

            preparedStatement.setString(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                lookAndFeel = new LookAndFeel(id, rs.getString("cssTheme"), rs.getBoolean("compactList"), rs.getBoolean("roundCorner"));
            }

        } catch (Exception e) {
            throw e;
        }

        return lookAndFeel;
    }

    public static void main(String[] args) throws Exception {

//MASS LOADER
        PersistenceServiceImpl_JDBC_SQLITE impl_JDBC = new PersistenceServiceImpl_JDBC_SQLITE();

//        int massSize = 1500;
//        Collection<Receita> receitas = impl_JDBC.getMass(massSize);
//        Collection<List<Receita>> batchs = impl_JDBC.batch((List<Receita>) receitas, 300);
//        int batchNum = 1;
//        for (List<Receita> receitaBatch : batchs) {
//            impl_JDBC.createObjects(receitaBatch);
//            System.err.println("batch " + batchNum++ + " " + System.nanoTime());
//        }
//        int nIds = 10;
//        String[] ids = new String[nIds];
//            int i = 0;
//        for (Receita r : receitas) {
//            ids[i] = r.getNome();
//            i++;
//            if (i >= nIds) {
//                break;
//            }
//        }
//
//        Collection<Receita> rEceitas = impl_JDBC.getObjectsById(ids);
//        for(Receita r : rEceitas)System.err.println(r);
//        long init = System.currentTimeMillis();
//        for (List<Receita> receitaBatch : batchs) {
//            impl_JDBC.createObjects(receitaBatch);
//        }
//        System.err.println((System.currentTimeMillis() - init) / 1000 + " CREATING " + massSize);
//
//        System.err.println(" BULK DELETION ");
//
//        init = System.currentTimeMillis();
//        for (List<Receita> receitaBatch : batchs) {
//            impl_JDBC.deleteBulk(receitaBatch);
//        }
//        System.err.println((System.currentTimeMillis() - init) / 1000 + " BULK DELETION " + massSize);
//        
//        massSize = 100;
//        init = System.currentTimeMillis();
//        for (Receita receita : impl_JDBC.getMass(massSize)) {
//            impl_JDBC.create(receita);
//        }
//        System.err.println((System.currentTimeMillis() -init)/1000 + " CREATING " + massSize);
//
//        int ptn=1;
//        
//        init = System.currentTimeMillis();
//        Collection<Receita> all = impl_JDBC.getAll();
//        System.err.println((System.currentTimeMillis() -init)/1000 + " RETREAVING " + massSize);
//        
//        int ptn2=1;
//        
//        Collection<Receita> allFull = new ArrayList<>();
//        init = System.currentTimeMillis();
//        for(Receita receita : all){
//            allFull.add(impl_JDBC.getById(receita.getNome()));
//        }
//        System.err.println((System.currentTimeMillis() -init)/1000 + " RETREAVING BY ID FULL RELATIONS " + massSize);
//
//        int pt3=1;
//        
//        init = System.currentTimeMillis();
//        for(Receita receita : allFull){
//            impl_JDBC.delete(receita);
//        }
//        System.err.println((System.currentTimeMillis() -init)/1000 + " DELETING " + massSize);
//        impl_JDBC = new PersistenceServiceImpl_JDBC_SQLITE();

        System.err.println("Mostrar na inicializacao pagina bem vindo " + impl_JDBC.getShowWelcomePageAtInitialization());
        System.err.println("Mostrar na inicializacao trocador de pronomes " + impl_JDBC.getShowPronoumChooserAtInitialization());
        System.err.println("Pronome boas vindas " + impl_JDBC.getWelcomePronoum());

        impl_JDBC.updateShowWelcomePageAtInitialization(!impl_JDBC.getShowWelcomePageAtInitialization());
        impl_JDBC.updateShowPronoumChooserAtInitialization(!impl_JDBC.getShowPronoumChooserAtInitialization());
        impl_JDBC.updateWelcomePronoum(WelcomePage.BEM_VINDO);

        System.err.println("UPDATED Mostrar na inicializacao pagina bem vindo " + impl_JDBC.getShowWelcomePageAtInitialization());
        System.err.println("UPDATE Mostrar na inicializacao trocador de pronomes " + impl_JDBC.getShowPronoumChooserAtInitialization());
        System.err.println("UPDATE Pronome boas vindas " + impl_JDBC.getWelcomePronoum());

//        Receita r  = new Receita("SALADA COM ABACATE");
//        r.setTipoReceita(Receita.TIPO_COMIDA);
//        new PersistenceServiceImpl_JDBC_SQLITE().create(r);
    }

}
