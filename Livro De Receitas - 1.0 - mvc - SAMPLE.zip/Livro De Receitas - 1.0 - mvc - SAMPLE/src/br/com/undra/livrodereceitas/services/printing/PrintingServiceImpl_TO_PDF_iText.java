package br.com.undra.livrodereceitas.services.printing;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.menus.MenuActions;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.ChapterAutoNumber;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A printing service implementation that prints to a PDF and uses <b>iText</b>
 * as PDFs SYNTAX generator.
 *
 * @author alexandre
 */
public class PrintingServiceImpl_TO_PDF_iText implements PrintingService<Receita> {

    //TOC : Table Of Contents ou INDEX
    static public final String TOC = "ÍNDICE DO LIVRO - IDL";
    static public final String TOC_SELECTED = "ÍNDICE";
    static public final String BOOK_COVER_TITLE = "  LIVRO DE RECEITAS 1.0";
    static public final String BOOK_IMG = "/resources/img/LIVRORECEITAS1_0.png";
    static public final String COVER_IMG = "/resources/img/natural-food-96.png";

    public static final int SECTION_INDENTATION_LEFT = 30;

    /**
     * A font used in our PDF file
     */
    public static final Font NORMAL_SMALL = new Font(Font.FontFamily.UNDEFINED, 8, Font.NORMAL);
    /**
     * A font used in our PDF file
     */
    public static final Font FOOTER_FONT = new Font(Font.FontFamily.UNDEFINED, 6, Font.NORMAL);
    /**
     * A font used in our PDF file
     */
    public static final Font NORMAL = new Font(Font.FontFamily.UNDEFINED, 11, Font.NORMAL);
    /**
     * A font used in our PDF file
     */
    public final static Font ITALIC = new Font(Font.FontFamily.UNDEFINED, 34, Font.ITALIC);

    /**
     * A font used in our PDF file
     */
    public static final Font BOLD = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

    /**
     * The fonts for the title.
     */
    public static final Font[] FONT = new Font[4];

    static {
        FONT[0] = new Font(Font.FontFamily.HELVETICA, 24);
        FONT[1] = new Font(Font.FontFamily.HELVETICA, 18);
        FONT[2] = new Font(Font.FontFamily.HELVETICA, 14);
        FONT[3] = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
    }

    volatile private double index = 0;
    volatile private double progressValue;
    volatile private String progressMessage;

    volatile private boolean isPrinting = false;

    /**
     * Prints <code>src</code>, a <code>Receita</code> collection, to
     * <code>dest</code> stream.<br>
     *
     * @param src the source
     * @param dest a file to which is written PDF syntax.
     * @param printingProgress a MenuAction instance.
     */
    @Override
    public void print(Collection<Receita> src, OutputStream dest, Object printingProgress) {

        index = 0;
        isPrinting = true;

        MenuActions ma = (MenuActions) printingProgress;
        Collection<Receita> receitas = new ArrayList<>(src);

        Map<String, Chapter> chaptersMap = new LinkedHashMap<>();
        Map<String, Integer> chaptersNumberOfPagesMap = new LinkedHashMap<>();

        try {

            Document document = createFirstPassPdf(chaptersMap, chaptersNumberOfPagesMap, receitas, ma);
            document.close();

            createFinalPdf(dest, chaptersMap, chaptersNumberOfPagesMap, receitas, ma);

        } catch (DocumentException | IOException | SQLException ex) {
            Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            receitas.clear();
            isPrinting = false;
        }

    }

    private Document createFirstPassPdf(Map<String, Chapter> chaptersMap, Map<String, Integer> chaptersNumberOfPagesMap, Collection<Receita> receitas, MenuActions ma) throws IOException, DocumentException, BadElementException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document(new Rectangle(Image.getInstance(getClass().getResource(BOOK_IMG))));
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        writer.setInitialLeading(10);
        document.open();
        Paragraph nomeReceitaTitle = null;
        ChapterAutoNumber chapter = null;
        Section section = null;
        Section subsection = null;
        Chunk tocChunk = new Chunk(TOC, FONT[0]);
        Chapter toc = new ChapterAutoNumber(new Paragraph(tocChunk));

        int chapterNum = 0;
        writer.setPageEvent(new NumberOfPagesAndChapterInfoListener(chaptersMap, chaptersNumberOfPagesMap, toc));

        for (Receita receita : receitas) {

            index++;

            if (((int) (index)) % 2 == 0) {
                progressValue = index / receitas.size();
                progressMessage = ((int) (index)) + "/" + receitas.size();
                ma.setBarProgress(progressValue, progressMessage);
            }

            // Create nome receita
            Chunk nomeReceita = new Chunk(receita.getNome(), FONT[0]);
            nomeReceita.setLocalDestination(++chapterNum + ". " + receita.getNome());
            nomeReceitaTitle = new Paragraph(nomeReceita);
            nomeReceitaTitle.setIndentationLeft(0);

            //adds to chapter
            chapter = new ChapterAutoNumber(nomeReceitaTitle);
            chapter.setIndentationLeft(0);

            createIngredientesSection(chapter, receita);
            createModoPreparoSection(chapter, receita);
            createTipoReceitaSection(chapter, receita);

            chapter.setBookmarkOpen(false);

            document.add(chapter);
            chaptersMap.put(chapter.getTitle().getContent(), chapter);

            try {
                Thread.sleep(Util.getIntervalFromOneIterationAndAnother(receitas.size()));
            } catch (InterruptedException ex) {
                Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        //NAO COLOCA CAPA NEM IMAGEM SE FOR APENAS IMPRESSAO DE ALGUNS OBJETOS
        if (ma.getCurrentAction().equals(MenuActions.IMPRIMIR_SELECIONADAS_ACAO)) {

            //APENAS COLOCA TOC SE TIVER MAIS DO QUE UMA RECEITA
            if (receitas.size() > 1) {
                document.add(toc);
                chaptersMap.put(toc.getTitle().getContent(), toc);
            }

        } else if (ma.getCurrentAction().equals(MenuActions.IMPRIMIR_BOOK_ACAO)) {//COLOA CAPA, IMAGEM E TOC SE FOR BOOK PRINTING

            //adds cover
            Chapter cover = createCoverFirstPass();
            chaptersMap.put(COVER_IMG, cover);
            chaptersNumberOfPagesMap.put(COVER_IMG, 1);
            document.add(cover);

            //adds application img
//            Chapter applicationImgChapter = createImgFirstPass(writer);
//            chaptersMap.put(BOOK_IMG, applicationImgChapter);
//            chaptersNumberOfPagesMap.put(BOOK_IMG, 1);
//            document.add(applicationImgChapter);
            document.add(toc);
            chaptersMap.put(toc.getTitle().getContent(), toc);

        }

        return document;
    }

    private Chapter createCoverFirstPass() throws BadElementException, IOException {
        //adds cover
        Paragraph imgAndTextParagraph = new Paragraph(COVER_IMG);
        // Create an image
        Image img = Image.getInstance(getClass().getResource(COVER_IMG));
        img.setAlignment(Image.LEFT | Image.TEXTWRAP);
        img.scaleToFit(1000, 25);
        imgAndTextParagraph.add(img);
        // Create text elements
        imgAndTextParagraph.add(Chunk.NEWLINE);
        imgAndTextParagraph.add(Chunk.NEWLINE);
        imgAndTextParagraph.add(new Paragraph(BOOK_COVER_TITLE, BOLD));
        imgAndTextParagraph.add(Chunk.NEWLINE);
        Chapter cover = new ChapterAutoNumber(imgAndTextParagraph);
        return cover;
    }

    private Chapter createImgFirstPass(PdfWriter writer) throws IOException, BadElementException {
        // Create application img
        Paragraph applicationImageParagraph = new Paragraph(BOOK_IMG);
        Image applicationImg = Image.getInstance(getClass().getResource(BOOK_IMG));
        applicationImg.scaleToFit(writer.getPageSize().getWidth() - 90, writer.getPageSize().getHeight() - 1000);
        applicationImageParagraph.add(applicationImg);
        Chapter applicationImgChapter = new ChapterAutoNumber(applicationImageParagraph);
        return applicationImgChapter;
    }

    private void createIngredientesSection(ChapterAutoNumber chapter, Receita receita) {
        Paragraph title = new Paragraph(Util.PROPERTIES.getProperty("tabIngredientes"), FONT[1]);
        title.setIndentationLeft(SECTION_INDENTATION_LEFT);
        Section section = chapter.addSection(title);
        section.setBookmarkTitle(Util.PROPERTIES.getProperty("tabIngredientes"));
        section.setIndentation(2 * SECTION_INDENTATION_LEFT);
        section.setBookmarkOpen(false);
        section.add(new Paragraph(receita.getIngredientes()));
    }

    private void createModoPreparoSection(ChapterAutoNumber chapter, Receita receita) {
        Paragraph title = new Paragraph(Util.PROPERTIES.getProperty("tabModoPreparo"), FONT[1]);
        title.setIndentationLeft(SECTION_INDENTATION_LEFT);
        Section section = chapter.addSection(title);
        section.setBookmarkTitle(Util.PROPERTIES.getProperty("tabModoPreparo"));
        section.setIndentation(2 * SECTION_INDENTATION_LEFT);
        section.setBookmarkOpen(false);
        section.add(new Paragraph(receita.getModoPreparo()));
    }

    private void createTipoReceitaSection(ChapterAutoNumber chapter, Receita receita) {
        Paragraph title = new Paragraph(Util.PROPERTIES.getProperty("tabTipoReceita"), FONT[1]);
        title.setIndentationLeft(SECTION_INDENTATION_LEFT);
        Section section = chapter.addSection(title);
        section.setBookmarkTitle(Util.PROPERTIES.getProperty("tabTipoReceita"));
        section.setIndentation(2 * SECTION_INDENTATION_LEFT);
        section.setBookmarkOpen(false);
        section.add(new Paragraph(receita.getTipoReceitaDetalhado()));
    }

    @Override
    public boolean isPrinting() {
        return isPrinting;
    }

    @Override
    public void setIsPrinting(boolean newValue) {
        isPrinting = newValue;
    }

    class TocPagesNumEventHelper extends PdfPageEventHelper {

        int tocPagesNum = 0;

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            tocPagesNum++;
        }

        @Override
        public void onOpenDocument(PdfWriter writer, Document document) {
            tocPagesNum = 0;
        }

        public int getTocPagesNum() {
            return tocPagesNum;
        }

    }

    TocPagesNumEventHelper eventHelper = new TocPagesNumEventHelper();

    @Deprecated
    private int getTocPagesNum(Chapter toc) {

        int tocPagesNum = 0;

        try {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(new Rectangle(Image.getInstance(getClass().getResource(BOOK_IMG))));
            PdfWriter writer = PdfWriter.getInstance(document, baos);

            writer.setPageEvent(eventHelper);

            document.open();

            document.add(toc);

            document.close();

            tocPagesNum = eventHelper.getTocPagesNum();

        } catch (DocumentException ex) {
            Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
        }

        return tocPagesNum;
    }

    class ChapterPagesNumEventHelper extends PdfPageEventHelper {

        int chapterPageNum = 0;

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            chapterPageNum++;
        }

        @Override
        public void onOpenDocument(PdfWriter writer, Document document) {
            chapterPageNum = 0;
        }

        public int getChapterPageNum() {
            return chapterPageNum;
        }

        public void setChapterPageNum(int chapterPageNum) {
            this.chapterPageNum = chapterPageNum;
        }
    }

    ChapterPagesNumEventHelper chapterEventHelper = new ChapterPagesNumEventHelper();

    @Deprecated
    private int getChapterPageNum(Chapter chapter) {

        int chapterPageNum = 0;

        try {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(new Rectangle(Image.getInstance(getClass().getResource(BOOK_IMG))));
            PdfWriter writer = PdfWriter.getInstance(document, baos);
            writer.setInitialLeading(10);
            writer.setPageEvent(chapterEventHelper);

            document.open();

            chapter.setBookmarkOpen(false);

            document.add(chapter);

            document.close();

            chapterPageNum = chapterEventHelper.getChapterPageNum();

        } catch (DocumentException ex) {
            Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
        }

        return chapterPageNum;
    }

    /**
     * A listener for collecting number of pages and chapters info.
     */
    class NumberOfPagesAndChapterInfoListener extends PdfPageEventHelper {

        private String actualChapterTitle = "";

        private final Map<String, Chapter> chaptersMap;
        private final Map<String, Integer> chaptersNumberOfPagesMap;
        private final Chapter toc;

        public NumberOfPagesAndChapterInfoListener(Map<String, Chapter> chaptersMap, Map<String, Integer> chaptersNumberOfPagesMap, Chapter toc) {
            this.chaptersMap = chaptersMap;
            this.chaptersNumberOfPagesMap = chaptersNumberOfPagesMap;
            this.toc = toc;
        }

        int contentInitPage = 0;
        int pageCount = 0;

        @Override
        public void onEndPage(PdfWriter writer, Document document) {

            if (chaptersNumberOfPagesMap.containsKey(actualChapterTitle)) {
                contentInitPage++;
                chaptersNumberOfPagesMap.put(actualChapterTitle, contentInitPage);
            } else {
                contentInitPage = 1;
                chaptersNumberOfPagesMap.put(actualChapterTitle, contentInitPage);
            }

        }

        @Override
        public void onChapter(PdfWriter writer, Document document, float paragraphPosition, Paragraph title) {

            actualChapterTitle = title.getContent();

            //TOC : Table Of Contents or INDEX
            if (title.getContent().contains(TOC)) {
            } else {
                if (!title.getContent().contains(BOOK_IMG) && !title.getContent().contains(COVER_IMG)) {
                    Chunk chunk = new Chunk(title.getContent(), NORMAL);
                    chunk.setLocalGoto(title.getContent());
                    title = new Paragraph(chunk);
                    toc.add(title);
                }
            }
        }
    }

    private void createFinalPdf(OutputStream dest, Map<String, Chapter> chaptersMap, Map<String, Integer> chaptersNumberOfPagesMap, Collection<Receita> receitas, MenuActions ma) throws FileNotFoundException, DocumentException, SQLException, UnsupportedEncodingException, IOException {

        Document document = new Document(new Rectangle(Image.getInstance(getClass().getResource(BOOK_IMG))));
        PdfWriter writer = PdfWriter.getInstance(document, dest);
        writer.setInitialLeading(10);

        class MyPdfPageEventHelper extends PdfPageEventHelper {

            int contentInitPage = 1;
            int pageCount = 0;
            int offPages = 0;
            int totalOfPages;

            @Override
            public void onOpenDocument(PdfWriter writer, Document document) {

                for (String chapterTitle : chaptersMap.keySet()) {
                    if (chapterTitle.contains(TOC)) {
                        offPages += chaptersNumberOfPagesMap.get(chapterTitle);
                    } else if (chapterTitle.contains(BOOK_IMG)) {
                        offPages += chaptersNumberOfPagesMap.get(chapterTitle);
                    } else if (chapterTitle.contains(COVER_IMG)) {
                        offPages += chaptersNumberOfPagesMap.get(chapterTitle);
                    } else {
                        totalOfPages += chaptersNumberOfPagesMap.get(chapterTitle);
                    }
                }

            }

            @Override
            public void onEndPage(PdfWriter writer, Document document) {
                try {
                    PdfContentByte canvas = writer.getDirectContent();
                    canvas.beginText();
                    canvas.setFontAndSize(BaseFont.createFont(BaseFont.HELVETICA_BOLD, BaseFont.WINANSI, BaseFont.EMBEDDED), 10f);
                    String footer;
                    String dateTime = String.format("%s/%s/%s %s:%s:%s",
                            Calendar.getInstance().get(Calendar.DAY_OF_MONTH) < 10 ? "0" + Calendar.getInstance().get(Calendar.DAY_OF_MONTH) : "" + Calendar.getInstance().get(Calendar.DAY_OF_MONTH),
                            Calendar.getInstance().get(Calendar.MONTH) + 1 < 10 ? "0" + (Calendar.getInstance().get(Calendar.MONTH) + 1) : "" + (Calendar.getInstance().get(Calendar.MONTH) + 1),
                            Calendar.getInstance().get(Calendar.YEAR),
                            Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 10 ? "0" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY) : "" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                            Calendar.getInstance().get(Calendar.MINUTE) < 10 ? "0" + Calendar.getInstance().get(Calendar.MINUTE) : "" + Calendar.getInstance().get(Calendar.MINUTE),
                            Calendar.getInstance().get(Calendar.SECOND) < 10 ? "0" + Calendar.getInstance().get(Calendar.SECOND) : "" + Calendar.getInstance().get(Calendar.SECOND));
                    if (writer.getPageNumber() > offPages) {

                        footer = String.format(Util.PROPERTIES.getProperty("application.pdf.numbered.footer"), Util.PROPERTIES.getProperty("title") + " PDF Printing Service", dateTime, contentInitPage++, totalOfPages, Util.PROPERTIES.getProperty("developer"), Util.PROPERTIES.getProperty("developer.celular"), Util.PROPERTIES.getProperty("developer.email"));
//                        canvas.showTextAligned(Element.ALIGN_CENTER, String.valueOf(contentInitPage++) + " de " + totalOfPages, document.getPageSize().getWidth() / 2, document.getPageSize().getBottom() + 15, 0);
                        canvas.showTextAligned(Element.ALIGN_CENTER, footer, document.getPageSize().getWidth() / 2, document.getPageSize().getBottom() + 15, 0);

                    } else {

                        footer = String.format(Util.PROPERTIES.getProperty("application.pdf.footer"), Util.PROPERTIES.getProperty("title") + " PDF Printing Service", dateTime, Util.PROPERTIES.getProperty("developer"), Util.PROPERTIES.getProperty("developer.celular"), Util.PROPERTIES.getProperty("developer.email"));
                        canvas.showTextAligned(Element.ALIGN_CENTER, footer, document.getPageSize().getWidth() / 2, document.getPageSize().getBottom() + 15, 0);

                    }
                    canvas.endText();

                } catch (DocumentException ex) {
                    Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        writer.setPageEvent(new MyPdfPageEventHelper());

        document.open();

        //NAO COLOCA CAPA NEM IMAGEM SE FOR APENAS IMPRESSAO DE ALGUNS OBJETOS
        if (ma.getCurrentAction().equals(MenuActions.IMPRIMIR_SELECIONADAS_ACAO)) {

            addSingleItemMetaData(document);

            //APENAS COLOCA TOC SE TIVER MAIS DO QUE UMA RECEITA
            if (receitas.size() > 1) {

                addItensMetaData(document, receitas);

                //puts TOC chapter at applicationmarks first position
                document.add(rebuildToc(chaptersMap, chaptersNumberOfPagesMap, receitas, ma));
            }

        } else if (ma.getCurrentAction().equals(MenuActions.IMPRIMIR_BOOK_ACAO)) {

            addBookMetaData(document, receitas);

            //adds a cover
            addCover(document, writer);

            //puts TOC chapter at application bookmarks first position
            document.add(rebuildToc(chaptersMap, chaptersNumberOfPagesMap, receitas, ma));

        }

        //puts OTHER chapters below TOC,if there is any
        for (String chapterTitle : chaptersMap.keySet()) {
            index++;
            if (!isContent(chapterTitle)) {
            } else {
                document.add(chaptersMap.get(chapterTitle));
                if (((int) (index)) % 2 == 1) {
                    progressValue = index / receitas.size();
                    progressMessage = ((int) (index)) + "/" + receitas.size();
                    ma.setBarProgress(progressValue, progressMessage);
                }
            }
            try {
                Thread.sleep(Util.getIntervalFromOneIterationAndAnother(receitas.size()));
            } catch (InterruptedException ex) {
                Logger.getLogger(PrintingServiceImpl_TO_PDF_iText.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        document.close();

        while (!writer.isCloseStream()) {
        }

    }

    private void addSingleItemMetaData(Document document) {
        document.addTitle(Util.PROPERTIES.getProperty("single.title").toUpperCase());
        document.addAuthor(Util.PROPERTIES.getProperty("developer"));
        document.addCreationDate();
        document.addCreator(Util.PROPERTIES.getProperty("developer"));
        document.addKeywords("culinaria, receitas, vegetarianismo");
        document.addSubject("IMPRESSAO " + Util.PROPERTIES.getProperty("single.title"));
    }

    private void addItensMetaData(Document document, Collection<Receita> receitas) {
        document.addTitle(Util.PROPERTIES.getProperty("many.title").toUpperCase());
        document.addAuthor(Util.PROPERTIES.getProperty("developer"));
        document.addCreationDate();
        document.addCreator(Util.PROPERTIES.getProperty("developer"));
        document.addKeywords("culinaria, receitas, vegetarianismo");
        document.addSubject("IMPRESSAO " + receitas.size() + " " + Util.PROPERTIES.getProperty("many.title"));
    }

    private void addBookMetaData(Document document, Collection<Receita> receitas) {
        //COLOA CAPA, IMAGEM E TOC SE FOR BOOK PRINTING

        document.addTitle(Util.PROPERTIES.getProperty("title").toUpperCase());
        document.addAuthor(Util.PROPERTIES.getProperty("developer"));
        document.addCreationDate();
        document.addCreator(Util.PROPERTIES.getProperty("developer"));
        document.addKeywords("culinaria, receitas, vegetarianismo");
        document.addSubject("IMPRESSAO " + Util.PROPERTIES.getProperty("title") + " contendo " + receitas.size());
    }

    private Chapter rebuildToc(Map<String, Chapter> chaptersMap, Map<String, Integer> chaptersNumberOfPagesMap, Collection<Receita> receitas, MenuActions ma) throws BadElementException, IOException {

        Chunk tocChunk = new Chunk(TOC, FONT[0]);;

        //NAO COLOCA CAPA NEM IMAGEM SE FOR APENAS IMPRESSAO DE ALGUNS OBJETOS
        if (ma.getCurrentAction().equals(MenuActions.IMPRIMIR_SELECIONADAS_ACAO)) {

            //APENAS COLOCA TOC SE TIVER MAIS DO QUE UMA RECEITA
            if (receitas.size() > 1) {
                //puts TOC chapter at application bookmarks first position
                tocChunk = new Chunk(TOC_SELECTED, FONT[0]);
            }

        }

        Chapter toc = new ChapterAutoNumber(new Paragraph(tocChunk));

        int contentInitPage = 1;
        int pageCount = 0;

        toc.add(new Paragraph(" "));

        for (String chapterTitle : chaptersMap.keySet()) {

            if (!isContent(chapterTitle)) {
            } else {

                pageCount = chaptersNumberOfPagesMap.get(chapterTitle);
                String newTitle = chapterTitle + ", page " + contentInitPage + ", page count " + pageCount;

                contentInitPage += pageCount;
                Paragraph imgAndTextParagraph = new Paragraph();
                imgAndTextParagraph.setIndentationLeft(20);

                // Create an image
                Image img = Image.getInstance(getClass().getResource(COVER_IMG));
                img.setAlignment(Image.LEFT);
                img.scaleToFit(30, 15);
                imgAndTextParagraph.add(img);

                // Create text elements
                Chunk chunk = new Chunk(newTitle, NORMAL);
                chunk.setLocalGoto(chapterTitle);
                Paragraph contentTitle = new Paragraph(chunk);
                contentTitle.setIndentationLeft(30);
                imgAndTextParagraph.add(contentTitle);
                //adds to chapter
                toc.add(contentTitle);

            }

        }
        return toc;
    }

    private static boolean isContent(String chapterTitle) {
        return !chapterTitle.contains(TOC) && !chapterTitle.contains(BOOK_IMG) && !chapterTitle.contains(COVER_IMG);
    }

    private void addImage(Document document, PdfWriter writer) throws BadElementException, IOException, DocumentException {
        Paragraph p = new Paragraph();
        p.add(Chunk.NEWLINE);
        // Create cover
        Image coverImg = Image.getInstance(getClass().getResource(BOOK_IMG));
        coverImg.scaleToFit(writer.getPageSize().getWidth(), writer.getPageSize().getHeight() - 90);
        coverImg.setTransparency(new int[]{0x00, 0x10});
        p.add(coverImg);
        p.setIndentationLeft(5);

        Chapter cover = new ChapterAutoNumber(p);
        document.add(p);
    }

    private void addCover(Document document, PdfWriter writer) throws BadElementException, IOException, DocumentException {

        //adds cover
        Paragraph coverParagraph = new Paragraph();
        coverParagraph.setIndentationLeft(100);
        coverParagraph.add(Chunk.NEWLINE);
        coverParagraph.add(Chunk.NEWLINE);
        // Create an image
        Image img = Image.getInstance(getClass().getResource(COVER_IMG));
        img.setAlignment(Image.LEFT);

        img.scaleToFit(1000, 110);
        coverParagraph.add(img);
        // Create text elements
        coverParagraph.add(Chunk.NEWLINE);
        coverParagraph.add(Chunk.NEWLINE);

        
        ITALIC.setColor(new BaseColor(0, 7, 30));
        Paragraph title = new Paragraph(BOOK_COVER_TITLE, ITALIC);
        title.setFirstLineIndent(150);
        coverParagraph.add(title);

        coverParagraph.add(Chunk.NEWLINE);

        Chapter cover = new ChapterAutoNumber(coverParagraph);

        document.add(coverParagraph);

        PdfContentByte canvas = writer.getDirectContent();

        canvas.setColorStroke(new BaseColor(173, 179, 188));

        canvas.moveTo(270, 200);

        canvas.lineTo(270, 850);

        canvas.closePathStroke();

        canvas.moveTo(50, 700);

        canvas.lineTo(800, 700);

        canvas.closePathStroke();

    }

}
