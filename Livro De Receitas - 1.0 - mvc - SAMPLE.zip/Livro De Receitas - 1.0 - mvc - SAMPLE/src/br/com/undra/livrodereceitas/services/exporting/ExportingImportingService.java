package br.com.undra.livrodereceitas.services.exporting;

import java.io.File;
import java.util.Collection;

/**
 * The exporting/importing interface.
 * @author alexandre
 * @param <T>
 */
public interface ExportingImportingService<T> {
    /**
     * Exports the collection of <code>objects</code> to <code>file</code>.
     * @param objects
     * @param file
     * @throws Exception 
     */
    void export(Collection<T> objects, File file) throws Exception;
    /**
     * Imports from <code>source</code> and parses to a <code>Collection of objects</code>.
     * @param source
     * @return
     * @throws Exception 
     */
    Collection<T> imporT(File source) throws Exception;
}
