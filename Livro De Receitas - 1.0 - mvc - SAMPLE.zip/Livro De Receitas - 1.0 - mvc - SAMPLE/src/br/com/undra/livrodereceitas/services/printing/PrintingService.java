package br.com.undra.livrodereceitas.services.printing;

import java.io.OutputStream;
import java.util.Collection;

/**
 * A printing service abstraction.
 * @author alexandre
 * @param <T> type to print
 */
public interface PrintingService<T> {
    /**
     * Prints <code>src</code> collection to <code>dest</code> stream.<br>
     * 
     * @param src the source
     * @param dest the out put stream destination.
     * @param printingProgress if wants to be notified of the printing progress.
     */
    void print(Collection<T> src, OutputStream dest, Object printingProgress);
    boolean isPrinting();
    void setIsPrinting(boolean newValue);
}
