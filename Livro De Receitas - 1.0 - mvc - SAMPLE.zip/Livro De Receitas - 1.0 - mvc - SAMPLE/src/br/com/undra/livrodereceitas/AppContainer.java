package br.com.undra.livrodereceitas;

import br.com.undra.livrodereceitas.paginas.NotificationPage;
import br.com.undra.livrodereceitas.util.Notificator;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.scrollablelist.util.Selector;
import br.com.undra.jfxcomponents.searcher.Searcher;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.listeners.AppKeyListener;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.menus.MenuActions;
import br.com.undra.livrodereceitas.pagenavigator.PageNavigator;
import br.com.undra.livrodereceitas.paginas.ConfirmarSalvar;
import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.LoaderPage;
import br.com.undra.livrodereceitas.paginas.NenhumaReceitaSelecionada;
import br.com.undra.livrodereceitas.paginas.Notifications;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.paginas.Page;
import br.com.undra.livrodereceitas.paginas.WelcomePage;
import br.com.undra.livrodereceitas.paginas.tiporeceita.NovoTipoReceita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoCaloria;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoReceita;
import br.com.undra.livrodereceitas.services.persistence.PersistenceService;
import br.com.undra.livrodereceitas.services.persistence.PersistenceServiceImpl_JDBC_SQLITE;
import br.com.undra.livrodereceitas.util.Helper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import org.controlsfx.control.NotificationPane;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

/**
 * MVC do livro de receitas
 *
 * @author alexandre
 */
public class AppContainer implements App {

    private String title = Util.PROPERTIES.getProperty("title");
    private Stage stage;
    private Page currentPage;
    private final ListaDeReceitas listaDeReceitas;
    private final NenhumaReceitaSelecionada nenhumaReceitaSelecionada;
    private final NovaReceita novaReceita;
    private final DetalhesReceita detalhesReceita;
    private final ConfirmarSalvar confirmarSalvar;
    private final WelcomePage welcomePage;
    private final NotificationPage notificationPage;
    private final NotificationPane pageWrapper;

    private Thread noCreationalActivityWatcher;
    private Thread showHideNotificationThread;
    private Thread setupListenersThread;

    private final PersistenceService persistenceService;

    volatile private boolean isChangingPage = false;
    
    public static synchronized AppContainer newInstance(String title){
        return new AppContainer(title);
    }
    
    /**
     * The app constructor.
     * @param title
     */
    private AppContainer(String title) {
        Helper.preparePdfsAndViewers();
        this.title = title;
        welcomePage = new WelcomePage(this);
        nenhumaReceitaSelecionada = new NenhumaReceitaSelecionada(this);
        novaReceita = new NovaReceita(this);
        detalhesReceita = new DetalhesReceita(this);
        confirmarSalvar = new ConfirmarSalvar(this);
        listaDeReceitas = new ListaDeReceitas(this);
        notificationPage = new NotificationPage(this);
        notificationPage.setVisible(false);
        welcomePage.getChildren().add(notificationPage);
        Notifications.setContainer(this);
        setUpListaDeReceitas();
        pageWrapper = new NotificationPane();
        setUpPageWrapper();
        persistenceService = PersistenceServiceImpl_JDBC_SQLITE.getInstace();
        Notificator.setNotificationPage(notificationPage);
    }

    private void setUpListaDeReceitas() {
        listaDeReceitas.setExtras(Arrays.asList(novaReceita, detalhesReceita, confirmarSalvar, nenhumaReceitaSelecionada, novaReceita.getNovoTipoReceita()));
        listaDeReceitas.getEmptyListPage().getEmptyListLabel().setFont(Font.font(20));
    }

    private void setUpPageWrapper() {

        pageWrapper.setCloseButtonVisible(false);
        pageWrapper.setShowFromTop(true);
        pageWrapper.getStylesheets().add(getClass().getResource("/resources/css/notificationpane.css").toExternalForm());

//        pageWrapper.getStyleClass().clear();
//        
//        if (!pageWrapper.getStyleClass().contains("dark_custom")) {
//            pageWrapper.getStyleClass().add("dark_custom");
//        }
        pageWrapper.setOnHidden((event) -> {
            if (pageWrapper.getStyleClass().contains("error")) {
                pageWrapper.getStyleClass().remove("error");
            }
            if (pageWrapper.getStyleClass().contains("warning")) {
                pageWrapper.getStyleClass().remove("warning");
            }

            if (!pageWrapper.getStyleClass().contains("neutral")) {
                pageWrapper.getStyleClass().add("neutral");
            }
        });
        pageWrapper.setOnShowing((event) -> {

        });

    }

    public boolean isChangingPage() {
        return isChangingPage;
    }

    public void handleOpenningMessage() {
        if (listaDeReceitas.getView().getCurrentModel().size() == 0) {
            new Thread(() -> {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.runLater(() -> {
                    Notificator.notificate(this, Util.PROPERTIES.getProperty("empty.list.openning.message").toUpperCase(), 6500);
                });
//                showHideNotification("NENHUMA RECEITA NA LISTA. CRIE ALGUMA CLICANDO EM " + "⊕".toUpperCase());
            }).start();
        }
    }
    AppKeyListener appKeyListener;

    /**
     * Instala observadores para eventos de TECLADO e eventos de ADICAO, REMOCAO
     * E EDICAO de objetos<br>
     * no VerticcalFullScroller.
     */
    private void setUpListeners() {

        //LISTENER PARA COMANDAR ATRAVÉS DO TECLADO
        setupListenersThread = new Thread(() -> {

            while (root == null) {
            };
            appKeyListener = new AppKeyListener(this);
            root.setOnKeyPressed(appKeyListener);

        });
        setupListenersThread.start();

        //LISTENER PARA EVENTOS DE ADICIONAR OBJETOS NO VERTICALFULL SCROLLER.
        listaDeReceitas.ON_ADDITION().addListener((observable, oldValue, newValue) -> {
            handleReceitasCreation(newValue);
        });

        //LISTENER PARA EVENTOS DE REMOVER OBJETOS NO VERTICALFULLSCROLLER
        listaDeReceitas.ON_DELETION().addListener((observable, oldValue, newValue) -> {
            handleReceitasDeletion(newValue);
        });

        //LISTENER PARA EVENTOS DE SELECAO/DESELECAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaDeReceitas.ON_SELECTION().addListener((observable, oldValue, STATE) -> {
            handleReceitasSelectionUNselection(STATE);
        });

        //LISTENER PARA EVENTOS DE EDIÇÃO DE OBJETOS NO VERTICALFULLSCROLLER
        listaDeReceitas.ON_EDITION().addListener((observable, oldValue, newValue) -> {
            handleReceitasEdition(newValue);
        });

        //LISTENER PARA EVENTOS DE IMPORTAÇÃO DE OBJETOS NO VERTICALFULLSCROLLER
        listaDeReceitas.ON_IMPORTING().addListener((observable, oldValue, newValue) -> {

            if (newValue.equals(ScrollableListContainerSimple.IMPORTED)) {
                setMenuAsNotEmptyListState();
            }

        });

        //LISTENER PARA EVENTOS DE DES-IMPORTAÇÃO DE OBJETOS NO VERTICALFULLSCROLLER
        listaDeReceitas.ON_UN_IMPORTING().addListener((observable, oldValue, newValue) -> {

            if (newValue.equals(ScrollableListContainerSimple.UN_IMPORTED)) {
                if (listaDeReceitas.size() == 0) {
                    setMenuAsEmptyListState();
                }
            }

        });
    }

    private void handleReceitasEdition(String newValue) {
        if (newValue.equals(DetalhesReceita.EDITING_REQUESTED)) {
            detalhesReceita.makeEditionCancelableByEscKey();
            detalhesReceita.focusNomeReceita();
        } else if (newValue.equals(DetalhesReceita.EDITING_CANCELED)) {
            handleEditingCanceled();
        } else if (newValue.equals(ScrollableListContainerSimple.EDITING_FAILED_NO_MATCHING_FOUND)) {

        } else if (newValue.equals(ScrollableListContainerSimple.EDITING_FAILED_EXECUTING_CLIENT_HOOK_EDITING_LOGIC)) {

            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("edition.error.logger.message"), listaDeReceitas.getCurrentEdited().getDescricao());
            Notificator.notificateError(this, Util.PROPERTIES.getProperty("edition.error.notificator.message") + " " + listaDeReceitas.getCurrentEdited().getDescricao(), 3500);

        } else if (newValue.equals(ScrollableListContainerSimple.EDITED)) {
            handleEditingDone();
        }
    }

    private void handleEditingDone() {
        detalhesReceita.setCurrent(listaDeReceitas.getReceitaCurrentEdited());
        Logger.getLogger(AppContainer.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("edition.done.logger.message"), listaDeReceitas.getCurrentEdited().getDescricao());
        Notificator.notificate(this, Util.PROPERTIES.getProperty("edition.done.notificator.message") + " " + listaDeReceitas.getCurrentEdited().getDescricao(), 4000);

        PageNavigator.goToPageSmoothly(this, detalhesReceita);

        try {

            detalhesReceita.cleanUp();

            new Thread(() -> {
                while (!detalhesReceita.isCleanedUp()) {
                };
                while (isChangingPage) {
                }

                Platform.runLater(() -> {
                    detalhesReceita.fill(detalhesReceita.getCurrent());
                    detalhesReceita.block();
                    detalhesReceita.getReceitaTabPane().requestFocus();
                });

            }).start();

        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void handleEditingCanceled() {
        try {

            detalhesReceita.cleanUp();

            new Thread(() -> {
                while (!detalhesReceita.isCleanedUp()) {
                };
                Platform.runLater(() -> {
                    detalhesReceita.fill(detalhesReceita.getCurrent());
                    detalhesReceita.block();
                    detalhesReceita.makeEditionCancelableByEscKey();
                });

            }).start();

        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setIsChangingPage(boolean isChangingPage) {
        this.isChangingPage = isChangingPage;
    }

    private void handleReceitasCreation(String STATE) {
        if (STATE.equals(ScrollableListContainerSimple.ON_ADD_REQUEST)) {
            handle_RECEITA_ON_ADD_REQUEST();
        } else if (STATE.equals(ScrollableListContainerSimple.ADDED)) {
            handle_RECEITA_ON_ADDED();
        } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC)) {
            handle_RECEITA_ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC();
        } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_DUPLICATE_ENTRY)) {
            handle_RECEITA_ADDING_FAILED_DUPLICATED_KEY();
        } else if (STATE.equals(ScrollableListContainerSimple.ADDING_CANCELED)) {
            handle_RECEITA_ADDING_CANCELED();
        } else if (STATE.equals(ScrollableListContainerSimple.ADDING_REQUEST_REFUSED)) {
            handle_RECEITA_ADDING_REQUEST_REFUSED();
        }
    }

    private void handle_RECEITA_ADDING_FAILED_DUPLICATED_KEY() {
        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("saving.duplicated.entry.error.logger.message"), listaDeReceitas.getCurrentAdding().getDescricao());
        Notificator.notificateError(this, Util.PROPERTIES.getProperty("saving.duplicated.entry.error.notificator.message") + " " + listaDeReceitas.getCurrentAdding().getDescricao(), 3500);
        novaReceita.cleanUp();
        novaReceita.setState(NovaReceita.ADDING_FAILED);
    }

    private void handle_RECEITA_ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC() {
        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("saving.error.logger.message"), listaDeReceitas.getCurrentAdding().getDescricao());
        Notificator.notificateError(this, Util.PROPERTIES.getProperty("saving.error.notificator.message") + " " + listaDeReceitas.getCurrentAdding().getDescricao(), 3500);
        novaReceita.cleanUp();
        novaReceita.setState(NovaReceita.ADDING_FAILED);
    }

    private void handle_RECEITA_ON_ADDED() {
        Logger.getLogger(AppContainer.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("creation.done.logger.message"), listaDeReceitas.getCurrentAdding().getDescricao());
        Notificator.notificate(this, Util.PROPERTIES.getProperty("creation.done.notificator.message") + " " + listaDeReceitas.getCurrentAdding().getDescricao(), 4000);
        novaReceita.cleanUp();
        novaReceita.setState(NovaReceita.ADDING_FINISHED);
        if (noCreationalActivityWatcher != null) {
            noCreationalActivityWatcher.stop();
        }
        setMenuAsNotEmptyListState();
        PageNavigator.goToPageSmoothly(this, nenhumaReceitaSelecionada);
    }

    private void handle_RECEITA_ON_ADD_REQUEST() {
        if (!isEditing() && !isImporting()) {

            if (detalhesReceita.getCurrent() != null) {
                listaDeReceitas.unselect();
            }

            new Thread(() -> {

                while (!listaDeReceitas.isUnselectingDone()) {
                };

                while (isChangingPage()) {
                };

                Platform.runLater(() -> {
                    novaReceita.cleanUp();
                    novaReceita.setState(NovaReceita.ADDING_STARTED);
                    PageNavigator.goToPageSmoothly(this, novaReceita);
                    handleNoCreationalActivities();
                });

            }).start();

        } else {
            listaDeReceitas.shake();
            if (isImporting()) {
                listaDeReceitas.getView().ON_ADDITION().setValue(ScrollableListContainerSimple.ADDING_CANCELED);
            } else if (isEditing()) {
                listaDeReceitas.getView().ON_ADDITION().setValue(ScrollableListContainerSimple.ADDING_REQUEST_REFUSED);
            }
        }
    }

    private void handle_RECEITA_ADDING_CANCELED() {
        if (detalhesReceita.getCurrent() != null) {
            listaDeReceitas.unselect();
        }
        if (listaDeReceitas.getView().getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {

        } else {

        }
    }

    private void handle_RECEITA_ADDING_REQUEST_REFUSED() {
        listaDeReceitas.shake();
        if (isEditing()) {

        }

    }

    private void handleReceitasDeletion(String STATE) {

        if (STATE.equals(ScrollableListContainerSimple.MULTI_SELECTION_DELETION_COMPLETED) || STATE.equals(ScrollableListContainerSimple.SINGLE_SELECTION_REMOVED)) {

            if (STATE.equals(ScrollableListContainerSimple.MULTI_SELECTION_DELETION_COMPLETED)) {
                //PARA EVITAR CONGELAMENTO QUANDO BULK REMOVE
                new Thread(() -> {
                    String msg = "";
                    for (String removed : listaDeReceitas.getMultiSelectionRemoved()) {
                        msg = msg + removed + " REMOVIDA\n";
                    }
                    Logger.getLogger(AppContainer.class.getName()).log(Level.INFO, listaDeReceitas.getMultiSelectionRemoved().size() + Util.PROPERTIES.getProperty("deletion.multi.done.logger.message"), msg);
                    Notificator.notificateDeletion(this, listaDeReceitas, STATE, 3000);
                    listaDeReceitas.getMultiSelectionRemoved().clear();
                }).start();
            } else {
                Notificator.notificateDeletion(this, listaDeReceitas, STATE, 3000);
                Logger.getLogger(AppContainer.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deletion.single.done.logger.message"), listaDeReceitas.getCurrentRemoving().getDescricao());
            }

        } else if (STATE.equals(ScrollableListContainerSimple.DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC)) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("deletion.single.error.logger.message"), listaDeReceitas.getCurrentRemoving().getDescricao());
            Notificator.notificateError(this, Util.PROPERTIES.getProperty("deletion.single.error.notificator.message") + " " + listaDeReceitas.getCurrentRemoving().getDescricao(), 3500);
            listaDeReceitas.setHasBeenNotificatedOnDeletion(true);
        }

        if (listaDeReceitas.size() == 0) {
            if (canShowNoSelectedPage()) {
                PageNavigator.goToPageSmoothly(this, nenhumaReceitaSelecionada);
            }
            setMenuAsEmptyListState();
        }
    }

    Item currentEditing = new Item("");
    List<String> names = new ArrayList<>();

    /**
     * Aplica lógica adequada de ações no livro de receitas container, quando
     * STATE do Selector mudar.<br>
     * Os estados podem ser <br>
     * NO SELECTION <br>
     * SINGLE SELECTION <br>
     * MULTI SELECTION
     *
     * @param STATE O stado do seletor.
     */
    private void handleReceitasSelectionUNselection(String STATE) {

        if (STATE.equals(Selector.NO_SELECTION)) {

            handle_NO_SELECTION_STATE();

        } else if (STATE.equals(Selector.SINGLE_SELECTION)) {
            if (isEditing()) {
                if (detalhesReceita.getCurrent() != null) {
                    currentEditing.setDescricao(detalhesReceita.getCurrent().getNome());
                } else {
                    currentEditing.setDescricao("???????????");
                }
                try {
                    if (!listaDeReceitas.getCurrentSelected().equals(currentEditing)) {
                        listaDeReceitas.reverseSingleSelection(currentEditing);
                    }
                } catch (Exception e) {
                }
                listaDeReceitas.shake();
            } else {
                handle_SINGLE_SELECTION_STATE();
            }

        } else if (STATE.equals(Selector.MULTI_SELECTION)) {

            handle_MULTI_SELECTION_STATE();

        } else if (STATE.equals(Selector.SELECTED_ALL)) {

            handle_SELECTED_ALL_STATE();

        } else if (STATE.equals(Selector.INVERTED_SELECTION_READY)) {

            handle_MULTI_SELECTION_STATE();

        }
    }

    private void handle_SELECTED_ALL_STATE() {
        //se selecionado, HAbilita opcao EXPORTAR SELECIONADAS DO MENU
        setMenuAsSomeSelectionState();
    }

    private void handle_MULTI_SELECTION_STATE() {
        //se selecionado, HAbilita opcao EXPORTAR SELECIONADAS DO MENU
        setMenuAsSomeSelectionState();

        if (isAnyActivityGoingOn()) {

            handleAnyActivityGoingOn();

        } else {

            handle_NO_ActivityGoingOn();
        }
    }

    private void handle_NO_ActivityGoingOn() {
        if (listaDeReceitas.getView().getSelection().size() == 1) {

            handle_SINGLE_SELECTION_STATE();

        } else {

        }
    }

    private void handleAnyActivityGoingOn() {

        if (detalhesReceita.isEditing() || currentPage.equals(detalhesReceita)) {

            currentEditing.setDescricao(detalhesReceita.getCurrent().getNome());
            names.clear();

            if (isCurrentEditingStillAtSelectionList()) {

            } else {

                //REMOVEU DA MULTI SELECTION O ITEM QUE ESTAVA NA PAGINA DE DETALHES
                if (canShowNoSelectedPage()) {
                    showNoSelectionPage();
                } else {
                    putCurrentEditingBackToSelectionList();
                }

            }
        } else if (novaReceita.hasNoActivity() && currentPage.equals(novaReceita)) {
            showNoSelectionPage();
        }

    }

    private void putCurrentEditingBackToSelectionList() {
        currentEditing.setDescricao(detalhesReceita.getCurrent().getNome());
        names.clear();
        names.add(currentEditing.getDescricao());
        listaDeReceitas.multiSelect(names);
    }

    private void showNoSelectionPage() {
        if (noCreationalActivityWatcher != null) {
            noCreationalActivityWatcher.stop();
        }
        PageNavigator.goToPageSmoothly(this, nenhumaReceitaSelecionada);
        new Thread(() -> {
            while (Notificator.isNotificating) {
            }
            cancelAllCRUD();
        }).start();
    }

    private boolean isCurrentEditingStillAtSelectionList() {
        return listaDeReceitas.getView().getSelection().contains(currentEditing);
    }

    public boolean isAnyActivityGoingOn() {
        return !currentPage.equals(nenhumaReceitaSelecionada);
    }

    public boolean isAnyActionGoingOn() {
        return !Menu.getInstance(this).getActions().getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void handle_SINGLE_SELECTION_STATE() {

        if (canSeeDetailsPage()) {
            cancelAllCRUD();
            PageNavigator.goToPageSmoothly(this, detalhesReceita);
            new Thread(() -> {
                while (isChangingPage) {
                }
                Platform.runLater(() -> {
                    setMenuAsSomeSelectionState();
                    handleDetalhesReceita();

                });
            }).start();
        } else {
            listaDeReceitas.shake();
            listaDeReceitas.unselect(listaDeReceitas.getCurrentSelected().getDescricao());
        }
    }

    /**
     * Diz se de fato está ocorrendo alguma atividade de edição.
     *
     * @return
     */
    public boolean isEditing() {
        return detalhesReceita.hasAnyActivity();
    }

    /**
     * Diz se de fato está ocorrendo alguma atividade de edição nesta receita.
     *
     * @param nomeReceita a receita que está sendo inquirida.
     * @return
     */
    private boolean isEditing(String nomeReceita) {
        return detalhesReceita.hasAnyActivity(nomeReceita);
    }

    private void handle_NO_SELECTION_STATE() {

        setMenuAsNoSelectionState();

        if (canShowNoSelectedPage()) {
            if (noCreationalActivityWatcher != null) {
                noCreationalActivityWatcher.stop();
            }
            PageNavigator.goToPageSmoothly(this, nenhumaReceitaSelecionada);
            new Thread(() -> {
                while (Notificator.isNotificating) {
                }
                cancelAllCRUD();
            }).start();
        } else {
            listaDeReceitas.shake();
            if (currentPage.equals(detalhesReceita)) {
                if (detalhesReceita.getCurrent() != null) {
                    listaDeReceitas.selectSingle(detalhesReceita.getCurrent().getNome());
                    Notificator.showNotificationPage(Notifications.get("ab", listaDeReceitas));
                }
            }
        }
    }

    private void handleNoCreationalActivities() {
        noCreationalActivityWatcher = new Thread(() -> {
            int sleep = 5000;

            while (isChangingPage()) {
            }

            if (isAdding()) {
                try {
                    Thread.sleep(sleep);
                    if (novaReceita.hasNoActivity()) {
                        Notificator.notificateWithCloseButton(this, Util.PROPERTIES.getProperty("adding.help.message"), 6000);
                        Thread.sleep(2 * sleep);
                    }
                } catch (Exception e) {
                }
                int TRIES = 1;
                int tries = TRIES;
                while (true) {
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (novaReceita.hasNoActivity()) {
                        Notificator.notificateWithCloseButton(this, Util.PROPERTIES.getProperty("adding.help.message"), sleep);
                    }
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    tries--;
                    if (tries > 0 && novaReceita.hasNoActivity()) {
                    } else {
                        if (novaReceita.hasNoActivity()) {
                            break;
                        } else {
                            tries = TRIES;
                        }
                    }
                }
                Platform.runLater(() -> {
                    novaReceita.handleCancelarMouseClicked(null);
                });
            }
        });
        noCreationalActivityWatcher.setDaemon(true);
        noCreationalActivityWatcher.start();
    }

    public String getTitle() {
        return title;
    }

    public Stage getStage() {
        return stage;
    }

    public ListaDeReceitas getListaDeReceitas() {
        return listaDeReceitas;
    }

    public Page getCurrentPage() {
        return currentPage;
    }

    public WelcomePage getWelcomePage() {
        return welcomePage;
    }

    public NenhumaReceitaSelecionada getNenhumaReceitaSelecionada() {
        return nenhumaReceitaSelecionada;
    }

    public NovaReceita getNovaReceita() {
        return novaReceita;
    }

    public DetalhesReceita getDetalhesReceita() {
        return detalhesReceita;
    }

    public ConfirmarSalvar getConfirmarSalvar() {
        return confirmarSalvar;
    }

    public NotificationPane getPageWrapper() {
        return pageWrapper;
    }

    public NotificationPage getNotificationPage() {
        return notificationPage;
    }

    public Menu getMenu() {
        return Menu.getInstance(this);
    }

    public Thread getNoCreationalActivityWatcher() {
        return noCreationalActivityWatcher;
    }

    public Collection<String> getNomesReceitasAssociadasA(Item item, Class tipoReceita) throws Exception {
        Collection<String> nomes = persistenceService.getNomesReceitasAssociadas(item.getDescricao(), tipoReceita);
        Collection<String> nomesRet = new ArrayList<>(nomes);
        nomes.clear();
        return nomesRet;
    }

    public Collection<String> getNomesReceitasAssociadasATipoCalorico(Item item) throws Exception {
        Collection<String> nomes = persistenceService.getNomesReceitasAssociadas(item.getDescricao(), TipoCaloria.class);
        Collection<String> nomesRet = new ArrayList<>(nomes);
        nomes.clear();
        return nomesRet;
    }

    public NovoTipoReceita getNovoTipoReceita() {

        NovoTipoReceita novoTipoReceita = null;
        try {
            if (novaReceita.getNovoTipoReceita().isVisible()) {
                novoTipoReceita = novaReceita.getNovoTipoReceita();
            }
            if (detalhesReceita.getNovoTipoReceita().isVisible()) {
                novoTipoReceita = detalhesReceita.getNovoTipoReceita();
            }
        } catch (Exception e) {
        }
        return novoTipoReceita;

    }

    public void setNoCreationalActivityWatcher(Thread noCreationalActivityWatcher) {
        this.noCreationalActivityWatcher = noCreationalActivityWatcher;
    }

    public Thread getShowHideNotificationThread() {
        return showHideNotificationThread;
    }

    public void setShowHideNotificationThread(Thread showHideNotificationThread) {
        this.showHideNotificationThread = showHideNotificationThread;
    }

    public void setCurrentPage(Page currentPage) {
        this.currentPage = currentPage;
    }

    private boolean canShowNoSelectedPage() {
        //MANTEM USUARIO NA PAGINA WELCOME ATÉ QUE ELE PROPRIO SAIA DELA.
        //SE USUARIO ESTIVER NA PAGINA WELCOME, RETORNA FALSE, INDICANDO QUE NAO PODE IR PARA NO SELECTED PAGE.
        if (currentPage.equals(welcomePage)) {
            return false;
        }
        //QUANDO USUARIO NAO ESTIVER MAIS NA WELCOMA PAGE... E QUANDO NAO HOUVER 
        //ATIVIDADE ALGUMA NAS PAGINAS, RETORNA TRUE INDICANDO QUE PODE MOSTRAR NO SELECTEC PAGE.
        return novaReceita.hasNoActivity() && detalhesReceita.hasNoActivity();
    }

    private boolean canSeeDetailsPage() {
        return novaReceita.hasNoActivity() && !isImporting();
    }

    public boolean canLogOut() {
        return novaReceita.hasNoActivity() && detalhesReceita.hasNoActivity() && !isImporting();
    }

    private void handleDetalhesReceita() {
        if (noCreationalActivityWatcher != null) {
            noCreationalActivityWatcher.stop();
        }
        setUpDetalhes(listaDeReceitas.getView().getSelection().get(0));
    }

    private void cancelAllCRUD() {
        if (isAdding()) {
            Platform.runLater(() -> {
                listaDeReceitas.ON_ADDITION().setValue(ScrollableListContainerSimple.ADDING_CANCELED);
                novaReceita.cleanUp();
                novaReceita.getSTATE().setValue(NovaReceita.ADDING_CANCELED);
            });
        }
    }

    private void setUpDetalhes(Item item) {

        try {

            detalhesReceita.cleanUp();
            Receita receita = persistenceService.getById(item.getDescricao());
            detalhesReceita.setCurrent(receita);

            new Thread(() -> {
                while (!detalhesReceita.isCleanedUp()) {
                };
                Platform.runLater(() -> {
                    detalhesReceita.fill(receita);
                    detalhesReceita.block();
                });
            }).start();

        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public boolean hasReceitas() {
        return listaDeReceitas.getView().getCurrentModel().size() != 0;
    }

    public void onAddCanceled() {
        if (noCreationalActivityWatcher != null) {
            noCreationalActivityWatcher.stop();
        }
        pageWrapper.hide();
        listaDeReceitas.ON_ADDITION().setValue(ScrollableListContainerSimple.ADDING_CANCELED);
        Notificator.notificate(this, Util.PROPERTIES.getProperty("on.adding.canceled.message"), 3000);
        listaDeReceitas.getView().requestFocus();
    }

    public void addNovaReceita(Receita novaReceita) {
        try {
            listaDeReceitas.add(novaReceita);
        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<TipoComida> toTiposComidas(List<String> tipos) {

        List<TipoComida> tiposComida = new ArrayList<>();

        try {

            for (String tipo : tipos) {

                tiposComida.add((TipoComida) persistenceService.getTipoReceitaById(TipoComida.class, tipo));

            }

        } catch (Exception e) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, e);
        }

        return tiposComida;

    }

    public List<TipoBebida> toTiposBebidas(List<String> tipos) {

        List<TipoBebida> tiposBebida = new ArrayList<>();

        try {

            for (String tipo : tipos) {

                tiposBebida.add((TipoBebida) persistenceService.getTipoReceitaById(TipoBebida.class, tipo));

            }

        } catch (Exception e) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, e);
        }

        return tiposBebida;

    }

    public TipoCaloria toTipoCaloria(String tipo) {

        TipoCaloria tc = null;

        try {
            tc = (TipoCaloria) persistenceService.getTipoReceitaById(TipoCaloria.class, tipo);
        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }

        return tc;
    }

    public void ensureVisibility() {

        new Thread(() -> {
            Platform.runLater(() -> {
                String text = pageWrapper.getText();
                pageWrapper.setText("");
                pageWrapper.show();
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ex) {
                    Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                }
                pageWrapper.hide();
                pageWrapper.setText(text);
            });
        }).start();

    }

    public void newReceita() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean isAdding() {
        return currentPage.equals(novaReceita) || currentPage.equals(confirmarSalvar);
    }

    // SESSAO PERSISTENCIA
    public void reloadTiposReceitas() {
        novaReceita.reloadAllTipoReceitaNow();
        detalhesReceita.reloadAllTipoReceitaNow();
    }

    public void saveTipoReceita(TipoReceita tipoReceita) throws Exception {
        persistenceService.createTipoReceita(tipoReceita);
    }

    public void deleteTipoReceita(TipoReceita tipoReceita) throws Exception {
        persistenceService.deleteTipoReceita(tipoReceita);
    }

    public Collection<TipoReceita> getAllTiposReceitas(Class clazz) {

        Collection tipos = null;
        String okLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.comidas.success.message");
        String errorLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.comidas.error.message");

        if (clazz.getSimpleName().equals("TipoBebida")) {
            okLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.bebidas.success.message");
            errorLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.bebidas.error.message");
        } else if (clazz.getSimpleName().equals("TipoCaloria")) {
            okLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.caloricos.success.message");
            errorLogMessage = Util.PROPERTIES.getProperty("retrieving.tipos.caloricos.error.message");;
        }

        try {
            tipos = persistenceService.getAllTiposReceitas(clazz);
            Logger.getLogger(AppContainer.class.getName()).log(Level.INFO, okLogMessage, tipos.size());
        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, errorLogMessage, ex);
        }

        return tipos;

    }

    public void save(Receita novaReceita) throws Exception {
        persistenceService.create(novaReceita);
    }

    public void save(Collection<Receita> receitas) throws Exception {
        persistenceService.createObjects(receitas);
    }

    public void update(Receita oldReceita, Receita newReceita) throws Exception {
        persistenceService.update(oldReceita, newReceita);
    }

    public void updateReceita(Receita oldReceita, Receita newReceita) {
        listaDeReceitas.edit(oldReceita, newReceita);
    }

    public void delete(String id) throws Exception {
        persistenceService.deleteById(id);
    }

    public void delete(Collection<Receita> bulk) throws Exception {
        persistenceService.deleteBulk(bulk);
    }

    public void deleteByIds(String... ids) throws Exception {
        persistenceService.deleteBulk(ids);
    }

    public void deleteTiposReceitaByIds(String[] ids, Class aClass) throws Exception {
        persistenceService.deleteTiposReceitaByIds(ids, aClass);
    }

    public TipoReceita getTipoReceitaById(Class clazz, String id) throws Exception {
        return persistenceService.getTipoReceitaById(clazz, id);
    }

    public void createTiposReceita(Collection<TipoReceita> tiposReceita) throws Exception {
        persistenceService.createTiposReceita(tiposReceita);
    }

    Splash splash;

    @Override
    public void start(Stage stage) throws Exception {

        splash = new Splash(this);
        //splash = null;
        if (splash == null) {

            handle_NO_SPLASH_Start(stage);

        } else {

            handle_SPLASH_Start(stage);

        }

        doLoadings(stage);

        setUpListeners();
    }

    private void handle_SPLASH_Start(Stage stage) {
        this.stage = stage;
        currentPage = nenhumaReceitaSelecionada;
//        nenhumaReceitaSelecionada.getLoaderPage().ON_UPDATE().addListener((observable, oldValue, newValue) -> {
//            splash.setValue(newValue.doubleValue());
//            splash.setMessage(nenhumaReceitaSelecionada.getLoaderPage().getSingleLoaderMessage());
//        });
        nenhumaReceitaSelecionada.getLoaderPage().addOutPut(splash);
        Scene splashScene = new Scene(splash);
        stage.setScene(splashScene);
        stage.setResizable(false);
        stage.initStyle(StageStyle.UNDECORATED);
//        stage.setAlwaysOnTop(true);
        stage.show();
    }

    volatile private FlowPane root;

    public FlowPane getRoot() {
        return root;
    }

    private void handle_NO_SPLASH_Start(Stage stage1) {
        this.stage = stage1;
        root = new FlowPane();
        pageWrapper.setContent(nenhumaReceitaSelecionada);
        root.getChildren().add(listaDeReceitas);
        root.getChildren().add(pageWrapper);
        currentPage = nenhumaReceitaSelecionada;
        Scene loadedBookScene = new Scene(root);
        stage1.setScene(loadedBookScene);
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        //set Stage boundaries to visible bounds of the main screen
        stage1.setX(primaryScreenBounds.getMinX());
        stage1.setY(primaryScreenBounds.getMinY());
        stage1.setWidth(primaryScreenBounds.getWidth());
        stage1.setHeight(primaryScreenBounds.getHeight());
        stage1.setTitle(title);
        stage1.show();
        listaDeReceitas.block();
        try {
//            stage.setFullScreen(true);
        } catch (Exception e) {
        }
        listaDeReceitas.setUp(loadedBookScene);
        nenhumaReceitaSelecionada.setUp(listaDeReceitas);
        listaDeReceitas.getView().requestFocus();
        stage1.setMinWidth(1100);
        stage1.setMinHeight(760);
    }

    private Runnable getReceitasLoadingRunnable(int sleep) {

        return () -> {

            Collection<Receita> receitas = new ArrayList<>();

            try {
                receitas = persistenceService.getAll();
            } catch (Exception ex) {
                Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
            }

            double i = 1;
            LoadingRunnable loaderUpdater = new LoadingRunnable(nenhumaReceitaSelecionada.getLoaderPage().getReceitasLoader());

            if (receitas.isEmpty()) {

                Platform.runLater(() -> {
                    setMenuAsEmptyListState();
                    nenhumaReceitaSelecionada.getLoaderPage().setReceitaLoaderValue(LoaderPage.NOTHING_TO_LOAD, "");
                });

            } else {

                if (splash == null) {
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                Platform.runLater(() -> {
                    listaDeReceitas.getView().setUp("dark-theme");
                    setMenuAsNotEmptyListState();
                });

                int intervalFromOneLoadAndAnother = Util.getintervalFromOneLoadAndAnother(receitas.size());

                if (splash == null) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                Platform.runLater(() -> {
                    listaDeReceitas.setUpBeforeLoading();
                });

                int importingBulkSize = Util.getImportBulkSize(receitas.size());
                List<Receita> tempReceitas = new ArrayList<>(receitas);
                Collection<List<Receita>> receitasBacthed = Util.batch(tempReceitas, importingBulkSize);
                tempReceitas.clear();
                Collection<Item> bulkItens = new ArrayList<>();
                for (List<Receita> receitasBatch : receitasBacthed) {

                    for (Receita receita : receitasBatch) {

                        Item item = Item.newInstance(receita.getNome(), listaDeReceitas.getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS);

                        i++;

                        bulkItens.add(item);

                    }

                    loaderUpdater.setUpdated(false);
                    loaderUpdater.setNewValue(i / receitas.size());
                    loaderUpdater.setMessage(((int) (i)) + "/" + receitas.size());
                    loaderUpdater.setSleep(intervalFromOneLoadAndAnother);
//                    loaderUpdater.setItem(item);

                    Platform.runLater(loaderUpdater);

                    while (!loaderUpdater.hasUpdated()) {
                    }

                    listaDeReceitas.loadBulk(bulkItens);

                    bulkItens.clear();

                }

                String message = Integer.toString(receitas.size());
                receitas.clear();
                bulkItens.clear();
                receitasBacthed.forEach((t) -> {
                    t.clear();
                    t = null;
                });

                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setReceitaLoaderValue(1, message);
                });

            }

            Platform.runLater(() -> {
                listaDeReceitas.getView().setUp("glass-theme");
                listaDeReceitas.setUpAfterLoading();
            });
        };
    }

    private void setMenuAsEmptyListState() {
        Menu.getInstance(this).setAsEmptyList();
    }

    private void setMenuAsNotEmptyListState() {
        Menu.getInstance(this).setAsNOTEmptyList();
    }

    private void setMenuAsNoSelectionState() {
        //se nada selecionado, desabilita opcao EXPORTAR SELECIONADAS DO MENU
        Menu.getInstance(this).setAsNoSelection();
    }

    private void setMenuAsSomeSelectionState() {
        //se selecionado, HAbilita opcao EXPORTAR SELECIONADAS DO MENU
        Menu.getInstance(this).setAsSomeSelection();
    }

    private Runnable getTiposComidasLoadingRunnable(int sleep) {
        return () -> {

            Collection<Item> allItens = new ArrayList<>();
            double i = 1;
            LoadingRunnable loaderUpdater = new LoadingRunnable(nenhumaReceitaSelecionada.getLoaderPage().getTipoComidaLoader());
            Collection<TipoReceita> allTipos = getAllTiposReceitas(TipoComida.class);

            if (allTipos.isEmpty()) {

                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoComidaLoaderValue(LoaderPage.NOTHING_TO_LOAD, "");
                });

            } else {

                for (TipoReceita tr : allTipos) {
                    allItens.add(Item.newInstance(tr.getNome(), novaReceita.getListaTiposComidas().getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
                    loaderUpdater.setNewValue(i / allTipos.size());
                    loaderUpdater.setMessage(((int) (i)) + "/" + allTipos.size());

                    Platform.runLater(loaderUpdater);
                    while (!loaderUpdater.hasUpdated()) {
                    }
                    loaderUpdater.setUpdated(false);
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    i++;
                }

                novaReceita.getListaTiposComidas().load(allItens);

                String message = Integer.toString(allTipos.size());
                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoComidaLoaderValue(1, message);
                });
            }
        };
    }

    private Runnable getTiposBebidasLoadingRunnable(int sleep) {
        return () -> {

            Collection<Item> allItens = new ArrayList<>();
            double i = 1;
            LoadingRunnable loaderUpdater = new LoadingRunnable(nenhumaReceitaSelecionada.getLoaderPage().getTipoBebidaLoader());
            Collection<TipoReceita> allTipos = getAllTiposReceitas(TipoBebida.class);

            if (allTipos.isEmpty()) {

                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoBebidaLoaderValue(LoaderPage.NOTHING_TO_LOAD, "");
                });

            } else {

                for (TipoReceita tr : allTipos) {
                    allItens.add(Item.newInstance(tr.getNome(), novaReceita.getListaTiposBebidas().getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
                    loaderUpdater.setNewValue(i / allTipos.size());
                    loaderUpdater.setMessage(((int) (i)) + "/" + allTipos.size());
                    Platform.runLater(loaderUpdater);
                    while (!loaderUpdater.hasUpdated()) {
                    }
                    loaderUpdater.setUpdated(false);
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    i++;
                }

                novaReceita.getListaTiposBebidas().load(allItens);

                String message = Integer.toString(allTipos.size());
                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoBebidaLoaderValue(1, message);
                });
            }

        };
    }

    private Runnable getTiposCaloriasLoadingRunnable(int sleep) {
        return () -> {

            Collection<Item> allItens = new ArrayList<>();
            double i = 1;
            LoadingRunnable loaderUpdater = new LoadingRunnable(nenhumaReceitaSelecionada.getLoaderPage().getTipoCaloriaLoader());
            Collection<TipoReceita> allTipos = getAllTiposReceitas(TipoCaloria.class);

            if (allTipos.isEmpty()) {

                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoCaloriaLoaderValue(LoaderPage.NOTHING_TO_LOAD, "");
                });

            } else {

                for (TipoReceita tr : allTipos) {
                    allItens.add(Item.newInstance(tr.getNome(), novaReceita.getListaTiposCalorias().getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
                    loaderUpdater.setNewValue(i / allTipos.size());
                    loaderUpdater.setMessage(((int) (i)) + "/" + allTipos.size());
                    Platform.runLater(loaderUpdater);
                    while (!loaderUpdater.hasUpdated()) {
                    }
                    loaderUpdater.setUpdated(false);
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    i++;
                }

                novaReceita.getListaTiposCalorias().load(allItens);

                String message = Integer.toString(allTipos.size());
                Platform.runLater(() -> {
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoCaloriaLoaderValue(1, message);
                });
            }
        };
    }

    public void unselect(String nome) {
        Platform.runLater(() -> {
            listaDeReceitas.unselect(nome);
        });
    }

    public Receita getReceita(String id) throws Exception {
        return persistenceService.getById(id);
    }

    public void importar(Receita receita) throws Exception {
        listaDeReceitas.importar(receita);
    }

    public void importar(Collection<Receita> receitas) throws Exception {
        listaDeReceitas.importar(receitas);
    }

    private boolean isImporting() {
        return Menu.getInstance(this).isImporting();
    }

    public void desimportar(Collection<Receita> receitas) throws Exception {
        listaDeReceitas.desimportar(receitas);
    }

    public void desimportar(Receita receita) throws Exception {
        listaDeReceitas.desimportar(receita);
    }

    public void exportSelected() {
        Menu.getInstance(this).handleExportSelected();
    }

    public void printSelected() {
        Menu.getInstance(this).handlePrintSelected();
    }

//    public synchronized boolean canExecuteClientHookDeletionLogic(String nomeReceita) {
//        return !isPreEditing(nomeReceita) && !isEditingContextHelp();
//    }
    public synchronized boolean canExecuteClientHookDeletionLogic(String nomeReceita) {
        return !isEditing(nomeReceita);
    }

    /**
     * Diz se receita está selecionada na página de edição/detalhes<br>
     * MAS NÃO ESTÁ SENDO EDITADA.
     *
     * @param nome
     * @return
     */
    public synchronized boolean isPreEditing(String nome) {
        if (detalhesReceita.getCurrent() == null) {
            return false;
        }
        return currentPage.equals(detalhesReceita) && detalhesReceita.getCurrent().getNome().equals(nome) && detalhesReceita.hasNoActivity();
    }

    /**
     * Diz se ALGUMA receita está selecionada na página de edição/detalhes<br>
     * MAS NÃO ESTÁ SENDO EDITADA.
     *
     * @return
     */
    public synchronized boolean isPreEditing() {
        return currentPage.equals(detalhesReceita) && detalhesReceita.hasNoActivity();
    }

    /**
     * Limpa pagina de edicao e vai para pagina nenhum objeto selecionado.
     *
     */
    public synchronized void cancelPreEditing() {
        if (isPreEditing()) {
            detalhesReceita.getSTATE().setValue(DetalhesReceita.STATELESS);
            detalhesReceita.cleanUp();
            PageNavigator.goToPageSmoothly(this, nenhumaReceitaSelecionada);
        };
    }

    /**
     * Before shutDown hook.<br>
     * Toma conta de coisas necessárias antes da encerrar a VM.
     *
     * @see br.com.undra.livrodereceitas.App#stop()
     */
    public void beforeShutDown() {
        Logger.getLogger(getClass().getName()).log(Level.INFO, "Before shutdown hook executing");
        Menu.getInstance(this).getAboutPage().disposeDirect();
        Menu.getInstance(this).getAboutPage().dispose();
        Helper.beforeShutDown();

        if (showHideNotificationThread != null) {
            showHideNotificationThread.stop();
        }
        if (setupListenersThread != null) {
            setupListenersThread.stop();
        }
        listaDeReceitas.setIsRemovingMultiSelectionCanceled(true);
        listaDeReceitas.saveLookAndFeel(getClass().getSimpleName());
        nenhumaReceitaSelecionada.beforeShutDown();
        novaReceita.beforeShutDown();
        confirmarSalvar.beforeShutDown();
        detalhesReceita.beforeShutDown();
        welcomePage.beforeShutDown();
    }

    public boolean hasNoActivity() {
        return getCurrentPage().equals(nenhumaReceitaSelecionada) || getCurrentPage().equals(welcomePage) || (novaReceita.hasNoActivity() && !isEditing());
    }

    public boolean isSearching() {
        return listaDeReceitas.getView().getSearcherContainer().getSearcher().getState().equals(Searcher.SEARCHING);
    }

    public boolean isAboutActiveBeforeAltF4() {
        if (Menu.getInstance(this).getAboutPage() != null) {
            return Menu.getInstance(this).getAboutPage().isShowing();
        } else {
            return false;
        }
    }

    private volatile boolean isNovoTipoReceitaVisible = false;

    public boolean isNovoTipoReceitaVisible() {
        isNovoTipoReceitaVisible = false;
        try {
            if (novaReceita.getNovoTipoReceita().isVisible()) {
                isNovoTipoReceitaVisible = true;
            }
            if (detalhesReceita.getNovoTipoReceita().isVisible()) {
                isNovoTipoReceitaVisible = true;
            }
        } catch (Exception e) {
        }
        return isNovoTipoReceitaVisible;
    }

    class LoadingRunnable implements Runnable {

        double newValue;
        Pane loader;
        int sleep;
        Item item;
        String message;
        volatile boolean updated = false;

        public LoadingRunnable(Pane loader) {
            this.loader = loader;
        }

        @Override
        public void run() {
            switch (loader.getId()) {
                case "receitasLoader":
                    nenhumaReceitaSelecionada.getLoaderPage().setReceitaLoaderValue(newValue, message);
//                    listaDeReceitas.load(item);
                    listaDeReceitas.setProgressValue(newValue);
                    break;
                case "tipoComidaLoader":
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoComidaLoaderValue(newValue, message);
                    break;
                case "tipoBebidaLoader":
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoBebidaLoaderValue(newValue, message);
                    break;
                case "tipoCaloriaLoader":
                    nenhumaReceitaSelecionada.getLoaderPage().setTipoCaloriaLoaderValue(newValue, message);
                    break;
                default:
                    break;
            }

            updated = true;
        }

        public void setNewValue(double newValue) {
            this.newValue = newValue;
        }

        public void setSleep(int sleep) {
            this.sleep = sleep;
        }

        public void setItem(Item item) {
            this.item = item;
        }

        private void setMessage(String message) {
            this.message = message;
        }

        private void setUpdated(boolean b) {
            updated = b;
        }

        private boolean hasUpdated() {
            return updated;
        }

    }

    private void doLoadings(Stage stage) {

        this.stage = stage;

        Platform.runLater(() -> {

            listaDeReceitas.block();

            setUpLoaderPage();
            EventHandler doLoadings = getLoadingsHandler(stage);
            FadeTransition fadeInLoaderPage = new FadeTransition(Duration.seconds(0.5), nenhumaReceitaSelecionada.getLoaderPage());
            fadeInLoaderPage.setFromValue(0.0);
            fadeInLoaderPage.setToValue(0.88);
            fadeInLoaderPage.setOnFinished(doLoadings);
            fadeInLoaderPage.play();

        });

    }

    private EventHandler getLoadingsHandler(Stage stage) {
        return (event) -> {

            LoaderPage loader = nenhumaReceitaSelecionada.getLoaderPage();
            int sleep = 1;
            if (splash == null) {
                sleep = 600;
            }
            Runnable receitas = getReceitasLoadingRunnable(sleep);
            Runnable tiposComidas = getTiposComidasLoadingRunnable(sleep);
            Runnable tiposBebidas = getTiposBebidasLoadingRunnable(sleep);
            Runnable tiposCalorias = getTiposCaloriasLoadingRunnable(sleep);

            loader.load(receitas, tiposComidas, tiposBebidas, tiposCalorias);

            new Thread(() -> {

                while (!loadingsDone()) {
                }

                Platform.runLater(() -> {

                    if (splash != null) {

                        new Thread(() -> {
                            Platform.runLater(() -> {
                                //PRA QUE ESSA LINHA ? NAO COMENTEI ANTES E AGORA NAO ME RECORDO.
                                //SE RETIRADA, APARENTEMENTE, NAO CAUSA IMPACTO.
                                nenhumaReceitaSelecionada.getLoaderPage().ON_UPDATE().setValue(1);
                            });
                        }).start();
                        try {
                            Thread.sleep(500);
                        } catch (Exception e) {
                        }

                        stage.close();

                        Stage newStage = new Stage();

                        newStage.setResizable(true);

                        root = new FlowPane();

                        pageWrapper.setContent(nenhumaReceitaSelecionada);

                        root.getChildren().add(listaDeReceitas);
                        root.getChildren().add(pageWrapper);

                        Scene loadedBookScene = new Scene(root);
                        newStage.setScene(loadedBookScene);
                        newStage.show();

                        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
                        //set Stage boundaries to visible bounds of the main screen
                        newStage.setX(primaryScreenBounds.getMinX());
                        newStage.setY(primaryScreenBounds.getMinY());
                        newStage.setWidth(primaryScreenBounds.getWidth());
                        newStage.setHeight(primaryScreenBounds.getHeight());
                        newStage.setTitle(title);

                        listaDeReceitas.block();

                        listaDeReceitas.setUp(loadedBookScene);
                        nenhumaReceitaSelecionada.setUp(listaDeReceitas);
                        nenhumaReceitaSelecionada.getLoaderPage().setVisible(false);

                        listaDeReceitas.getView().requestFocus();
                        newStage.setMinWidth(1100);
                        newStage.setMinHeight(760);
                        doLoadingsDone(newStage);
                    } else {
                        doLoadingsDone(stage);
                    }
                });

            }, "DO LOADINGS DONE - Thread").start();

        };
    }

    private void doLoadingsDone(Stage stage) {

        this.stage = stage;

        if (nenhumaReceitaSelecionada.getLoaderPage().isSingleLoader()) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException ex) {
            }
        } else {
            try {
                Thread.sleep(4000);
            } catch (InterruptedException ex) {
            }
        }

        if (splash == null) {
            Platform.runLater(() -> {

                EventHandler fadeOutLoaderPageHandler = getFadeOutLoaderPageHandler(stage);

                FadeTransition fadeOutLoaderPage = new FadeTransition(Duration.seconds(1.0), nenhumaReceitaSelecionada.getLoaderPage());

                fadeOutLoaderPage.setFromValue(0.85);
                fadeOutLoaderPage.setToValue(0);
                fadeOutLoaderPage.setOnFinished(fadeOutLoaderPageHandler);
                fadeOutLoaderPage.play();

            });
        } else {

            //MANTEM EM FULL SCREEN
            stage.setFullScreenExitHint("");
            Platform.runLater(() -> {
                try {
                    stage.setFullScreen(true);
                } catch (Exception e) {
                }

                //MANTEM EM FULL SCREEN
                stage.fullScreenProperty().addListener((observable, oldValue, newValue) -> {
                    if (!newValue) {
                        try {
                            stage.setFullScreen(true);
                        } catch (Exception e) {
                        }
                    }
                });

                if (welcomePage.isMostrarNaInicializacao()) {
                    PageNavigator.goToPage(this, welcomePage);
                } else {
                    PageNavigator.goToPage(this, nenhumaReceitaSelecionada);
                }
                listaDeReceitas.unblock();
                listaDeReceitas.restoreLookAndFeel(getClass().getSimpleName());
            });
        }
    }

    public boolean loadingsDone() {

        try {
            return nenhumaReceitaSelecionada.getLoaderPage().isLoaded();
        } catch (Exception e) {
        }

        return false;
    }

    private EventHandler getFadeOutLoaderPageHandler(Stage stage) {
        return (evt) -> {

            nenhumaReceitaSelecionada.getLoaderPage().setVisible(false);

            try {
                stage.setFullScreen(true);
            } catch (Exception e) {
            }

            handleOpenningMessage();
            listaDeReceitas.unblock();

        };
    }

    private void setUpLoaderPage() {
        FadeTransition f1 = new FadeTransition(Duration.seconds(4.0), nenhumaReceitaSelecionada.getLoaderPage().getReceitasLoader());
        f1.setFromValue(1);
        f1.setToValue(0);
        f1.setOnFinished((event) -> {
            nenhumaReceitaSelecionada.getLoaderPage().getReceitasLoader().setOpacity(1);
        });
        f1.play();
        FadeTransition f2 = new FadeTransition(Duration.seconds(4.0), nenhumaReceitaSelecionada.getLoaderPage().getTipoComidaLoader());
        f2.setFromValue(1);
        f2.setToValue(0);
        f2.setOnFinished((event) -> {
            nenhumaReceitaSelecionada.getLoaderPage().getTipoComidaLoader().setOpacity(1);
        });
        f2.play();
        FadeTransition f3 = new FadeTransition(Duration.seconds(4.0), nenhumaReceitaSelecionada.getLoaderPage().getTipoBebidaLoader());
        f3.setFromValue(1);
        f3.setToValue(0);
        f3.setOnFinished((event) -> {
            nenhumaReceitaSelecionada.getLoaderPage().getTipoBebidaLoader().setOpacity(1);
        });
        f3.play();
        FadeTransition f4 = new FadeTransition(Duration.seconds(4.0), nenhumaReceitaSelecionada.getLoaderPage().getTipoCaloriaLoader());
        f4.setFromValue(1);
        f4.setToValue(0);
        f4.setOnFinished((event) -> {
            nenhumaReceitaSelecionada.getLoaderPage().getTipoCaloriaLoader().setOpacity(1);
        });
        f4.play();
    }

    /**
     * Executa várias açoes antes da VM encerrar.
     *
     * @see #beforeShutDown()
     * @throws Exception
     */
    @Override
    public void stop() throws Exception {
        beforeShutDown();
        Logger.getLogger(getClass().getName()).log(Level.INFO, "{0} stopped!", title);
    }
}
