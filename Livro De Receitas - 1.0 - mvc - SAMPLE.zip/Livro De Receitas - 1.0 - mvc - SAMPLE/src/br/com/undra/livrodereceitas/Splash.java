package br.com.undra.livrodereceitas;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.util.Fonts;
import java.io.IOException;
import java.io.OutputStream;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

/**
 *
 * @author alexandre
 */
public class Splash extends Pane implements Output {

    AppContainer container;

    public Splash(AppContainer container) {
        this.container = container;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLSplash.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        setValue(0);
        splashAppName.setFont(Fonts.APP_FONT_SPLASH_NAME);
        splashAppName.setText("    " + Util.PROPERTIES.getProperty("title").toUpperCase());
        developer.setText("                                      "+Util.getDeveloperAndContact());
    }

    @FXML
    private Pane splashProgressBar;

    @FXML
    private Label splashMessage;

    @FXML
    private Label splashAppName;

    @FXML
    private Label developer;

    public void setValue(double newValue) {
        if (0 <= newValue && newValue <= 1) {
            splashProgressBar.setPrefWidth(getPrefWidth() * newValue);
        }
    }

    public void setMessage(String msg) {
        splashMessage.setText(msg);
    }

    @Override
    public void write(Object o) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void write(String s) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void write(OutputStream os) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void write(Object... o) throws Exception {

        setValue((Double) o[0]);
        setMessage((String) o[1]);

    }

    @Override
    public void write(String... s) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void write(OutputStream... os) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
