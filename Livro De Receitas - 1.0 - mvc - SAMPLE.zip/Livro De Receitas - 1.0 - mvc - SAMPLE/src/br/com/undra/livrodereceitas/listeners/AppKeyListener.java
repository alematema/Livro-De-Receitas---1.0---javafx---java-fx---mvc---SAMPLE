package br.com.undra.livrodereceitas.listeners;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.ListaDeReceitas;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposBebidas;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposCalorias;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposComidas;
import br.com.undra.livrodereceitas.util.Helper;
import br.com.undra.livrodereceitas.util.Notificator;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;

/**
 * The App key listener
 *
 * @author alexandre
 */
public class AppKeyListener implements EventHandler<KeyEvent> {

    private final AppContainer appContainer;
    private boolean wasCtrlPressed = false;
    private boolean wasAltPressed = false;

    public AppKeyListener(AppContainer appContainer) {
        this.appContainer = appContainer;
    }

    @Override
    public void handle(KeyEvent e) {

//        if(!e.isControlDown() && !e.isAltDown()){
//            wasAltPressed = false;
//            wasAltPressed = false;
//            return;
//        }
        //SÓ PARA TESTAR
        if (wasCtrlPressed && e.getCode() == KeyCode.O) {
            wasCtrlPressed = false;
            Platform.runLater(() -> {
                Notificator.notificateWarning(appContainer, Long.toString(System.nanoTime()), 2000);
            });
            return;
        }
        if (wasCtrlPressed && e.getCode() == KeyCode.M) {
            wasCtrlPressed = false;
            //MENU ABRIR/FECHAR
            handle_M_KEY();
            return;
        }

        if (wasCtrlPressed && e.getCode() == KeyCode.I) {
            wasCtrlPressed = false;
            //IMPORTACAO
            handle_I_KEY();
            return;
        }
        if (wasCtrlPressed && e.getCode() == KeyCode.E) {
            wasCtrlPressed = false;
            //EXPORTACAO
            handle_E_KEY();
            return;
        }
        if (wasCtrlPressed && e.getCode() == KeyCode.P) {
            wasCtrlPressed = false;
            //IMPRESSAO
            handle_P_KEY();
            return;
        }
        if (wasCtrlPressed && e.getCode() == KeyCode.K) {
            wasCtrlPressed = false;
            //MAPA ATALHOS TECLADO
            handle_K_KEY();
            return;
        }
        //PARA ANULAR CRTL + A DO GlobalKeyListener, o listener do Componnente Scrollador
        if (wasCtrlPressed && e.getCode() == KeyCode.A) {
            wasCtrlPressed = false;
            return;
        }
        //Para ABRIR ajuda master usando Ctrl+N
        if (wasCtrlPressed && e.getCode() == KeyCode.N) {
            wasCtrlPressed = false;
            Platform.runLater(() -> {
                appContainer.getListaDeReceitas().getView().handleAddItemMouseClicked(null);
            });
            return;
        }
        if (wasCtrlPressed && e.getCode() == KeyCode.H) {
            wasCtrlPressed = false;
            handle_H_KEY();
            return;
        }

        switch (e.getCode()) {
            case CONTROL:
                wasCtrlPressed = true;
                break;
            case ESCAPE:
                handle_ESCAPE_KEY();
                break;
            case ENTER:
                handle_ENTER_KEY();
                break;
            case F1:
                handle_F1_KEY();
                break;
            case F4:
                if (wasAltPressed) {
                    handle_ALT_F4();
                }
                break;
            case ALT:
                wasAltPressed = true;
                break;
            default:
                break;
        }
    }

    private void handle_M_KEY() {
        if (Menu.getInstance(appContainer).isVisible()) {
            Menu.getInstance(appContainer).setVisible(false);
        } else {
            Menu.getInstance(appContainer).setVisible(true);
        }
    }

    private void handle_I_KEY() {
        //IMPORTAÇÃO
        Platform.runLater(() -> {
            Menu.getInstance(appContainer).handleImporting();
        });
    }

    private void handle_E_KEY() {
        //EXPORTAÇÃO
        if (appContainer.getListaDeReceitas().getView().getSelection().size() > 0) {
            Platform.runLater(() -> {
                Menu.getInstance(appContainer).handleExportSelected();
            });
        } else {
            Platform.runLater(() -> {
                Menu.getInstance(appContainer).handleExportAll();
            });
        }

    }

    private void handle_P_KEY() {
        //IMPRESSAO EM PDF
        if (appContainer.getListaDeReceitas().getView().getSelection().size() > 0) {
            if (appContainer.getListaDeReceitas().isSelecting()) {
                Platform.runLater(() -> {
                    Menu.getInstance(appContainer).handlePrintAll();
                });
            } else {
                Platform.runLater(() -> {
                    Menu.getInstance(appContainer).handlePrintSelected();
                });
            }
        } else {
            Platform.runLater(() -> {
                Menu.getInstance(appContainer).handlePrintAll();
            });
        }
    }

    /**
     * Handler para abrir ajuda master do menu usando Ctrl+H
     */
    private void handle_H_KEY() {
        Platform.runLater(() -> {
            Menu.getInstance(appContainer).handleOpenMasterHelpPdf();
        });
    }

    /**
     * Handler para mostrar mapa atalhos do teclado.
     */
    private void handle_K_KEY() {
        Menu.getInstance(appContainer).handleOpenMapaAtalhosTecladoPdf();
    }

    /**
     * Handler para confirmações através de enter key.
     *
     * @return
     */
    private boolean handle_ENTER_KEY() {
        //CONFIRMA O QUE ESTIVER SENDO NOTIFICADO NA PAGINA DE NOFITICACAO.
        //TEM PRIORIDADE SOBRE OUTRAS OPERACOES , COMO NOVA RECEITA, ETC.
        if (appContainer.getNotificationPage().isVisible()) {
            Platform.runLater(() -> {
                appContainer.getNotificationPage().getDefOkBtn().fire();
            });
            return true;
        }

        //CONFIRMA SALVAR O NOVo TIPO RECEITA
        if (appContainer.getNovoTipoReceita()!=null&&appContainer.getNovoTipoReceita().isVisible()) {
            appContainer.getNovoTipoReceita().handleSalvarTipoReceitaMouseClicked(null);
        }

        //MENU ACTIONS
        //CONFIRMA COM ENTER KEY A ACAO QUE ESTIVER EXPOSTA
        if (appContainer.getMenu().getActions().isVisible()) {
            Platform.runLater(() -> {
                Menu.getInstance(appContainer).getActions().getExecutarMenuAction().fire();
            });
            return true;
        }
        //CONFIRMA SALVAR A NOVA RECEITA
        if (appContainer.isAdding()) {
            if (appContainer.getCurrentPage().equals(appContainer.getConfirmarSalvar())) {
                Platform.runLater(() -> {
                    appContainer.getConfirmarSalvar().clickConfirmar();
                    appContainer.getListaDeReceitas().getView().requestFocus();
                });
            }
        }
        return false;
    }

    /**
     * Handler para cancelamentos.
     */
    private void handle_ESCAPE_KEY() {

        if (Menu.getInstance(appContainer).isVisible()) {
            Menu.getInstance(appContainer).setVisible(false);
        }

        //CANCELA O QUE ESTIVER SENDO NOTIFICADO NA PAGINA DE NOFITICACAO.
        //TEM PRIORIDADE SOBRE OUTRAS OPERACOES , COMO CANCELAR NOVA RECEITA, ETC.
        if (appContainer.getNotificationPage().isVisible()) {
            Platform.runLater(() -> {
                appContainer.getNotificationPage().getDefCancelBtn().fire();
            });
            return;
        }

        //CANCELA COM ESC NOVA TIPO RECEITA
        if (appContainer.isNovoTipoReceitaVisible()) {
            appContainer.getNovoTipoReceita().handlecancelarSalvarTipoReceitaMouseClicked(null);
        }

        //MENU ACTIONS
        //CANCELA COM ESCAPE A ACAO EXPOSTA
        if (Menu.getInstance(appContainer).getActions().isVisible()) {
            Platform.runLater(() -> {
                Menu.getInstance(appContainer).getActions().getCancelarMenuAction().fire();
            });
            return;
        }

        //CANCELA COM ESC NOVA RECEITA
        if (appContainer.getCurrentPage().equals(appContainer.getNovaReceita()) && appContainer.getNovaReceita().canAdditionBeCanceledByEscKey()) {
            Platform.runLater(() -> {
                appContainer.getNovaReceita().handleCancelarMouseClicked(null);
                appContainer.getListaDeReceitas().getView().requestFocus();
            });
            //CANCELA COM ESC CONFIRMA SALVAR RECEITA
        } else if (appContainer.getCurrentPage().equals(appContainer.getConfirmarSalvar()) && (appContainer.getConfirmarSalvar().isFocusedd())) {
            Platform.runLater(() -> {
                appContainer.getConfirmarSalvar().clickCancelar();
                appContainer.getListaDeReceitas().getView().requestFocus();
            });
            //CANCELA COM ESC EDITAR RECEITA
        } else if (appContainer.getCurrentPage().equals(appContainer.getDetalhesReceita()) && appContainer.getDetalhesReceita().canEditionBeCanceledByEscKey()) {

            if (appContainer.getDetalhesReceita().isEditing()) {
                Platform.runLater(() -> {
                    appContainer.getDetalhesReceita().handleCancelarEditarMouseClicked(null);
                    appContainer.getListaDeReceitas().getView().requestFocus();
                });
            } else {
                Platform.runLater(() -> {
                    appContainer.getDetalhesReceita().desapear();
                    appContainer.getListaDeReceitas().getView().requestFocus();
                });
            }
        }
    }

    /**
     * Handler para mostrar ajuda contextualizada.
     */
    private void handle_F1_KEY() {
        if (Helper.isCreatingContextHelp(appContainer)) {

            /**
             * If mouse points to add item icon, then shows creation helper pdf
             * contextualizedly.
             */
            if (Helper.isAddItemIcon(appContainer)) {

                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class)) {
                    Helper.openCreateTiposComidasHelperPdfViewer();
                    return;
                }
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class)) {
                    Helper.openCreateTiposBebidasHelperPdfViewer();
                    return;
                }
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class)) {
                    Helper.openCreateTiposCaloriasHelperPdfViewer();
                    return;
                }

            }

            Helper.openCreateHelperPdfViewer();
            return;
        }
        if (Helper.isEditingContextHelp(appContainer)) {
            Helper.openEditHelperPdfViewer();
            return;
        }
        if (Helper.isScrollerContextHelp(appContainer)) {
            //The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
            if (Helper.getCurrentContext(appContainer).getClass().equals(ListaDeReceitas.class) && appContainer.getListaDeReceitas().getView().getCurrentModel().isEmpty()) {
                Helper.openCreateHelperPdfViewer();
                return;
            }
            if (appContainer.isPreEditing() || appContainer.isEditing()) {

                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class) && (appContainer.getDetalhesReceita().getListaTiposComidas().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposComidasHelperPdfViewer();
                    return;
                }
                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class) && (appContainer.getDetalhesReceita().getListaTiposBebidas().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposBebidasHelperPdfViewer();
                    return;
                }
                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class) && (appContainer.getDetalhesReceita().getListaTiposCalorias().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposCaloriasHelperPdfViewer();
                    return;
                }

            } else if (appContainer.getCurrentPage().equals(appContainer.getNovaReceita())) {
                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class) && (appContainer.getNovaReceita().getListaTiposComidas().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposComidasHelperPdfViewer();
                    return;
                }
                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class) && (appContainer.getNovaReceita().getListaTiposBebidas().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposBebidasHelperPdfViewer();
                    return;
                }
                // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class) && (appContainer.getNovaReceita().getListaTiposCalorias().getView().getCurrentModel().isEmpty())) {
                    Helper.openCreateTiposCaloriasHelperPdfViewer();
                    return;
                }
            }

            /**
             * The scroller list is the context and it is NOT empty.Shows the
             * selection,searching,navigations helper pdf.
             */
            Helper.openListHelperPdfViewer();
            return;
        }
        if (Helper.isEditingOrAddingConfirmation(appContainer)) {
            if (Helper.isEditing(appContainer)) {
                Helper.openEditingConfirmationHelperPdfViewer();
            } else {
                Helper.openAddingConfirmationHelperPdfViewer();
            }
            return;
        }
        if (Helper.isSearchingContextHelp(appContainer)) {
            Helper.openSearchingHelperPdfViewer();
            return;
        }
        if (Helper.isMenuContextHelp(appContainer)) {

            if (Helper.getCurrentContextId(appContainer) != null) {

                try {

                    Text action = (Text) Helper.getCurrentContextId(appContainer);

                    if (action.equals(Menu.getInstance(appContainer).getImprimir())) {
                        Helper.openMasterHelperPdfViewer(35, Util.PROPERTIES.getProperty("printing.all.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getImprimirSelecionadas())) {
                        Helper.openMasterHelperPdfViewer(38, Util.PROPERTIES.getProperty("printing.selected.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getExportar())) {
                        Helper.openMasterHelperPdfViewer(28, Util.PROPERTIES.getProperty("export.all.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getExportarSelecionadas())) {
                        Helper.openMasterHelperPdfViewer(30, Util.PROPERTIES.getProperty("export.selected.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getImportar())) {
                        Helper.openMasterHelperPdfViewer(32, Util.PROPERTIES.getProperty("import.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getAjuda())) {
                        Helper.openMasterHelperPdfViewer();
                    } else if (action.equals(Menu.getInstance(appContainer).getMapaAtalhos())) {
                        Helper.openMasterHelperPdfViewer(55, Util.PROPERTIES.getProperty("shortcuts.helper.pdf.viewer.title"));
                    } else if (action.equals(Menu.getInstance(appContainer).getAbout())) {
                        Helper.openMasterHelperPdfViewer(57, Util.PROPERTIES.getProperty("about.helper.pdf.viewer.title"));
                    }

                } catch (Exception e) {
                }
            } else {
            }

            return;
        }

        if (Helper.isNoSelectionPageContextHelp(appContainer)) {
        }
        if (!Helper.isSearchingContextHelp(appContainer) && !Helper.isEditingOrAddingConfirmation(appContainer) && !Helper.isCreatingContextHelp(appContainer) && !Helper.isEditingContextHelp(appContainer) && !Helper.isScrollerContextHelp(appContainer)) {
            Helper.openMasterHelperPdfViewer();
        }
    }

    private void handle_ALT_F4() {
        wasAltPressed = false;
        appContainer.beforeShutDown();
        //Closes any other window, except the application window... and do nothing
        if (!altF4ClosedAppContainer()) {
        } else {

            //Do before shutdown stuffs and then shuts down the app.
//            appContainer.beforeShutDown();
//            Logger.getLogger(getClass().getName()).log(Level.INFO, "ALT+F4 handler : INVOKING app.beforeShutDown()");
        }
    }

    /**
     * Tells if no one other window, except the application window, was closed
     * by ALT+F4
     *
     * @return
     */
    private boolean altF4ClosedAppContainer() {
        return !Helper.isPdfViewerActiveBeforeAltF4() && !appContainer.isAboutActiveBeforeAltF4();
    }

    /**
     * Before shutDown hook.<br>
     *
     * @see br.com.undra.livrodereceitas.App#stop()
     */
    public void beforeShutDown() {
    }

}
