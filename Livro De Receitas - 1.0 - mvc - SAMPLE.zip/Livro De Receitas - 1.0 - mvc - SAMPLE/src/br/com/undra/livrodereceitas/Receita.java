package br.com.undra.livrodereceitas;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoCaloria;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import java.util.List;
import java.util.Objects;

/**
 * Modela uma receita.
 *
 * @author alexandre
 */
public class Receita implements Comparable<Receita> {

    public static String TIPO_COMIDA = "COMIDA";
    public static String TIPO_BEBIDA = "BEBIDA";

    public static int count = 0;

    private String nome;
    private String ingredientes;
    private String modoPreparo;
    private String tipoReceita;

    private List<TipoComida> tiposComida;
    private TipoCaloria tipoCaloria;

    private List<TipoBebida> tiposBebida;

    public Receita(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getModoPreparo() {
        return modoPreparo;
    }

    public void setModoPreparo(String modoPreparo) {
        this.modoPreparo = modoPreparo;
    }

    public List<TipoComida> getTiposComida() {
        return tiposComida;
    }

    public void setTiposComida(List<TipoComida> tiposComida) {
        this.tiposComida = tiposComida;
    }

    public TipoCaloria getTipoCaloria() {
        return tipoCaloria;
    }

    public void setTipoCaloria(TipoCaloria tipoCaloria) {
        this.tipoCaloria = tipoCaloria;
    }

    public List<TipoBebida> getTiposBebida() {
        return tiposBebida;
    }

    public void setTiposBebida(List<TipoBebida> tiposBebida) {
        this.tiposBebida = tiposBebida;
    }

    public String getTipoReceita() {
        return tipoReceita;
    }

    public void setTipoReceita(String tipoReceita) {
        this.tipoReceita = tipoReceita;
    }

    public String getTipoReceitaDetalhado() {
        StringBuilder sb = new StringBuilder();

        sb.append(tipoReceita).append(" ");

        if (tiposComida != null && !tiposComida.isEmpty()) {

            for (int i = 0; i < tiposComida.size() - 1; i++) {
                sb.append(tiposComida.get(i).getNome()).append(",");
            }
            sb.append(tiposComida.get(tiposComida.size() - 1).getNome());

        } else if (tiposBebida != null && !tiposBebida.isEmpty()) {

            for (int i = 0; i < tiposBebida.size() - 1; i++) {
                sb.append(tiposBebida.get(i).getNome()).append(",");
            }
            sb.append(tiposBebida.get(tiposBebida.size() - 1).getNome());

        }

        if (tipoCaloria != null) {
            sb.append(" - ").append(tipoCaloria.getNome());
        }

        return sb.toString();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.nome);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Receita other = (Receita) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Receita o) {
        return nome.compareTo(o.getNome());
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("RECEITA ").append(nome);

        if (tiposComida != null && !tiposComida.isEmpty()) {

            sb.append("\t").append(NovaReceita.INICIO_RESUMO_TIPO_COMIDA).append(NovaReceita.INICIO_RESUMO_TIPO_COMIDA_PLUS);
            for (int i = 0; i < tiposComida.size() - 1; i++) {
                sb.append(tiposComida.get(i).getNome()).append(",");
            }
            sb.append(tiposComida.get(tiposComida.size() - 1).getNome());

        } else if (tiposBebida != null && !tiposBebida.isEmpty()) {

            sb.append("\t").append(NovaReceita.INICIO_RESUMO_TIPO_BEBIDA).append(NovaReceita.INICIO_RESUMO_TIPO_BEBIDA_PLUS);
            for (int i = 0; i < tiposBebida.size() - 1; i++) {
                sb.append(tiposBebida.get(i).getNome()).append(",");
            }
            sb.append(tiposBebida.get(tiposBebida.size() - 1).getNome());

        }

        if (tipoCaloria != null) {
            sb.append(" - ").append(tipoCaloria.getNome());
        }

        if (ingredientes != null) {
            sb.append("\n").append(".").append(Util.PROPERTIES.getProperty("tabIngredientes")).append("\n").append("\t").append(ingredientes);
        }

        if (modoPreparo != null) {
            sb.append("\n").append(".").append(Util.PROPERTIES.getProperty("tabModoPreparo")).append("\n").append("\t").append(modoPreparo);
        }

        sb.append("\n");

        return sb.toString();
    }

}
