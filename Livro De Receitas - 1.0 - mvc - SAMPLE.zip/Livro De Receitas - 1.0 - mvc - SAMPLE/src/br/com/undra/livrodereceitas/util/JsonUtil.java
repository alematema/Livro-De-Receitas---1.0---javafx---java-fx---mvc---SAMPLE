package br.com.undra.livrodereceitas.util;

import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoCaloria;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;

/**
 * A converter from json to java objects and vice versa.
 * <br> Uses JACKSON libs.
 *
 * @author alexandre
 */
public class JsonUtil {

    private static final ObjectMapper CONVERTER;

    static {
        CONVERTER = new ObjectMapper();
    }

    public static synchronized String toJson(Object object) throws JsonProcessingException {
        String json = CONVERTER.writeValueAsString(object);
        return json;
    }

    public static synchronized <T> T toJava(String json, Class<T> aClass) throws IOException {
        return CONVERTER.readValue(json, aClass);
    }

    public static List<Receita> toReceitas(String json) throws Exception {

        List<LinkedHashMap> receitasParsed = toJava(json, List.class);
        List<Receita> receitasFromJson = new ArrayList<>();

        for (LinkedHashMap receitaMapped : receitasParsed) {

            Receita receita = new Receita((String) receitaMapped.get("nome"));
            receita.setIngredientes((String) receitaMapped.get("ingredientes"));
            receita.setModoPreparo((String) receitaMapped.get("modoPreparo"));
            receita.setTipoReceita((String) receitaMapped.get("tipoReceita"));
            if (receitaMapped.get("tiposComida") != null) {

                List<TipoComida> tiposComida = new ArrayList<>();

                for (LinkedHashMap tc : (List<LinkedHashMap>) receitaMapped.get("tiposComida")) {
                    tiposComida.add(new TipoComida((String) tc.get("nome")));
                }

                receita.setTiposComida(tiposComida);

            } else if (receitaMapped.get("tiposBebida") != null) {

                List<TipoBebida> tiposBebida = new ArrayList<>();

                for (LinkedHashMap tb : (List<LinkedHashMap>) receitaMapped.get("tiposBebida")) {
                    tiposBebida.add(new TipoBebida((String) tb.get("nome")));
                }

                receita.setTiposBebida(tiposBebida);
            }

            if (receitaMapped.get("tipoCaloria") != null) {
                receita.setTipoCaloria(new TipoCaloria((String) ((LinkedHashMap) receitaMapped.get("tipoCaloria")).get("nome")));
            }

            receitasFromJson.add(receita);

        }

        return receitasFromJson;

    }

    public static String getJson(File jsonFile) throws FileNotFoundException {
        
        Scanner s = new Scanner(jsonFile);
        String json = "";
        while (s.hasNext()) {
            json += s.nextLine();
        }

        return json;
    }
}
