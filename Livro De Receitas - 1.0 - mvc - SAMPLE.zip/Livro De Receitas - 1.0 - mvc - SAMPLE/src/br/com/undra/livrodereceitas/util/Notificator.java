package br.com.undra.livrodereceitas.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.paginas.Notification;
import br.com.undra.livrodereceitas.paginas.NotificationPage;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.stage.StageStyle;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * A notificator helper.
 *
 * @author alexandre
 */
public class Notificator {

    static private NotificationPage notificationPage;

    static public void setNotificationPage(NotificationPage np) {
        notificationPage = np;
    }

    static volatile public boolean isNotificating = false;

    static volatile private boolean wasHidden = false;

    public static synchronized void showNotificationPage(Notification notification) {
        notificationPage.setNotification(notification);
        notificationPage.setUp();
        notificationPage.setVisible(true);
        if (notificationPage.getContainer().getPageWrapper().isShowing()) {
            notificationPage.getContainer().getPageWrapper().hide();
            wasHidden = true;
        }

    }
    public static synchronized void showNotificationPage(Notification notification,VerticalScrollableListWrapper wrapper) {
        notificationPage.setNotification(notification);
        notificationPage.setUp(wrapper);
        notificationPage.setVisible(true);
        if (notificationPage.getContainer().getPageWrapper().isShowing()) {
            notificationPage.getContainer().getPageWrapper().hide();
            wasHidden = true;
        }

    }

    public static void showNotificationPage(AppContainer container, Notification notification) {
        notificationPage.setNotification(notification);
        notificationPage.setUp();
        notificationPage.setVisible(true);
        isNotificating = true;
        if (notificationPage.getContainer().getPageWrapper().isShowing()) {
            notificationPage.getContainer().getPageWrapper().hide();
            wasHidden = true;
        }
        
    }

    public synchronized static void hideNotificationPage(AppContainer container) {
            container.getNotificationPage().setVisible(false);
        if (wasHidden) {
            container.getPageWrapper().show();
            wasHidden = false;
        }
        isNotificating = false;
        Platform.runLater(() -> {
        });
    }

    public static void notificate(AppContainer container, String text, int timeOut) {

        try {
            if (container.getCurrentPage().getNotificationPage() != null) {
                if (container.getCurrentPage().getNotificationPage().isVisible()) {
                    isNotificating = true;
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        new Thread(() -> {
            isNotificating = true;
            while (container.isChangingPage()) {
            }

            if (container.getShowHideNotificationThread() != null) {
                container.getShowHideNotificationThread().stop();
            }
            Platform.runLater(() -> {
                container.getPageWrapper().setText("");
                container.getPageWrapper().hide();
                container.getPageWrapper().show(text);
            });

            try {
                Thread.sleep(timeOut);
            } catch (InterruptedException ex) {
                Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Platform.runLater(() -> {
                if (container.getPageWrapper().getStyleClass().contains("error")) {
                    container.getPageWrapper().getStyleClass().remove("error");
                    container.getPageWrapper().getStyleClass().add("neutral");
                }
                if (container.getPageWrapper().getStyleClass().contains("warning")) {
                    container.getPageWrapper().getStyleClass().remove("warning");
                    container.getPageWrapper().getStyleClass().add("neutral");
                }
                container.getPageWrapper().hide();
                if (container.getCurrentPage().getNotificationPage() != null) {
                    if (container.getCurrentPage().getNotificationPage().isVisible()) {
                        isNotificating = true;
                    } else {
                        isNotificating = false;
                    }
                } else {
                    isNotificating = false;
                }
            });
        }).start();
    }

    public static void notificateError(AppContainer appContainer, String text, int timeOut) {

        appContainer.getPageWrapper().getStyleClass().remove("neutral");
        appContainer.getPageWrapper().getStyleClass().add("error");
        notificate(appContainer, text, timeOut);

    }

    public static void notificateWarning(AppContainer appContainer, String text, int timeOut) {

        appContainer.getPageWrapper().getStyleClass().remove("neutral");
        appContainer.getPageWrapper().getStyleClass().add("warning");
        notificate(appContainer, text, timeOut);

    }

    public static void notificateDeletion(AppContainer appContainer, VerticalScrollableListWrapper wrapper, String singleMultiDeletion, int timeOut) {

        //NOTIFICA USUARIO
        if (singleMultiDeletion.equals(ScrollableListContainerSimple.MULTI_SELECTION_DELETION_COMPLETED)) {
            notificate(appContainer, wrapper.getMultiSelectionRemoved().size() + " " + Util.getPROPERTIES(wrapper).getProperty("textoNotificacaoMultiSelecaoRemovida"), timeOut);
        }
        //NOTIFICA USUARIIO
        if (singleMultiDeletion.equals(ScrollableListContainerSimple.SINGLE_SELECTION_REMOVED)) {
            notificate(appContainer, Util.getPROPERTIES(wrapper).getProperty("textoNotificacaoItemRemovido") + " : " + wrapper.getSingleRemoved(), timeOut);
        }
    }

    public static void notificateWithCloseButton(AppContainer appContainer, String text, int timeOut) {

        Platform.runLater(() -> {
            appContainer.getPageWrapper().setText("");
            appContainer.getPageWrapper().hide();
        });

        Thread showHideNotificationThread = new Thread(() -> {

            Platform.runLater(() -> {
                appContainer.getPageWrapper().hide();
                appContainer.getPageWrapper().setCloseButtonVisible(true);
                appContainer.getPageWrapper().show(text);
            });

            try {
                Thread.sleep(timeOut);
            } catch (InterruptedException ex) {
                Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
            }
            Platform.runLater(() -> {
                appContainer.getPageWrapper().hide();
                appContainer.getPageWrapper().setCloseButtonVisible(false);

            });
        });

        appContainer.setShowHideNotificationThread(showHideNotificationThread);

        showHideNotificationThread.start();
    }

    public static Optional showConfirmarRemoverMultiSelection(int size, VerticalScrollableListWrapper wrapper) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, size + " " + Util.getPROPERTIES(wrapper).getProperty("tituloNotificacaoRemoverMultiSelecao"), ButtonType.YES, ButtonType.NO);
        alert.setGraphic(new ImageView(Item.DELETE_IMAGE));
        alert.setTitle(Util.getPROPERTIES(wrapper).getProperty("textoNotificacaoRemover"));

        alert.setHeaderText("Confirmar " + Util.getPROPERTIES(wrapper).getProperty("textoNotificacaoRemover"));
        alert.initStyle(StageStyle.UNDECORATED);
        //Deactivate Defaultbehavior for yes-Button:
        Button yesButton = (Button) alert.getDialogPane().lookupButton(ButtonType.YES);
        yesButton.setDefaultButton(false);
        //Activate Defaultbehavior for no-Button:
        Button noButton = (Button) alert.getDialogPane().lookupButton(ButtonType.NO);
        noButton.setDefaultButton(true);
        Optional confirmarRemover = alert.showAndWait();
        return confirmarRemover;

    }

}
