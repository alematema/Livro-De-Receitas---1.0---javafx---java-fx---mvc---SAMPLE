package br.com.undra.livrodereceitas.util;

/**
 *
 * @author alexandre
 */
public class Fonts {
    
    final public static javafx.scene.text.Font CHILANKA;
    final public static javafx.scene.text.Font CHILANKA_MEDIUM;
    final public static javafx.scene.text.Font CHILANKA_15;
    final public static javafx.scene.text.Font CHILANKA_APP_NAME;
    public static javafx.scene.text.Font APP_FONT;
    public static javafx.scene.text.Font APP_FONT_MEDIUM;
    public static javafx.scene.text.Font APP_FONT_SPLASH_NAME;
    public static javafx.scene.text.Font ITEM_FONT;
    
    
    static{
        CHILANKA=javafx.scene.text.Font.loadFont(Fonts.class.getResourceAsStream("/resources/font/Chilanka.ttf"), 23);
        CHILANKA_15=javafx.scene.text.Font.loadFont(Fonts.class.getResourceAsStream("/resources/font/Chilanka.ttf"), 15);
        CHILANKA_MEDIUM=javafx.scene.text.Font.loadFont(Fonts.class.getResourceAsStream("/resources/font/Chilanka.ttf"), 40);
        CHILANKA_APP_NAME=javafx.scene.text.Font.loadFont(Fonts.class.getResourceAsStream("/resources/font/Chilanka.ttf"), 25);
        
        APP_FONT = CHILANKA;
        APP_FONT_MEDIUM = CHILANKA_MEDIUM;
        APP_FONT_SPLASH_NAME = CHILANKA_APP_NAME;
        ITEM_FONT = CHILANKA_15;
    }
    
}
