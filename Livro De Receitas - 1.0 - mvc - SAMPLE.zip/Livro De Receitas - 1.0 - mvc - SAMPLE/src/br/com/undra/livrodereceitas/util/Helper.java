package br.com.undra.livrodereceitas.util;

import br.com.undra.jfxcomponents.searcher.SearcherContainer;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.ListaDeReceitas;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.paginas.ConfirmarSalvar;
import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.NenhumaReceitaSelecionada;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposBebidas;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposCalorias;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposComidas;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingNode;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JPanel;
import org.icepdf.ri.common.MyAnnotationCallback;
import org.icepdf.ri.common.SwingController;
import org.icepdf.ri.common.SwingViewBuilder;

/**
 * Shows user's pdfs helpers.
 *
 * @author alexandre
 */
public class Helper {

    //pdfs and theirs viewers
    static Thread keyMapCreationThread;
    static Stage PDF_VIEWER;
    static SwingController controller;
    static File keyMapPdf = null;
    static File listHelperPdf = null;
    static File createHelperPdf = null;
    static File editHelperPdf = null;
    static File masterHelperPdf = null;
    static SwingNode swingNode;
    static JPanel viewerPanel;

    static Node currentContext;
    static Node currentContextId;
    static Map<AppContainer, Map<Node, Node>> appContainerCurrentContextMap = new HashMap<>();

    /**
     * Usado para ajuda contextualizada
     *
     * @param context
     * @return
     * @see
     * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
     */
    public static EventHandler<? super Event> getMouseEventIdentifiedHandler(AppContainer appContainer, Node context) {
        return (event) -> {
            context.requestFocus();
            Helper.setCurrentContext(appContainer, context, (Node) event.getTarget());
        };
    }

    static {

        controller = new SwingController();
        //for image quality enhancement
        System.getProperties().put("org.icepdf.core.imageReference", "scaled");
        System.getProperties().put("org.icepdf.core.screen.interpolation", "VALUE_INTERPOLATION_BICUBIC");

        SwingViewBuilder viewerBuilder = new SwingViewBuilder(controller);

        //The view container
        viewerPanel = viewerBuilder.buildViewerPanel();
        controller.getDocumentViewController().setAnnotationCallback(new MyAnnotationCallback(controller.getDocumentViewController()));
        //the pdfs viewer window
        PDF_VIEWER = new Stage();
        swingNode = new SwingNode();
        swingNode.setContent(viewerPanel);
        
        StackPane pane = new StackPane(swingNode);
        Scene scene = new Scene(pane, (int) (0.9 * Toolkit.getDefaultToolkit().getScreenSize().getWidth()), PDF_VIEWER.getHeight());
        PDF_VIEWER.setScene(scene);
        PDF_VIEWER.toFront();
        
    }

    /**
     * Abre o viewer do key Map Pdf : o pdf mapa de atalhos do teclado da app.
     * <br>
     *
     * @see #prepareKeyMapPdfAndViewer
     * @see #preparePdfsAndViewers
     */
    public static void openKeyMapPdfViewer() {
        openMasterHelperPdfViewer(55, Util.PROPERTIES.getProperty("key.map.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do list helper Pdf : o pdf de ajuda para navegacao,
     * pesquisa e selecao de itens da lista da app.
     * <br>
     *
     * @see #prepareListHelperPdfAndViewer()
     * @see #preparePdfsAndViewers
     */
    public static void openListHelperPdfViewer() {

        PDF_VIEWER.setTitle(Util.PROPERTIES.getProperty("list.helper.pdf.viewer.title"));

        if (listHelperPdf == null) {

            new Thread(() -> {
                prepareListHelperPdfAndViewer();
                openListHelperPdfViewer();
            }).start();

        } else {

            try {
                if (!PDF_VIEWER.isShowing()) {
                    PDF_VIEWER.show();
                }

                PDF_VIEWER.toFront();
                //opens scroller/selection/navigation helper pdf
                controller.openDocument(listHelperPdf.getCanonicalPath());
                controller.setZoom(1.5f);
                //continous pages 
                controller.setPageViewMode(2, false);

            } catch (IOException ex) {
                Logger.getLogger(Helper.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void openCreateTiposComidasHelperPdfViewer() {
        openMasterHelperPdfViewer(57, Util.PROPERTIES.getProperty("create.tipos.comidas.helper.pdf.viewer.title"));
    }

    public static void openCreateTiposBebidasHelperPdfViewer() {
        openMasterHelperPdfViewer(59, Util.PROPERTIES.getProperty("create.tipos.bebidas.helper.pdf.viewer.title"));
    }

    public static void openCreateTiposCaloriasHelperPdfViewer() {
        openMasterHelperPdfViewer(61, Util.PROPERTIES.getProperty("create.tipos.calorias.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do create helper Pdf : o pdf de ajuda para criar um
     * objeto/item da app.
     * <br>
     *
     * @see #prepareCreateHelperPdfAndViewer()
     * @see #preparePdfsAndViewers
     */
    public static void openCreateHelperPdfViewer() {
        openMasterHelperPdfViewer(5, Util.PROPERTIES.getProperty("create.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do edit helper Pdf : o pdf de ajuda para editar um
     * objeto/item da app.
     * <br>
     *
     * @see #prepareEditHelperPdfAndViewer()
     * @see #preparePdfsAndViewers
     */
    public static void openEditHelperPdfViewer() {
        openMasterHelperPdfViewer(11, Util.PROPERTIES.getProperty("edit.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do SEARCHING helper Pdf : o pdf de ajuda para PESQUISAR
     * ITENS da app.
     * <br>
     *
     */
    public static void openSearchingHelperPdfViewer() {
        openMasterHelperPdfViewer(26, Util.PROPERTIES.getProperty("searching.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do confirmation CREATION helper Pdf : o pdf de ajuda para
     * confirmar editar/salvar um objeto/item da app.
     * <br>
     *
     */
    public static void openAddingConfirmationHelperPdfViewer() {
        openMasterHelperPdfViewer(9, Util.PROPERTIES.getProperty("confirmation.create.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do confirmation EDITION helper Pdf : o pdf de ajuda para
     * confirmar editar/salvar um objeto/item da app.
     * <br>
     *
     */
    public static void openEditingConfirmationHelperPdfViewer() {
        openMasterHelperPdfViewer(13, Util.PROPERTIES.getProperty("confirmation.edition.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do master helper Pdf : o pdf da ajuda da app.
     * <br>
     *
     * @see #prepareMasterHelperPdfAndViewer()
     * @see #preparePdfsAndViewers
     */
    public static void openMasterHelperPdfViewer() {
        openMasterHelperPdfViewer(0, Util.PROPERTIES.getProperty("master.helper.pdf.viewer.title"));
    }

    /**
     * Abre o viewer do master helper Pdf : o pdf da ajuda da app.<br>
     * Abre na página pageNum e seta o titulo com string title.
     * <br>
     *
     * @param pageNum
     * @param title
     * @see #prepareMasterHelperPdfAndViewer()
     * @see #preparePdfsAndViewers
     */
    public static void openMasterHelperPdfViewer(int pageNum, String title) {

        PDF_VIEWER.setTitle(title);

        if (masterHelperPdf == null) {

            new Thread(() -> {
                prepareMasterHelperPdfAndViewer();
                openMasterHelperPdfViewer(pageNum, Util.PROPERTIES.getProperty("master.helper.pdf.viewer.title"));
            }).start();

        } else {

            try {
                if (!PDF_VIEWER.isShowing()) {
                    PDF_VIEWER.show();
                }

                PDF_VIEWER.toFront();
                //opens master helper pdf
                controller.openDocument(masterHelperPdf.getCanonicalPath());
                //zooms it
                controller.setZoom(1.5f);
                //continous pages 
                controller.setPageViewMode(2, false);
                //opens bookmark
                controller.toggleUtilityPaneVisibility();
                //shows pdf at pageNum
                showPage(pageNum);

            } catch (IOException ex) {
                Logger.getLogger(Helper.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Shows the page assigned to pageNum.
     *
     * @param pageNum
     */
    private static void showPage(int pageNum) {
        controller.showPage(pageNum - 1);
    }

    /**
     * Fecha PDF_VIEWER. <br>
     * Disposes PDF_VIEWER, closes controller's document and disposes it.
     */
    public static void closePdfViewer() {
        
        controller.dispose();
        controller.closeDocument();
        PDF_VIEWER.close();
        PDF_VIEWER = null;
        
        swingNode.setContent(null);
        swingNode = null;
        viewerPanel.removeAll();
        
        viewerPanel = null;

    }

    /**
     * Prepares pdfs and viewers BEFORE their showing time.<br>
     * Should be invoked at the very starting of the app.
     *
     * @see br.com.undra.livrodereceitas.AppContainer#AppContainer(String)
     * @see #prepareKeyMapPdfAndViewer()
     *
     */
    public static void preparePdfsAndViewers() {
        new Thread(() -> {
            Helper.prepareKeyMapPdfAndViewer();
            Helper.prepareListHelperPdfAndViewer();
            Helper.prepareCreateHelperPdfAndViewer();
            Helper.prepareEditHelperPdfAndViewer();
            Helper.prepareMasterHelperPdfAndViewer();
        }).start();
    }

    /**
     * Prepares for further use the key map pdf and its viewer.
     *
     * @see #openKeyMapPdfViewer()
     */
    private static void prepareKeyMapPdfAndViewer() {

        if (keyMapPdf == null) {

            try {
                String resource = "/resources/pdf/keymap/MapaAtalhosTeclado.pdf";
                URL res = Helper.class
                        .getResource(resource);

                if (res.getProtocol().equals("jar")) {
                    try {
                        InputStream input = Helper.class
                                .getResourceAsStream(resource);
                        keyMapPdf = new File(System.getProperty("java.io.tmpdir") + "/" + "ATALHOS.TECLADO.LIVRO.1.0.pdf");
                        keyMapPdf.deleteOnExit();
                        try (OutputStream out = new FileOutputStream(keyMapPdf)) {
                            int read;
                            byte[] bytes = new byte[1024];
                            while ((read = input.read(bytes)) != -1) {
                                out.write(bytes, 0, read);

                            }
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(Helper.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                }

            } catch (Exception ex) {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

            //tenta novamente exibir keyMapPdf dos atalhos a partir de user.dir/MapaAtalhosTeclado.pdf
            if (keyMapPdf == null) {
                keyMapPdf = new File(System.getProperty("user.dir") + "/" + "MapaAtalhosTeclado.pdf");
                Logger
                        .getLogger(Helper.class
                                .getName()).log(Level.INFO, "PDF mapa atalhos exibido a partir de user.dir/MapaAtalhosTeclado.pdf");

            } else {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.INFO, "PDF mapa atalhos exibido a partir de java.io.tmpdir/ATALHOS.TECLADO.LIVRO.1.0.pdf");
            }

            keyMapPdf.deleteOnExit();

        }
    }

    /**
     * Prepares for further use the scroller/searching/selecting pdf helper and
     * its viewer.
     *
     * @see #openListHelperPdfViewer()
     */
    private static void prepareListHelperPdfAndViewer() {

        if (listHelperPdf == null) {

            try {
                String resource = "/resources/pdf/helper/ListHelper.pdf";
                URL res = Helper.class
                        .getResource(resource);

                if (res.getProtocol().equals("jar")) {
                    try {
                        InputStream input = Helper.class
                                .getResourceAsStream(resource);
                        listHelperPdf = new File(System.getProperty("java.io.tmpdir") + "/" + "ListHelper.pdf");
                        listHelperPdf.deleteOnExit();
                        try (OutputStream out = new FileOutputStream(listHelperPdf)) {
                            int read;
                            byte[] bytes = new byte[1024];
                            while ((read = input.read(bytes)) != -1) {
                                out.write(bytes, 0, read);

                            }
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(Helper.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                }

            } catch (Exception ex) {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

            //tenta novamente exibir listHelperPdf dos atalhos a partir de user.dir/scrollerHelperPdf.pdf
            if (listHelperPdf == null) {
                listHelperPdf = new File(System.getProperty("user.dir") + "/" + "ListHelper.pdf");
                Logger
                        .getLogger(Helper.class
                                .getName()).log(Level.INFO, "PDF ListHelper exibido a partir de user.dir/ListHelper.pdf");

            } else {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.INFO, "PDF ListHelper exibido a partir de java.io.tmpdir/ListHelper.pdf");
            }

            listHelperPdf.deleteOnExit();

        }
    }

    /**
     * Prepares for further use the create pdf helper and its viewer.
     *
     * @see #openCreateHelperPdfViewer()
     */
    private static void prepareCreateHelperPdfAndViewer() {

        if (createHelperPdf == null) {

            try {
                String resource = "/resources/pdf/helper/CreateHelper.pdf";
                URL res = Helper.class
                        .getResource(resource);

                if (res.getProtocol().equals("jar")) {
                    try {
                        InputStream input = Helper.class
                                .getResourceAsStream(resource);
                        createHelperPdf = new File(System.getProperty("java.io.tmpdir") + "/" + "CreateHelper.pdf");
                        createHelperPdf.deleteOnExit();
                        try (OutputStream out = new FileOutputStream(createHelperPdf)) {
                            int read;
                            byte[] bytes = new byte[1024];
                            while ((read = input.read(bytes)) != -1) {
                                out.write(bytes, 0, read);

                            }
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(Helper.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                }

            } catch (Exception ex) {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

            //tenta novamente exibir CreateHelper dos atalhos a partir de user.dir/CreateHelper.pdf
            if (createHelperPdf == null) {
                createHelperPdf = new File(System.getProperty("user.dir") + "/" + "CreateHelper.pdf");
                Logger
                        .getLogger(Helper.class
                                .getName()).log(Level.INFO, "PDF CreateHelper exibido a partir de user.dir/CreateHelper.pdf");

            } else {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.INFO, "PDF CreateHelper exibido a partir de java.io.tmpdir/CreateHelper.pdf");
            }

            createHelperPdf.deleteOnExit();

        }
    }

    /**
     * Prepares for further use the edit pdf helper and its viewer.
     *
     * @see #openEditHelperPdfViewer()
     */
    private static void prepareEditHelperPdfAndViewer() {

        if (editHelperPdf == null) {

            try {
                String resource = "/resources/pdf/helper/EditHelper.pdf";
                URL res = Helper.class
                        .getResource(resource);

                if (res.getProtocol().equals("jar")) {
                    try {
                        InputStream input = Helper.class
                                .getResourceAsStream(resource);
                        editHelperPdf = new File(System.getProperty("java.io.tmpdir") + "/" + "EditHelper.pdf");
                        editHelperPdf.deleteOnExit();
                        try (OutputStream out = new FileOutputStream(editHelperPdf)) {
                            int read;
                            byte[] bytes = new byte[1024];
                            while ((read = input.read(bytes)) != -1) {
                                out.write(bytes, 0, read);

                            }
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(Helper.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                }

            } catch (Exception ex) {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

            //tenta novamente exibir EditHelper dos atalhos a partir de user.dir/EditHelper.pdf
            if (editHelperPdf == null) {
                editHelperPdf = new File(System.getProperty("user.dir") + "/" + "EditHelper.pdf");
                Logger
                        .getLogger(Helper.class
                                .getName()).log(Level.INFO, "PDF EditHelper exibido a partir de user.dir/EditHelper.pdf");

            } else {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.INFO, "PDF EditHelper exibido a partir de java.io.tmpdir/EditHelper.pdf");
            }

            editHelperPdf.deleteOnExit();

        }
    }

    /**
     * Prepares for further use the master pdf helper and its viewer.
     *
     * @see #openMasterHelperPdfViewer(int)
     */
    private static void prepareMasterHelperPdfAndViewer() {

        if (masterHelperPdf == null) {

            try {
                String resource = "/resources/pdf/helper/MasterHelper.pdf";
                URL res = Helper.class
                        .getResource(resource);

                if (res.getProtocol().equals("jar")) {
                    try {
                        InputStream input = Helper.class
                                .getResourceAsStream(resource);
                        masterHelperPdf = new File(System.getProperty("java.io.tmpdir") + "/" + "MasterHelper.pdf");
                        masterHelperPdf.deleteOnExit();
                        try (OutputStream out = new FileOutputStream(masterHelperPdf)) {
                            int read;
                            byte[] bytes = new byte[1024];
                            while ((read = input.read(bytes)) != -1) {
                                out.write(bytes, 0, read);

                            }
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(Helper.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                }

            } catch (Exception ex) {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

            //tenta novamente exibir MasterHelper dos atalhos a partir de user.dir/MasterHelper.pdf
            if (masterHelperPdf == null) {
                masterHelperPdf = new File(System.getProperty("user.dir") + "/" + "MasterHelper.pdf");
                Logger
                        .getLogger(Helper.class
                                .getName()).log(Level.INFO, "PDF MasterHelper exibido a partir de user.dir/MasterHelper.pdf");

            } else {
                Logger.getLogger(Helper.class
                        .getName()).log(Level.INFO, "PDF MasterHelper exibido a partir de java.io.tmpdir/MasterHelper.pdf");
            }

            masterHelperPdf.deleteOnExit();

        }
    }

//    public static void setCurrentContext(Node currentContext) {
//        if (!currentContext.equals(Helper.currentContext)) {
//            if (currentContext.getId() != null) {
//            }
////            System.err.println("CONTEXT [" + currentContext.getClass().getSimpleName() + ", " + null + "]");
//            Helper.currentContext = currentContext;
//            Helper.currentContextId = null;
//        }
//    }
    /**
     * Sets currentContext and its id.<br>
     *
     * @param source
     * @param target A class name
     */
    @Deprecated
    public static void setCurrentContext(Node source, Node target) {
        Helper.currentContext = source;
        Helper.currentContextId = target;
//        if (Helper.isAddItemIcon()) {
//            Helper.currentContextId.requestFocus();
//        }
    }

    /**
     * Sets AppContainers currentContext and currentContex's id.<br>
     *
     * @param appContainer the app container
     * @param source a node within appContainer
     * @param target a node within source
     */
    public static void setCurrentContext(AppContainer appContainer, Node source, Node target) {

        if (appContainerCurrentContextMap.containsKey(appContainer)) {
            if (!appContainerCurrentContextMap.get(appContainer).keySet().contains(source)) {
                appContainerCurrentContextMap.get(appContainer).clear();
                appContainerCurrentContextMap.get(appContainer).put(source, target);
                Helper.update(appContainer, source, target);
            } else {
                if (!appContainerCurrentContextMap.get(appContainer).get(source).equals(target)) {
                    appContainerCurrentContextMap.get(appContainer).put(source, target);
                    Helper.update(appContainer, source, target);
                }
            }

        } else {
            Map<Node, Node> sourceTargetMap = new HashMap<>();
            sourceTargetMap.put(source, target);
            appContainerCurrentContextMap.put(appContainer, sourceTargetMap);
            Helper.update(appContainer, source, target);
        }

    }

    /**
     * Do before shut down stuffs.
     */
    public static volatile boolean isBeforeShutdownDone = false;

    public static void beforeShutDown() {
        isBeforeShutdownDone = false;
        closePdfViewer();
        isBeforeShutdownDone = true;
    }

    public synchronized static Node getCurrentContextId(AppContainer appContainer) {
        return appContainerCurrentContextMap.get(appContainer).get(getCurrentContext(appContainer));
    }

    public synchronized static Node getCurrentContext(AppContainer appContainer) {
        return appContainerCurrentContextMap.get(appContainer).keySet().iterator().next();
    }

    /**
     * Tells if should open context help pdf.
     *
     * @param app
     * @return
     */
    public static boolean isMenuContextHelp(AppContainer app) {
        if (app == null) {
            return false;
        }
        return Menu.getInstance(app).isVisible();
    }

    /**
     * Tells if should open searching help pdf.
     *
     * @param appContainer
     * @return
     */
    public static boolean isSearchingContextHelp(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            if (getCurrentContextId(appContainer) != null && (getCurrentContextId(appContainer) instanceof SearcherContainer)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Tells if should open list item navigation and scrolling help pdf.
     *
     * @return
     */
    public static boolean isScrollerContextHelp(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            return !Helper.isSearchingContextHelp(appContainer) && (getCurrentContext(appContainer).getClass().equals(ListaDeReceitas.class
            ) || getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class
            ) || getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class
            ) || getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class
            ));
        } else {
            return false;
        }
    }

    /**
     * Tells if app is creating or is about to create an item.
     *
     * @param app
     * @return
     */
    public static boolean isCreatingContextHelp(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            if (isAddItemIcon(appContainer)) {
                return true;

            }
            return getCurrentContext(appContainer).getClass().equals(NovaReceita.class
            );
        } else {
            return false;
        }
    }

    public static boolean isAddItemIcon(AppContainer appContainer) {
        return getCurrentContextId(appContainer) != null && getCurrentContextId(appContainer).getClass().equals(MaterialDesignIconView.class
        ) && ((MaterialDesignIconView) getCurrentContextId(appContainer)).getGlyphName().equals(Util.PROPERTIES.getProperty("add.icon.glyph.name"));
    }

    /**
     * Tells if app is editing an item.
     *
     * @param app
     * @return
     */
    public static boolean isEditingContextHelp(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            return getCurrentContext(appContainer).getClass().equals(DetalhesReceita.class
            );
        } else {
            return false;
        }
    }

    /**
     * Tells if app is showing no selection page.
     *
     * @param app
     * @return
     */
    public static boolean isNoSelectionPageContextHelp(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            return getCurrentContext(appContainer).getClass().equals(NenhumaReceitaSelecionada.class
            );
        } else {
            return false;
        }
    }

    public static boolean isPdfViewerActiveBeforeAltF4() {
        if (PDF_VIEWER != null) {
            return PDF_VIEWER.isShowing();
        } else {
            return false;
        }
    }

    /**
     * Tells if app is showing confirmation page.
     *
     * @param app
     * @return
     */
    public static boolean isEditingOrAddingConfirmation(AppContainer appContainer) {
        if (getCurrentContext(appContainer) != null) {
            return getCurrentContext(appContainer).getClass().equals(ConfirmarSalvar.class
            );
        } else {
            return false;
        }
    }

    public static boolean isEditing(AppContainer appContainer) {
        if (Helper.isEditingOrAddingConfirmation(appContainer)) {
            return ((ConfirmarSalvar) getCurrentContext(appContainer)).isEditing();
        } else {
            return false;
        }
    }

    private static void update(AppContainer appContainer, Node source, Node target) {
        try {
            System.err.println("Helper[" + appContainer.getClass().getSimpleName() + ", " + source.getClass().getSimpleName() + ", " + target.getClass().getSimpleName() + "]");

            if (!PDF_VIEWER.isShowing()) {
                return;

            }
            if (Helper.isCreatingContextHelp(appContainer)) {

                /**
                 * If mouse points to add item icon, then shows creation helper
                 * pdf contextualizedly.
                 */
                if (Helper.isAddItemIcon(appContainer)) {

                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class
                    )) {
                        Helper.openCreateTiposComidasHelperPdfViewer();
                        return;

                    }
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class
                    )) {
                        Helper.openCreateTiposBebidasHelperPdfViewer();
                        return;

                    }
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class
                    )) {
                        Helper.openCreateTiposCaloriasHelperPdfViewer();
                        return;
                    }

                }

                Helper.openCreateHelperPdfViewer();
                return;
            }
            if (Helper.isEditingContextHelp(appContainer)) {
                Helper.openEditHelperPdfViewer();
                return;

            }
            if (Helper.isScrollerContextHelp(appContainer)) {
                //The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                if (Helper.getCurrentContext(appContainer).getClass().equals(ListaDeReceitas.class
                ) && appContainer.getListaDeReceitas().getView().getCurrentModel().isEmpty()) {
                    Helper.openCreateHelperPdfViewer();
                    return;

                }
                if (appContainer.isPreEditing() || appContainer.isEditing()) {

                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class
                    ) && (appContainer.getDetalhesReceita().getListaTiposComidas().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposComidasHelperPdfViewer();
                        return;

                    }
                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class
                    ) && (appContainer.getDetalhesReceita().getListaTiposBebidas().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposBebidasHelperPdfViewer();
                        return;

                    }
                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class
                    ) && (appContainer.getDetalhesReceita().getListaTiposCalorias().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposCaloriasHelperPdfViewer();
                        return;

                    }

                } else if (appContainer.getCurrentPage().equals(appContainer.getNovaReceita())) {
                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposComidas.class
                    ) && (appContainer.getNovaReceita().getListaTiposComidas().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposComidasHelperPdfViewer();
                        return;

                    }
                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposBebidas.class
                    ) && (appContainer.getNovaReceita().getListaTiposBebidas().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposBebidasHelperPdfViewer();
                        return;

                    }
                    // The scroller list is the context. But if it IS EMPTY, shows creation helper pdf, rather than selection,searching,navigations helper pdf.
                    if (Helper.getCurrentContext(appContainer).getClass().equals(ListaTiposCalorias.class
                    ) && (appContainer.getNovaReceita().getListaTiposCalorias().getView().getCurrentModel().isEmpty())) {
                        Helper.openCreateTiposCaloriasHelperPdfViewer();
                        return;
                    }
                }

                /**
                 * The scroller list is the context and it is NOT empty.Shows
                 * the selection,searching,navigations helper pdf.
                 */
                Helper.openListHelperPdfViewer();
                return;
            }
            if (Helper.isEditingOrAddingConfirmation(appContainer)) {
                if (Helper.isEditing(appContainer)) {
                    Helper.openEditingConfirmationHelperPdfViewer();
                } else {
                    Helper.openAddingConfirmationHelperPdfViewer();
                }
                return;
            }
            if (Helper.isSearchingContextHelp(appContainer)) {
                Helper.openSearchingHelperPdfViewer();
                return;
            }
            if (Helper.isMenuContextHelp(appContainer)) {

                if (Helper.getCurrentContextId(appContainer) != null) {

                    try {

                        Text action = (Text) Helper.getCurrentContextId(appContainer);

                        if (action.equals(Menu.getInstance(appContainer).getImprimir())) {
                            Helper.openMasterHelperPdfViewer(35, Util.PROPERTIES.getProperty("printing.all.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getImprimirSelecionadas())) {
                            Helper.openMasterHelperPdfViewer(38, Util.PROPERTIES.getProperty("printing.selected.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getExportar())) {
                            Helper.openMasterHelperPdfViewer(28, Util.PROPERTIES.getProperty("export.all.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getExportarSelecionadas())) {
                            Helper.openMasterHelperPdfViewer(30, Util.PROPERTIES.getProperty("export.selected.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getImportar())) {
                            Helper.openMasterHelperPdfViewer(32, Util.PROPERTIES.getProperty("import.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getAjuda())) {
                            Helper.openMasterHelperPdfViewer();
                        } else if (action.equals(Menu.getInstance(appContainer).getMapaAtalhos())) {
                            Helper.openMasterHelperPdfViewer(55, Util.PROPERTIES.getProperty("shortcuts.helper.pdf.viewer.title"));
                        } else if (action.equals(Menu.getInstance(appContainer).getAbout())) {
                            Helper.openMasterHelperPdfViewer(63, Util.PROPERTIES.getProperty("about.helper.pdf.viewer.title"));
                        }

                    } catch (Exception e) {
                    }
                } else {
                }

                return;
            }

            if (Helper.isNoSelectionPageContextHelp(appContainer)) {
            }
            if (!Helper.isSearchingContextHelp(appContainer) && !Helper.isEditingOrAddingConfirmation(appContainer) && !Helper.isCreatingContextHelp(appContainer) && !Helper.isEditingContextHelp(appContainer) && !Helper.isScrollerContextHelp(appContainer)) {
                Helper.openMasterHelperPdfViewer();
            }
        } catch (Exception e) {
            System.err.println("Helper[FAILED UPDATING] " + System.currentTimeMillis());
        }
    }

}
