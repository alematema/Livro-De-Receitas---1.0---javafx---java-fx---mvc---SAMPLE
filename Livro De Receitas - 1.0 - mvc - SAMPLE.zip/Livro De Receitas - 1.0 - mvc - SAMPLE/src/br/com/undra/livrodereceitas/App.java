package br.com.undra.livrodereceitas;

import br.com.undra.livrodereceitas.paginas.Page;
import javafx.stage.Stage;

/**
 * An app interface
 * @author alexandre
 */
public interface App {
    Page getCurrentPage();
    void start(Stage s)throws Exception;
    /**
     * Executa várias açoes antes da VM encerrar.
     * @see br.com.undra.livrodereceitas.AppContainer#beforeShutDown()
     * @throws Exception 
     */
    void stop()throws Exception;
//    App newInstance();
}
