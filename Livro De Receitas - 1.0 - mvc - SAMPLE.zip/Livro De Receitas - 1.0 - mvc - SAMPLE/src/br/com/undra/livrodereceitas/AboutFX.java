package br.com.undra.livrodereceitas;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.util.Helper;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingNode;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author alexandre
 */
public class AboutFX {

    private About about;
    private Stage ABOUT_VIEWER;
    SwingNode swingNode;

    public AboutFX() {
        about = new About();
        about.setAboutFX(this);
        Platform.runLater(() -> {
            ABOUT_VIEWER = new Stage();
            swingNode = new SwingNode();
            swingNode.setContent(about.getRootPane());
            StackPane pane = new StackPane(swingNode);
            Scene scene = new Scene(pane);
            ABOUT_VIEWER.setScene(scene);
            ABOUT_VIEWER.toFront();
            ABOUT_VIEWER.setTitle(String.format(Util.PROPERTIES.getProperty("about.title"), Util.PROPERTIES.getProperty("title")));
            about.dispose();
            about.setVisible(false);
            ABOUT_VIEWER.focusedProperty().addListener((observable, oldValue, newValue) -> {
                if(oldValue==true && newValue == false){
                    esconder();
                }else if(oldValue==false && newValue == true){
                }
            });
        });

    }

    public boolean isShowing() {
        return ABOUT_VIEWER.isShowing();
    }

    public void abrir() {
        System.err.println("showing AboutFX");
        Platform.runLater(() -> {
            ABOUT_VIEWER.show();
        });
    }

    public void esconder() {
        System.err.println("closing AboutFX");
        Platform.runLater(() -> {
            ABOUT_VIEWER.close();
        });
    }
    
    public void disposeDirect(){
        System.err.println("disposing DIRECTLY AboutFX");
        try {
                ABOUT_VIEWER.close();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.setAboutFX(null);
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.getRootPane().removeAll();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.dispose();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                swingNode.setContent(null);
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }

            about = null;
            ABOUT_VIEWER = null;
        
    }

    public void dispose() {
        System.err.println("disposing AboutFX");
        Platform.runLater(() -> {

            try {
                ABOUT_VIEWER.close();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.setAboutFX(null);
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.getRootPane().removeAll();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                about.dispose();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }
            try {
                swingNode.setContent(null);
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }

            about = null;
            ABOUT_VIEWER = null;
        });
    }

}
