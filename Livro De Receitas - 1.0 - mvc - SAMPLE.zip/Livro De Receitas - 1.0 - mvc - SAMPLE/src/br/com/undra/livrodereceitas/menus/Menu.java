package br.com.undra.livrodereceitas.menus;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.paginas.Notifications;
import br.com.undra.livrodereceitas.paginas.Page;
import br.com.undra.livrodereceitas.util.Notificator;
import de.jensd.fx.glyphs.icons525.Icons525View;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javafx.animation.ScaleTransition;
import javafx.animation.Transition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import br.com.undra.livrodereceitas.About;
import br.com.undra.livrodereceitas.AboutFX;
import br.com.undra.livrodereceitas.pagenavigator.PageNavigator;
import br.com.undra.livrodereceitas.util.Helper;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.image.ImageView;

/**
 * Um modelo para menu.
 *
 * @author alexandre
 */
public class Menu extends Pane {

    private static Menu instance;

    private static Map<AppContainer, Menu> containers = new HashMap<>();

    public static Menu getInstance(AppContainer appContainer) {

        if (!containers.containsKey(appContainer)) {
            containers.put(appContainer, new Menu(appContainer));
        }

        return containers.get(appContainer);
    }

    private static String DISABLED_COLOR = "#797a7c";

    private Tooltip menuTooltip;
    private Font toolTipsFont = Font.font(12);

    private AppContainer container;

    @FXML
    private Pane menuOuterContainer;

    @FXML
    private MaterialIconView menuPointer;

    @FXML
    private Pane menuContainer;

    @FXML
    private Text exportar;

    @FXML
    private MaterialDesignIconView exportarIcon;

    @FXML
    private Text importar;

    @FXML
    private Text exportarSelecionadas;

    @FXML
    private Text imprimir;
    @FXML
    private Icons525View imprimirIcon;

    @FXML
    private Text imprimirSelecionadas;

    @FXML
    private Icons525View imprimirSelecionadasIcon;

    @FXML
    private MaterialDesignIconView exportarSelecionadasIcon;

    @FXML
    private MaterialDesignIconView printerIcon;

    @FXML
    private Text gerarCardapio;

    @FXML
    private MaterialIconView gerarCardapiosIcon;

    @FXML
    private MaterialDesignIconView helpIcon;

    @FXML
    private Text ajuda;

    @FXML
    private Text mapaAtalhos;

    @FXML
    private MaterialDesignIconView mapaAtalhosIcon;

    @FXML
    private ImageView aboutIcon;

    @FXML
    private Text about;

    @FXML
    private Text logout;

    @FXML
    private Icons525View logoutIcon;
    @FXML
    private Icons525View helpMainIcon;

    @FXML
    private Pane logoutContainer;

    @FXML
    private Text paginaInicial;

    private MenuActions actions;

    private Tooltip gerarCardapioTooltip;
    private Tooltip imprimirTooltip;
    private Tooltip imprimirSelecionadasTooltip;
    private Tooltip exportarTooltip;
    private Tooltip exportarSelectionadasTooltip;
    private Tooltip importarTooltip;
    private Tooltip ajudaTooltip;
    private Tooltip atalhosTooltip;
    private Tooltip paginaInicialTooltip;
    private Tooltip aboutTooltip;

    @FXML
    void handleMouseClicked(MouseEvent event) {

        setVisible(false);

        new Thread(() -> {
            Platform.runLater(() -> {

                try {

                    Text action = (Text) event.getTarget();

                    if (action.equals(imprimir)) {
                        handlePrintAll();
                    } else if (action.equals(imprimirSelecionadas)) {
                        handlePrintSelected();
                    } else if (action.equals(exportar)) {
                        handleExportAll();
                    } else if (action.equals(exportarSelecionadas)) {
                        handleExportSelected();
                    } else if (action.equals(importar)) {
                        handleImporting();
                    } else if (action.equals(gerarCardapio)) {
                        handleGerarCardapio();
                    } else if (action.equals(ajuda)) {
                        handleOpenMasterHelpPdf();
                    } else if (action.equals(mapaAtalhos)) {
                        handleOpenMapaAtalhosTecladoPdf();
                    } else if (action.equals(paginaInicial)) {
                        handleRestaurarPaginaInicial();
                    } else if (action.equals(about)) {
                        handleAboutPage();
                    } else if (action.equals(logout)) {
                        handleLogout();
                    }
                } catch (Exception e) {
                }

            });
        }).start();

    }

    private Menu() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLMenu.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        getStylesheets().add(getClass().getResource("/resources/css/menu.css").toExternalForm());

        setOnMouseMoved(Helper.getMouseEventIdentifiedHandler(container,this));

    }

    private Menu(AppContainer container) {

        this();
        this.container = container;
        actions = new MenuActions(this);
        setMenuActionsNamesAndToolTips();

        // DESAbilita opcao EXPORTAR SELECIONADAS DO MENU,SUPONDO AO INICIAR LIVRO NENHUM ITEM ESTEJA SELECIONADO
        exportarSelecionadasIcon.setFill(Paint.valueOf(DISABLED_COLOR));
        exportarSelecionadas.setFill(Paint.valueOf(DISABLED_COLOR));
        exportarSelecionadas.setDisable(true);

        setAsEmptyList();

        ScaleTransition st = new ScaleTransition(Duration.seconds(0.8), helpMainIcon);
        st.setAutoReverse(true);
        st.setCycleCount(Transition.INDEFINITE);
        st.setFromX(1);
        st.setFromY(1);
        st.setToX(0.6);
        st.setToY(0.6);
        st.play();

        menuTooltip = new Tooltip(String.format(Util.PROPERTIES.getProperty("menu.tool.tip"), Util.PROPERTIES.getProperty("main.menu.shortcut")));
        menuTooltip.setFont(toolTipsFont);

    }

    /**
     * Sets menu actions names and their keyboard shortcuts tool tips.<br>
     * Actions like imprimir,exportar,importar,ajuda,mapa atalhos,about etc.
     */
    private void setMenuActionsNamesAndToolTips() {
        imprimir.setText(Util.PROPERTIES.getProperty("app.printing.menu.action.text"));
        imprimirSelecionadas.setText(Util.PROPERTIES.getProperty("app.printing.selected.menu.action.text"));
        exportar.setText(Util.PROPERTIES.getProperty("application.exporting.menu.action.text"));
        exportarSelecionadas.setText(Util.PROPERTIES.getProperty("application.exporting.selected.menu.action.text"));
        importar.setText(Util.PROPERTIES.getProperty("application.importing.menu.action.text"));
        gerarCardapio.setText(Util.PROPERTIES.getProperty("application.gerar.cardapios.menu.action.text"));
        ajuda.setText(Util.PROPERTIES.getProperty("application.ajuda.menu.action.text"));
        mapaAtalhos.setText(Util.PROPERTIES.getProperty("application.mapa.teclado.menu.action.text"));
        paginaInicial.setText(Util.PROPERTIES.getProperty("application.initial.page.menu.action.text"));
        about.setText(Util.PROPERTIES.getProperty("application.about.page.menu.action.text"));
        logout.setText(Util.PROPERTIES.getProperty("application.logout.menu.action.text"));

        imprimirTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("print.all.shortcut") + ")");
        imprimirTooltip.setFont(toolTipsFont);
        Tooltip.install(imprimir, imprimirTooltip);

        imprimirSelecionadasTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("print.selected.shortcut") + ")");
        imprimirSelecionadasTooltip.setFont(toolTipsFont);
        Tooltip.install(imprimirSelecionadas, imprimirSelecionadasTooltip);

        exportarTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("export.all.shortcut") + ")");
        exportarTooltip.setFont(toolTipsFont);
        Tooltip.install(exportar, exportarTooltip);

        exportarSelectionadasTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("export.selected.shortcut") + ")");
        exportarSelectionadasTooltip.setFont(toolTipsFont);
        Tooltip.install(exportarSelecionadas, exportarSelectionadasTooltip);

        importarTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("import.shortcut") + ")");
        importarTooltip.setFont(toolTipsFont);
        Tooltip.install(importar, importarTooltip);

        ajudaTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("main.help.shortcut") + "),(" + Util.PROPERTIES.getProperty("context.help.shortcut") + " ajuda específica)");
        ajudaTooltip.setFont(toolTipsFont);
        Tooltip.install(ajuda, ajudaTooltip);

        atalhosTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("keymap.help.shortcut") + ")");
        atalhosTooltip.setFont(toolTipsFont);
        Tooltip.install(mapaAtalhos, atalhosTooltip);

        paginaInicialTooltip = new Tooltip(Util.PROPERTIES.getProperty("application.initial.page.menu.tool.tip"));
        paginaInicialTooltip.setFont(toolTipsFont);
        Tooltip.install(paginaInicial, paginaInicialTooltip);

        aboutTooltip = new Tooltip(String.format(Util.PROPERTIES.getProperty("application.about.page.menu.tool.tip"), Util.PROPERTIES.getProperty("developer")));
        aboutTooltip.setFont(toolTipsFont);
        Tooltip.install(about, aboutTooltip);

        gerarCardapioTooltip = new Tooltip((Util.PROPERTIES.getProperty("notification.page.cardapio.not.supported.yet.title").toUpperCase() + "\n" + String.format(Util.PROPERTIES.getProperty("notification.page.cardapio.not.supported.yet.broken.lined.message"), Util.PROPERTIES.getProperty("developer"), Util.PROPERTIES.getProperty("developer.celular"), Util.PROPERTIES.getProperty("developer.email"))));
        gerarCardapioTooltip.setFont(toolTipsFont);
        Tooltip.install(gerarCardapio, gerarCardapioTooltip);
    }

    public void setUp(Page page) {
        try {

            actions.setUpHeightAndWidthListeners();

            setOpacity(0.95);

            if (page.equals(container.getNenhumaReceitaSelecionada())) {
                imprimirSelecionadasIcon.setFill(Paint.valueOf(DISABLED_COLOR));
                imprimirSelecionadas.setFill(Paint.valueOf(DISABLED_COLOR));
                imprimirSelecionadas.setDisable(true);
            } else if (page.equals(container.getWelcomePage())) {
                setOpacity(0.8);
            }

        } catch (Exception e) {
        }

    }

    public AppContainer getAppContainer() {
        return container;
    }

    public MenuActions getActions() {
        return actions;
    }

    public Tooltip getMenuTooltip() {
        return menuTooltip;
    }

    public Text getExportar() {
        return exportar;
    }

    public Text getImportar() {
        return importar;
    }

    public Text getExportarSelecionadas() {
        return exportarSelecionadas;
    }

    public Text getImprimir() {
        return imprimir;
    }

    public Text getImprimirSelecionadas() {
        return imprimirSelecionadas;
    }

    public Text getAjuda() {
        return ajuda;
    }

    public Text getMapaAtalhos() {
        return mapaAtalhos;
    }

    public Text getAbout() {
        return about;
    }

    public boolean isImporting() {
        return actions.isImporting();
    }

    // DESAbilita opcao EXPORTAR SELECIONADAS DO MENU,SUPONDO AO INICIAR LIVRO NENHUM ITEM ESTEJA SELECIONADO
    public void setAsNoSelection() {
        exportarSelecionadasIcon.setFill(Paint.valueOf(DISABLED_COLOR));
        exportarSelecionadas.setFill(Paint.valueOf(DISABLED_COLOR));
        exportarSelecionadas.setDisable(true);

        imprimirSelecionadas.setFill(Paint.valueOf(DISABLED_COLOR));
        imprimirSelecionadasIcon.setFill(Paint.valueOf(DISABLED_COLOR));
        imprimirSelecionadas.setDisable(true);
    }

    // HAbilita opcao EXPORTAR SELECIONADAS DO MENU ENTRE OUTRAS.
    public void setAsSomeSelection() {

        exportarSelecionadasIcon.setFill(Paint.valueOf("WHITE"));
        exportarSelecionadas.setFill(Paint.valueOf("WHITE"));
        exportarSelecionadas.setDisable(false);

        imprimirSelecionadas.setFill(Paint.valueOf("WHITE"));
        imprimirSelecionadasIcon.setFill(Paint.valueOf("WHITE"));
        imprimirSelecionadas.setDisable(false);

    }

    public void setAsEmptyList() {

        setAsNoSelection();

        printerIcon.setFill(Paint.valueOf(DISABLED_COLOR));
        imprimir.setFill(Paint.valueOf(DISABLED_COLOR));
        imprimirIcon.setFill(Paint.valueOf(DISABLED_COLOR));

        exportar.setFill(Paint.valueOf(DISABLED_COLOR));
        exportarIcon.setFill(Paint.valueOf(DISABLED_COLOR));
        gerarCardapio.setFill(Paint.valueOf(DISABLED_COLOR));
        gerarCardapiosIcon.setFill(Paint.valueOf(DISABLED_COLOR));

        imprimir.setDisable(true);
        exportar.setDisable(true);
        gerarCardapio.setDisable(true);
    }

    public void setAsNOTEmptyList() {
        printerIcon.setFill(Paint.valueOf("WHITE"));
        imprimir.setFill(Paint.valueOf("WHITE"));
        imprimirIcon.setFill(Paint.valueOf("WHITE"));

        if (!container.getListaDeReceitas().getView().getSelection().isEmpty()) {
            setAsSomeSelection();
        }

        exportar.setFill(Paint.valueOf("WHITE"));
        exportarIcon.setFill(Paint.valueOf("WHITE"));

        gerarCardapio.setFill(Paint.valueOf("WHITE"));
        gerarCardapiosIcon.setFill(Paint.valueOf("WHITE"));

        imprimir.setDisable(false);
        exportar.setDisable(false);
        gerarCardapio.setDisable(false);

    }

    public void setActions(MenuActions actions) {
        this.actions = actions;
    }

    /**
     * Handler para imprimir em PDF todos os objetos.
     */
    public void handlePrintAll() {

        //CONDICIONAL TESTE PARA PROCESSAR OU NAO CHAMADAS AO MENU, FEITAS ATRAVES DOS ATALHOS DO TECLADO 
        if (container.getListaDeReceitas().size() > 0) {

            if (!canPrintAllNow()) {
                waitThenTryPrintingAll();
            } else {
                printAllNow();
            }

        } else {
            container.getListaDeReceitas().shake();
        }

    }

    private boolean canPrintAllNow() {
        return !container.getListaDeReceitas().isRemoving() && !container.getListaDeReceitas().isSelecting() && actions.getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void waitThenTryPrintingAll() {

        int timeOut = 3000;

        //SE ESTIVER LIVRE, MAS SE ESTIVER REMOVENDO OBJETOS OU SELECIONADO OBJETOS ENTAO AGUARDA REMOVER/SELECIONAR FINALIZAR.
        if (actions.getCurrentAction().equals(MenuActions.LIVRE)) {
            actions.getActionIcon().setGlyphName("PRINTER");
            actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("printing.action.text"));
            actions.setUp(Util.PROPERTIES.getProperty("application.printing.action.text"));
            if (container.getListaDeReceitas().isRemoving()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.removing.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.printing.waiting.deletion.complete.action.text"));
            } else if (container.getListaDeReceitas().isSelecting()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.selection.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.printing.waiting.selection.complete.action.text"));
            }
        } else {//ALGUMA ACAO ESTAVA SENDO REALIZADA. ENTAO NOTIFICA INDISPONIBILIDADE DESTE SERVIÇO E RETORNA.
            Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("printing.unavaliable.message"), timeOut);
            return;
        }

        new Thread(() -> {
            while (!canPrintAllNow()) {
            }
            Platform.runLater(() -> {
                printAllNow();
            });
        }).start();
    }

    /**
     * Imprime em PDF todos os objetos.
     */
    private void printAllNow() {
        actions.getActionIcon().setGlyphName("PRINTER");
        actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("printing.action.text"));
        actions.setUp(Util.PROPERTIES.getProperty("application.printing.preparing.action.text"));
        actions.printAll();
    }

    /**
     * Handler para imprimir em PDF apenas objetos selecionados.
     */
    public void handlePrintSelected() {
        //CONDICIONAL TESTE PARA PROCESSAR OU NAO CHAMADAS AO MENU, FEITAS ATRAVES DOS ATALHOS DO TECLADO 
        if (container.getListaDeReceitas().getView().getSelection().size() > 0) {
            if (!canPrintSelectedNow()) {
                waitThenTryPrintingSelected();
            } else {
                printSelectedNow();
            }
        }

    }

    private boolean canPrintSelectedNow() {
        return !container.getListaDeReceitas().isSelecting()  && !container.getListaDeReceitas().isRemoving() && actions.getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void waitThenTryPrintingSelected() {

        int timeOut = 3000;

        //SE ESTIVER LIVRE, MAS SE ESTIVER REMOVENDO OBJETOS OU SELECIONADO OBJETOS ENTAO AGUARDA REMOVER/SELECIONAR FINALIZAR.
        if (actions.getCurrentAction().equals(MenuActions.LIVRE)) {
            actions.getActionIcon().setGlyphName("PRINTER");
            actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("printing.action.text"));
            if (container.getListaDeReceitas().isSelecting()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.selection.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("selected.printing.waiting.selection.complete.action.text"));
            } else if (container.getListaDeReceitas().isRemoving()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.removing.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("selected.printing.waiting.deletion.complete.action.text"));
            }
        } else {//ALGUMA ACAO ESTAVA SENDO REALIZADA. ENTAO NOTIFICA INDISPONIBILIDADE DESTE SERVIÇO E RETORNA.
            Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("printing.unavaliable.message"), timeOut);
            return;
        }

        new Thread(() -> {
            while (!canPrintSelectedNow()) {
            }
            Platform.runLater(() -> {
                printSelectedNow();
            });
        }).start();

    }

    /**
     * Imprime em PDF APENAS os objetos selecionados.
     */
    private void printSelectedNow() {

        actions.getActionIcon().setGlyphName("PRINTER");
        actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("printing.action.text"));

        if (container.getListaDeReceitas().getView().getSelection().size() > 1) {
            actions.setUp(Util.PROPERTIES.getProperty("application.printing.selected.preparing.action.text"));
            actions.printSelected();
        } else if (container.getListaDeReceitas().getView().getSelection().size() == 1) {
            actions.setUp(Util.PROPERTIES.getProperty("application.printing.selectec.single.preparing.action.text"));
            actions.printSelected();
        } else {
            actions.setUp(Util.PROPERTIES.getProperty("nothing.to.print.message"));
            actions.handleNadaParaImprimir();
        }
    }

    /**
     * Handler para exportar para JSON TODOS os objetos.
     */
    public void handleExportAll() {
        //CONDICIONAL TESTE PARA PROCESSAR OU NAO CHAMADAS AO MENU, FEITAS ATRAVES DOS ATALHOS DO TECLADO 
        if (container.getListaDeReceitas().size() > 0) {

            if (!canExportAllNow()) {
                waitThenTryExportingAll();
            } else {
                exportAllNow();
            }

        } else {
            container.getListaDeReceitas().shake();
        }
    }

    /**
     * Handler para importar de JSON.
     */
    public void handleImporting() {
        if (!canImportNow()) {
            waitThenTryImporting();
        } else {
            importNow();
        }
    }

    /**
     * Handler para exportar para JSON APENAS objetos selecionados.
     */
    public void handleExportSelected() {
        //CONDICIONAL TESTE PARA PROCESSAR OU NAO CHAMADAS AO MENU, FEITAS ATRAVES DOS ATALHOS DO TECLADO 
        if (container.getListaDeReceitas().getView().getSelection().size() > 0) {
            if (!canExportSelectedNow()) {
                waitThenTryExportingSelected();
            } else {
                exportSelectedNow();
            }
        }
    }

    private void handleGerarCardapio() {
        Platform.runLater(() -> {
            Notificator.showNotificationPage(container, Notifications.get(Notifications.CARDAPIO_NOT_SUPPORTED_YET, container.getListaDeReceitas()));
        });
    }

    /**
     * Handler para executar corretamente o logout.
     */
    public void handleLogout() {

        if (container.canLogOut()) {

            logout();

        } else {

            Notificator.showNotificationPage(Notifications.get(Notifications.LOG_OUT_CONFIRMATION, container.getListaDeReceitas()));

        }

    }

    /**
     * Executa o logout.<br>
     * Faz alguns encerramentos preliminares e chama Platform.exit()<br>
     * AppContainer.stop() toma conta de VÁRIAS OUTRAS coisas necessárias antes
     * da encerrar a VM.
     */
    public void logout() {

        PageNavigator.goToPageSmoothly(container, container.getNenhumaReceitaSelecionada());

        new Thread(() -> {
            while (container.isChangingPage()) {
            };
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
            }
            Platform.runLater(() -> {
                container.getNotificationPage().setVisible(false);
                Notificator.notificate(container, "ENCERRANDO...", 2000);
                aboutPage.esconder();
                aboutPage.dispose();
                container.getCurrentPage().disableMenuIcon();
                container.getCurrentPage().setOpacity(0.60);
                container.getListaDeReceitas().setOpacity(0.60);
                container.getListaDeReceitas().block();
            });
        }).start();

        new Thread(() -> {
            try {

                Thread.sleep(1000);

                while (container.isChangingPage()) {
                };
                while (Notificator.isNotificating) {
                };

                Thread.sleep(500);
                Platform.runLater(() -> {
                    Platform.exit();
                });
            } catch (InterruptedException ex) {
                Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
            }

        }).start();

    }

    private boolean canExportSelectedNow() {
        return !container.getListaDeReceitas().isSelecting() && !container.getListaDeReceitas().isRemoving() && actions.getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void waitThenTryExportingSelected() {

        int timeOut = 3000;

        //SE ESTIVER LIVRE, MAS SE ESTIVER REMOVENDO OBJETOS OU SELECIONADO OBJETOS ENTAO AGUARDA REMOVER/SELECIONAR FINALIZAR.
        if (actions.getCurrentAction().equals(MenuActions.LIVRE)) {
            actions.getActionIcon().setGlyphName("EXPORT");
            actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("exporting.action.text"));
            if (container.getListaDeReceitas().isSelecting()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.selection.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("selected.exporting.waiting.selection.complete.action.text"));
            } else if (container.getListaDeReceitas().isRemoving()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.removing.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("selected.exporting.waiting.deletion.complete.action.text"));
            }
        } else {//ALGUMA ACAO ESTAVA SENDO REALIZADA. ENTAO NOTIFICA INDISPONIBILIDADE DESTE SERVIÇO E RETORNA.
            Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("exporting.unavaliable.message"), timeOut);
            return;
        }

        new Thread(() -> {
            while (!canExportSelectedNow()) {
                System.err.println("waiting exporting selected frreing");
            }
            Platform.runLater(() -> {
                exportSelectedNow();
            });
        }).start();
    }

    private boolean canImportNow() {
        return !container.getListaDeReceitas().isSelecting() && !container.getListaDeReceitas().isRemoving() && actions.getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void waitThenTryImporting() {

        int timeOut = 3000;

        //SE ESTIVER LIVRE, MAS SE ESTIVER REMOVENDO OBJETOS OU SELECIONADO OBJETOS ENTAO AGUARDA REMOVER/SELECIONAR FINALIZAR.
        if (actions.getCurrentAction().equals(MenuActions.LIVRE)) {

            actions.getActionIcon().setGlyphName("IMPORT");
            actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("importing.action.text"));
            if (container.getListaDeReceitas().isSelecting()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.selection.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.importing.waiting.selection.complete.action.text"));
            } else if (container.getListaDeReceitas().isRemoving()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.removing.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.importing.waiting.deletion.complete.action.text"));
            }

        } else {//ALGUMA ACAO ESTAVA SENDO REALIZADA. ENTAO NOTIFICA INDISPONIBILIDADE DESTE SERVIÇO E RETORNA.
            Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("importing.unavaliable.message"), timeOut);
            return;
        }

        new Thread(() -> {
            while (!canImportNow()) {
            }
            Platform.runLater(() -> {
                importNow();
            });
        }).start();
    }

    /**
     * Importa de JSON.
     */
    private void importNow() {
        actions.getActionIcon().setGlyphName("IMPORT");
        actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("importing.action.text"));
        actions.setUp(Util.PROPERTIES.getProperty("application.importing.action.text"));
        actions.importar();
    }

    /**
     * Exporta para JSON APENAS objetos selecionados.
     */
    private void exportSelectedNow() {
        actions.getActionIcon().setGlyphName("EXPORT");
        actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("exporting.action.text"));
        if (container.getListaDeReceitas().getView().getSelection().size() > 1) {
            actions.setUp(Util.PROPERTIES.getProperty("application.exporting.selected.preparing.action.text"));
            actions.exportSelected();
        } else if (container.getListaDeReceitas().getView().getSelection().size() == 1) {
            actions.setUp(Util.PROPERTIES.getProperty("application.exporting.selectec.single.preparing.action.text"));
            actions.exportSelected();
        } else {
            actions.setUp(Util.PROPERTIES.getProperty("nothing.to.export.message"));
            actions.handleNadaParaExportar();
        }
    }

    private boolean canExportAllNow() {
        return !container.getListaDeReceitas().isRemoving() &&  actions.getCurrentAction().equals(MenuActions.LIVRE);
    }

    private void waitThenTryExportingAll() {

        int timeOut = 3000;

        //SE ESTIVER LIVRE, MAS SE ESTIVER REMOVENDO OBJETOS OU SELECIONADO OBJETOS ENTAO AGUARDA REMOVER/SELECIONAR FINALIZAR.
        if (actions.getCurrentAction().equals(MenuActions.LIVRE)) {
            actions.getActionIcon().setGlyphName("EXPORT");
            actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("exporting.action.text"));
            if (container.getListaDeReceitas().isSelecting()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.selection.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.exporting.waiting.selection.complete.action.text"));
            } else if (container.getListaDeReceitas().isRemoving()) {
                Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("waiting.complete.removing.notification.text"), timeOut);
                actions.setUp(Util.PROPERTIES.getProperty("application.exporting.waiting.deletion.complete.action.text"));
            }
        } else {//ALGUMA ACAO ESTAVA SENDO REALIZADA. ENTAO NOTIFICA INDISPONIBILIDADE DESTE SERVIÇO E RETORNA.
            Notificator.notificateWarning(container, Util.PROPERTIES.getProperty("exporting.unavaliable.message"), timeOut);
            return;
        }

        new Thread(() -> {
            while (!canExportAllNow()) {
            }
            Platform.runLater(() -> {
                exportAllNow();
            });
        }).start();

    }

    /**
     * Exporta para JSON todos objetos.
     */
    private void exportAllNow() {
        actions.getActionIcon().setGlyphName("EXPORT");
        actions.getExecutarMenuAction().setText(Util.PROPERTIES.getProperty("exporting.action.text"));
        actions.setUp(Util.PROPERTIES.getProperty("application.exporting.preparing.action.text"));
        actions.exportAll();
    }

    /**
     * Handler para mostrar mapa de atalhos do teclado da app. <br>
     */
    public void handleOpenMapaAtalhosTecladoPdf() {
        Helper.openKeyMapPdfViewer();
    }

    /**
     * Handler para mostrar master helper pdf da app. <br>
     */
    public void handleOpenMasterHelpPdf() {
        Helper.openMasterHelperPdfViewer();
    }

    AboutFX aboutPage = new AboutFX();

    private void handleAboutPage() {
        aboutPage.abrir();
    }

    /**
     * Handler para restaurar pagina inicial da app. <br>
     */
    private void handleRestaurarPaginaInicial() {
        container.getWelcomePage().restaurar();
    }

    public void handleMouseClicked() {
        if (isVisible()) {
            setVisible(false);
        } else {
            setVisible(true);
        }
    }

    File pdf = null;

    public void doSomethinf() {

        System.out.println(System.getProperty("user.dir"));

    }

    public AboutFX getAboutPage() {
        return aboutPage;
    }

    public static void main(String[] args) {
        new Menu().doSomethinf();
    }

}
