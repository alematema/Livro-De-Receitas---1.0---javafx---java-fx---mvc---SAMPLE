package br.com.undra.livrodereceitas.menus;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.paginas.LoaderPage;
import static br.com.undra.livrodereceitas.paginas.LoaderPage.NOTHING_TO_LOAD;
import br.com.undra.livrodereceitas.services.exporting.ExportingImportingService;
import br.com.undra.livrodereceitas.services.exporting.ExportingImpotingServiceImpl_JSON;
import br.com.undra.livrodereceitas.services.printing.PrintingService;
import br.com.undra.livrodereceitas.services.printing.PrintingServiceImpl_TO_PDF_iText;
import br.com.undra.livrodereceitas.util.Notificator;
import com.jfoenix.controls.JFXButton;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.util.Duration;

/**
 * Models the menu actions:<br>
 * IMPRIMIR LIVRO<br>
 * IMPRIMIR RECEITA<br>
 * EXPORTAR LIVRO<br>
 * IMPORTAR RECEITAS<br>
 *
 * @author alexandre
 */
// #262d3a
public class MenuActions extends Pane {

    @FXML
    private Pane statusBarCmp;
    @FXML
    private Pane statusBar;
    @FXML
    private Label msgL1;

    @FXML
    private Pane menuActionPane;

    @FXML
    private JFXButton executarMenuAction;

    @FXML
    private JFXButton cancelarMenuAction;

    @FXML
    private Label actionLabel;

    @FXML
    private Pane errorMessageContainer;

    @FXML
    private Label errorMsgLabel;

    @FXML
    private MaterialDesignIconView errorMessageIcon;

    private Menu menu;

    volatile private boolean isCanceled = false;
    volatile private double statusBarValue;
    volatile private String statusBarMessage;

    public static String EXPORTAR_ACAO = "EXPORTAR_ACAO";
    public static String EXPORTAR_SELECIONADAS_ACAO = "EXPORTAR_SELECIONADAS_ACAO";
    public static String IMPORTAR_ACAO = "IMPORTAR_ACAO";
    public static String IMPRIMIR_BOOK_ACAO = "IMPRIMIR_ACAO";
    public static String IMPRIMIR_SELECIONADAS_ACAO = "IMPRIMIR_SELECIONADAS_ACAO";
    public volatile static String LIVRE = "LIVRE";

    volatile private String currentAction = LIVRE;

    final private FileChooser fileChooser;

    private ExportingImportingService exportImportService;
    private PrintingService printingService;

    volatile private boolean isImporting;

    @FXML
    private MaterialDesignIconView actionIcon;
    @FXML
    private Text developer;

    private ChangeListener<? super Number> menuActionHeightListener = (observable, oldValue, newValue) -> {

        setPrefHeight(newValue.doubleValue());
        cancelarMenuAction.setLayoutY(newValue.doubleValue() * 0.9);
        executarMenuAction.setLayoutY(newValue.doubleValue() * 0.9);
        developer.setLayoutY(newValue.doubleValue()-15);
        
        
    };

    private ChangeListener<? super Number> menuActionWidthListener = (observable, oldValue, newValue) -> {

        setPrefWidth(newValue.doubleValue());
        executarMenuAction.setLayoutX(newValue.doubleValue() - executarMenuAction.getPrefWidth() - 30);
        cancelarMenuAction.setLayoutX(executarMenuAction.getLayoutX() - executarMenuAction.getPrefWidth() - 10);
        if (currentAction.equals(IMPORTAR_ACAO)) {
            cancelarMenuAction.setLayoutX(newValue.doubleValue() - cancelarMenuAction.getPrefWidth() - 30);
        }

        double spacingLocal = (getPrefWidth() - getStatusBarMaxWidth()) / 2 - statusBar.getLayoutX();
        statusBarCmp.setLayoutX(spacingLocal);

        double layoutY = (getPrefHeight() - getElementsHeight()) / 2 - 30;
        statusBarCmp.setLayoutY(layoutY);

        errorMessageContainer.setLayoutY(statusBarCmp.getLayoutY() + 50);
        errorMessageContainer.setLayoutX(statusBarCmp.getLayoutX());

    };

    private double statusBarMaxWidth;

    private volatile boolean loaded = false;
    private volatile boolean actionDone;
    private volatile boolean inAction;

    public MenuActions() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLMenuActions.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        cancelarMenuAction.toFront();
        executarMenuAction.toFront();
        fileChooser = new FileChooser();

    }

    public MenuActions(Menu menu) {
        this();
        this.menu = menu;

        setVisible(false);

        developer.setText(Util.getDeveloperAndContact());
        
        exportImportService = new ExportingImpotingServiceImpl_JSON();
        printingService = new PrintingServiceImpl_TO_PDF_iText();

        EventHandler<ActionEvent> cancelarMenuActionEvent = (event) -> {
            handleCancelarMenuActionMouseClicked(null);
        };

        EventHandler<ActionEvent> executarMenuActionEvent = (event) -> {
            handleExecutarMenuActionMouseClicked(null);
        };

        cancelarMenuAction.setOnAction(cancelarMenuActionEvent);
        executarMenuAction.setOnAction(executarMenuActionEvent);

    }

    public Menu getMenu() {
        return menu;
    }

    public String getCurrentAction() {
        return currentAction;
    }

    public double getStatusBarMaxWidth() {
        statusBarMaxWidth = getPrefWidth() * 0.7;
        return statusBarMaxWidth;
    }

    double elementsHeight = -1;

    public double getElementsHeight() {

        //for calculate only once
        if (elementsHeight < 0) {

            elementsHeight = 0;
            elementsHeight += statusBarCmp.getHeight();
            elementsHeight += 30;
            elementsHeight += errorMessageContainer.getHeight();

        }

        return elementsHeight;
    }

    /**
     * Atualiza barras de progresso.<br>
     * As barras são a de progresso da Lista e a progress bar da acao corrente.
     *
     * @param newValue o novo valor.
     * @param newMessage a nova mensagem.
     */
    public void setBarProgress(double newValue, String newMessage) {
        statusBarValue = newValue;
        statusBarMessage = newMessage;
        applyNewValue(msgL1, statusBarValue, statusBar, statusBarMessage);
        menu.getAppContainer().getListaDeReceitas().setProgressValue(statusBarValue);
    }

    /**
     * Atualiza bar com newValue e target com newMessage.
     *
     * @param target o target da newMessage.
     * @param newValue o newValue da bar.
     * @param bar a bar que sera atualizada com newValue.
     * @param newMessage a newMessage da target.
     */
    private synchronized void applyNewValue(Label target, double newValue, Pane bar, String newMessage) {

        if (newValue >= 0 && newValue <= 1) {

            handleApplyNewValue(bar, newValue, target, newMessage);

        } else if (newValue == NOTHING_TO_LOAD) {

            handleApplyNothingToDoValue(bar, target);

        }
    }

    private void handleApplyNothingToDoValue(Pane bar, Label target) {
        switch (bar.getId()) {
            case "statusBar":
                actionDone = true;
                setNothingToLoadMessage(Util.PROPERTIES.getProperty("canceled.action.message"), target, bar);

                break;

            default:
                break;
        }
    }

    private void handleApplyNewValue(Pane bar, double newValue, Label target, String newMessage) {
        Platform.runLater(() -> {
            bar.setPrefWidth(getStatusBarMaxWidth() * newValue);
        });

        String pristineText = getPristineText(target.getText());

        Platform.runLater(() -> {
            target.setText(pristineText + newMessage);
        });

        if (newValue == 1) {

            handleActionCompleted(bar, target, newMessage);

        } else if (newValue == 0) {
            handleActionStarted(bar);
        } else {
            handleActionInProgress(bar);
            if (isPrinting()) {
                if (newValue == 0.5) {
                    Platform.runLater(() -> {
                        bar.setStyle("-fx-background-color: red;-fx-background-radius:4;-fx-cursor:wait");
                        // SETTINGS APROPRIADOS DAS MENSAGENS READY TO PRINT
                        if (currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
                            msgL1.setText(Util.PROPERTIES.getProperty("ready.to.print.application.message"));
                        } else if (currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
                            if (objects.size() > 1) {
                                msgL1.setText(Util.PROPERTIES.getProperty("ready.to.print.selected.message"));
                            } else {
                                msgL1.setText(Util.PROPERTIES.getProperty("ready.to.print.selected.single.message"));
                            }
                        }

                    });
                }
            }
        }
    }

    private void handleActionInProgress(Pane bar) {
        Platform.runLater(() -> {
            bar.setStyle("-fx-background-color: red;-fx-background-radius:4;-fx-cursor:wait");
        });
    }

    private void handleActionStarted(Pane bar) {
        Platform.runLater(() -> {
            bar.setStyle("-fx-background-color:  #595959;-fx-background-radius:4;-fx-cursor:close_hand");
            bar.setPrefWidth(getStatusBarMaxWidth());
        });
    }

    private void handleActionCompleted(Pane bar, Label target, String message) {
        Platform.runLater(() -> {

            bar.setStyle("-fx-background-color: #8bff00;-fx-background-radius:4;-fx-cursor:default");

            switch (bar.getId()) {
                case "statusBar":
                    actionDone = true;
                    if (currentAction.equals(EXPORTAR_ACAO)) {
                        target.setText(Util.PROPERTIES.getProperty("ready.to.export.application.message"));
                    } else if (currentAction.equals(IMPORTAR_ACAO)) {
                        target.setText(message);
                    } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
                        if (objects.size() > 1) {
                            msgL1.setText(Util.PROPERTIES.getProperty("ready.to.export.selected.message"));
                        } else {
                            msgL1.setText(Util.PROPERTIES.getProperty("ready.to.export.selected.single.message"));
                        }
                    } else if (currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
                        msgL1.setText(Util.PROPERTIES.getProperty("printing.application.success.message"));
                    }
                    break;

                default:
                    break;
            }
        });
    }

    private void setNothingToLoadMessage(String message, Label target, Pane loader) {
        Platform.runLater(() -> {
            target.setText(message);
            loader.setStyle("-fx-background-color:  #595959;-fx-background-radius:4");
            loader.setPrefWidth(getStatusBarMaxWidth());
        });
    }

    /**
     * Lógica para recuperar textos originais como CARREGANDO RECEITAS ou
     * CARREGANDO TIPOS DE COMIDAS.
     * <br> FORMALMENTE : getPristineText("CARREGANDO RECEITAS 0/0 ...") =
     * CARREGANDO RECEITAS
     * <br>FORMALMENTE : getPristineText("CARREGANDO RECEITAS 2/1000") =
     * CARREGANDO RECEITAS
     * <br>FORMALMENTE : getPristineText("CARREGANDO RECEITAS MAIS QUALQUER
     * PALAVRA OU PALAVRAS") = CARREGANDO RECEITAS
     *
     * @param text the text
     * @return
     */
    private String getPristineText(String text) {

        int j = 0;
        if (text.endsWith("...")) {
            String elipsesOut = text.substring(0, text.length() - 3);
            text = elipsesOut;
        }
        String[] splits = text.split(" ");
        if (text.contains("/")) {
            j = splits.length - 1;
        } else {
            j = splits.length;
        }

        String pristineText = "";
        for (int i = 0; i < j; i++) {
            pristineText += splits[i];
            pristineText += " ";
        }

        return pristineText;
    }

    volatile private boolean readyToAction = false;

    /**
     * Executa apropriadamente cancelamento da currentAction.<br>
     * Além disso,o método habilita para GC as coleçoes referenciadas por outros
     * metodos.
     *
     * @param event
     */
    @FXML
    public void handleCancelarMenuActionMouseClicked(MouseEvent event) {

        isCanceled = true;
        cancelarMenuAction.setVisible(false);
        executarMenuAction.setVisible(false);

        if (isExporting()) {
            if (canCancelExporting()) {
                if (objects != null) {
                    objects.clear();
                }
                handleCanceledAction(Util.PROPERTIES.getProperty("canceled.exporting.message"), 3000);
            }
        } else if (isPrinting()) {
            if (canCancelPrinting()) {
                if (objects != null) {
                    objects.clear();
                }
                handleCanceledAction(Util.PROPERTIES.getProperty("canceled.printing.message"), 3000);
            }
        }else{
            
        }
    }

    private boolean canCancelExporting() {
        return readyToAction;
    }

    /**
     * Informa se currentAction é EXPORTAR_ACAO ou EXPORTAR_SELECIONADAS_ACAO.
     *
     * @return
     */
    private boolean isExporting() {
        return currentAction.equals(EXPORTAR_ACAO) || currentAction.equals(EXPORTAR_SELECIONADAS_ACAO);
    }

    /**
     * Informa se currentAction é IMPRIMIR_BOOK_ACAO ou
     * IMPRIMIR_SELECIONADAS_ACAO.
     *
     * @return
     */
    private boolean isPrinting() {
        return currentAction.equals(IMPRIMIR_BOOK_ACAO) || currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO);
    }

    private boolean canCancelPrinting() {
        return readyToAction;
    }

    @FXML
    public void handleExecutarMenuActionMouseClicked(MouseEvent event) {
        //if not ready to action then can take an action.
        //otherwise, if ready to action, then the code bellow avoids unnecessary repetition
        if (!inAction) {
            if (isExporting()) {
                handleExport();
            } else if (currentAction.equals(IMPORTAR_ACAO)) {

            } else if (isPrinting()) {
                handlePrint();
            }
        }
    }

    /**
     * Escolhe-se o arquivo para o qual se deseja serializar os objetos da
     * colecao objects.<br>
     * Notifica sucesso ou falha na exportacao.<br>
     * Delega para algum outro metodo habilitar para GC os objetos da colecao
     * objects.
     */
    private void handleExport() {
        inAction = true;
        executarMenuAction.setVisible(false);
        cancelarMenuAction.setVisible(false);
        doFileChooserInitialFileNameSetting();
        while (true) {
            File jsonFile = fileChooser.showSaveDialog(menu.getAppContainer().getStage().getOwner());
            if (jsonFile != null) {
                try {

                    exportImportService.export(objects, jsonFile);

                    // SETTINGS APROPRIADOS DAS NOTIFICACOES DE SUCESSO NA EXPORTACAO DOS OBJETOS 
                    if (currentAction.equals(EXPORTAR_ACAO)) {
                        msgL1.setText(Util.PROPERTIES.getProperty("exporting.application.success.message"));
                        Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("exporting.application.success.notificator.message") + " " + jsonFile.getName(), 2000);
                    } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
                        if (objects.size() > 1) {
                            msgL1.setText(Util.PROPERTIES.getProperty("exporting.selected.success.message"));
                            Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("exporting.selected.success.notificator.message") + " " + jsonFile.getName(), 2000);
                        } else {
                            msgL1.setText(Util.PROPERTIES.getProperty("exporting.selected.single.success.message"));
                            Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("exporting.selected.single.success.notificator.message") + " " + jsonFile.getName(), 2000);
                        }
                    }
                    //ESTE METODO LIBERA PARA GC OS OBJETOS DA COLECAO objects
                    handleExportSuccessful(jsonFile);
                    inAction = false;
                    break;
                } catch (Exception e) {
                    handleExportError(jsonFile);
                }
            } else {
                executarMenuAction.setVisible(true);
                cancelarMenuAction.setVisible(true);
                handleCanceledAction();
                break;
            }
        }
    }

    private void handleExportError(File jsonFile) {
        Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty("exporting.application.error.message"), 4000);
        try {
            Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("exporting.application.error.logger.message"), jsonFile.getCanonicalPath());
        } catch (IOException ex) {
            Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
        }
        FadeTransition ft = new FadeTransition(Duration.seconds(3.0), this);
        ft.setFromValue(1);
        ft.setToValue(0);
        ft.setOnFinished((event) -> {
            executarMenuAction.setVisible(true);
            cancelarMenuAction.setVisible(true);
            setOpacity(1);
            setVisible(false);
            isCanceled = false;
            menu.getAppContainer().getListaDeReceitas().unblock();
            //LIBERA PARA GC OS OBJETOS DA COLECAO objects
            if (objects != null) {
                objects.clear();
            }
            currentAction = LIVRE;
            inAction = false;
        });
        ft.play();
    }

    /**
     * Gera o arquivo PDF.<br>
     *
     * Escolhe-se o arquivo para o qual se deseja gravar a sintax PDF relativa
     * aos objetos da colecao objects.<br>
     * Notifica sucesso ou falha na geracao do PDF.<br>
     * Delega para algum outro metodo habilitar para GC os objetos da colecao
     * objects.
     */
    private void handlePrint() {
        inAction = true;
        executarMenuAction.setVisible(false);
        cancelarMenuAction.setVisible(false);

        doFileChooserInitialFileNameSetting();

        while (true) {

            File pdf = fileChooser.showSaveDialog(menu.getAppContainer().getStage().getOwner());

            if (pdf != null) {
                try {

                    menu.getAppContainer().getListaDeReceitas().getView().setStatusMessage(Util.getPROPERTIES(menu.getAppContainer().getListaDeReceitas()).getProperty("printingObjects"));
                    FileOutputStream fos = new FileOutputStream(pdf);
                    //immediately forces printing flag
                    printingService.setIsPrinting(true);
                    msgL1.setText(Util.PROPERTIES.getProperty("printing.application.generating.pdf.message"));

                    //writes objects as pdf syntax to fos
                    new Thread(() -> {
                        printingService.print(objects, fos, this);
                    }).start();

                    new Thread(() -> {
                        while (printingService.isPrinting()) {
                        }

                        //ESTE METODO LIBERA PARA GC OS OBJETOS DA COLECAO objects
                        handlePrintSuccessful(pdf);
                        inAction = false;
                    }).start();

                    return;
                } catch (FileNotFoundException e) {
                    handlePrintError(pdf);
                }
            } else {
                executarMenuAction.setVisible(true);
                cancelarMenuAction.setVisible(true);
                handleCanceledAction();
                break;
            }
        }
    }

    //FILECHOOSER INITIAL FILE NAME SETTING
    private void doFileChooserInitialFileNameSetting() {
        if (currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
            fileChooser.setInitialFileName(Util.PROPERTIES.getProperty("printed.application.initial.file.name"));
        } else if (currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
            if (menu.getAppContainer().getListaDeReceitas().getView().getSelection().size() == 1) {
                fileChooser.setInitialFileName(menu.getAppContainer().getListaDeReceitas().getView().getSelection().get(0).getDescricao() + ".pdf");
            } else {
                fileChooser.setInitialFileName(Util.PROPERTIES.getProperty("printed.selected.initial.file.name"));
            }
        } else if (currentAction.equals(EXPORTAR_ACAO)) {
            fileChooser.setInitialFileName(Util.PROPERTIES.getProperty("exported.application.initial.file.name"));
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
            fileChooser.setInitialFileName(Util.PROPERTIES.getProperty("exported.selected.initial.file.name"));
        }

    }

    private void handlePrintError(File pdf) {
        Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty("printing.application.error.message"), 4000);
        try {
            Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("printing.application.error.logger.message"), pdf.getCanonicalPath());
        } catch (IOException ex) {
            Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
        }
        FadeTransition ft = new FadeTransition(Duration.seconds(3.0), this);
        ft.setFromValue(1);
        ft.setToValue(0);
        ft.setOnFinished((event) -> {
            executarMenuAction.setVisible(true);
            cancelarMenuAction.setVisible(true);
            setOpacity(1);
            setVisible(false);
            isCanceled = false;
            menu.getAppContainer().getListaDeReceitas().unblock();
            //LIBERA PARA GC OS OBJETOS DA COLECAO objects
            if (objects != null) {
                objects.clear();
            }
            currentAction = LIVRE;
            inAction = false;
        });
        ft.play();
    }

    /**
     * Notifica exportação realizada com sucesso.<br>
     * Habilita para GC os objetos da colecao objects.
     *
     * @param f
     */
    private void handleExportSuccessful(File f) {

        if (currentAction.equals(EXPORTAR_ACAO)) {
            try {
                Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("exporting.application.success.logger.message"), f.getCanonicalPath());
            } catch (IOException ex) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
            try {
                Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("exporting.selected.success.logger.message"), f.getCanonicalPath());
            } catch (IOException ex) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        new Thread(() -> {
            while (Notificator.isNotificating) {
            }
            FadeTransition ft = new FadeTransition(Duration.seconds(3.5), this);
            ft.setFromValue(1);
            ft.setToValue(0);
            ft.setOnFinished((event) -> {
                executarMenuAction.setVisible(true);
                cancelarMenuAction.setVisible(true);
                setOpacity(1);
                setVisible(false);
                isCanceled = false;
                menu.getAppContainer().getListaDeReceitas().unblock();
                //LIBERA PARA GC OS OBJETOS DA COLECAO objects
                if (objects != null) {
                    objects.clear();
                }
                currentAction = LIVRE;
            });
            ft.play();

        }).start();
    }

    /**
     * Notifica impressao realizada com sucesso.<br>
     * Habilita para GC os objetos da colecao objects.
     *
     * @param pdf
     */
    private void handlePrintSuccessful(File pdf) {

        Platform.runLater(() -> {
            setUpScrollerAfterAction();
        });

        setBarProgress(1, "1/1");
        // SETTINGS APROPRIADOS DAS NOTIFICACOES DE SUCESSO NA IMPRESSAO EM PDF DOS OBJETOS 
        if (currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
            Platform.runLater(() -> {
                msgL1.setText(Util.PROPERTIES.getProperty("printing.application.success.message"));
            });
            Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("printing.application.success.notificator.message") + " " + pdf.getName(), 2000);
        } else if (currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
            if (objects.size() > 1) {
                Platform.runLater(() -> {
                    msgL1.setText(Util.PROPERTIES.getProperty("printing.selected.success.message"));
                });
                Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("printing.selected.success.notificator.message") + " " + pdf.getName(), 2000);
            } else {
                Platform.runLater(() -> {
                    msgL1.setText(Util.PROPERTIES.getProperty("printing.selected.single.success.message"));
                });
                Notificator.notificate(menu.getAppContainer(), Util.PROPERTIES.getProperty("printing.selected.single.success.notificator.message") + " " + pdf.getName(), 2000);
            }
        }

        if (currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
            try {
                Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("printing.application.success.logger.message"), pdf.getCanonicalPath());
            } catch (IOException ex) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
            try {
                Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("printing.selected.success.logger.message"), pdf.getCanonicalPath());
            } catch (IOException ex) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        new Thread(() -> {
            while (Notificator.isNotificating) {
            }
            FadeTransition ft = new FadeTransition(Duration.seconds(3.5), this);
            ft.setFromValue(1);
            ft.setToValue(0);
            ft.setOnFinished((event) -> {
                executarMenuAction.setVisible(true);
                cancelarMenuAction.setVisible(true);
                setOpacity(1);
                setVisible(false);
                isCanceled = false;

                menu.getAppContainer().getListaDeReceitas().unblock();
                //LIBERA PARA GC OS OBJETOS DA COLECAO objects
                if (objects != null) {
                    objects.clear();
                }
                currentAction = LIVRE;
                inAction = false;
            });
            ft.play();

        }).start();
    }

    public void setUp(String action) {

        inAction = false;

        menu.getAppContainer().getListaDeReceitas().block();

        executarMenuAction.setVisible(false);
        cancelarMenuAction.setVisible(false);

        actionLabel.setText(action);
        msgL1.setText(action);

        setBarProgress(0, Util.PROPERTIES.getProperty("action.page.init.msg"));

//        statusBarCmp.setVisible(false);
        setPrefHeight(menu.getAppContainer().getCurrentPage().getPrefHeight());
        setPrefWidth(menu.getAppContainer().getCurrentPage().getPrefWidth());

        developer.setLayoutY(getPrefHeight()-15);
        
        double spacingLocal = (getPrefWidth() - getStatusBarMaxWidth()) / 2 - statusBar.getLayoutX();
        statusBarCmp.setLayoutX(spacingLocal);

        double layoutY = (getPrefHeight() - getElementsHeight()) / 2 - 30;
        statusBarCmp.setLayoutY(layoutY);

        errorMessageContainer.setLayoutY(statusBarCmp.getLayoutY() + 50);
        errorMessageContainer.setLayoutX(statusBarCmp.getLayoutX());
        errorMessageContainer.setVisible(false);

        cancelarMenuAction.setLayoutY(getPrefHeight() * 0.9);
        executarMenuAction.setLayoutY(getPrefHeight() * 0.9);

        executarMenuAction.setLayoutX(getPrefWidth() - executarMenuAction.getPrefWidth() - 30);
        cancelarMenuAction.setLayoutX(executarMenuAction.getLayoutX() - executarMenuAction.getPrefWidth() - 10);

        try {
            menu.getAppContainer().getCurrentPage().heightProperty().removeListener(menuActionHeightListener);
            menu.getAppContainer().getCurrentPage().widthProperty().removeListener(menuActionWidthListener);
            menu.getAppContainer().getCurrentPage().heightProperty().addListener(menuActionHeightListener);
            menu.getAppContainer().getCurrentPage().widthProperty().addListener(menuActionWidthListener);
        } catch (Exception e) {
        }

        if (!menu.getAppContainer().getCurrentPage().getChildren().contains(this)) {
            menu.getAppContainer().getCurrentPage().getChildren().add(this);
        }

        setVisible(true);

        isCanceled = false;

    }

    public void setUpHeightAndWidthListeners() {

        try {
            menu.getAppContainer().getCurrentPage().heightProperty().removeListener(menuActionHeightListener);
            menu.getAppContainer().getCurrentPage().widthProperty().removeListener(menuActionWidthListener);
            menu.getAppContainer().getCurrentPage().heightProperty().addListener(menuActionHeightListener);
            menu.getAppContainer().getCurrentPage().widthProperty().addListener(menuActionWidthListener);
        } catch (Exception e) {
        }

    }

    public MaterialDesignIconView getActionIcon() {
        return actionIcon;
    }

    public JFXButton getExecutarMenuAction() {
        return executarMenuAction;
    }

    public JFXButton getCancelarMenuAction() {
        return cancelarMenuAction;
    }

    String receitasJson;

    /**
     * Imprime em PDF TODOS os objetos representados na lista.<br>
     * Tanto os selecionados quanto os não selecionados.
     */
    public void printAll() {

        setUpBeforePrintAll();

        if (nadaParaImprimir()) {
            handleNadaParaImprimir();
            return;
        }

        //Este método recupera da persistencia os objects e passa
        //o controle de execucao para os botoes CANCELAR e PROSSEGUIR
        handlePrepararObjetosParaAcao(IMPRIMIR_BOOK_ACAO);

    }

    /**
     * Settings para Imprimir TODOS os objetos representados na lista.<br>
     * Tanto os selecionados quanto os não selecionados.
     */
    private void setUpBeforePrintAll() {

        fileChooser.setTitle(Util.PROPERTIES.getProperty("file.chooser.printing.title"));
        cancelarMenuAction.setLayoutX(getPrefWidth() - cancelarMenuAction.getPrefWidth() - 30);

        errorMessageContainer.setVisible(false);
        cancelarMenuAction.setVisible(true);

        currentAction = IMPRIMIR_BOOK_ACAO;

        statusBarCmp.setVisible(true);

        actionLabel.setText(Util.PROPERTIES.getProperty("application.printing.action.text"));

        menu.getAppContainer().getListaDeReceitas().setUpBeforePrinting();

    }

    /**
     * Imprime em PDF APENAS os objetos SELECIONADOS representados na lista.<br>
     */
    public void printSelected() {

        setUpBeforePrintSelected();

        if (nadaParaImprimir()) {
            handleNadaParaImprimir();
            return;
        }

        //Este método recupera da persistencia os objects e passa
        //o controle de execucao para os botoes CANCELAR e PROSSEGUIR
        handlePrepararObjetosParaAcao(IMPRIMIR_SELECIONADAS_ACAO);

    }

    /**
     * Settings para imprimir em PDF APENAS os objetos SELECTIONADOS
     * representados na lista.<br>
     * APENAS os selecionados sao impressos em PDF.
     */
    private void setUpBeforePrintSelected() {
        fileChooser.setTitle(Util.PROPERTIES.getProperty("file.chooser.printing.title"));
        cancelarMenuAction.setLayoutX(getPrefWidth() - cancelarMenuAction.getPrefWidth() - 30);

        errorMessageContainer.setVisible(false);
        cancelarMenuAction.setVisible(true);

        currentAction = IMPRIMIR_SELECIONADAS_ACAO;

        statusBarCmp.setVisible(true);

        if (menu.getAppContainer().getListaDeReceitas().getView().getSelection().size() > 1) {
            actionLabel.setText(Util.PROPERTIES.getProperty("application.printing.selected.action.text"));
        } else {
            actionLabel.setText(Util.PROPERTIES.getProperty("single.printing.action.text"));
        }

        menu.getAppContainer().getListaDeReceitas().setUpBeforePrinting();

    }

    private boolean nadaParaImprimir() {
        return nadaParaExportar();
    }

    /**
     * Notifica, libera os serviços fazendo currentAction = LIVRE e retorna.
     *
     */
    public void handleNadaParaImprimir() {
        handleNadaAFazerAction("nothing.to.print.message");
    }

    /**
     * Exporta APENAS os objetos representados na lista que estejam
     * SELECIONADOS. <br>
     * Os NAO selecionados NAO sao exportados.
     */
    public void exportSelected() {
        setUpBeforeExportarSelecionadas();
        handlePrepararObjetosParaAcao(EXPORTAR_SELECIONADAS_ACAO);
    }

    /**
     * Exporta TODOS os objetos representados na lista.<br>
     * Tanto os selecionados quanto os não selecionados.
     */
    public void exportAll() {

        setUpBeforeExportAll();

        if (nadaParaExportar()) {
            handleNadaParaExportar();
            return;
        }

        //Este método recupera da persistencia os objects e passa
        //o controle de execucao para os botoes CANCELAR e PROSSEGUIR
        handlePrepararObjetosParaAcao(EXPORTAR_ACAO);

    }

    List<Receita> objects = new ArrayList<>();

    /**
     * Este método apenas recupera, apropriadamente, da persistencia<br>
     * os objetos a se exportAll. Guarda referencias para esses objetos na
     * colecao objects.
     */
    @Deprecated
    private void handlePrepararObjetosParaExportar() {

        readyToAction = false;
        objects.clear();
        new Thread(() -> {

            //O size da colecao a se exportAll.
            int size = getExportingCollectionSize();
            //O size da colecao a se exportAll.
            int n = getExportingCollectionSize();
            //A coleção de objetos que representa os objetos da persistencia.
            List<Item> itensToExport = getRepresentedObjectsCollectionToExport();

            int intervalFromOneIterationAndAnother = Util.getIntervalFromOneIterationAndAnother(size);

            double i = 0;

            for (Item item : itensToExport) {
                try {
                    if (isCanceled) {
                        break;
                    }
                    objects.add((Receita) getObjectFromPersistence(item));
                    i++;
                    setBarProgress(i / n, ((int) (i)) + "/" + n);
                    if (isCanceled) {
                        break;
                    }
                    if (i < n) {
                        try {
                            Thread.sleep(intervalFromOneIterationAndAnother);
                        } catch (Exception e) {
                        }
                    }
                } catch (Exception ex) {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("exporting.error.message") + " ", ex);
                }
            }

            if (itensToExport != null) {
                itensToExport.clear();
            }

            menu.getAppContainer().getListaDeReceitas().setUpAfterExporting();

            //Daqui para frente, a execução é passada para os botoes CANCELAR ou PROSSEGUIR a EXPORTACAO
            //Em algum outro método, É GARANTIDO liberar para GC os objetos da colecao objects 
            if (!isCanceled) {
                handlePreparedExportacaoNAOCancelada();
                readyToAction = true;
            } else {
                readyToAction = false;
                handleCanceledAction(Util.PROPERTIES.getProperty("canceled.exporting.message"), 3000);
            }

        }).start();
    }

    /**
     * Este método apenas recupera, apropriadamente, da persistencia<br>
     * os objetos para a acao. Guarda referencias para esses objetos na colecao
     * objects.
     *
     * @param acao a acao a se executar como exportar ou imprimir.
     */
    private void handlePrepararObjetosParaAcao(String acao) {

        readyToAction = false;
        objects.clear();

        new Thread(() -> {

            prepareObjects();

            //atualiza mensagens na Lista
            if (isExporting()) {
                Platform.runLater(() -> {
                menu.getAppContainer().getListaDeReceitas().setUpAfterExporting();
                });
            } else if (isPrinting()) {
                Platform.runLater(() -> {
                    menu.getAppContainer().getListaDeReceitas().getView().setStatusMessage(Util.getPROPERTIES(menu.getAppContainer().getListaDeReceitas()).getProperty("ready.to.print"));
                });
            }

            //Daqui para frente, a execução é passada para os botoes CANCELAR ou PROSSEGUIR a EXPORTACAO/IMPRESSAO
            //Em algum outro método, É GARANTIDO liberar para GC os objetos da colecao objects 
            if (!isCanceled) {
                handlePreparedAndNotCanceledAction();
            } else {
                handleCanceledAction();
            }

        }).start();
    }

    private void prepareObjects() {

        //O size da colecao a se executar action nela.
        int size = getOnActionCollectionSize();
        //O size da colecao a se executar action nela.
        int n = getOnActionCollectionSize();
        //A coleção de objetos que representa os objetos da persistencia.
        Collection<Item> itens = getRepresentedObjectsCollectionToActUpon();

        int intervalFromOneIterationAndAnother = Util.getIntervalFromOneIterationAndAnother(size);

        double i = 0;

        for (Item item : itens) {
            try {
                if (isCanceled) {
                    break;
                }
                objects.add((Receita) getObjectFromPersistence(item));
                i++;

                if (isExporting()) {
                    setBarProgress(i / n, ((int) (i)) + "/" + n);
                } else if (isPrinting()) {
                    setBarProgress(i / (2 * n), ((int) (i)) + "/" + n);
                }
                if (isCanceled) {
                    break;
                }
                if (i < n) {
                    try {
                        Thread.sleep(intervalFromOneIterationAndAnother);
                    } catch (Exception e) {
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("exporting.error.message") + " ", ex);
            }
        }

        if (itens != null) {
            itens.clear();
        }
    }

    /**
     * Verifica qual acao corrente e gera mensagem apropriada.
     */
    private void handleCanceledAction() {
        readyToAction = false;
        if (isExporting()) {
            handleCanceledAction(Util.PROPERTIES.getProperty("canceled.exporting.message"), 3000);
        } else if (isPrinting()) {
            handleCanceledAction(Util.PROPERTIES.getProperty("canceled.printing.message"), 3000);
        }
    }

    private void handlePreparedAndNotCanceledAction() {
        if (isExporting()) {
            handlePreparedExportacaoNAOCancelada();
        } else if (isPrinting()) {
            handlePreparedPrintingNAOCancelada();
        }
        readyToAction = true;
    }

    @Deprecated
    private List<Item> getRepresentedObjectsCollectionToExport() {
        List<Item> itensToExport = null;
        if (currentAction.equals(EXPORTAR_ACAO)) {
            itensToExport = new ArrayList<>(menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().get());
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
            Set<Item> orderedItens = new TreeSet<>(menu.getAppContainer().getListaDeReceitas().getView().getSelection());;
            itensToExport = new ArrayList<>(orderedItens);
            orderedItens.clear();
        }
        return itensToExport;
    }

    /**
     * Retorna coleção ORDENADA.
     *
     * @return Collection<Item>
     */
    private Collection<Item> getRepresentedObjectsCollectionToActUpon() {
        Collection<Item> itens = null;
        if (currentAction.equals(EXPORTAR_ACAO) || currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
            itens = new ArrayList<>(menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().get());
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO) || currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
            //ORDENA DE ACORDO COM COMPARE IMPLEMENTADO EM Item.
            itens = new TreeSet<>(menu.getAppContainer().getListaDeReceitas().getView().getSelection());
        }
        return itens;
    }

    /**
     * Há uma correspondência BIUNÍVOCA entre item e o objeto persistido.
     *
     * @param item o item correspondente ao objeto.
     * @return o objeto correspondente ao item.
     * @throws Exception
     */
    private Object getObjectFromPersistence(Item item) throws Exception {
        return menu.getAppContainer().getReceita(item.getDescricao());
    }

    private boolean nadaParaExportar() {
        return menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().isEmpty();
    }

    public void handleNadaParaExportar() {
        handleNadaAFazerAction("nothing.to.export.message");
    }

    private synchronized void handleNadaAFazerAction(String message) {
        new Thread(() -> {
            Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty(message));
            Platform.runLater(() -> {
                statusBarCmp.setVisible(true);
                errorMessageContainer.setVisible(true);
                errorMsgLabel.setText(Util.PROPERTIES.getProperty(message));
                cancelarMenuAction.setVisible(false);
                executarMenuAction.setVisible(false);
                setUpScrollerAfterAction();
            });
            setBarProgress(LoaderPage.NOTHING_TO_LOAD, "");
            while (Notificator.isNotificating) {
            }
            Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty(message), 4000);
            while (Notificator.isNotificating) {
            }
            try {
                Thread.sleep(4000);
            } catch (Exception e) {
            }
            Platform.runLater(() -> {
                statusBarCmp.setVisible(true);
                errorMessageContainer.setVisible(false);
                cancelarMenuAction.setVisible(false);

                menu.getAppContainer().getListaDeReceitas().unblock();
                setVisible(false);
                currentAction = LIVRE;

            });

        }).start();
    }

    /**
     * Restaura o header do scroller apos alguma acao que pode te lo modificado.
     */
    private void setUpScrollerAfterAction() {
        menu.getAppContainer().getListaDeReceitas().setUpAfterImporting();
        menu.getAppContainer().getListaDeReceitas().setUpAfterUnImporting();
        menu.getAppContainer().getListaDeReceitas().setUpAfterPrinting();
    }

    /**
     * Settings para Exportar TODOS os objetos representados na lista.<br>
     * Tanto os selecionados quanto os não selecionados.
     */
    private void setUpBeforeExportAll() {
        fileChooser.setTitle(Util.PROPERTIES.getProperty("file.chooser.exporting.title"));
        cancelarMenuAction.setLayoutX(getPrefWidth() - cancelarMenuAction.getPrefWidth() - 30);

        errorMessageContainer.setVisible(false);
        cancelarMenuAction.setVisible(true);

        currentAction = EXPORTAR_ACAO;

        statusBarCmp.setVisible(true);

        actionLabel.setText(Util.PROPERTIES.getProperty("application.exporting.action.text"));

        menu.getAppContainer().getListaDeReceitas().setUpBeforeExporting();

    }

    /**
     * Settings para Exportar APENAS os objetos representados na lista que
     * estejam SELECIONADOS. <br>
     */
    private void setUpBeforeExportarSelecionadas() {

        fileChooser.setTitle(Util.PROPERTIES.getProperty("file.chooser.exporting.title"));

        cancelarMenuAction.setLayoutX(getPrefWidth() - cancelarMenuAction.getPrefWidth() - 30);

        errorMessageContainer.setVisible(false);
        cancelarMenuAction.setVisible(true);

        currentAction = EXPORTAR_SELECIONADAS_ACAO;

        statusBarCmp.setVisible(true);
        if (menu.getAppContainer().getListaDeReceitas().getView().getSelection().size() > 1) {
            actionLabel.setText(Util.PROPERTIES.getProperty("application.exporting.selectec.action.text"));
        } else {
            actionLabel.setText(Util.PROPERTIES.getProperty("application.exporting.selectec.single.action.text"));
        }

        menu.getAppContainer().getListaDeReceitas().setUpBeforeExporting();

    }

    public void setCurrentAction(String currentAction) {
        this.currentAction = currentAction;
    }
    

    /**
     * Daqui para frente, a execução é passada para os botoes CANCELAR ou
     * PROSSEGUIR a EXPORTACAO<br>
     * Em algum outro método, É GARANTIDO liberar para GC os objetos da colecao
     * objects
     */
    private void handlePreparedExportacaoNAOCancelada() {
        try {

            try {
                Thread.sleep(500);
            } catch (Exception e) {
            }

            Platform.runLater(() -> {
                executarMenuAction.setLayoutX(getPrefWidth() - executarMenuAction.getPrefWidth() - 30);
                cancelarMenuAction.setLayoutX(executarMenuAction.getLayoutX() - executarMenuAction.getPrefWidth() - 10);
                executarMenuAction.setVisible(true);

            });

        } catch (Exception ex) {
            Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty("exporting.application.error.message"), 3500);
        }
    }

    /**
     * Daqui para frente, a execução é passada para os botoes CANCELAR ou
     * PROSSEGUIR a IMPRESSÃO<br>
     * Em algum outro método, É GARANTIDO liberar para GC os objetos da colecao
     * objects
     */
    private void handlePreparedPrintingNAOCancelada() {
        try {

            try {
                Thread.sleep(500);
            } catch (Exception e) {
            }

            Platform.runLater(() -> {
                executarMenuAction.setLayoutX(getPrefWidth() - executarMenuAction.getPrefWidth() - 30);
                cancelarMenuAction.setLayoutX(executarMenuAction.getLayoutX() - executarMenuAction.getPrefWidth() - 10);
                executarMenuAction.setVisible(true);

            });

        } catch (Exception ex) {
            Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
            Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty("printing.application.error.message"), 3500);
        }
    }

    Collection<Receita> receitasFromJson;
    List<LinkedHashMap> receitasParsed;

    public boolean isImporting() {
        return isImporting;
    }

    private void handleCanceledAction(String message, int timeOut) {

        Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, message);

        new Thread(() -> {
            Platform.runLater(() -> {
                statusBarCmp.setVisible(true);
                errorMessageContainer.setVisible(false);
                cancelarMenuAction.setVisible(false);
                executarMenuAction.setVisible(false);
                setBarProgress(LoaderPage.NOTHING_TO_LOAD, "");
                if (objects != null) {
                    objects.clear();
                }
                setUpScrollerAfterAction();

                Util.GC();
            });

            Notificator.notificate(menu.getAppContainer(), message, 2000);
            try {
                Thread.sleep(500);
            } catch (Exception e) {
            }
            while (Notificator.isNotificating) {
            }

            FadeTransition ft = new FadeTransition(Duration.seconds(1.5), this);
            ft.setFromValue(1);
            ft.setToValue(0);
            ft.setOnFinished((event) -> {
                setOpacity(1);
                setVisible(false);
                isCanceled = false;
                isImporting = false;
                menu.getAppContainer().getListaDeReceitas().unblock();
                currentAction = LIVRE;
            });
            ft.play();

        }).start();

    }

    @Deprecated
    private int getExportingCollectionSize() {
        int size = 0;
        if (currentAction.equals(EXPORTAR_ACAO)) {
            size = menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().size();
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO)) {
            size = menu.getAppContainer().getListaDeReceitas().getView().getSelection().size();
        }
        return size;
    }

    private int getOnActionCollectionSize() {
        int size = 0;
        if (currentAction.equals(EXPORTAR_ACAO) || currentAction.equals(IMPRIMIR_BOOK_ACAO)) {
            size = menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().size();
        } else if (currentAction.equals(EXPORTAR_SELECIONADAS_ACAO) || currentAction.equals(IMPRIMIR_SELECIONADAS_ACAO)) {
            size = menu.getAppContainer().getListaDeReceitas().getView().getSelection().size();
        }
        return size;
    }

    class ImportingDoneRunnable implements Runnable {

        int importFailedCount;
        int importCount;
        MenuActions menuActions;

        public ImportingDoneRunnable(MenuActions menuActions) {
            this.menuActions = menuActions;
        }

        @Override
        public void run() {

            menu.getAppContainer().getListaDeReceitas().setUpAfterImporting();
            errorMessageContainer.setVisible(true);

            if (importFailedCount > 0) {
                errorMessageContainer.setVisible(true);
                String current = errorMsgLabel.getText();
                errorMsgLabel.setText(importFailedCount + " " + current);
            }

            if (importFailedCount == receitasFromJson.size()) {
                statusBarCmp.setVisible(false);
                errorMsgLabel.setText(Util.PROPERTIES.getProperty("nothing.was.imported.message"));
            } else {
                errorMessageContainer.setVisible(false);
                if (importCount - importFailedCount != 1) {
                    setBarProgress(1, (importCount - importFailedCount) + " " + Util.PROPERTIES.getProperty("many.was.imported.message"));
                } else {
                    setBarProgress(1, Util.PROPERTIES.getProperty("only.one.was.imported.message"));
                }
            }
        }

        public void setImportFailedCount(int importFailedCount) {
            this.importFailedCount = importFailedCount;
        }

        public void setImportCount(int importCount) {
            this.importCount = importCount;
        }

    }

    List<Receita> importadas = new ArrayList<>();

    public void importar() {

        setUpBeforeImportar();

        while (true) {

            File jsonFile = fileChooser.showOpenDialog(menu.getAppContainer().getStage().getOwner());

            if (jsonFile != null) {
                try {

                    receitasFromJson = exportImportService.imporT(jsonFile);

                    cancelarMenuAction.setVisible(true);
                    doBulkImport(jsonFile);
                    break;
                } catch (Exception e) {
                    Notificator.notificateError(menu.getAppContainer(), Util.PROPERTIES.getProperty("importing.application.error.notificator.message") + " " + jsonFile.getName(), 3000);
                    menu.getAppContainer().getListaDeReceitas().setUpAfterImporting();
                    try {
                        Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("importing.application.error.logger.message"), jsonFile.getCanonicalPath());
                    } catch (IOException ex) {
                        Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } else {
                handleCanceledAction(Util.PROPERTIES.getProperty("canceled.importing.message"), 3000);
                break;
            }

        }

    }

    private void setUpBeforeImportar() {
        fileChooser.setTitle(Util.PROPERTIES.getProperty("file.chooser.importing.title"));
        actionLabel.setText(Util.PROPERTIES.getProperty("application.import.action.text"));
        isImporting = true;
        currentAction = IMPORTAR_ACAO;
        importadas.clear();
        statusBarCmp.setVisible(true);

        errorMessageContainer.setVisible(false);
        cancelarMenuAction.setVisible(false);

        isCanceled = false;

        cancelarMenuAction.setLayoutX(getPrefWidth() - cancelarMenuAction.getPrefWidth() - 30);
        menu.getAppContainer().getListaDeReceitas().setUpBeforeImporting();

    }

    private Collection<List<Receita>> batch(List<Receita> receitas, int batchSize) {
        return Util.batch(receitas, batchSize);
    }

    @SuppressWarnings("empty-statement")
    private void doBulkImport(File jsonFile) {
        new Thread(() -> {
            int size = menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().size();
            int importingBulkSize = Util.getImportBulkSize(receitasFromJson.size());
            double i = 0;
            int n = receitasFromJson.size();
            int importFailedCount = 0;
            Collection<Receita> importaveis = new ArrayList<>();
            List<Receita> tmpReceitas = new ArrayList<>(receitasFromJson);
            Collection<List<Receita>> receitasBacthed = batch(tmpReceitas, importingBulkSize);
            tmpReceitas.clear();
            for (List<Receita> receitaBatch : receitasBacthed) {
                while(menu.getAppContainer().isSearching()){};
                importaveis.clear();
                //APENAS AS IMPORTÁVEIS SERÃO IMPORTADAS.
                //AS QUE FOREM DETECTADAS COMO DUPLICATAS, SERAO REMOVIDAS DO BATCH.
                Util.getImportaveis(menu.getAppContainer().getListaDeReceitas(), receitaBatch, importaveis);
                n -= (receitaBatch.size() - importaveis.size());
                if (isCanceled) {
                    break;
                }
                if (importaveis.size() > 0) {
                    try {
                        Platform.runLater(() -> {
                            menu.getAppContainer().getListaDeReceitas().setUpBeforeImporting();
                        });
                        //A COLEÇÃO IMPORTAVEIS É LIBERADA PARA GC EM OUTRO OBJETO.
                        menu.getAppContainer().importar(importaveis);
                        importadas.addAll(importaveis);
                        i++;
                    } catch (Exception e) {
                        Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("importing.error.message") + " ", e.getMessage());
                        int notBulkImportingFailedCount = doSingleImportingAfterBulkImportingFailure(receitaBatch, ((int) (i)), importingBulkSize);
                        importFailedCount += notBulkImportingFailedCount;
                    }
                    while (!menu.getAppContainer().getListaDeReceitas().isImportingDone()) {
                    };
                }
                if (n != 0) {
                    setBarProgress((1.0 * importadas.size()) / n, importadas.size() + "/" + receitasFromJson.size());
                } else {
                    setBarProgress(0, importadas.size() + "/" + n);
                }
                if (isCanceled) {
                    break;
                }
            }
            cancelarMenuAction.setVisible(false);
            receitasBacthed.clear();
            if (!isCanceled) {
                handleImportacaoNAOCancelada(importFailedCount, n, jsonFile);
            } else {
                handleImportacaoCancelada();
            }
            importaveis.clear();
            Util.GC();
        }).start();
    }

    private int doSingleImportingAfterBulkImportingFailure(List<Receita> receitaBatch, int bulkI, int importingBulkSize) {

        double i = 0;
        int n = receitasFromJson.size();
        int importFailedCount = 0;

        for (Receita receita : receitaBatch) {

            if (isCanceled) {
                break;
            }
            try {
                Platform.runLater(() -> {
                    menu.getAppContainer().getListaDeReceitas().setUpBeforeImporting();
                });
                menu.getAppContainer().importar(receita);
                importadas.add(receita);
                i++;
            } catch (Exception e) {
                Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("importing.error.message") + " ", e.getMessage());
                importFailedCount++;
            }
            while (!menu.getAppContainer().getListaDeReceitas().isImportingDone()) {
            };
//            setBarProgress(i / n, ((int) (i)) + "/" + n);
            setBarProgress(((bulkI * importingBulkSize) + i) / n, ((bulkI * importingBulkSize) + ((int) (i))) + "/" + n);
            if (isCanceled) {
                break;
            }
        }
        if (!isCanceled) {
        } else {
            handleImportacaoCancelada();
        }

        return importFailedCount;
    }

    @Deprecated
    private void doImport(File jsonFile) {
        boolean isBulkImporting = false;
        new Thread(() -> {

            if (!isBulkImporting) {

                int size = menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().size();
                int intervalFromOneWritingAndAnother = Util.getIntervalFromOneIterationAndAnother(size);

                double i = 0;
                int n = receitasFromJson.size();

                int importFailedCount = 0;

                for (Receita receita : receitasFromJson) {

                    if (isCanceled) {
                        break;
                    }
                    try {
                        menu.getAppContainer().importar(receita);
                        importadas.add(receita);
                        i++;
                    } catch (Exception e) {
                        Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("importing.error.message") + " ", e.getMessage());
                        importFailedCount++;
                    }
                    while (!menu.getAppContainer().getListaDeReceitas().isImportingDone()) {
                    };
                    setBarProgress(i / n, ((int) (i)) + "/" + n);

                    if (isCanceled) {
                        break;
                    }

                    if (i < n) {
//                    try {
//                        Thread.sleep(intervalFromOneWritingAndAnother);
//                    } catch (Exception e) {
//                    }
                    }
                }

                cancelarMenuAction.setVisible(false);

                if (!isCanceled) {
                    handleImportacaoNAOCancelada(importFailedCount, i, jsonFile);
                } else {
                    handleImportacaoCancelada();
                }

            }

        }).start();
    }

    private void handleImportacaoCancelada() {
        if (!importadas.isEmpty()) {
            handleBulkReversalImportacoes();
        } else {
            handleCanceledAction(Util.PROPERTIES.getProperty("canceled.importing.message"), 3000);
        }
        isImporting = false;
    }

    /**
     * Reverses bulkly all imported objects.
     */
    private void handleBulkReversalImportacoes() {
        new Thread(() -> {
            cancelarMenuAction.setVisible(false);

            double i = 0;
            int n = importadas.size();
            int importingBulkSize = Util.getImportBulkSize(importadas.size());

            Platform.runLater(() -> {
                msgL1.setText(Util.PROPERTIES.getProperty("canceling.importing.message"));
                menu.getAppContainer().getListaDeReceitas().setUpAfterImporting();
                menu.getAppContainer().getListaDeReceitas().setUpBeforeUnImporting();
            });

            Collection<List<Receita>> receitasBacthed = batch(importadas, importingBulkSize);
            Collection<Receita> bulk;
            for (List<Receita> receitaBatch : receitasBacthed) {
                bulk = receitaBatch;
                try {
                    Platform.runLater(() -> {
                        menu.getAppContainer().getListaDeReceitas().setUpBeforeUnImporting();
                    });
                    while(menu.getAppContainer().isSearching()){};
                    menu.getAppContainer().desimportar(bulk);
                    i++;
                } catch (Exception e) {
                    bulk.clear();
                }
                double statusBarValue = 1 - (i * importingBulkSize) / n;
                String statusMessage = (-(((int) (i)) * importingBulkSize) + n) + "/" + n;
                setBarProgress(statusBarValue, statusMessage);
                bulk.clear();

            }
            receitasBacthed.clear();
            new Thread(() -> {
                String msg = "";
                for (Receita imported : importadas) {
                    msg = msg + imported.getNome() + " DES-IMPORTADA\n";
                }
                Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("un.importing.success.message"), msg);
                importadas.clear();
                Util.GC();
            }).start();
            isImporting = false;
            Util.GC();
            handleCanceledAction(Util.PROPERTIES.getProperty("canceled.importing.message"), 3000);

        }).start();
    }

    @Deprecated
    private void handleReverseImportacoes() {
        new Thread(() -> {

            double ii = 0;
            int nn = importadas.size();

            cancelarMenuAction.setVisible(false);
            Platform.runLater(() -> {
                msgL1.setText(Util.PROPERTIES.getProperty("canceling.importing.message"));
            });
            for (Receita receita : importadas) {

                try {
                    menu.getAppContainer().desimportar(receita);
                    ii++;
                } catch (Exception e) {
                }
                setBarProgress(ii / nn, ((int) (ii)) + "/" + nn);

                if (ii < nn) {
                    try {
                        int size = menu.getAppContainer().getListaDeReceitas().getView().getCurrentModel().getChangefulModel().size();
                        Thread.sleep(Util.getIntervalFromOneIterationAndAnother(size));
                    } catch (Exception e) {
                    }
                }
            }
            String msg = "";
            for (Receita imported : importadas) {
                msg = msg + imported.getNome() + " DES-IMPORTADA\n";
            }
            Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("un.importing.success.message"), msg);
            isImporting = false;
            handleCanceledAction(Util.PROPERTIES.getProperty("canceled.importing.message"), 3000);

        }).start();
    }

    private void handleImportacaoNAOCancelada(int importFailedCount, double importCount, File jsonFile) {

        ImportingDoneRunnable ir = new ImportingDoneRunnable(this);
        ir.setImportFailedCount(importFailedCount);
        ir.setImportCount(((int) (importCount)));
        Platform.runLater(ir);
        new Thread(() -> {

            if (importCount - importFailedCount == 0) {
                try {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("nothing.was.imported.logger.message"), jsonFile.getCanonicalPath());
                } catch (IOException ex) {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (importadas.size() == 1) {
                try {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("only.one.was.imported.logger.message") + " " + jsonFile.getCanonicalPath() + " " + Util.PROPERTIES.getProperty("only.one.was.imported.complement.logger.message"), importadas.get(0).getNome());
                } catch (IOException ex) {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (importadas.size() > 1) {
                String msg = "";
                for (Receita imported : importadas) {
                    msg = msg + imported.getNome() + " IMPORTADA\n";
                }
                try {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("many.was.imported.logger.message") + " " + jsonFile.getCanonicalPath() + Util.PROPERTIES.getProperty("many.was.imported.complement.logger.message"), msg);
                } catch (IOException ex) {
                    Logger.getLogger(MenuActions.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            importadas.clear();
            Util.GC();
        }).start();

        try {
            Thread.sleep(1500);
        } catch (Exception e) {
        }

        FadeTransition ft = new FadeTransition(Duration.seconds(3.5), this);
        ft.setFromValue(1);
        ft.setToValue(0);
        ft.setOnFinished((event) -> {
            setOpacity(1);
            setVisible(false);
            currentAction = LIVRE;
            menu.getAppContainer().getListaDeReceitas().unblock();
            statusBarCmp.setVisible(true);
            errorMessageContainer.setVisible(false);
            isImporting = false;
            menu.getAppContainer().getListaDeReceitas().setUpAfterImporting();
        });
        ft.play();
    }

}
