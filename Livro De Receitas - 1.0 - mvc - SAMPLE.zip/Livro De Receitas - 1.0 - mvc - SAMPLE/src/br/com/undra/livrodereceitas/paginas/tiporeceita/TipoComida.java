package br.com.undra.livrodereceitas.paginas.tiporeceita;

/**
 * Modela um tipo de comida, como por exemplo:
 * <br> VEGETARIANA, PÃO, TORTA, CARNE, SALADA.
 * @author alexandre
 */
public class TipoComida extends TipoReceita{
    
    public static TipoComida VEGETARIANA = new TipoComida("VEGETARIANA");
    public static TipoComida PEIXE = new TipoComida("PEIXE");
    public static TipoComida TORTA = new TipoComida("TORTA");
    public static TipoComida SOBREMESA = new TipoComida("SOBREMESA");
    public static TipoComida BOLO = new TipoComida("BOLO");
    public static TipoComida GRÃOS = new TipoComida("GRÃOS");
    public static TipoComida PÃO = new TipoComida("PÃO");
    public static TipoComida CARNE = new TipoComida("CARNE");
    public static TipoComida SALADA = new TipoComida("SALADA");
    
    private String nome;
    
    public TipoComida() {
    }

    public TipoComida(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }

    /**
     *
     * @param nome
     */
    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return  "TIPO COMIDA - "+nome; //To change body of generated methods, choose Tools | Templates.
    }
    
}
