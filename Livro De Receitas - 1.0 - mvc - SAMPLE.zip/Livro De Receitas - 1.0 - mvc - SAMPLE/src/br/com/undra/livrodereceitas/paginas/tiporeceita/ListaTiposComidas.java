package br.com.undra.livrodereceitas.paginas.tiporeceita;

import br.com.undra.jfxcomponents.menus.SearchingMenu;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.ListaDeReceitas;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.util.Helper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 * Uma lista dos tipos de comidas, como por exemplo:
 * <br> VEGETARIANA, PÃO, TORTA, CARNE, SALADA.
 *
 * @author alexandre
 */
public class ListaTiposComidas extends FullVerticalScrollableListWrapperImpl {

    private NovaReceita novaReceita;
    private DetalhesReceita detalhesReceita;
    private String currentAdding;

    private final Collection<Item> excludables = new ArrayList<>();
    private final Collection<Item> UNexcludables = new ArrayList<>();

    private static int inst_count = 0;

    /**
     * Usado para ajuda contextualizada
     *
     * @see
     * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
     */
    EventHandler<? super Event> onMouseMoveIdentifiedHandler;

    public ListaTiposComidas() {
        inst_count++;
        System.err.println("INSTANCIAS DE LISTA TIPOS COMIDAS = " + inst_count);
        super.getView().getContextMenuArrowDown().getImprimir().setDisable(true);
        super.getView().getContextMenuArrowDown().getExportar().setDisable(true);
        super.getView().getContextMenuUpArrow().getImprimir().setDisable(true);
        super.getView().getContextMenuUpArrow().getExportar().setDisable(true);
        super.getView().getContextMenuUpArrow().getExportIcon().setDisable(true);
        super.getView().getContextMenuUpArrow().getPrinterIcon().setDisable(true);
        super.getView().getContextMenuArrowDown().getExportIcon().setDisable(true);
        super.getView().getContextMenuArrowDown().getPrinterIcon().setDisable(true);

        getEmptyListPage().getEmptyListLabel().setText(Util.getPROPERTIES(this).getProperty("mensagemListaVazia"));
        getEmptyListPage().getEmptyListLabel().setFont(Font.font(14));

        focusedProperty().addListener((observable, oldValue, focused) -> {
            if (oldValue == true && focused == false) {
            } else if (oldValue == false && focused == true) {
                handleFocusGained();
            }
        });

    }

    public ListaTiposComidas(NovaReceita novaReceita) {
        this();
        this.novaReceita = novaReceita;
        /**
         * Usado para ajuda contextualizada
         *
         * @see
         * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
         */
        if (novaReceita.getAppContainer() != null) {
            onMouseMoveIdentifiedHandler = Helper.getMouseEventIdentifiedHandler(novaReceita.getAppContainer(), this);
            setOnMouseMoved(onMouseMoveIdentifiedHandler);
        }
    }

    public ListaTiposComidas(DetalhesReceita detalhesReceita) {
        this();
        this.detalhesReceita = detalhesReceita;
        /**
         * Usado para ajuda contextualizada
         *
         * @see
         * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
         */
        if (detalhesReceita.getAppContainer() != null) {
            onMouseMoveIdentifiedHandler = Helper.getMouseEventIdentifiedHandler(detalhesReceita.getAppContainer(), this);
            setOnMouseMoved(onMouseMoveIdentifiedHandler);
        }
    }

    private void handleFocusGained() {
        if (detalhesReceita != null && detalhesReceita.getAppContainer().isEditing()) {
            super.getView().requestFocus();
        }
        if (novaReceita != null) {
            super.getView().requestFocus();
        }
    }
    
    @Override
    public void setUp(Object parent) {

        prefWidthProperty().bind(((TabPane) parent).widthProperty().subtract(350));
        prefHeightProperty().bind(((TabPane) parent).heightProperty().multiply(4.7 / 7));

        VBox lista = super.getView().getVBox();
        lista.prefWidthProperty().bind(prefWidthProperty());
        lista.prefHeightProperty().bind(prefHeightProperty());

        super.getView().prefWidthProperty().bind(prefWidthProperty());
        super.getView().prefHeightProperty().bind(prefHeightProperty());
        super.getSearcherContainer().prefWidthProperty().bind(prefWidthProperty());

        super.getView().getMenu().setLayoutY(-50);
        ((SearchingMenu) super.getView().getMenu()).getMenuPointer().setLayoutX(208);
        ((SearchingMenu) super.getView().getMenu()).getMenuPointer().setLayoutY(80);
        ((SearchingMenu) super.getView().getMenu()).getMenuPointer().setRotate(0);
        ((SearchingMenu) super.getView().getMenu()).getMenuPointer().setGlyphSize(25);

        super.getView().setLayoutY(super.getSearcherContainer().getPrefHeight());
        super.getSearcherContainer().toFront();
        super.getView().requestFocus();

    }

    @Override
    public void executeClientHookDeletionLogic() throws Exception {
        if (novaReceita != null) {
            novaReceita.deleteTipoReceita(new TipoComida(getCurrentRemoving().getDescricao()));
            novaReceita.getAppContainer().getDetalhesReceita().reloadTipoReceita(TipoComida.class);
        } else {
            detalhesReceita.deleteTipoReceita(new TipoComida(getCurrentRemoving().getDescricao()));
            detalhesReceita.getAppContainer().getNovaReceita().reloadTipoReceita(TipoComida.class);
        }
    }

    @Override
    public void executeClientHookAdditionLogic() throws Exception {
        if (novaReceita != null) {
            novaReceita.saveTipoReceita(getTipoComida());
            novaReceita.getAppContainer().getDetalhesReceita().reloadTipoReceita(TipoComida.class);
        } else {
            detalhesReceita.saveTipoReceita(getTipoComida());
            detalhesReceita.getAppContainer().getNovaReceita().reloadTipoReceita(TipoComida.class);
        }
    }

    @Override
    public void addAndSelect(String nomeItem) {
        currentAdding = nomeItem;
        super.addAndSelect(nomeItem);
    }

    @Override
    public void add(String nomeItem) {
        currentAdding = nomeItem;
        try {
            super.add(nomeItem); //To change body of generated methods, choose Tools | Templates.
        } catch (Exception ex) {
            Logger.getLogger(ListaTiposComidas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private TipoComida getTipoComida() {
        TipoComida tc = new TipoComida();
        tc.setNome(currentAdding);
        return tc;
    }

    @Override
    public boolean canExecuteClientHookDeletionLogicAt(Item item) throws Exception {
        AppContainer container = null;
        if (novaReceita != null) {
            container = novaReceita.getAppContainer();
        } else {
            container = detalhesReceita.getAppContainer();
        }
        //deve retornar nenhuma nome Receita Associada A Item
        Collection<String> nomes = container.getNomesReceitasAssociadasA(item, TipoComida.class);
        boolean isEmpty = nomes.isEmpty();
        nomes.clear();
        return isEmpty;
    }

    @Override
    public Collection<Item> getUNexcludables(Collection<Item> selection) {
        UNexcludables.clear();

        selection.parallelStream().forEach((item) -> {
            try {
                if (!canExecuteClientHookDeletionLogicAt(item)) {
                    UNexcludables.add(item);
                }
            } catch (Exception ex) {
                Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        return UNexcludables;
    }

    /**
     * Executa lógica de deleção.<br>
     * É a super classe responsável por habilitar a colecao bulk para GC.
     *
     * @param bulk
     * @throws Exception
     */
    @Override
    public void executeClientHookBulkDeletionLogic(Collection<Item> bulk) throws Exception {
        String[] ids = Util.toIds(bulk);

        AppContainer container = null;
        if (novaReceita != null) {
            container = novaReceita.getAppContainer();
        } else {
            container = detalhesReceita.getAppContainer();
        }

        container.deleteTiposReceitaByIds(ids, TipoComida.class);

        ids = null;
    }

    @Override
    public String getAppCurrentItemSelected() {

        if (super.getView().getSelector().getCurrent() != null) {
            return super.getView().getSelector().getCurrent().getDescricao();
        } else {
            return null;
        }

    }

}
