package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.util.Helper;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.IOException;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * The no selection page.
 *
 * @author alexandre
 */
public class NenhumaReceitaSelecionada extends Page {

    private AppContainer appContainer;

    @FXML
    private MaterialDesignIconView nenhumaReceitaSelecionadaIcon;

    @FXML
    private MaterialDesignIconView noSelectionPageMenuAppIcon;
    private Menu menu;
    private LoaderPage loaderPage;

    private NotificationPage notificationPage;
    @FXML
    private Text developer;

    private final ListChangeListener childrenChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {
            while (change.next()) {

                if (change.wasAdded()) {
                    for (Object o : change.getAddedSubList()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = (NotificationPage) o;
                        }
                    }
                }

                if (change.wasRemoved()) {
                    for (Object o : change.getRemoved()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = null;
                        }
                    }
                }
            }
        }
    };

    /**
     * Usado para ajuda contextualizada
     *
     * @see br.com.undra.livrodereceitas.util.Helper
     */
    EventHandler<? super Event> onMouseMoveHandler;

    /**
     * The no selection page.
     *
     * @author alexandre
     */
    public NenhumaReceitaSelecionada() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLNenhumaReceitaSelecionada.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        getChildren().addListener(childrenChangedListener);

    }

    /**
     * The no selection page.
     *
     * @author alexandre
     */
    public NenhumaReceitaSelecionada(AppContainer appContainer) {
        this();
        this.appContainer = appContainer;

        boolean singleLoader = true;
        loaderPage = new LoaderPage(appContainer, singleLoader);
        loaderPage.setUp();

        menu = Menu.getInstance(appContainer);
        menu.setVisible(false);

        getChildren().add(loaderPage);

        onMouseMoveHandler = Helper.getMouseEventIdentifiedHandler(appContainer,this);
        
        /**
         * Usado para ajuda contextualizada
         *
         * @see br.com.undra.livrodereceitas.util.Helper
         */
        setOnMouseMoved(onMouseMoveHandler);
        
        
        developer.setText(Util.getDeveloperAndContact());

    }

    ChangeListener<Number> widthChangeListener;
    ChangeListener<Number> heightChangeListener;

    public void setUp(FullVerticalScrollableListWrapperImpl verticalFullScroller) {

        prefWidthProperty().bind(getScene().widthProperty().subtract(verticalFullScroller.widthProperty()));
        prefHeightProperty().bind(getScene().heightProperty());

        loaderPage.setPrefWidth(getPrefWidth());
        loaderPage.setPrefHeight(getPrefHeight());

        noSelectionPageMenuAppIcon.setLayoutY(Double.parseDouble(noSelectionPageMenuAppIcon.getSize()) + 35);
        menu.setLayoutY(noSelectionPageMenuAppIcon.getLayoutY() + 10);

        noSelectionPageMenuAppIcon.setLayoutX(getWidth() - Double.parseDouble(noSelectionPageMenuAppIcon.getSize()) - 35);
        menu.setLayoutX(noSelectionPageMenuAppIcon.getLayoutX() - menu.getPrefWidth() + 5);

        developer.setLayoutY(getPrefHeight()-15);
        
        try {
            heightProperty().removeListener(heightChangeListener);
        } catch (Exception e) {
        }
        heightChangeListener = (observable, oldValue, newValue) -> {

            nenhumaReceitaSelecionadaIcon.setLayoutY((Double.parseDouble(nenhumaReceitaSelecionadaIcon.getSize())));
            noSelectionPageMenuAppIcon.setLayoutY(Double.parseDouble(noSelectionPageMenuAppIcon.getSize()) + 35);
            menu.setLayoutY(noSelectionPageMenuAppIcon.getLayoutY() + 10);
            appContainer.ensureVisibility();
            loaderPage.setPrefHeight(newValue.doubleValue());
            loaderPage.doHeightAdjust();
            developer.setLayoutY(newValue.doubleValue()-15);


        };
        heightProperty().addListener(heightChangeListener);

        try {
            widthProperty().removeListener(widthChangeListener);
        } catch (Exception e) {
        }

        widthChangeListener = (observable, oldValue, newValue) -> {

            setLayoutX(verticalFullScroller.getWidth());
            nenhumaReceitaSelecionadaIcon.setLayoutX((getWidth() - Double.parseDouble(nenhumaReceitaSelecionadaIcon.getSize())) / 2);
            noSelectionPageMenuAppIcon.setLayoutX(getWidth() - Double.parseDouble(noSelectionPageMenuAppIcon.getSize()) - 35);
            menu.setLayoutX(noSelectionPageMenuAppIcon.getLayoutX() - menu.getPrefWidth() + 5);

            loaderPage.setPrefWidth(newValue.doubleValue());
            loaderPage.doWidthAdjust();

            appContainer.ensureVisibility();
        };

        widthProperty().addListener(widthChangeListener);

        if (!getChildren().contains(menu)) {
            getChildren().add(menu);
            Tooltip.install(noSelectionPageMenuAppIcon, menu.getMenuTooltip());
        }

        menu.setUp(this);

    }

    public MaterialDesignIconView getMenuLivroReceitasMaior() {
        return noSelectionPageMenuAppIcon;
    }

    public LoaderPage getLoaderPage() {
        return loaderPage;
    }

    public Menu getMenu() {
        return menu;
    }

    @Override
    public NotificationPage getNotificationPage() {
        return notificationPage;
    }

    @FXML
    void handleMenuMouseClicked(MouseEvent event) {
        menu.handleMouseClicked();
    }

    @Override
    public void closeMenu() {
        menu.setVisible(false);
    }

    /**
     * Before shutDown hook.
     */
    @Override
    public void beforeShutDown() {
    }

    @Override
    public void disableMenuIcon() {
        try {
            noSelectionPageMenuAppIcon.setVisible(false);
            noSelectionPageMenuAppIcon.setDisable(true);
        } catch (Exception e) {
        }
    }
}
