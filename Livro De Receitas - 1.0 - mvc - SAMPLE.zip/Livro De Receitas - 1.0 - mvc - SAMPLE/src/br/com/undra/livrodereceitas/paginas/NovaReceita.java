package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposCalorias;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposComidas;
import br.com.undra.livrodereceitas.paginas.tiporeceita.ListaTiposBebidas;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.scrollablelist.util.Selector;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.pagenavigator.PageNavigator;
import br.com.undra.livrodereceitas.paginas.tiporeceita.NovoTipoReceita;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoCaloria;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoReceita;
import br.com.undra.livrodereceitas.util.Helper;
import br.com.undra.livrodereceitas.util.Notificator;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * MVC nova objeto.
 *
 * @author alexandre
 */
public class NovaReceita extends Page {

    public static String ADDING_STARTED = "ADDING_STARTED";
    public static String ADDING_CANCELED = "ADDING_CANCELED";
    public static String ADDING_CONFIRMING = "ADDING_CONFIRMING";
    public static String ADDING_FINISHED = "ADDING_FINISHED";
    public static String ADDING_FAILED = "ADDING_FAILED";

    public static String INICIO_RESUMO_TIPO_COMIDA = "COMIDA";
    public static String INICIO_RESUMO_TIPO_BEBIDA = "BEBIDA";
    public static String INICIO_RESUMO_TIPO_COMIDA_PLUS = ", TIPO ";
    public static String INICIO_RESUMO_TIPO_BEBIDA_PLUS = ", TIPO ";

    private FullVerticalScrollableListWrapperImpl listaTiposComidas;
    private FullVerticalScrollableListWrapperImpl listaTiposBebidas;
    private FullVerticalScrollableListWrapperImpl listaTiposCalorias;

    private AppContainer appContainer;

    @FXML
    private MaterialDesignIconView menuAppIcon;
    private Menu menu;
    @FXML
    private JFXButton salvar;
    @FXML
    private JFXButton cancelar;
    @FXML
    private TabPane receitaTabPane;
    @FXML
    private JFXTextField nomeReceita;
    @FXML
    private Tab tabIngredientes;
    @FXML
    private Tab tabModoPreparo;
    @FXML
    private JFXTextArea ingredientes;
    @FXML
    private JFXTextArea modoPreparo;
    @FXML
    private Tab tabTipo;
    @FXML
    private Label resumoTipoLabel;
    Tooltip resumoTipoTooltip;

    @FXML
    private TabPane tipoReceitaTabPane;
    @FXML
    private Tab tabTipoComida;
    @FXML
    private Label helpTextComida;
    @FXML
    private Tab tabTipoBebida;
    @FXML
    private Label helpTextBebida;
    @FXML
    private Tab tabTipoCalorias;
    @FXML
    private Label helpTextCalorias;
    @FXML
    private TextArea helpBoxTipoBebidas;
    @FXML
    private TextArea helpBoxTipoComida;
    @FXML
    private TextArea helpBoxTipoCalorias;

    @FXML
    private Text developer;

    @FXML
    private Label novaReceitaLbl;

    private NovoTipoReceita novoTipoReceita;
    private boolean tiposComidasLoaded = false;
    private boolean tiposBebidasLoaded = false;
    private boolean tiposCaloriasLoaded = false;

    private StringProperty STATE = new SimpleStringProperty("STATELESS");

    private ChangeListener<Number> novaReceitaHeightListener = (observable, oldValue, newValue) -> {

        receitaTabPane.setPrefHeight(getPrefHeight() - nomeReceita.getPrefHeight() - 85);
        appContainer.ensureVisibility();

        menu.setLayoutY(menuAppIcon.getLayoutY() - 5);

        //    SESSAO TIPO RECEITA
        tipoReceitaTabPane.setPrefHeight(5 * newValue.doubleValue() / 6);

    };

    private ChangeListener novaReceitaWidthListener;

    private AnchorPane comidasContent;
    private AnchorPane bebidasContent;
    private AnchorPane caloriasContent;

    private NotificationPage notificationPage;
    private final ListChangeListener childrenChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {
            while (change.next()) {

                if (change.wasAdded()) {
                    for (Object o : change.getAddedSubList()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = (NotificationPage) o;
                        }
                    }
                }

                if (change.wasRemoved()) {
                    for (Object o : change.getRemoved()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = null;
                        }
                    }
                }
            }
        }
    };

    /**
     * Usado para ajuda contextualizada
     *
     * @see br.com.undra.livrodereceitas.util.Helper
     */
    EventHandler<? super Event> onMouseMoveHandler;

    /**
     * MVC nova objeto.
     *
     * @author alexandre
     */
    public NovaReceita() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLNovaReceita.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

    }

    /**
     * MVC nova objeto.
     *
     * @author alexandre
     */
    public NovaReceita(AppContainer appContainer) {
        this();
        this.appContainer = appContainer;
        listaTiposComidas = new ListaTiposComidas(this);
        listaTiposBebidas = new ListaTiposBebidas(this);
        listaTiposCalorias = new ListaTiposCalorias(this);

        listaTiposComidas.restoreLookAndFeel(getClass().getSimpleName());
        listaTiposBebidas.restoreLookAndFeel(getClass().getSimpleName());
        listaTiposCalorias.restoreLookAndFeel(getClass().getSimpleName());

        receitaTabPane.getTabs().get(0).setText(Util.PROPERTIES.getProperty("tabIngredientes"));
        receitaTabPane.getTabs().get(1).setText(Util.PROPERTIES.getProperty("tabModoPreparo"));
        receitaTabPane.getTabs().get(2).setText(Util.PROPERTIES.getProperty("tabTipoReceita"));

        comidasContent = (AnchorPane) tabTipoComida.getContent();
        comidasContent.getChildren().add(listaTiposComidas);
        bebidasContent = (AnchorPane) tabTipoBebida.getContent();
        bebidasContent.getChildren().add(listaTiposBebidas);
        caloriasContent = (AnchorPane) tabTipoCalorias.getContent();
        caloriasContent.getChildren().add(listaTiposCalorias);

        novoTipoReceita = new NovoTipoReceita(this);

        novoTipoReceita.setVisible(false);

        getChildren().add(novoTipoReceita);

        resumoTipoTooltip = new Tooltip();
        resumoTipoTooltip.setFont(Font.font(13));
        Tooltip.install(resumoTipoLabel, resumoTipoTooltip);

        resumoTipoLabel.setFont(Font.font(20));

        cleanUp();
        /**
         * Usado para ajuda contextualizada
         *
         * @see br.com.undra.livrodereceitas.util.Helper
         */
        nomeReceita.setOnMouseMoved(Helper.getMouseEventIdentifiedHandler(appContainer, this));
        /**
         * Usado para ajuda contextualizada
         *
         * @see br.com.undra.livrodereceitas.util.Helper
         */
        onMouseMoveHandler = Helper.getMouseEventIdentifiedHandler(appContainer, this);
        setUpListeners();
        getChildren().addListener(childrenChangedListener);
        menu = Menu.getInstance(appContainer);
        menu.setVisible(false);
    }

    @FXML
    void handleMenuMouseClicked(MouseEvent event) {

        if (menu.isVisible()) {
            menu.setVisible(false);
        } else {
            menu.setVisible(true);
        }

    }

    @FXML
    public void handleMouseClicked(MouseEvent event) {
//        System.err.println("relative Y "+event.getSceneY()+", absolute Y "+event.getScreenY() +" prefHeight "+getPrefHeight() + " / totalHeight " +getScene().getWindow().getHeight());
    }

    @FXML
    public void handleCancelarMouseClicked(MouseEvent event) {
        cleanUp();
        STATE.setValue(ADDING_CANCELED);
        PageNavigator.goToPageSmoothly(appContainer, appContainer.getNenhumaReceitaSelecionada());
        appContainer.onAddCanceled();
    }

    @FXML
    void handleSalvarMouseClicked(MouseEvent event) {

        if (!isOkNomeReceita()) {

            Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("namelessReceitaErrorMessage"), 2500);

        } else {

            if (!isOkTiposReceita()) {

                notificateTiposReceitaErrorAndReselectTab();

            } else {

                //TEM TIPO COMIDA MAS NAO TEM TIPO CALÓRICO 
                if (resumoTipoLabel.getText().contains(INICIO_RESUMO_TIPO_COMIDA) && !resumoTipoLabel.getText().contains("-")) {

                    selectTab(tipoReceitaTabPane, tabTipoCalorias);
                    Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("calorlessReceitaErrorMessage"), 3000);

                } else {

                    fillConfirmationPage();

                    PageNavigator.goToPageSmoothly(appContainer, appContainer.getConfirmarSalvar());

                    checkIngredientesEModoDePreparo();

                    showSavingConfirmationMessage();
                }
            }
        }
    }

    private void showSavingConfirmationMessage() {
        new Thread(() -> {

            //DORME SOMENTE SE FOI FEITA ALGUMA NOTIFICACAO DE WARNING.
            if (modoPreparo.getText().trim().equals("") || ingredientes.getText().trim().equals("")) {

                while (Notificator.isNotificating) {
                }

                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                }
            }

            Platform.runLater(() -> {

                if (appContainer.getCurrentPage().equals(appContainer.getConfirmarSalvar())) {

                    appContainer.getPageWrapper().hide();
                    appContainer.getPageWrapper().setCloseButtonVisible(true);
                    appContainer.getPageWrapper().setText(Util.PROPERTIES.getProperty("savingConfirmationMessage"));
                    appContainer.getPageWrapper().show();

                }
            });

        }).start();
    }

    private void checkIngredientesEModoDePreparo() {
        String message = "";

        if (ingredientes.getText().trim().equals("")) {
            message = Util.PROPERTIES.getProperty("ingredientlessReceitaErrorMessage");
        }
        if (modoPreparo.getText().trim().equals("")) {
            message = Util.PROPERTIES.getProperty("howToMakelessReceitaErrorMessage");
        }
        if (modoPreparo.getText().trim().equals("") && ingredientes.getText().trim().equals("")) {
            message = Util.PROPERTIES.getProperty("ingredientslessHowToMakelessErrorMessage");
        }
        if (!message.equals("")) {
            int timeOut = 2500;
            Notificator.isNotificating = true;
            Notificator.notificateWarning(appContainer, message, 3000);
        }
    }

    private void notificateTiposReceitaErrorAndReselectTab() {
        selectTab(receitaTabPane, tabTipo);
        Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("typelessReceitaErrorMessage"), 3000);
        if (resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_COMIDA)) {
            selectTab(tipoReceitaTabPane, tabTipoComida);
        } else if (resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_BEBIDA)) {
            selectTab(tipoReceitaTabPane, tabTipoBebida);
        }
    }

    private boolean isOkNomeReceita() {
        return !nomeReceita.getText().trim().equals("");
    }

    private boolean isOkTiposReceita() {
        return !resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_COMIDA) && !resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_BEBIDA);
    }

    @FXML
    void handleNomeReceitaKeyReleased(KeyEvent event) {

        //saves when ENTER is released
        if (event.getCode().equals(KeyCode.ENTER)) {
            handleSalvarMouseClicked(null);
        }

        nomeReceita.requestFocus();

    }

    private void handleTipoSelectionUNselection(String STATE, VerticalScrollableListWrapper controller) {

        if (STATE.equals(Selector.SELECTED_ALL)) {
            handle_TIPO_SELECTED_ALL(controller);
        } else if (STATE.equals(Selector.NO_SELECTION)) {
            handle_TIPO_NO_SELECTION_STATE(controller);
        } else if (STATE.equals(Selector.INVERTED_SELECTION_READY)) {
            handle_TIPO_INVERTED_SELECTION_STATE(controller);
        } else if (STATE.equals(Selector.SINGLE_SELECTION)) {
            handle_TIPO_SINGLE_SELECTION_STATE(controller);
        } else if (STATE.equals(Selector.MULTI_SELECTION)) {
            if (controller.getView().getSelection().isEmpty()) {
                handle_TIPO_NO_SELECTION_STATE(controller);
            } else {
                handle_TIPO_MULTI_SELECTION_STATE(controller);
            }
        } else if (STATE.equals(Selector.SINGLE_TO_MULTI_SELECTION_CHANGED)) {
            //Quando nao for lista calorias, que ESTÁ DESABILITADA MULTISELECAO, 
            //zera o text do label para logicas de multiselecao das listas de comida e bebida.
            if (!(controller instanceof ListaTiposCalorias)) {
                resumoTipoLabel.setText("");
                listaTiposCalorias.unSelectAll();
            }
        }

        Tooltip.uninstall(resumoTipoLabel, resumoTipoTooltip);
        resumoTipoTooltip.setText(resumoTipoLabel.getText());
        Tooltip.install(resumoTipoLabel, resumoTipoTooltip);

//        //Para DEselecionar no nome da receita e para passar o focus para ele.
//        new Thread(() -> {
//            Platform.runLater(() -> {
//                nomeReceita.requestFocus();
//                nomeReceita.selectEnd();
//                nomeReceita.selectForward();
//            });
//        }).start();
    }

    @Override
    public void setUp(FullVerticalScrollableListWrapperImpl verticalFullScroller) {

        menu.setLayoutY(menuAppIcon.getLayoutY() - 5);

        menuAppIcon.setLayoutX(getWidth() - Double.parseDouble(menuAppIcon.getSize()) - 10);
        menu.setLayoutX(menuAppIcon.getLayoutX() - menu.getPrefWidth() + 10);

        novaReceitaWidthListener = (observable, oldValue, newValue) -> {
            setLayoutX(verticalFullScroller.getPrefWidth());
            salvar.setLayoutX(getWidth() - salvar.getPrefWidth() - 10);
            cancelar.setLayoutX(salvar.getLayoutX() - salvar.getPrefWidth() - 10);
            receitaTabPane.setPrefWidth(getWidth());
            developer.setLayoutX(receitaTabPane.getPrefWidth() / 2 + 30);
            nomeReceita.setPrefWidth(cancelar.getLayoutX());
            menuAppIcon.setLayoutX(getWidth() - Double.parseDouble(menuAppIcon.getSize()) - 10);
            appContainer.ensureVisibility();

            menu.setLayoutX(menuAppIcon.getLayoutX() - menu.getPrefWidth() + 10);

            //    SESSAO TIPO RECEITA
            tipoReceitaTabPane.setPrefWidth(getPrefWidth());
            helpBoxTipoComida.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoComida.getPrefWidth()).doubleValue() - 50);
            helpBoxTipoBebidas.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoBebidas.getPrefWidth()).doubleValue() - 50);
            helpBoxTipoCalorias.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoCalorias.getPrefWidth()).doubleValue() - 50);

        };

        if (!tiposCaloriasLoaded) {
            loadTiposCalorias();
        }
        if (!tiposBebidasLoaded) {
            loadTiposBebidas();
        }
        if (!tiposComidasLoaded) {
            loadTiposComidas();
        }

        prefWidthProperty().bind(getScene().widthProperty().subtract(verticalFullScroller.widthProperty()));
        prefHeightProperty().bind(getScene().heightProperty());

        novoTipoReceita.setPrefWidth(getPrefWidth());
        novoTipoReceita.setPrefHeight(getPrefHeight());

        doTipoReceitaBindings();

        heightProperty().removeListener(novaReceitaHeightListener);
        heightProperty().addListener(novaReceitaHeightListener);
        widthProperty().removeListener(novaReceitaWidthListener);
        widthProperty().addListener(novaReceitaWidthListener);

        if (resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_COMIDA)) {
            tipoReceitaTabPane.getSelectionModel().select(tabTipoComida);
        }
        if (resumoTipoLabel.getText().equals(INICIO_RESUMO_TIPO_BEBIDA)) {
            tipoReceitaTabPane.getSelectionModel().select(tabTipoBebida);
        }

        if (resumoTipoLabel.getText().trim().equals("")) {
            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
        }

        if (!getChildren().contains(menu)) {
            getChildren().add(menu);
            Tooltip.install(menuAppIcon, menu.getMenuTooltip());
        }

        menu.setUp(this);

    }

    private void doTipoReceitaBindings() {
        //    SESSAO TIPO RECEITA

        tipoReceitaTabPane.setPrefHeight(2 * getPrefHeight() / 3);

        tipoReceitaTabPane.prefWidthProperty().addListener((observable, oldValue, newValue) -> {
            resumoTipoLabel.setPrefWidth(newValue.doubleValue() - 30);
        });

        resumoTipoLabel.setTextOverrun(OverrunStyle.WORD_ELLIPSIS);

        resumoTipoLabel.textProperty().addListener((observable, oldValue, newValue) -> {

            if (newValue.length() >= 80) {
                resumoTipoLabel.setFont(Font.font(16));
            } else {
                resumoTipoLabel.setFont(Font.font(20));
            }

        });

        listaTiposCalorias.setUp(tipoReceitaTabPane);
        listaTiposCalorias.setLayoutY(helpTextCalorias.getLayoutY() + 30);
        listaTiposCalorias.setLayoutX(30);

        helpBoxTipoCalorias.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoCalorias.getPrefWidth()).doubleValue() - 50);

        listaTiposBebidas.setUp(tipoReceitaTabPane);
        listaTiposBebidas.setLayoutY(helpTextBebida.getLayoutY() + 30);
        listaTiposBebidas.setLayoutX(30);

        helpBoxTipoBebidas.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoBebidas.getPrefWidth()).doubleValue() - 50);

        listaTiposComidas.setUp(tipoReceitaTabPane);
        listaTiposComidas.setLayoutY(helpTextComida.getLayoutY() + 30);
        listaTiposComidas.setLayoutX(30);

        helpBoxTipoComida.setLayoutX(tipoReceitaTabPane.prefWidthProperty().subtract(helpBoxTipoComida.getPrefWidth()).doubleValue() - 50);

//        listaTiposComidas.getView().setCompactList(ScrollableListContainerSimple.MIN_WINDOW_HEIGHT - 1);
//        listaTiposBebidas.getView().setCompactList(ScrollableListContainerSimple.MIN_WINDOW_HEIGHT - 1);
//        listaTiposCalorias.getView().setCompactList(ScrollableListContainerSimple.MIN_WINDOW_HEIGHT - 1);
    }

    private void loadTiposComidas() {

        Collection<Item> allItens = new ArrayList<>();
        appContainer.getAllTiposReceitas(TipoComida.class).forEach((t) -> {
            allItens.add(Item.newInstance(t.getNome(), listaTiposComidas.getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
        });

        listaTiposComidas.load(allItens);
        listaTiposComidas.getView().getCurrentModel().loadingDone();

        tiposComidasLoaded = true;

    }

    private void loadTiposBebidas() {

        Collection<Item> allItens = new ArrayList<>();
        appContainer.getAllTiposReceitas(TipoBebida.class).forEach((t) -> {
            allItens.add(Item.newInstance(t.getNome(), listaTiposBebidas.getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
        });

        listaTiposBebidas.load(allItens);
        listaTiposBebidas.getView().getCurrentModel().loadingDone();

        tiposBebidasLoaded = true;

    }

    private void loadTiposCalorias() {

        Collection<Item> allItens = new ArrayList<>();
        appContainer.getAllTiposReceitas(TipoCaloria.class).forEach((t) -> {
            allItens.add(Item.newInstance(t.getNome(), listaTiposCalorias.getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
        });

        listaTiposCalorias.load(allItens);
        listaTiposCalorias.getView().getCurrentModel().loadingDone();

        tiposCaloriasLoaded = true;

//        listaTiposCalorias.add("0 - ZERO CALORIA");
//        listaTiposCalorias.add("1 - POUCO CALÓRICA");
//        listaTiposCalorias.add("2 - CALÓRICA");
//        listaTiposCalorias.add("3 - MUITO CALÓRICA");
//        listaTiposCalorias.add("4 - HIPER CALÓRICA");
    }

    private void setUpListeners() {

        //usado para ajuda contextualizada
        setOnMouseMoved(onMouseMoveHandler);
        receitaTabPane.setOnMouseMoved(onMouseMoveHandler);

        int sleep = 500;

        setUpTabListeners(sleep);

        heightProperty().addListener((observable, oldValue, newValue) -> {
            novoTipoReceita.setPrefHeight(newValue.doubleValue());
            novoTipoReceita.getTipoLabel().setLayoutY(newValue.doubleValue() * 0.45);
            novoTipoReceita.getNomeTipoTextField().setLayoutY(novoTipoReceita.getTipoLabel().getLayoutY() + 70);
            novoTipoReceita.getCancelarSalvarTipoReceita().setLayoutY(novoTipoReceita.getTipoLabel().getLayoutY() + 140);
            novoTipoReceita.getSalvarTipoReceita().setLayoutY(novoTipoReceita.getTipoLabel().getLayoutY() + 140);
        });

        widthProperty().addListener((observable, oldValue, newValue) -> {
            novoTipoReceita.setPrefWidth(newValue.doubleValue());
            novoTipoReceita.getNomeTipoTextField().setLayoutX(newValue.doubleValue() / 2 - novoTipoReceita.getNomeTipoTextField().getPrefWidth() / 2);
            novoTipoReceita.getSalvarTipoReceita().setLayoutX(novoTipoReceita.getNomeTipoTextField().getLayoutX() + novoTipoReceita.getNomeTipoTextField().getPrefWidth() - novoTipoReceita.getSalvarTipoReceita().getPrefWidth());
            novoTipoReceita.getCancelarSalvarTipoReceita().setLayoutX(novoTipoReceita.getSalvarTipoReceita().getLayoutX() - novoTipoReceita.getSalvarTipoReceita().getPrefWidth() - 10);
            novoTipoReceita.getTipoLabel().setLayoutX(novoTipoReceita.getNomeTipoTextField().getLayoutX() - 50);
        });

        setUpListaTiposComidasListeners();

        setUpListaTiposBebidasListeners();

        setUpListaTiposCaloriasListener();
    }

    private void setUpListaTiposCaloriasListener() {
        //LISTENER PARA EVENTOS DE SELECAO/DESELECAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposCalorias.ON_SELECTION().addListener((observable, oldValue, STATE) -> {
            handleTipoSelectionUNselection(STATE, listaTiposCalorias);
        });

        //LISTENER PARA EVENTOS DE ADICAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposCalorias.ON_ADDITION().addListener((observable, oldValue, STATE) -> {

            if (STATE.equals(ScrollableListContainerSimple.ON_ADD_REQUEST)) {

                novoTipoReceita.setScroller(listaTiposCalorias);
                handle_ON_ADD_REQUEST_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newCaloricTypeMessage"));

            } else if (STATE.equals(ScrollableListContainerSimple.ADDED)) {

                handle_ON_ADDED_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newCaloricTypeLoogerMessage"), Util.PROPERTIES.getProperty("newCaloricTypeNotificatorMessage"), listaTiposCalorias, 2500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newCaloricTypeSavingLoggerErrorMessage"), Util.PROPERTIES.getProperty("newCaloricTypeSavingNotificatorErrorMessage"), listaTiposCalorias, 3500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_DUPLICATE_ENTRY)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newCaloricTypeDuplicatedEntryLoggerErrorMessage"), Util.PROPERTIES.getProperty("newCaloricTypeDuplicatedEntryNotificatorErrorMessage"), listaTiposCalorias, 4500);

            }
        });

        //LISTENER PARA EVENTOS DE REMOVER OBJETOS NO VERTICALFULLSCROLLER
        listaTiposCalorias.ON_DELETION().addListener((observable, oldValue, newValue) -> {

            if (newValue.equals(ScrollableListContainerSimple.DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC)) {

                Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("deleteCaloricTypeLoggerErrorMessage"), listaTiposCalorias.getCurrentRemoving().getDescricao());
                Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("deleteCaloricTypeNotificatorErrorMessage") + " " + listaTiposCalorias.getCurrentRemoving().getDescricao(), 2500);

            } else {

                if (newValue.equals(ScrollableListContainerSimple.MULTI_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteCaloricsTypesLoggerSuccessMessage"), listaTiposCalorias.getMultiSelectionRemoved().size());
                }
                if (newValue.equals(ScrollableListContainerSimple.SINGLE_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteCaloricTypeLoggerSuccessMessage"), listaTiposCalorias.getCurrentRemoving().getDescricao());
                }

                Notificator.notificateDeletion(appContainer, listaTiposCalorias, newValue, 3000);
            }

            listaTiposCalorias.getView().requestFocus();

        });
    }

    private void setUpListaTiposBebidasListeners() {
        //LISTENER PARA EVENTOS DE SELECAO/DESELECAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposBebidas.ON_SELECTION().addListener((observable, oldValue, STATE) -> {
            handleTipoSelectionUNselection(STATE, listaTiposBebidas);
        });

        //LISTENER PARA EVENTOS DE ADICAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposBebidas.ON_ADDITION().addListener((observable, oldValue, STATE) -> {

            if (STATE.equals(ScrollableListContainerSimple.ON_ADD_REQUEST)) {

                novoTipoReceita.setScroller(listaTiposBebidas);
                handle_ON_ADD_REQUEST_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newDrinkTypeMessage"));

            } else if (STATE.equals(ScrollableListContainerSimple.ADDED)) {

                handle_ON_ADDED_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newDrinkTypeLoogerMessage"), Util.PROPERTIES.getProperty("newDrinkTypeNotificatorMessage"), listaTiposBebidas, 2500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newDrinkTypeSavingLoggerErrorMessage"), Util.PROPERTIES.getProperty("newDrinkTypeSavingNotificatorErrorMessage"), listaTiposBebidas, 3500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_DUPLICATE_ENTRY)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newDrinkTypeDuplicatedEntryLoggerErrorMessage"), Util.PROPERTIES.getProperty("newDrinkTypeDuplicatedEntryNotificatorErrorMessage"), listaTiposBebidas, 4500);

            }
        });

        //LISTENER PARA EVENTOS DE REMOVER OBJETOS NO VERTICALFULLSCROLLER
        listaTiposBebidas.ON_DELETION().addListener((observable, oldValue, newValue) -> {

            if (newValue.equals(ScrollableListContainerSimple.DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC)) {

                Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("deleteDrinkTypeLoggerErrorMessage"), listaTiposBebidas.getCurrentRemoving().getDescricao());
                Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("deleteDrinkTypeNotificatorErrorMessage") + " " + listaTiposBebidas.getCurrentRemoving().getDescricao(), 2500);

            } else {

                if (newValue.equals(ScrollableListContainerSimple.MULTI_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteDrinksTypesLoggerSuccessMessage"), listaTiposBebidas.getMultiSelectionRemoved().size());
                }
                if (newValue.equals(ScrollableListContainerSimple.SINGLE_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteDrinkTypeLoggerSuccessMessage"), listaTiposBebidas.getCurrentRemoving().getDescricao());
                }

                Notificator.notificateDeletion(appContainer, listaTiposBebidas, newValue, 3000);
            }

            listaTiposBebidas.getView().requestFocus();

        });
    }

    private void setUpListaTiposComidasListeners() {
        //LISTENER PARA EVENTOS DE SELECAO/DESELECAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposComidas.ON_SELECTION().addListener((observable, oldValue, STATE) -> {
            handleTipoSelectionUNselection(STATE, listaTiposComidas);
        });

        //LISTENER PARA EVENTOS DE ADICAO DE OBJETOS NO VERTICALFULLSCROLLER
        listaTiposComidas.ON_ADDITION().addListener((observable, oldValue, STATE) -> {

            if (STATE.equals(ScrollableListContainerSimple.ON_ADD_REQUEST)) {

                novoTipoReceita.setScroller(listaTiposComidas);
                handle_ON_ADD_REQUEST_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newFoodTypeMessage"));

            } else if (STATE.equals(ScrollableListContainerSimple.ADDED)) {

                handle_ON_ADDED_NOVO_TIPO_RECEITA(Util.PROPERTIES.getProperty("newFoodTypeLoogerMessage"), Util.PROPERTIES.getProperty("newFoodTypeNotificatorMessage"), listaTiposComidas, 2500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newFoodTypeSavingLoggerErrorMessage"), Util.PROPERTIES.getProperty("newFoodTypeSavingNotificatorErrorMessage"), listaTiposComidas, 3500);

            } else if (STATE.equals(ScrollableListContainerSimple.ADDING_FAILED_DUPLICATE_ENTRY)) {

                handle_ON_ADDING_FAILED(Util.PROPERTIES.getProperty("newFoodTypeDuplicatedEntryLoggerErrorMessage"), Util.PROPERTIES.getProperty("newFoodTypeDuplicatedEntryNotificatorErrorMessage"), listaTiposComidas, 4500);

            }
        });

        //LISTENER PARA EVENTOS DE REMOVER OBJETOS NO VERTICALFULLSCROLLER
        listaTiposComidas.ON_DELETION().addListener((observable, oldValue, newValue) -> {

            if (newValue.equals(ScrollableListContainerSimple.DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC)) {

                Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, Util.PROPERTIES.getProperty("deleteFoodTypeLoggerErrorMessage"), listaTiposComidas.getCurrentRemoving().getDescricao());
                Notificator.notificateError(appContainer, Util.PROPERTIES.getProperty("deleteFoodTypeNotificatorErrorMessage") + " " + listaTiposComidas.getCurrentRemoving().getDescricao(), 2500);

            } else {

                if (newValue.equals(ScrollableListContainerSimple.MULTI_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteFoodsTypesLoggerSuccessMessage"), listaTiposComidas.getMultiSelectionRemoved().size());
                }
                if (newValue.equals(ScrollableListContainerSimple.SINGLE_SELECTION_REMOVED)) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, Util.PROPERTIES.getProperty("deleteFoodTypeLoggerSuccessMessage"), listaTiposComidas.getCurrentRemoving().getDescricao());
                }

                Notificator.notificateDeletion(appContainer, listaTiposComidas, newValue, 3000);
            }

            listaTiposComidas.getView().requestFocus();

        });
    }

    private void setUpTabListeners(int sleep) {
        tabTipo.setOnSelectionChanged((event) -> {
            new Thread(() -> {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException ex) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.runLater(() -> {
                    selectTab(tipoReceitaTabPane, tabTipoComida);
                    listaTiposComidas.getView().requestFocus();
                });
            }).start();
        });
        tabTipoBebida.setOnSelectionChanged((event) -> {

            if (tabTipoCalorias.isDisable()) {
                tabTipoCalorias.setDisable(false);
                listaTiposBebidas.unSelectAll();
                resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
            } else {
                tabTipoCalorias.setDisable(true);
                listaTiposComidas.unSelectAll();
                listaTiposCalorias.unSelectAll();
                resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA);
            }

            new Thread(() -> {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException ex) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.runLater(() -> {
                    listaTiposBebidas.getView().requestFocus();
                    if (tabTipoCalorias.isDisable()) {
                        resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA);
                    } else {
                        resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
                    }
                });
            }).start();
        });
        tabTipoComida.setOnSelectionChanged((event) -> {
            new Thread(() -> {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException ex) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.runLater(() -> {
                    listaTiposComidas.getView().requestFocus();
                });
            }).start();
        });
        tabTipoCalorias.setOnSelectionChanged((event) -> {
            new Thread(() -> {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException ex) {
                    Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.runLater(() -> {
                    listaTiposCalorias.getView().requestFocus();
                });
            }).start();

        });

        tabIngredientes.setOnSelectionChanged((event) -> {

            new Thread(() -> {
                Platform.runLater(() -> {
                    ingredientes.requestFocus();
                });
            }).start();

        });

        tabModoPreparo.setOnSelectionChanged((event) -> {
            new Thread(() -> {
                Platform.runLater(() -> {
                    modoPreparo.requestFocus();
                });
            }).start();
        });
    }

    private void handle_ON_ADDING_FAILED(String logMessage, String notificationMessage, VerticalScrollableListWrapper controller, int timeOut) {
        Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, logMessage, controller.getCurrentAdding().getDescricao());
        Notificator.notificateError(appContainer, notificationMessage + " " + controller.getCurrentAdding().getDescricao(), timeOut);
        novoTipoReceita.cleanUp();
        novoTipoReceita.setVisible(false);
        controller.getView().requestFocus();
    }

    private void handle_ON_ADDED_NOVO_TIPO_RECEITA(String logMessage, String notificationMessage, VerticalScrollableListWrapper controller, int timeOut) {
        Logger.getLogger(NovaReceita.class.getName()).log(Level.INFO, logMessage, controller.getCurrentAdding().getDescricao());
        Notificator.notificate(appContainer, notificationMessage + " " + controller.getCurrentAdding().getDescricao() + " SALVO", timeOut);
        novoTipoReceita.cleanUp();
        novoTipoReceita.setVisible(false);
        controller.getView().requestFocus();
    }

    private void handle_ON_ADD_REQUEST_NOVO_TIPO_RECEITA(String title) {
        Platform.runLater(() -> {
            novoTipoReceita.cleanUp();
            novoTipoReceita.setTitle(title);
            novoTipoReceita.setVisible(true);
            novoTipoReceita.getNomeTipoTextField().requestFocus();
        });
    }

    private void fillConfirmationPage() {

        appContainer.getConfirmarSalvar().getNomeReceita().setText(nomeReceita.getText());

        appContainer.getConfirmarSalvar().setEditing(false);

        if (ingredientes.getText().trim().equals("")) {
            appContainer.getConfirmarSalvar().getIngredientes().setText(Util.PROPERTIES.getProperty("ingredientlessReceitaErrorMessage"));
        } else {
            appContainer.getConfirmarSalvar().getIngredientes().setText(getTabContent(receitaTabPane, tabIngredientes));
        }
        if (modoPreparo.getText().trim().equals("")) {
            appContainer.getConfirmarSalvar().getModoPreparo().setText(Util.PROPERTIES.getProperty("howToMakelessReceitaErrorMessage"));
        } else {
            appContainer.getConfirmarSalvar().getModoPreparo().setText(getTabContent(receitaTabPane, tabModoPreparo));
        }

        appContainer.getConfirmarSalvar().getTipoRefeicaoText().setText(resumoTipoLabel.getText());

    }

    private void selectTab(TabPane tabPane, Tab tab) {
        for (Tab t : tabPane.getTabs()) {
            if (t.getText().equals(tab.getText())) {
                tabPane.getSelectionModel().select(t);
            }
        }
    }

    public void cleanUp() {
        nomeReceita.setText("");
        for (Tab t : receitaTabPane.getTabs()) {
            if (t.getText().equals(Util.PROPERTIES.getProperty("tabIngredientes"))) {
                receitaTabPane.getSelectionModel().select(t);
            }
            AnchorPane content = (AnchorPane) t.getContent();
            try {
                ((JFXTextArea) content.getChildren().get(0)).setText("");
            } catch (Exception e) {
            }
        }

        listaTiposComidas.unSelectAll();
        listaTiposBebidas.unSelectAll();
        listaTiposCalorias.unSelectAll();
        resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
    }

    private String getTabContent(TabPane tabPane, Tab tab) {
        String tabContent = "";
        for (Tab t : tabPane.getTabs()) {
            if (t.getText().equals(tab.getText())) {
                AnchorPane content = (AnchorPane) t.getContent();
                try {
                    tabContent = ((JFXTextArea) content.getChildren().get(0)).getText();
                } catch (Exception e) {
                }
            }
        }
        return tabContent;
    }

    public JFXTextField getNomeReceita() {
        return nomeReceita;
    }

    public JFXTextArea getIngredientes() {
        return ingredientes;
    }

    public JFXTextArea getModoPreparo() {
        return modoPreparo;
    }

    public Label getResumoTipoLabel() {
        return resumoTipoLabel;
    }

    public boolean hasNoActivity() {
        return nomeReceita.getText().trim().equals("") && ingredientes.getText().trim().equals("") && modoPreparo.getText().trim().equals("") || STATE.getValue().equals(ADDING_FINISHED);
    }

    public StringProperty getSTATE() {
        return STATE;
    }

    public void setState(String newState) {
        try {
            STATE.setValue(newState);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setTiposReceitaLoaded(boolean newValue) {
        tiposComidasLoaded = newValue;
        tiposBebidasLoaded = newValue;
        tiposCaloriasLoaded = newValue;
    }

    public JFXButton getSalvarButton() {
        return salvar;
    }

    public AppContainer getAppContainer() {
        return appContainer;
    }

    public NovoTipoReceita getNovoTipoReceita() {
        return novoTipoReceita;
    }

    public FullVerticalScrollableListWrapperImpl getListaTiposComidas() {
        return listaTiposComidas;
    }

    public FullVerticalScrollableListWrapperImpl getListaTiposBebidas() {
        return listaTiposBebidas;
    }

    public FullVerticalScrollableListWrapperImpl getListaTiposCalorias() {
        return listaTiposCalorias;
    }

    @Override
    public NotificationPage getNotificationPage() {
        return notificationPage;
    }

//    SESSAO TIPO RECEITA
    private void handle_TIPO_SELECTED_ALL(VerticalScrollableListWrapper controller) {

        if (controller instanceof ListaTiposComidas) {
            handle_TIPO_COMIDA_SELECTED_ALL(controller);
        } else if (controller instanceof ListaTiposBebidas) {
            handle_TIPO_BEBIDAS_SELECTED_ALL(controller);
        } else if (controller instanceof ListaTiposCalorias) {
            // MULTI SELECTION TIPO CALORIA ESTÁ DESABILITADO
        }

    }

    private void handle_TIPO_COMIDA_SELECTED_ALL(VerticalScrollableListWrapper controller) {

        try {

            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS);
            for (Item item : controller.getView().getSelection()) {
                resumoTipoLabel.setText(resumoTipoLabel.getText() + item.getDescricao() + ", ");
            }
            resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));
            //ADICIONA O TIPO DE CALORIA NO ULTIMA DA LISTA DE TIPOS, CASO HAJA ALGUM TIPO CALORIA SELECIONADA
            if (listaTiposCalorias.getCurrentSelected() != null) {
                try {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().split("-")[1].trim());
                } catch (Exception e) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().trim());
                }
            }

        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    private void handle_TIPO_BEBIDAS_SELECTED_ALL(VerticalScrollableListWrapper controller) {

        try {

            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA + INICIO_RESUMO_TIPO_BEBIDA_PLUS);
            for (Item item : controller.getView().getSelection()) {
                resumoTipoLabel.setText(resumoTipoLabel.getText() + item.getDescricao() + ", ");
            }
            resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));

        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    private void handle_TIPO_INVERTED_SELECTION_STATE(VerticalScrollableListWrapper controller) {

        if (controller instanceof ListaTiposComidas) {
            handle_TIPO_COMIDA_INVERTED_SELECTION(controller);
        } else if (controller instanceof ListaTiposBebidas) {
            handle_TIPO_BEBIDA_INVERTED_SELECTION(controller);
        } else if (controller instanceof ListaTiposCalorias) {
            // INVERTED SELECTION TIPO CALORIA ESTÁ DESABILITADO
        }

    }

    private void handle_TIPO_COMIDA_INVERTED_SELECTION(VerticalScrollableListWrapper controller) {

        try {

            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS);

            for (Item tipoComida : controller.getView().getSelection()) {
                resumoTipoLabel.setText(resumoTipoLabel.getText() + tipoComida.getDescricao() + ", ");
            }

            resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));

            //ADICIONA O TIPO DE CALORIA NO ULTIMA DA LISTA DE TIPOS,, CASO HAJA ALGUM TIPO CALORIA SELECIONADA
            if (listaTiposCalorias.getCurrentSelected() != null) {

                try {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().split("-")[1].trim());
                } catch (Exception e) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().trim());
                }
            }
        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    private void handle_TIPO_BEBIDA_INVERTED_SELECTION(VerticalScrollableListWrapper controller) {

        try {

            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA + INICIO_RESUMO_TIPO_BEBIDA_PLUS);
            for (Item item : controller.getView().getSelection()) {
                resumoTipoLabel.setText(resumoTipoLabel.getText() + item.getDescricao() + ", ");
            }
            resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));

        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    private void handle_TIPO_NO_SELECTION_STATE(VerticalScrollableListWrapper controller) {
        if (controller instanceof ListaTiposComidas) {
            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
            listaTiposCalorias.unSelectAll();
        } else if (controller instanceof ListaTiposBebidas) {
            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA);
        } else if (controller instanceof ListaTiposCalorias) {
            if (resumoTipoLabel.getText().contains(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS)) {
                String[] tiposComidas = resumoTipoLabel.getText().split(" - ");
                String[] currents = tiposComidas[0].split(",");
                resumoTipoLabel.setText("");
                for (String tipoComida : currents) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + tipoComida + ",");
                }
                resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));
            }
        }
    }

    private void handle_TIPO_SINGLE_SELECTION_STATE(VerticalScrollableListWrapper controller) {
        if (controller instanceof ListaTiposComidas) {
            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS + listaTiposComidas.getCurrentSelected().getDescricao().toUpperCase());
        } else if (controller instanceof ListaTiposBebidas) {
            resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA + INICIO_RESUMO_TIPO_BEBIDA_PLUS + listaTiposBebidas.getCurrentSelected().getDescricao().toUpperCase());
        } else if (controller instanceof ListaTiposCalorias) {
            if (resumoTipoLabel.getText().contains(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS)) {
                String[] tiposComidas = resumoTipoLabel.getText().split(" - ");
                String[] currents = tiposComidas[0].split(",");
                resumoTipoLabel.setText("");
                for (String tipoComida : currents) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + tipoComida + ",");
                }
                resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));
                try {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().split("-")[1].trim());
                } catch (Exception e) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().trim());
                }
            } else {
                resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA);
                Notificator.notificateWarning(appContainer, Util.PROPERTIES.getProperty("selectingCaloricsBeforeFoodTypeErrorMessage"), 3500);
            }
        }
    }

    private void handle_TIPO_MULTI_SELECTION_STATE(VerticalScrollableListWrapper controller) {
        if (controller instanceof ListaTiposComidas) {
            handle_TIPO_COMIDA_MULTI_SELECTION(controller);
        } else if (controller instanceof ListaTiposBebidas) {
            handle_TIPO_BEBIDA_MULTI_SELECTION(controller);
        } else if (controller instanceof ListaTiposCalorias) {
            // MULTI SELECTION TIPO CALORIA ESTÁ DESABILITADO
        }
    }

    private void handle_TIPO_BEBIDA_MULTI_SELECTION(VerticalScrollableListWrapper controller) {
        try {

            if (apenas_UM_TipoSelecionado(controller)) {
                String currentSelection = listaTiposBebidas.getCurrentSelected().getDescricao().toUpperCase();
                if (!resumoTipoLabel.getText().contains(currentSelection)) {
                    resumoTipoLabel.setText(INICIO_RESUMO_TIPO_BEBIDA + INICIO_RESUMO_TIPO_BEBIDA_PLUS + listaTiposBebidas.getCurrentSelected().getDescricao().toUpperCase());
                } else {
                    removeFromResumoTipoReceita(currentSelection);
                }
            } else {
                String currentSelection = listaTiposBebidas.getCurrentSelected().getDescricao().toUpperCase();
                if (!resumoTipoLabel.getText().contains(currentSelection)) {
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + ", " + listaTiposBebidas.getCurrentSelected().getDescricao().toUpperCase());
                } else {//removes from multi
                    removeFromResumoTipoReceita(currentSelection);
                }
            }

        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    private void removeFromResumoTipoReceita(String currentSelection) {
        //removes from multi
        resumoTipoLabel.setText(resumoTipoLabel.getText().replace(", " + currentSelection + ", ", ", "));
        resumoTipoLabel.setText(resumoTipoLabel.getText().replace(", " + currentSelection, ""));
        resumoTipoLabel.setText(resumoTipoLabel.getText().replace(currentSelection + ", ", ""));
        resumoTipoLabel.setText(resumoTipoLabel.getText().replace(currentSelection, ""));
    }

    private void handle_TIPO_COMIDA_MULTI_SELECTION(VerticalScrollableListWrapper controller) {
        try {
            if (apenas_UM_TipoSelecionado(controller)) {
                String currentSelection = listaTiposComidas.getCurrentSelected().getDescricao().toUpperCase();
                if (!resumoTipoLabel.getText().contains(currentSelection)) {
                    resumoTipoLabel.setText(INICIO_RESUMO_TIPO_COMIDA + INICIO_RESUMO_TIPO_COMIDA_PLUS + listaTiposComidas.getCurrentSelected().getDescricao().toUpperCase());
                } else {//removes from multi
                    removeFromResumoTipoReceita(currentSelection);
                }
            } else {
                String currentSelection = listaTiposComidas.getCurrentSelected().getDescricao().toUpperCase();
                if (!resumoTipoLabel.getText().contains(currentSelection)) {
                    String[] tiposComidas = resumoTipoLabel.getText().split(" - ");
                    String[] currents = tiposComidas[0].split(",");
                    resumoTipoLabel.setText("");
                    for (String tipoComida : currents) {
                        resumoTipoLabel.setText(resumoTipoLabel.getText() + tipoComida + ",");
                    }
                    resumoTipoLabel.setText(resumoTipoLabel.getText().substring(0, resumoTipoLabel.getText().lastIndexOf(",")));
                    resumoTipoLabel.setText(resumoTipoLabel.getText() + ", " + listaTiposComidas.getCurrentSelected().getDescricao().toUpperCase());
                    //ADICIONA O TIPO DE CALORIA NO ULTIMA DA LISTA DE TIPOS,, CASO HAJA ALGUM TIPO CALORIA SELECIONADA
                    if (listaTiposCalorias.getCurrentSelected() != null) {

                        try {
                            resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().split("-")[1].trim());
                        } catch (Exception e) {
                            resumoTipoLabel.setText(resumoTipoLabel.getText() + " - " + listaTiposCalorias.getCurrentSelected().getDescricao().toUpperCase().trim());
                        }
                    }

                } else {//removes from multi
                    removeFromResumoTipoReceita(currentSelection);
                }
            }
        } catch (Exception e) {
            Logger.getLogger(NovaReceita.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    private static boolean apenas_UM_TipoSelecionado(VerticalScrollableListWrapper controller) {
        return controller.getView().getSelection().size() == 1;
    }

    public void saveTipoReceita(TipoReceita tipoReceita) throws Exception {
        appContainer.saveTipoReceita(tipoReceita);
    }

    public void deleteTipoReceita(TipoReceita tipoReceita) throws Exception {
        appContainer.deleteTipoReceita(tipoReceita);
    }

    public Collection<TipoReceita> getAllTiposReceitas(Class clazz) {
        return appContainer.getAllTiposReceitas(clazz);
    }

    public void reloadTipoReceita(Class aClass) {
        if (aClass.equals(TipoComida.class)) {
            tiposComidasLoaded = false;
        } else if (aClass.equals(TipoBebida.class)) {
            tiposBebidasLoaded = false;
        } else if (aClass.equals(TipoCaloria.class)) {
            tiposCaloriasLoaded = false;
        }
    }

    public void reloadTipoReceitaNow(Class aClass) {
        try {
            if (aClass.equals(TipoComida.class)) {
                loadTiposComidas();
            } else if (aClass.equals(TipoBebida.class)) {
                loadTiposBebidas();
            } else if (aClass.equals(TipoCaloria.class)) {
                loadTiposCalorias();
            }
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }
    }

    public void reloadAllTipoReceitaNow() {
        try {
            loadTiposComidas();
            loadTiposBebidas();
            loadTiposCalorias();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }
    }

    public boolean canAdditionBeCanceledByEscKey() {
        return nomeReceita.isFocused()
                || ingredientes.isFocused()
                || modoPreparo.isFocused();
    }

    @Override
    public void closeMenu() {
        menu.setVisible(false);
    }

    /**
     * Before shutDown hook.
     */
    @Override
    public void beforeShutDown() {
        listaTiposComidas.saveLookAndFeel(getClass().getSimpleName());
        listaTiposBebidas.saveLookAndFeel(getClass().getSimpleName());
        listaTiposCalorias.saveLookAndFeel(getClass().getSimpleName());
    }

    @Override
    public void disableMenuIcon() {
        try {
            menuAppIcon.setVisible(false);
            menuAppIcon.setDisable(true);
        } catch (Exception e) {
        }
    }

}
