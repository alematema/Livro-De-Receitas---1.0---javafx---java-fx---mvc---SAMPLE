package br.com.undra.livrodereceitas.paginas.tiporeceita;

/**
 * Modela um tipo de bebida, como por exemplo:
 * <br> SUCO NATURAL,SUCO NÃO-NATURAL,ALCOOLICA,APERITIVO,ETC.
 * @author alexandre
 */
public class TipoBebida extends TipoReceita{
    
    public static TipoBebida SUCO_NAO_NATURAL = new TipoBebida("SUCO NÃO-NATURAL");
    public static TipoBebida ALCOOLICA = new TipoBebida("ALCOÓLICA");
    public static TipoBebida REFRIGERANTE = new TipoBebida("REFRIGERANTE");
    public static TipoBebida APERITIVO = new TipoBebida("APERITIVO");
    public static TipoBebida REMÉDIO = new TipoBebida("REMÉDIO");
    public static TipoBebida SUCO_NATURAL = new TipoBebida("SUCO NATURAL");
    public static TipoBebida ÁGUA = new TipoBebida("ÁGUA");
    
    
    private String nome;
    
    public TipoBebida() {
    }

    public TipoBebida(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return  "TIPO BEBIDA - "+nome; //To change body of generated methods, choose Tools | Templates.
    }
    
}
