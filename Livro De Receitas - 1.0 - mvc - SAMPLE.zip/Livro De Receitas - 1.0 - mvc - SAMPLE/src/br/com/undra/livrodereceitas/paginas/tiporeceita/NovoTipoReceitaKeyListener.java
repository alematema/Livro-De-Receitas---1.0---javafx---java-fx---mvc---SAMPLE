package br.com.undra.livrodereceitas.paginas.tiporeceita;

import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

/**
 * um listener para eventos de teclado, na tela novo tipo receita.
 * @author alexandre
 */
public class NovoTipoReceitaKeyListener implements NativeKeyListener{

    private final NovoTipoReceita novoTipoReceita;

    public NovoTipoReceitaKeyListener(NovoTipoReceita novoTipoReceita) {
        this.novoTipoReceita = novoTipoReceita;
    }
    
    
    @Override
    public void nativeKeyPressed(NativeKeyEvent e) {

        switch (e.getKeyCode()) {

            case NativeKeyEvent.VC_ESCAPE:
                //CANCELA COM ESC NOVA TIPO RECEITA
                if(novoTipoReceita.isVisible()){
                    novoTipoReceita.handlecancelarSalvarTipoReceitaMouseClicked(null);
                }
                break;

            case NativeKeyEvent.VC_ENTER:
                //CONFIRMA SALVAR O NOVo TIPO RECEITA
               if(novoTipoReceita.isVisible()){
                    novoTipoReceita.handleSalvarTipoReceitaMouseClicked(null);
                }
                break;
            default:
                break;
        }

        
        
    }

    @Override
    public void nativeKeyTyped(NativeKeyEvent nke) {
    }
    @Override
    public void nativeKeyReleased(NativeKeyEvent nke) {
    }
    
}
