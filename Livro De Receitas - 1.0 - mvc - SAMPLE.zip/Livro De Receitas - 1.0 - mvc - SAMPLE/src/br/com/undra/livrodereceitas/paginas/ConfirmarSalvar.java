package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.pagenavigator.PageNavigator;
import static br.com.undra.livrodereceitas.paginas.NovaReceita.ADDING_FINISHED;
import br.com.undra.livrodereceitas.util.Helper;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

/**
 * A mvc confirmar salvar.
 *
 * @author alexandre
 */
public class ConfirmarSalvar extends Page {

    private AppContainer appContainer;
    @FXML
    private JFXButton cancelar;
    @FXML
    private JFXButton confirmar;
    @FXML
    private JFXTextArea ingredientes;
    @FXML
    private JFXTextArea modoPreparo;
    @FXML
    private JFXTextArea tipoRefeicaoText;
    @FXML
    private JFXTextArea nomeReceita;
    @FXML
    private Label tipoLable;
    @FXML
    private Label modoPreparpLable;
    @FXML
    private Label ingredientesLable;
    private boolean isEditing = false;

    private StringProperty STATE = new SimpleStringProperty();

    private NotificationPage notificationPage;

    private final ListChangeListener childrenChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {

            while (change.next()) {

                if (change.wasAdded()) {
                    for (Object o : change.getAddedSubList()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = (NotificationPage) o;
                        }
                    }
                }

                if (change.wasRemoved()) {
                    for (Object o : change.getRemoved()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = null;
                        }
                    }
                }
            }
        }
    };

    EventHandler<? super Event> onMouseMoveHandler;

    /**
     * A mvc confirmar salvar.
     *
     * @author alexandre
     */
    public ConfirmarSalvar() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLConfirmarSalvar.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        ingredientesLable.setText(Util.PROPERTIES.getProperty("tabIngredientes"));
        modoPreparpLable.setText(Util.PROPERTIES.getProperty("tabModoPreparo"));
        tipoLable.setText(Util.PROPERTIES.getProperty("tabTipoReceita"));

        getChildren().addListener(childrenChangedListener);

    }

    /**
     * A mvc confirmar salvar.
     *
     * @author alexandre
     * @param appContainer
     */
    public ConfirmarSalvar(AppContainer appContainer) {
        this();
        this.appContainer = appContainer;
        //usado para ajuda contextualizada
        onMouseMoveHandler = Helper.getMouseEventIdentifiedHandler(appContainer,this);
        setOnMouseMoved(onMouseMoveHandler);
    }

    @FXML
    void handleCancelarSalvarMouseClicked(MouseEvent event) {
        appContainer.getPageWrapper().setCloseButtonVisible(false);
        appContainer.getPageWrapper().hide();
        if (!isEditing) {
            PageNavigator.goToPageSmoothly(appContainer, appContainer.getNovaReceita());
            new Thread(() -> {
                try {
                    Thread.sleep(1100);
                } catch (Exception e) {
                }
                Platform.runLater(() -> {
                    appContainer.getNovaReceita().getNomeReceita().requestFocus();
                    appContainer.getNovaReceita().getNomeReceita().selectEnd();
                    appContainer.getNovaReceita().getNomeReceita().selectForward();
                });
            }).start();

        } else {

            PageNavigator.goToPageSmoothly(appContainer, appContainer.getDetalhesReceita());
            new Thread(() -> {
                try {
                    Thread.sleep(1100);
                } catch (Exception e) {
                }
                Platform.runLater(() -> {
                    appContainer.getDetalhesReceita().getNomeReceita().requestFocus();
                    appContainer.getDetalhesReceita().getNomeReceita().selectEnd();
                    appContainer.getDetalhesReceita().getNomeReceita().selectForward();

                });
            }).start();
        }
    }

    @FXML
    void handleConfirmarSalvarMouseClicked(MouseEvent event) {

        appContainer.getPageWrapper().setCloseButtonVisible(false);
        appContainer.getPageWrapper().hide();

        if (!isEditing) {
            appContainer.getNovaReceita().setState(ADDING_FINISHED);
            appContainer.addNovaReceita(createFillAndGet(appContainer.getNovaReceita().getNomeReceita().getText()));
            appContainer.getNovaReceita().cleanUp();
        } else {
            appContainer.getDetalhesReceita().getDetalhesReceitaLbl().setText(Util.PROPERTIES.getProperty("detalhes.receita.text"));
            appContainer.getDetalhesReceita().setState(DetalhesReceita.EDITING_FINISHED);
            Receita oldReceita = appContainer.getDetalhesReceita().getCurrent();
            appContainer.updateReceita(oldReceita, createFillAndGet(appContainer.getDetalhesReceita().getNomeReceita().getText()));
        }
    }

    private Receita createFillAndGet(String nome) {
        Receita receita = new Receita(nome);
        if (!isEditing) {
            getDataFromCreationAndFill(receita);
        } else {
            getDataFromEditionAndFill(receita);
        }

        return receita;
    }

    private void getDataFromCreationAndFill(Receita receita) {
        receita.setIngredientes(appContainer.getNovaReceita().getIngredientes().getText());
        receita.setModoPreparo(appContainer.getNovaReceita().getModoPreparo().getText());

        String[] splits = appContainer.getNovaReceita().getResumoTipoLabel().getText().split(" - ");
        String[] tiposDirty = splits[0].split(",");
        List<String> tipos = new ArrayList<>();
        String inicio_resumo_tipo = "";
        String inicio_resumo_plus = "";

        if (appContainer.getNovaReceita().getResumoTipoLabel().getText().contains(NovaReceita.INICIO_RESUMO_TIPO_COMIDA)) {

            inicio_resumo_tipo = NovaReceita.INICIO_RESUMO_TIPO_COMIDA;
            inicio_resumo_plus = NovaReceita.INICIO_RESUMO_TIPO_COMIDA_PLUS;

        } else if (appContainer.getNovaReceita().getResumoTipoLabel().getText().contains(NovaReceita.INICIO_RESUMO_TIPO_BEBIDA)) {

            inicio_resumo_tipo = NovaReceita.INICIO_RESUMO_TIPO_BEBIDA;
            inicio_resumo_plus = NovaReceita.INICIO_RESUMO_TIPO_BEBIDA_PLUS;

        }

        for (String s : tiposDirty) {

            if (!s.contains(inicio_resumo_tipo)) {
                String TIPO = inicio_resumo_plus.replaceAll(",", "").trim();
                if (s.contains(TIPO)) {
                    String tipo = s.replace(TIPO, "").trim();
                    tipos.add(tipo);
                } else {
                    tipos.add(s.trim());
                }
            }
        }

        if (appContainer.getNovaReceita().getResumoTipoLabel().getText().contains(NovaReceita.INICIO_RESUMO_TIPO_COMIDA)) {

            receita.setTiposComida(appContainer.toTiposComidas(tipos));
            receita.setTipoCaloria(appContainer.toTipoCaloria(splits[1]));

            receita.setTipoReceita(Receita.TIPO_COMIDA);

        } else if (appContainer.getNovaReceita().getResumoTipoLabel().getText().contains(NovaReceita.INICIO_RESUMO_TIPO_BEBIDA)) {

            receita.setTiposBebida(appContainer.toTiposBebidas(tipos));

            receita.setTipoReceita(Receita.TIPO_BEBIDA);
        }
    }

    private void getDataFromEditionAndFill(Receita receita) {
        receita.setIngredientes(appContainer.getDetalhesReceita().getIngredientes().getText());
        receita.setModoPreparo(appContainer.getDetalhesReceita().getModoPreparo().getText());

        String[] splits = appContainer.getDetalhesReceita().getResumoTipoLabel().getText().split(" - ");
        String[] tiposDirty = splits[0].split(",");
        List<String> tipos = new ArrayList<>();
        String inicio_resumo_tipo = "";
        String inicio_resumo_plus = "";

        if (appContainer.getDetalhesReceita().getResumoTipoLabel().getText().contains(DetalhesReceita.INICIO_RESUMO_TIPO_COMIDA)) {

            inicio_resumo_tipo = DetalhesReceita.INICIO_RESUMO_TIPO_COMIDA;
            inicio_resumo_plus = DetalhesReceita.INICIO_RESUMO_TIPO_COMIDA_PLUS;

        } else if (appContainer.getDetalhesReceita().getResumoTipoLabel().getText().contains(DetalhesReceita.INICIO_RESUMO_TIPO_BEBIDA)) {

            inicio_resumo_tipo = DetalhesReceita.INICIO_RESUMO_TIPO_BEBIDA;
            inicio_resumo_plus = DetalhesReceita.INICIO_RESUMO_TIPO_BEBIDA_PLUS;

        }

        for (String s : tiposDirty) {

            if (!s.contains(inicio_resumo_tipo)) {
                String TIPO = inicio_resumo_plus.replaceAll(",", "").trim();
                if (s.contains(TIPO)) {
                    String tipo = s.replace(TIPO, "").trim();
                    tipos.add(tipo);
                } else {
                    tipos.add(s.trim());
                }
            }
        }

        if (appContainer.getDetalhesReceita().getResumoTipoLabel().getText().contains(DetalhesReceita.INICIO_RESUMO_TIPO_COMIDA)) {

            receita.setTiposComida(appContainer.toTiposComidas(tipos));
            receita.setTipoCaloria(appContainer.toTipoCaloria(splits[1]));

            receita.setTipoReceita(Receita.TIPO_COMIDA);

        } else if (appContainer.getDetalhesReceita().getResumoTipoLabel().getText().contains(DetalhesReceita.INICIO_RESUMO_TIPO_BEBIDA)) {

            receita.setTiposBebida(appContainer.toTiposBebidas(tipos));

            receita.setTipoReceita(Receita.TIPO_BEBIDA);
        }
    }

    @Override
    public void setUp(FullVerticalScrollableListWrapperImpl verticalFullScroller) {

        prefWidthProperty().bind(getScene().widthProperty().subtract(verticalFullScroller.widthProperty()));
        prefHeightProperty().bind(getScene().heightProperty());

        widthProperty().addListener((observable, oldValue, newValue) -> {
            setLayoutX(verticalFullScroller.getPrefWidth());
            confirmar.setLayoutX(getWidth() - confirmar.getPrefWidth() - 10);
            cancelar.setLayoutX(confirmar.getLayoutX() - confirmar.getPrefWidth() - 10);
            ingredientes.setPrefWidth(newValue.doubleValue() - 20);
            modoPreparo.setPrefWidth(newValue.doubleValue() - 20);
            tipoRefeicaoText.setPrefWidth(newValue.doubleValue() - 20);
            nomeReceita.setPrefWidth(cancelar.getLayoutX() - 20);

        });

    }

    public JFXTextArea getIngredientes() {
        return ingredientes;
    }

    public JFXTextArea getModoPreparo() {
        return modoPreparo;
    }

    public JFXTextArea getTipoRefeicaoText() {
        return tipoRefeicaoText;
    }

    public JFXTextArea getNomeReceita() {
        return nomeReceita;
    }

    public JFXButton getCancelar() {
        return cancelar;
    }

    public JFXButton getConfirmar() {
        return confirmar;
    }

    @Override
    public NotificationPage getNotificationPage() {
        return notificationPage;
    }

    public boolean isFocusedd() {
        return isFocused() || confirmar.isFocused() || cancelar.isFocused() || nomeReceita.isFocused() || tipoRefeicaoText.isFocused() || ingredientes.isFocused() || modoPreparo.isFocused();
    }

    public void clickConfirmar() {
        handleConfirmarSalvarMouseClicked(null);
    }

    public void clickCancelar() {
        handleCancelarSalvarMouseClicked(null);
    }

    public boolean isEditing() {
        return isEditing;
    }

    public void setEditing(boolean isEditing) {
        this.isEditing = isEditing;
    }

    @Override
    public void closeMenu() {
    }

    /**
     * Before shutDown hook.
     */
    @Override
    public void beforeShutDown() {

    }
    
    @Override
    public void disableMenuIcon() {
    }

}
