package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.util.Notificator;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIcon;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.util.HashMap;
import java.util.Map;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 *
 * @author alexandre
 */
public class Notifications {

    private static AppContainer container;

    public static void setContainer(AppContainer container) {
        Notifications.container = container;
    }

    public static String CARDAPIO_NOT_SUPPORTED_YET = "CARDAPIO_NOT_SUPPORTED_YET";
    public static String LOG_OUT_CONFIRMATION = "LOG_OUT";
    public static String MULTI_SELECTION_DELETION = "MULTI_SELECTION_DELETION";
    public static String CANNOT_REMOVE_SINGLE_SELECTEC = "CANNOT_REMOVE_SINGLE_SELECTEC";
    public static String CAN_REMOVE_SINGLE_SELECTEC = "CAN_REMOVE_SINGLE_SELECTEC";
    public static String PDF_VIEWER_UNAVALIABLE = "PDF_VIEWER_UNAVALIABLE";
    private static Map<String, Notification> map;

    static {

        map = new HashMap<>();

//        Notification LOG_OUT_NOTIFICATION = get_LOG_OUT_NOTIFICATION();
//        Notification REMOVE_MULTI_SELECTION_NOTIFICATION = get_REMOVE_MULTI_SELECTION_NOTIFICATION();
//        map.put(LOG_OUT_CONFIRMATION, LOG_OUT_NOTIFICATION);
//        map.put(MULTI_SELECTION_DELETION, REMOVE_MULTI_SELECTION_NOTIFICATION);
    }

//    public static Notification get(String name) {
//
//        Notification notification = getNullObject();
//
////        if (map.containsKey(name)) {
////            notification = map.get(name);
////        }
//        if (name.equals(LOG_OUT_CONFIRMATION)) {
//            notification = get_LOG_OUT_NOTIFICATION();
//        } else if (name.equals(MULTI_SELECTION_DELETION)) {
//            notification = get_REMOVE_MULTI_SELECTION_NOTIFICATION();
//        } else if (name.equals(CANNOT_REMOVE_SINGLE_SELECTEC)) {
//            notification = get_CANNOT_REMOVE_SINGLE_SELECTEC_NOTIFICATION();
//        } else if (name.equals(CAN_REMOVE_SINGLE_SELECTEC)) {
//            notification = get_CAN_REMOVE_SINGLE_SELECTEC_NOTIFICATION();
//        }else if( name.equals(CARDAPIO_NOT_SUPPORTED_YET)){
//            notification = getCARDAPIO_NOT_SUPPORTED_YET();
//        }else if( name.equals(PDF_VIEWER_UNAVALIABLE)){
//            notification = getPDF_VIEWER_UNAVALIABLE_NOTIFICATION();
//        }
//
//        return notification;
//    }
    private static final double titleFontSize = 35;
    private static final double titleFontMidleSize = 30;
    private static final double messageFontSize = 22;
    private static final double messageFontSizeSmaller = 17;
    private static final double glyphSize = 60;
    private static final String style = "-fx-background-color:#ff402b;-fx-opacity:0.9";
    private static final String RED_BIT_TRANSPARENCY_STYLE = "-fx-background-color:#ff402b;-fx-opacity:0.9";
    private static final String WARN_BIT_TRANSPARENCY_STYLE = "-fx-background-color:#ff9900;-fx-opacity:0.9";
    private static final String BLUE_STYLE = "-fx-background-color:#0083ff";
    private static final String SKY_BLUE_STYLE = "-fx-background-color: #0083ff;-fx-opacity:0.9";
    private static final String SKY_DARK_BLUE_STYLE = "-fx-background-color: #003b7a";
    private static final String DARK_PETROLEO_STYLE = "-fx-background-color: #262d3a;-fx-opacity:0.9";
    private static final String SEALED_FOR_DELETION_SALMON_COLOR_STYLE = "-fx-background-color: darksalmon";
    private static final Paint RED = Paint.valueOf("red");
    private static final Paint WHITE = Paint.valueOf("white");


    public static Notification get(String name, VerticalScrollableListWrapper wrapper) {

        Notification notification = getNullObject(wrapper);

        if (name.equals(LOG_OUT_CONFIRMATION)) {
            notification = get_LOG_OUT_NOTIFICATION(wrapper);
        } else if (name.equals(MULTI_SELECTION_DELETION)) {
            notification = get_REMOVE_MULTI_SELECTION_NOTIFICATION(wrapper);
        } else if (name.equals(CANNOT_REMOVE_SINGLE_SELECTEC)) {
            notification = get_CANNOT_REMOVE_SINGLE_SELECTEC_NOTIFICATION(wrapper);
        } else if (name.equals(CAN_REMOVE_SINGLE_SELECTEC)) {
            notification = get_CAN_REMOVE_SINGLE_SELECTEC_NOTIFICATION(wrapper);
        } else if (name.equals(CARDAPIO_NOT_SUPPORTED_YET)) {
            notification = getCARDAPIO_NOT_SUPPORTED_YET_NOTIFICATION(wrapper);
        } else if (name.equals(PDF_VIEWER_UNAVALIABLE)) {
            notification = getPDF_VIEWER_UNAVALIABLE(wrapper);
        }

        return notification;
    }

    private static synchronized Notification get_LOG_OUT_NOTIFICATION(VerticalScrollableListWrapper wrapper) {
    
        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {
            container.getMenu().logout();
        };
        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            container.getMenu().logout();
        };

        container.getNotificationPage().getDefCancelBtn().setText(Util.PROPERTIES.getProperty("notification.page.cancel.button.logout.text"));
        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.logout.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(BLUE_STYLE);

        Label title = new Label("Confirmar sair");
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.SILVERWARE_VARIANT);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = "Há processo em andamento de edição/criação de receita. Sair mesmo assim?";
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSize));
        String style = WARN_BIT_TRANSPARENCY_STYLE;
        Notification LOG_OUT_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return LOG_OUT_NOTIFICATION;
    }

    private static Notification getNullObject(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        container.getNotificationPage().getDefCancelBtn().setText(Util.PROPERTIES.getProperty("notification.page.cancel.button.null.object.text"));
        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.null.object.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(BLUE_STYLE);

        Label title = new Label("OLÁ, HOUVE UM ERRO !!!");
        title.setTextFill(RED);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.ALERT_CIRCLE_OUTLINE);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(RED);
        Label message = new Label("Hoje o dia está bonito, não está? Bom te ver por aqui.");
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSize));
        String style = DARK_PETROLEO_STYLE;
        return new NullNotification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);

    }

    private static Notification get_REMOVE_MULTI_SELECTION_NOTIFICATION(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {

            for (Item item : wrapper.getView().getSelection()) {
                item.setStyle(SEALED_FOR_DELETION_SALMON_COLOR_STYLE);
            }

            wrapper.getView().removeMultiSelectionBulk();
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {

        };

        container.getNotificationPage().getDefCancelBtn().setText(Util.PROPERTIES.getProperty("notification.page.cancel.button.remove.multi.selection.text"));
        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.remove.multi.selection.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(BLUE_STYLE);

        int size = wrapper.getView().getSelection().size();
        size = size - wrapper.getUNexcludables(wrapper.getView().getSelection()).size();
        Label title = new Label(size + " " + Util.getPROPERTIES(wrapper).getProperty("tituloNotificacaoRemoverMultiSelecao"));
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.DELETE);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = Util.getPROPERTIES(wrapper).getProperty("textoNotificacaoRemover");
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSize));
        String style = RED_BIT_TRANSPARENCY_STYLE;
        Notification REMOVE_MULTI_SELECTION_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return REMOVE_MULTI_SELECTION_NOTIFICATION;

    }

    private static Notification get_CANNOT_REMOVE_SINGLE_SELECTEC_NOTIFICATION(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {

            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.cannot.remove.single.selection.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(false);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(BLUE_STYLE);

        Label title = new Label(Util.getPROPERTIES(wrapper).getProperty("cannot.remove.single.selected.title"));
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.BLOCK_HELPER);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = Util.getPROPERTIES(wrapper).getProperty("cannot.remove.single.selected.message");
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSize));
        String style = RED_BIT_TRANSPARENCY_STYLE;
        Notification CANNOT_REMOVE_SINGLE_SELECTEC_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return CANNOT_REMOVE_SINGLE_SELECTEC_NOTIFICATION;

    }

    private static Notification get_CAN_REMOVE_SINGLE_SELECTEC_NOTIFICATION(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {

            for (Item item : wrapper.getView().getSelection()) {
                item.setStyle(SEALED_FOR_DELETION_SALMON_COLOR_STYLE);
            }

            wrapper.getView().removeMultiSelectionBulk();
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
            if (container.hasNoActivity()) {
                wrapper.requestFocus();
            }
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            for (Item item : wrapper.getView().getSelection()) {
                item.setStyle(SEALED_FOR_DELETION_SALMON_COLOR_STYLE);
            }

            wrapper.getView().removeMultiSelectionBulk();
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        container.getNotificationPage().getDefCancelBtn().setText(Util.PROPERTIES.getProperty("notification.page.cancel.button.can.remove.single.selection.text"));
        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.can.remove.single.selection.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(BLUE_STYLE);

        Label title = new Label(Util.getPROPERTIES(wrapper).getProperty("can.remove.single.selected.title"));
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.DELETE);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = Util.getPROPERTIES(wrapper).getProperty("can.remove.single.selected.message");
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSize));
        String style = RED_BIT_TRANSPARENCY_STYLE;
        Notification CAN_REMOVE_SINGLE_SELECTEC_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return CAN_REMOVE_SINGLE_SELECTEC_NOTIFICATION;
    }

    private static Notification getCARDAPIO_NOT_SUPPORTED_YET_NOTIFICATION(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {

            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.cardapio.not.supported.yet.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(false);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(SKY_DARK_BLUE_STYLE);

        Label title = new Label(Util.PROPERTIES.getProperty("notification.page.cardapio.not.supported.yet.title"));
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.THUMB_UP);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = String.format(Util.PROPERTIES.getProperty("notification.page.cardapio.not.supported.yet.message"),Util.PROPERTIES.getProperty("developer"),Util.PROPERTIES.getProperty("developer.celular"),Util.PROPERTIES.getProperty("developer.email"));
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSizeSmaller));
        String style = SKY_BLUE_STYLE;
        Notification CARDAPIO_NOT_SUPPORTED_YET_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return CARDAPIO_NOT_SUPPORTED_YET_NOTIFICATION;
    }

    private static Notification getPDF_VIEWER_UNAVALIABLE(VerticalScrollableListWrapper wrapper) {

        EventHandler<? super Event> defCancelBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<? super Event> defOkBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        EventHandler<ActionEvent> defCancelActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };
        EventHandler<ActionEvent> defOkActionBtn = (event) -> {
            Notificator.hideNotificationPage(container);
            wrapper.unblock();
        };

        container.getNotificationPage().getDefOkBtn().setText(Util.PROPERTIES.getProperty("notification.page.confirmation.button.pdf.viewer.unavaliable.text"));
        container.getNotificationPage().getDefCancelBtn().setVisible(false);
        container.getNotificationPage().getDefOkBtn().setVisible(true);
        container.getNotificationPage().getDefOkBtn().setStyle(SKY_DARK_BLUE_STYLE);

        Label title = new Label(Util.PROPERTIES.getProperty("notification.page.pdf.viewer.unavaliable.title"));
        title.setTextFill(WHITE);
        title.setFont(Font.font(titleFontSize));
        MaterialDesignIconView iconTitle = new MaterialDesignIconView(MaterialDesignIcon.EMOTICON_DEAD);
        iconTitle.setGlyphSize(glyphSize);
        iconTitle.setFill(WHITE);
        String msg = Util.PROPERTIES.getProperty("notification.page.pdf.viewer.unavaliable.message");
        Label message = new Label(msg);
        message.setTextFill(WHITE);
        message.setFont(Font.font(messageFontSizeSmaller));
        String style = RED_BIT_TRANSPARENCY_STYLE;
        Notification PDF_VIEWER_UNAVALIABLE_NOTIFICATION = new Notification(title, iconTitle, null, message, defCancelBtn, defOkBtn, defCancelActionBtn, defOkActionBtn, style);
        return PDF_VIEWER_UNAVALIABLE_NOTIFICATION;
    }
}
