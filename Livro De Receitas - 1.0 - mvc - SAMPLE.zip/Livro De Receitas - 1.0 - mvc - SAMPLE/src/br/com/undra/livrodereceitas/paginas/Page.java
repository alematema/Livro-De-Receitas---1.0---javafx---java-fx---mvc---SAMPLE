package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import javafx.scene.layout.Pane;

/**
 * Commom interface.
 *
 * @author alexandre
 */
public abstract class Page extends Pane {

    public abstract void setUp(FullVerticalScrollableListWrapperImpl verticalFullScroller);

    public abstract void closeMenu();

    public abstract NotificationPage getNotificationPage();

    /**
     * Before shutDown hook.
     */
    public abstract void beforeShutDown();
    
    public abstract void disableMenuIcon();
}
