package br.com.undra.livrodereceitas.paginas;

import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.ConfirmarSalvar;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.paginas.NenhumaReceitaSelecionada;
import br.com.undra.livrodereceitas.paginas.Page;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.application.Platform;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

/**
 *
 * @author alexandre
 */
public class ReceitaContainerRunner extends Application {

    public void start(Stage stage) throws Exception {

//        openConfirmarSalvar(new Stage());
//        openNenhumaSelecionada(new Stage());
//        openNovaReceita(new Stage());
//        openDetalhesReceita(new Stage());
//        openFirstThenCloseAndOpenTheSecond(new NenhumaReceitaSelecionada(), new NovaReceita());
//        openFirstThenCloseAndOpenTheSecond(new NenhumaReceitaSelecionada(), new ConfirmarSalvar());
//        openFirstThenCloseAndOpenTheSecond(new NenhumaReceitaSelecionada(), new DetalhesReceita());
//        openFirstThenCloseAndOpenTheSecond(new DetalhesReceita(), new NenhumaReceitaSelecionada());
//        openFirstThenCloseAndOpenTheSecond(new DetalhesReceita(),new NovaReceita());
        openFirstThenCloseAndOpenTheSecond(new NovaReceita(),new DetalhesReceita());

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void stop() throws Exception {
        System.out.println(getClass().getName());
        try {
            GlobalScreen.unregisterNativeHook();
        } catch (NativeHookException e1) {
            e1.printStackTrace();
        }
    }

    private void openFirstThenCloseAndOpenTheSecond(Page firstPage, Page secondPage) {

        Stage stage = new Stage();

        Pane root = new Pane();

        FullVerticalScrollableListWrapperImpl verticalFullScroller = new FullVerticalScrollableListWrapperImpl();

        root.getChildren().add(verticalFullScroller);
        root.getChildren().add(firstPage);

        Scene scene = new Scene(root);
        stage.setScene(scene);

        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX() + 30);
        stage.setY(primaryScreenBounds.getMinY() + 30);
        stage.setWidth(primaryScreenBounds.getWidth() * 0.9);
        stage.setHeight(primaryScreenBounds.getHeight() * 0.9);

        stage.setTitle("Livro de Receitar - V1");

        stage.show();
        try {
            stage.setFullScreen(true);
        } catch (Exception e) {
        }

        verticalFullScroller.setUp(scene);
        firstPage.setUp(verticalFullScroller);

        stage.setMinWidth(1000);
        stage.setMinHeight(710);

        new Thread(() -> {

            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                Logger.getLogger(ReceitaContainerRunner.class.getName()).log(Level.SEVERE, null, ex);
            }

            Platform.runLater(() -> {

                root.getChildren().remove(firstPage);
                root.getChildren().add(secondPage);

                stage.show();

                secondPage.setUp(verticalFullScroller);

                stage.setWidth(stage.getWidth() + 1);
                stage.setWidth(stage.getWidth() - 1);
                stage.setHeight(stage.getHeight()+1);
                stage.setHeight(stage.getHeight()-1);

            });

        }).start();

    }

    private void openConfirmarSalvar(Stage stage) {
        Pane root = new Pane();

        FullVerticalScrollableListWrapperImpl verticalFullScroller = new FullVerticalScrollableListWrapperImpl();
        ConfirmarSalvar confirmarSalvar = new ConfirmarSalvar();

        root.getChildren().add(verticalFullScroller);
        root.getChildren().add(confirmarSalvar);

        Scene scene = new Scene(root);
        stage.setScene(scene);
//        stage.initStyle(StageStyle.TRANSPARENT);
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX() + 30);
        stage.setY(primaryScreenBounds.getMinY() + 30);
        stage.setWidth(primaryScreenBounds.getWidth() * 0.9);
        stage.setHeight(primaryScreenBounds.getHeight() * 0.9);

        stage.setTitle("Livro de Receitar - V1");

        stage.show();

        verticalFullScroller.setUp(scene);
        confirmarSalvar.setUp(verticalFullScroller);
        confirmarSalvar.setLayoutX(verticalFullScroller.getWidth());

        stage.setMinWidth(1000);
        stage.setMinHeight(710);
    }

    private void openNenhumaSelecionada(Stage stage) {

        Pane root = new Pane();

        FullVerticalScrollableListWrapperImpl verticalFullScroller = new FullVerticalScrollableListWrapperImpl();
        NenhumaReceitaSelecionada nenhumaReceitaSelecionada = new NenhumaReceitaSelecionada();

        root.getChildren().add(verticalFullScroller);
        root.getChildren().add(nenhumaReceitaSelecionada);

        Scene scene = new Scene(root);
        stage.setScene(scene);
//        stage.initStyle(StageStyle.TRANSPARENT);
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX() + 30);
        stage.setY(primaryScreenBounds.getMinY() + 30);
        stage.setWidth(primaryScreenBounds.getWidth() * 0.9);
        stage.setHeight(primaryScreenBounds.getHeight() * 0.9);

        stage.setTitle("Livro de Receitar - V1");

        stage.show();

        verticalFullScroller.setUp(scene);
        nenhumaReceitaSelecionada.setUp(verticalFullScroller);

        nenhumaReceitaSelecionada.setLayoutX(verticalFullScroller.getWidth());

        stage.setMinWidth(1000);
        stage.setMinHeight(710);
    }

    private void openNovaReceita(Stage stage) {

        Pane root = new Pane();

        FullVerticalScrollableListWrapperImpl verticalFullScroller = new FullVerticalScrollableListWrapperImpl();
        NovaReceita novaReceita = new NovaReceita();

        root.getChildren().add(verticalFullScroller);
        root.getChildren().add(novaReceita);

        Scene scene = new Scene(root);
        stage.setScene(scene);
//        stage.initStyle(StageStyle.TRANSPARENT);
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX() + 30);
        stage.setY(primaryScreenBounds.getMinY() + 30);
        stage.setWidth(primaryScreenBounds.getWidth() * 0.9);
        stage.setHeight(primaryScreenBounds.getHeight() * 0.9);

        stage.setTitle("Livro de Receitar - V1");

        stage.show();

        verticalFullScroller.setUp(scene);
        novaReceita.setUp(verticalFullScroller);
//        novaReceita.setLayoutX(verticalFullScroller.getWidth());

        stage.setMinWidth(1000);
        stage.setMinHeight(710);
    }

    private void openDetalhesReceita(Stage stage) {
        Pane root = new Pane();

        FullVerticalScrollableListWrapperImpl verticalFullScroller = new FullVerticalScrollableListWrapperImpl();
        DetalhesReceita detalhesReceita = new DetalhesReceita();

        root.getChildren().add(verticalFullScroller);
        root.getChildren().add(detalhesReceita);

        Scene scene = new Scene(root);
        stage.setScene(scene);

        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX() + 30);
        stage.setY(primaryScreenBounds.getMinY() + 30);
        stage.setWidth(primaryScreenBounds.getWidth() * 0.9);
        stage.setHeight(primaryScreenBounds.getHeight() * 0.9);

        stage.setTitle("Livro de Receitar - V1");

        stage.show();

        verticalFullScroller.setUp(scene);
        detalhesReceita.setUp(verticalFullScroller);

        stage.setMinWidth(1000);
        stage.setMinHeight(710);
    }

}
