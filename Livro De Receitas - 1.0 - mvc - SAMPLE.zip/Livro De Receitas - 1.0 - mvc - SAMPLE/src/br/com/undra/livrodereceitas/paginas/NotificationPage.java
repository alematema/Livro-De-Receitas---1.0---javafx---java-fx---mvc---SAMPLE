package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import com.jfoenix.controls.JFXButton;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.IOException;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * A notification page for getting information from client<br>
 * and for showing client an issue.
 *
 * @author alexandre
 */
public class NotificationPage extends Pane {

    private AppContainer container;

    @FXML
    private Pane notificationContainer;

    @FXML
    private MaterialDesignIconView close;

    @FXML
    private MaterialDesignIconView iconTitle;

    @FXML
    private Label title;

    @FXML
    private Label message;

    @FXML
    private Pane commandsBox;

    @FXML
    private JFXButton defOkBtn;

    @FXML
    private JFXButton defCancelBtn;

    @FXML
    private Text developer;

    private Notification notification;

    private ChangeListener<Number> heightChangeListener;
    private ChangeListener<Number> widthChangeListener;

    public NotificationPage(AppContainer container) {

        this.container = container;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLNotificationPage.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        heightChangeListener = (observable, oldValue, newValue) -> {
            setPrefHeight(newValue.doubleValue());
            message.setLayoutY(newValue.doubleValue() / 2);
            commandsBox.setLayoutY(newValue.doubleValue() - commandsBox.getPrefHeight() - 10);
            developer.setLayoutY(newValue.doubleValue()-15);
        };

        widthChangeListener = (observable, oldValue, newValue) -> {
            setPrefWidth(newValue.doubleValue());
            commandsBox.setLayoutX(newValue.doubleValue() - commandsBox.getPrefWidth() - 10);
        };

        try {
            container.getCurrentPage().prefHeightProperty().addListener(heightChangeListener);
            container.getCurrentPage().prefWidthProperty().addListener(widthChangeListener);
        } catch (Exception e) {
        }

        notificationContainer.setStyle("-fx-background-color:#ff402b;-fx-opacity:0.9");

        developer.setText(Util.getDeveloperAndContact());
        
    }

    @FXML
    public void closeMouseClicked(MouseEvent event) {
        setVisible(false);
        container.getListaDeReceitas().unblock();
    }

    public void setUp() {

        container.getListaDeReceitas().block();

        setPrefHeight(container.getCurrentPage().getPrefHeight());
        setPrefWidth(container.getCurrentPage().getPrefWidth());

        message.setLayoutY(getPrefHeight() / 2);
        commandsBox.setLayoutY(getPrefHeight() - commandsBox.getPrefHeight() - 10);
        commandsBox.setLayoutX(getPrefWidth() - commandsBox.getPrefWidth() - 10);
        developer.setLayoutY(getPrefHeight()-15);
        message.setPrefWidth(getPrefWidth() - 10);

        setVisible(false);

        if (!container.getCurrentPage().getChildren().contains(this)) {
            container.getCurrentPage().getChildren().add(this);
        }

        try {
            container.getCurrentPage().prefHeightProperty().removeListener(heightChangeListener);
            container.getCurrentPage().prefWidthProperty().removeListener(widthChangeListener);
            container.getCurrentPage().prefHeightProperty().addListener(heightChangeListener);
            container.getCurrentPage().prefWidthProperty().addListener(widthChangeListener);
        } catch (Exception e) {
        }
    }

    public void setUp(VerticalScrollableListWrapper wrapper) {

        wrapper.block();

        setPrefHeight(container.getCurrentPage().getPrefHeight());
        setPrefWidth(container.getCurrentPage().getPrefWidth());

        message.setLayoutY(getPrefHeight() / 2);
        commandsBox.setLayoutY(getPrefHeight() - commandsBox.getPrefHeight() - 10);
        commandsBox.setLayoutX(getPrefWidth() - commandsBox.getPrefWidth() - 10);
        developer.setLayoutY(getPrefHeight()-15);

        message.setPrefWidth(getPrefWidth() - 10);

        setVisible(false);

        if (!container.getCurrentPage().getChildren().contains(this)) {
            container.getCurrentPage().getChildren().add(this);
        }

        try {
            container.getCurrentPage().prefHeightProperty().removeListener(heightChangeListener);
            container.getCurrentPage().prefWidthProperty().removeListener(widthChangeListener);
            container.getCurrentPage().prefHeightProperty().addListener(heightChangeListener);
            container.getCurrentPage().prefWidthProperty().addListener(widthChangeListener);
        } catch (Exception e) {
        }
    }

    public void setNotification(Notification notification) {
        this.notification = notification;
        title.setText(notification.getTitle().getText());
        title.setTextFill(notification.getTitle().getTextFill());
        title.setFont(notification.getTitle().getFont());
        title.setStyle(notification.getTitle().getStyle());
        message.setText(notification.getMessage().getText());
        message.setTextFill(notification.getMessage().getTextFill());
        message.setFont(notification.getMessage().getFont());
        message.setStyle(notification.getMessage().getStyle());
        iconTitle.setGlyphName(notification.getIconTitle().getGlyphName());
        iconTitle.setGlyphSize(notification.getIconTitle().getGlyphSize());
        iconTitle.setFill(notification.getIconTitle().getFill());
        defCancelBtn.setOnMouseClicked(notification.getDefCancelBtnHandler());
        defCancelBtn.setOnAction(notification.getDefCancelActionBtnHandler());
        defOkBtn.setOnMouseClicked(notification.getDefOkBtnHandler());
        defOkBtn.setOnAction(notification.getDefOkActionBtnHandler());
        setStyle(notification.getStyle());
    }

    public AppContainer getContainer() {
        return container;
    }

    public JFXButton getDefOkBtn() {
        return defOkBtn;
    }

    public JFXButton getDefCancelBtn() {
        return defCancelBtn;
    }

    public Notification getNotification() {
        return notification;
    }

}
