package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.Output;
import br.com.undra.livrodereceitas.Splash;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FillTransition;
import javafx.animation.Transition;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.util.Duration;

/**
 * A loader page.<br>
 * Shows RECEITAS LOADING, TIPO COMIDA LOADING, TIPO BEBIDA LOADING AND TIPO
 * CALORIA LOADING.
 *
 * @author alexandre
 */
public class LoaderPage extends Pane {

    private DoubleProperty ON_UPDATE = new SimpleDoubleProperty(0);

    public static int NOTHING_TO_LOAD = -1;

    @FXML
    private Pane receitasLoaderCmp;

    @FXML
    private Pane receitasLoader;

    @FXML
    private Label msgL1;

    @FXML
    private Pane tipoComidaLoaderCmp;

    @FXML
    private Pane tipoComidaLoader;

    @FXML
    private Label msgL2;

    @FXML
    private Pane tipoBebidaLoaderCmp;

    @FXML
    private Pane tipoBebidaLoader;

    @FXML
    private Label msgL3;

    @FXML
    private Pane tipoCaloriaLoaderCmp;

    @FXML
    private Pane tipoCaloriaLoader;

    @FXML
    private Label msgL4;

    @FXML
    private MaterialIconView loaderPageIcon;

    private double loadersMaxWidth;

    private double spacing = 100;

    private volatile boolean loaded = false;
    private volatile boolean receitasLoaded;
    private volatile boolean tipoBebidaLoaded;
    private volatile boolean tipoCaloriaLoaded;
    private volatile boolean tipoComidaLoaded;

    @FXML
    private Label loadingLabel;

    private Timer reticenciasTimer;

    private FillTransition fillTransition;

    private AppContainer container;

    volatile private boolean singleLoader = false;

    private Collection<Output> outputs;

    public LoaderPage(AppContainer container, boolean singleLoader) {

        this.container = container;
        this.singleLoader = singleLoader;

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLoaderPage.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        if (singleLoader) {

            msgL1.setText("CARREGANDO");

            tipoComidaLoaderCmp.setVisible(false);
            tipoBebidaLoaderCmp.setVisible(false);
            tipoCaloriaLoaderCmp.setVisible(false);

        }

        fillTransition = new FillTransition(Duration.seconds(1.0), loaderPageIcon, Color.WHITE, new Color(242 / 255, 43 / 255, 26 / 255, 1));

        fillTransition.setAutoReverse(true);
        fillTransition.setCycleCount(Transition.INDEFINITE);

//        fillTransition.play();
//        loaderPageIcon.setFill(Paint.valueOf("#ef4537"));
        loadingLabel.setText("CARREGANDO");

        reticenciasTimer = new Timer();
        TimerTask reticenciasTimerTask = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    if (loadingLabel.getText().endsWith("CARREGANDO")) {
                        loadingLabel.setText("CARREGANDO.");
                    } else if (loadingLabel.getText().endsWith("CARREGANDO.")) {
                        loadingLabel.setText("CARREGANDO..");
                    } else if (loadingLabel.getText().endsWith("CARREGANDO..")) {
                        loadingLabel.setText("CARREGANDO...");
                    } else if (loadingLabel.getText().endsWith("CARREGANDO...")) {
                        loadingLabel.setText("CARREGANDO");
                    }
                });

            }
        };
        reticenciasTimer.scheduleAtFixedRate(reticenciasTimerTask, 0, 700);

        outputs = new ArrayList<>();

    }

    public double getLoadersMaxWidth() {
        loadersMaxWidth = getPrefWidth() * 0.7;
        return loadersMaxWidth;
    }

    public Pane getReceitasLoader() {
        return receitasLoader;
    }

    public Label getMsgL1() {
        return msgL1;
    }

    public Pane getTipoComidaLoader() {
        return tipoComidaLoader;
    }

    public Label getMsgL2() {
        return msgL2;
    }

    public Pane getTipoBebidaLoader() {
        return tipoBebidaLoader;
    }

    public Label getMsgL3() {
        return msgL3;
    }

    public Pane getTipoCaloriaLoader() {
        return tipoCaloriaLoader;
    }

    public Label getMsgL4() {
        return msgL4;
    }

    public Pane getReceitasLoaderCmp() {
        return receitasLoaderCmp;
    }

    public Pane getTipoComidaLoaderCmp() {
        return tipoComidaLoaderCmp;
    }

    public Pane getTipoBebidaLoaderCmp() {
        return tipoBebidaLoaderCmp;
    }

    public Pane getTipoCaloriaLoaderCmp() {
        return tipoCaloriaLoaderCmp;
    }

    double elementsHeight = -1;

    public double getElementsHeight() {

        //for calculate only once
        if (elementsHeight < 0) {

            elementsHeight = 0;

            if (!singleLoader) {
                elementsHeight += receitasLoaderCmp.getHeight();
                elementsHeight += spacing;
                elementsHeight += tipoComidaLoaderCmp.getHeight();
                elementsHeight += spacing;
                elementsHeight += tipoBebidaLoaderCmp.getHeight();
                elementsHeight += spacing;
                elementsHeight += tipoCaloriaLoader.getHeight();
            } else {
                elementsHeight += receitasLoaderCmp.getHeight();
            }
        }

        return elementsHeight;
    }

    public void doHeightAdjust() {
        double layoutY = (getPrefHeight() - getElementsHeight()) / 2 + 20;
        receitasLoaderCmp.setLayoutY(layoutY);
        tipoComidaLoaderCmp.setLayoutY(layoutY + receitasLoaderCmp.getHeight() + spacing);
        tipoBebidaLoaderCmp.setLayoutY(tipoComidaLoaderCmp.getLayoutY() + tipoComidaLoaderCmp.getHeight() + spacing);
        tipoCaloriaLoaderCmp.setLayoutY(tipoBebidaLoaderCmp.getLayoutY() + tipoBebidaLoaderCmp.getHeight() + spacing);
    }

    public void doWidthAdjust() {
        double spacingLocal = (getPrefWidth() - getLoadersMaxWidth()) / 2 - receitasLoader.getLayoutX();
        receitasLoaderCmp.setLayoutX(spacingLocal);
        tipoComidaLoaderCmp.setLayoutX(spacingLocal);
        tipoBebidaLoaderCmp.setLayoutX(spacingLocal);
        tipoCaloriaLoaderCmp.setLayoutX(spacingLocal);
    }

    private double getSpacing() {

        double spacing = 0;
        double current = 0;

        //finds the biggest spacing
        current = tipoComidaLoaderCmp.getLayoutY() - (receitasLoaderCmp.getLayoutY() + receitasLoaderCmp.getHeight());
        if (spacing < current) {
            spacing = current;
        }

        current = tipoBebidaLoaderCmp.getLayoutY() - (tipoComidaLoaderCmp.getLayoutY() + tipoComidaLoaderCmp.getHeight());
        if (spacing < current) {
            spacing = current;
        }

        current = tipoCaloriaLoaderCmp.getLayoutY() - (tipoBebidaLoaderCmp.getLayoutY() + tipoBebidaLoaderCmp.getHeight());
        if (spacing < current) {
            spacing = current;
        }

        return spacing;
    }

    public void setUp() {

        Platform.runLater(() -> {
            setReceitaLoaderValue(0, Util.PROPERTIES.getProperty("loaderPageInitMsg"));
            setTipoComidaLoaderValue(0, Util.PROPERTIES.getProperty("loaderPageInitMsg"));
            setTipoBebidaLoaderValue(0, Util.PROPERTIES.getProperty("loaderPageInitMsg"));
            setTipoCaloriaLoaderValue(0, Util.PROPERTIES.getProperty("loaderPageInitMsg"));
        });

    }

    volatile private double currentValue;
    volatile private AtomicInteger lazyLoadersCount = new AtomicInteger(0);

    private double receitasLoaderCurrentValue;
    private double tiposComidaLoaderCurrentValue;
    private double tiposBebidaLoaderCurrentValue;
    private double tiposCaloriasLoaderCurrentValue;

    private synchronized void applyNewValue(Label target, double newValue, Pane loader, String message) {

        if (newValue >= 0 && newValue <= 1) {

            setLoaderValue(newValue, loader);

            setLoaderMessage(newValue, target, message);

            setLoaderStyle(newValue, loader, target, message);

            updateOutputs();

        } else if (newValue == NOTHING_TO_LOAD) {

            setNothingToLoad(loader, target);

        }
    }

    private void setNothingToLoad(Pane loader, Label target) {
        lazyLoadersCount.addAndGet(1);

        switch (loader.getId()) {
            case "receitasLoader":
                receitasLoaded = true;
                if (!singleLoader) {
                    setNothingToLoadMessage(Util.PROPERTIES.getProperty("loader1NothingToLoadMsg"), target, loader);
                }
                break;
            case "tipoComidaLoader":
                tipoComidaLoaded = true;
                if (!singleLoader) {
                    setNothingToLoadMessage(Util.PROPERTIES.getProperty("loader2NothingToLoadMsg"), target, loader);
                }
                break;
            case "tipoBebidaLoader":
                tipoBebidaLoaded = true;
                if (!singleLoader) {
                    setNothingToLoadMessage(Util.PROPERTIES.getProperty("loader3NothingToLoadMsg"), target, loader);
                }
                break;
            case "tipoCaloriaLoader":
                tipoCaloriaLoaded = true;
                if (!singleLoader) {
                    setNothingToLoadMessage(Util.PROPERTIES.getProperty("loader4NothingToLoadMsg"), target, loader);
                }
                break;
            default:
                break;
        }

        if (isLoaded()) {
            doLoadingDone();
        }
    }

    private void setLoaderStyle(double newValue, Pane loader, Label target, String message) {

        if (!singleLoader) {

            handleNOTSingleLoaderStyle(newValue, loader, target, message);

        } else {

            handleSingleLoaderStyle(newValue, loader, message);

        }

    }

    private void handleNOTSingleLoaderStyle(double newValue, Pane loader, Label target, String message) {
        if (newValue == 1) {
            loader.setStyle("-fx-background-color: #00ff26;-fx-background-radius:4;-fx-cursor:default");
            switch (loader.getId()) {
                case "receitasLoader":
                    receitasLoaded = true;
                    target.setText(message + " " + Util.PROPERTIES.getProperty("loader1LoadedMsg"));
                    break;
                case "tipoComidaLoader":
                    tipoComidaLoaded = true;
                    target.setText(message + " " + Util.PROPERTIES.getProperty("loader2LoadedMsg"));
                    break;
                case "tipoBebidaLoader":
                    tipoBebidaLoaded = true;
                    target.setText(message + " " + Util.PROPERTIES.getProperty("loader3LoadedMsg"));
                    break;
                case "tipoCaloriaLoader":
                    tipoCaloriaLoaded = true;
                    target.setText(message + " " + Util.PROPERTIES.getProperty("loader4LoadedMsg"));
                    break;
                default:
                    break;
            }
            if (isLoaded()) {
                doLoadingDone();
            }
        } else if (newValue == 0) {
            Platform.runLater(() -> {
                loader.setStyle("-fx-background-color:  #595959;-fx-background-radius:4;-fx-cursor:close_hand");
                loader.setPrefWidth(getLoadersMaxWidth());
            });
        } else {
            Platform.runLater(() -> {
                loader.setStyle("-fx-background-color: #ff1500;-fx-background-radius:4;-fx-cursor:wait");
            });
        }
    }

    private void handleSingleLoaderStyle(double newValue, Pane loader, String message) {
        newValue = (newValue / (getLoadersCount() - lazyLoadersCount.get()));
        if (newValue == 1.0 / (getLoadersCount() - lazyLoadersCount.get())) {
            if (isLoaded()) {
                receitasLoader.setStyle("-fx-background-color: #00ff26;-fx-background-radius:4;-fx-cursor:default");
            }
            switch (loader.getId()) {
                case "receitasLoader":
                    receitasLoaded = true;
//                    msgL1.setText(message + " " + Util.PROPERTIES.getProperty("single.loader.loaded.msg"));
                    break;
                case "tipoComidaLoader":
                    tipoComidaLoaded = true;
//                    msgL1.setText(message + " " + Util.PROPERTIES.getProperty("loader1LoadedMsg"));
                    break;
                case "tipoBebidaLoader":
                    tipoBebidaLoaded = true;
//                    msgL1.setText(message + " " + Util.PROPERTIES.getProperty("loader1LoadedMsg"));
                    break;
                case "tipoCaloriaLoader":
                    tipoCaloriaLoaded = true;
//                    msgL1.setText(message + " " + Util.PROPERTIES.getProperty("loader1LoadedMsg"));
                    break;
                default:
                    break;
            }
            if (isLoaded()) {
                doLoadingDone();
            }
        } else if (newValue == 0) {
            Platform.runLater(() -> {
                loader.setStyle("-fx-background-color:  #595959;-fx-background-radius:4;-fx-cursor:close_hand");
                loader.setPrefWidth(getLoadersMaxWidth());
            });
        } else {
            Platform.runLater(() -> {
                receitasLoader.setStyle("-fx-background-color: #ff1500;-fx-background-radius:4;-fx-cursor:wait");
            });

        }
    }

    private void setLoaderMessage(double newValue, Label target, String message) {
        if (!singleLoader) {

            String pristineText = getPristineText(target.getText());
            target.setText(pristineText + message);

        } else {

            newValue = (newValue / (getLoadersCount() - lazyLoadersCount.get()));

            String pristineText = getPristineText(msgL1.getText());
            if (!isPartialLoaded(newValue)) {
                msgL1.setText(pristineText + message);
            } else {
                msgL1.setText(Util.PROPERTIES.getProperty("single.loader.not.loaded.msg"));
                if (!pristineText.equals(Util.PROPERTIES.getProperty("splash.single.loader.pristine.msg"))) {
                }
            }
        }
    }

    private boolean isPartialLoaded(double newValue) {
        return newValue == (1.0 / (getLoadersCount() - lazyLoadersCount.get()));
    }

    private void setLoaderValue(double newValue, Pane loader) {
        if (!singleLoader) {

            currentValue = newValue;
            loader.setPrefWidth(getLoadersMaxWidth() * newValue);
            ON_UPDATE.setValue(newValue);

        } else {

            newValue = (newValue / (getLoadersCount() - lazyLoadersCount.get()));

            switch (loader.getId()) {
                case "receitasLoader":

                    setCurrentValue(getCurrentValue() + (newValue - receitasLoaderCurrentValue));
                    receitasLoaderCurrentValue = newValue;
                    break;

                case "tipoComidaLoader":

                    setCurrentValue(getCurrentValue() + (newValue - tiposComidaLoaderCurrentValue));
                    tiposComidaLoaderCurrentValue = newValue;
                    break;

                case "tipoBebidaLoader":

                    setCurrentValue(getCurrentValue() + (newValue - tiposBebidaLoaderCurrentValue));
                    tiposBebidaLoaderCurrentValue = newValue;
                    break;

                case "tipoCaloriaLoader":

                    setCurrentValue(getCurrentValue() + (newValue - tiposCaloriasLoaderCurrentValue));
                    tiposCaloriasLoaderCurrentValue = newValue;
                    break;

                default:
                    break;
            }

            receitasLoader.setPrefWidth(getLoadersMaxWidth() * getCurrentValue());
            ON_UPDATE.setValue(getCurrentValue());
        }
    }

    private void setNothingToLoadMessage(String message, Label target, Pane loader) {
        Platform.runLater(() -> {
            target.setText(message);
            loader.setStyle("-fx-background-color:  #595959;-fx-background-radius:4");
            loader.setPrefWidth(getLoadersMaxWidth());
        });
    }

    public void setReceitaLoaderValue(double newValue, String message) {
        applyNewValue(msgL1, newValue, receitasLoader, message);
    }

    public void setTipoComidaLoaderValue(double newValue, String message) {
        applyNewValue(msgL2, newValue, tipoComidaLoader, message);
    }

    public void setTipoBebidaLoaderValue(double newValue, String message) {
        applyNewValue(msgL3, newValue, tipoBebidaLoader, message);
    }

    public void setTipoCaloriaLoaderValue(double newValue, String message) {
        applyNewValue(msgL4, newValue, tipoCaloriaLoader, message);
    }

    public boolean isLoaded() {

        loaded = receitasLoaded && tipoComidaLoaded & tipoBebidaLoaded && tipoCaloriaLoaded;

        return loaded;
    }

    private void doLoadingDone() {
        reticenciasTimer.cancel();
        Platform.runLater(() -> {
            if (container.getListaDeReceitas().size() != 0) {
                loadingLabel.setText(Util.PROPERTIES.getProperty("loader.loaded.msg"));
                if (isSingleLoader()) {
                    msgL1.setText(Util.PROPERTIES.getProperty("single.loader.loaded.msg"));
                }
            } else {
                loadingLabel.setText(Util.PROPERTIES.getProperty("loader.data.loaded.msg"));
                if (isSingleLoader()) {
                    msgL1.setText(Util.PROPERTIES.getProperty("single.loader.data.loaded.msg"));
                }
            }
            fillTransition.stop();
            loaderPageIcon.setFill(Paint.valueOf("#00ff26"));
        });
    }

    public void setReceitasLoaded(boolean receitasLoaded) {
        this.receitasLoaded = receitasLoaded;
    }

    public void setTipoBebidaLoaded(boolean tipoBebidaLoaded) {
        this.tipoBebidaLoaded = tipoBebidaLoaded;
    }

    public void setTipoCaloriaLoaded(boolean tipoCaloriaLoaded) {
        this.tipoCaloriaLoaded = tipoCaloriaLoaded;
    }

    public void setTipoComidaLoaded(boolean tipoComidaLoaded) {
        this.tipoComidaLoaded = tipoComidaLoaded;
    }

    public void load(Runnable... loadingTasks) {

        for (Runnable loadingTask : loadingTasks) {
            new Thread(loadingTask).start();
        }

    }

    /**
     * Lógica para recuperar textos originais como CARREGANDO RECEITAS ou
     * CARREGANDO TIPOS DE COMIDAS.
     * <br> FORMALMENTE : getPristineText("CARREGANDO RECEITAS 0/0 ...") =
     * CARREGANDO RECEITAS
     * <br>FORMALMENTE : getPristineText("CARREGANDO RECEITAS 2/1000") =
     * CARREGANDO RECEITAS
     * <br>FORMALMENTE : getPristineText("CARREGANDO RECEITAS MAIS QUALQUER
     * PALAVRA OU PALAVRAS") = CARREGANDO RECEITAS
     *
     * @param text the text
     * @return
     */
    private String getPristineText(String text) {

        int j = 0;
        if (text.endsWith("...")) {
            String elipsesOut = text.substring(0, text.length() - 3);
            text = elipsesOut;
        }
        String[] splits = text.split(" ");
        if (text.contains("/")) {
            j = splits.length - 1;
        } else {
            j = splits.length;
        }

        String pristineText = "";
        for (int i = 0; i < j; i++) {
            pristineText += splits[i];
            pristineText += " ";
        }

        return pristineText;
    }

    public synchronized double getCurrentValue() {
        return currentValue;
    }

    public synchronized void setCurrentValue(double newValue) {
        currentValue = newValue;
    }

    public boolean isSingleLoader() {
        return singleLoader;
    }

    public AtomicInteger getLazyLoadersCount() {
        return lazyLoadersCount;
    }

    public int getLoadersCount() {
        return 4;
    }

    public DoubleProperty ON_UPDATE() {
        return ON_UPDATE;
    }

    public void setSingleLoaderPristineMessage(String msg) {
        msgL1.setText(msg);
    }

    public String getSingleLoaderMessage() {
        return msgL1.getText();
    }

    public void addOutPut(Output o) {
        outputs.add(o);
    }

    private int getLoadingDonePercentage() {
        int percent = 0;

        if (singleLoader) {

        }

        return percent;
    }

    private void updateOutputs() {
        String msg = Util.PROPERTIES.getProperty("splash.single.loader.pristine.msg");
        outputs.forEach((o) -> {
            if (o instanceof Splash) {
                if (singleLoader) {
                    int percent = ((int) (getCurrentValue() * 100));
                    try {
//                        o.write(getCurrentValue(), msg + " " + percent + "%");
                        o.write(getCurrentValue(), msg);
                    } catch (Exception ex) {
                        Logger.getLogger(LoaderPage.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
    }

}
