package br.com.undra.livrodereceitas.paginas.tiporeceita;

import java.util.Objects;

/**
 * Uma abstração para api TipoComida, TipoBedida e TipoCaloria.
 * @author alexandre
 */
abstract public class TipoReceita implements Comparable<TipoReceita>{
    
    abstract public String getNome();
    abstract public void setNome(String nome);

    @Override
    public int compareTo(TipoReceita o) {
        return this.getNome().compareTo(o.getNome());
    }

    @Override
    public boolean equals(Object obj) {
        
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TipoReceita other = (TipoReceita) obj;
        if (!Objects.equals(this.getNome(), other.getNome())) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.getNome());
        return hash;
    }
    
}
