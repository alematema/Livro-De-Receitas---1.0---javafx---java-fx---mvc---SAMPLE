package br.com.undra.livrodereceitas.paginas.tiporeceita;

/**
 * Modela um tipo de bebida, como por exemplo:
 * <br> POUCO CALORICA,CALORICA,MUITO CALORICA,ETC.
 * @author alexandre
 */
public class TipoCaloria extends TipoReceita{
    
    public static TipoCaloria ZERO_CALORIA = new TipoCaloria("0  ZERO CALORIA");
    public static TipoCaloria CALORICA = new TipoCaloria("2  CALÓRICA");
    public static TipoCaloria POUCO_CALORIA = new TipoCaloria("1  POUCO CALORIA");
    public static TipoCaloria MUITO_CALÓRICA = new TipoCaloria("4  MUITO CALÓRICA");
    public static TipoCaloria HIPER_CALÓRICA = new TipoCaloria("5  HIPER CALÓRICA");
    
    private String nome;
    
    public TipoCaloria() {
    }

    public TipoCaloria(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return  "TIPO CALORIA - "+nome; //To change body of generated methods, choose Tools | Templates.
    }
    
}
