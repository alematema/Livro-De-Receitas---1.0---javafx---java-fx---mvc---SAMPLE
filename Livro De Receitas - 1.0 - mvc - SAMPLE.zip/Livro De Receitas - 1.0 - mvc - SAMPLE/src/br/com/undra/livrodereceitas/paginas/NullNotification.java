package br.com.undra.livrodereceitas.paginas;

import com.jfoenix.controls.JFXButton;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.util.Collection;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;

/**
 *
 * @author alexandre
 */
public class NullNotification extends Notification{
    
    public NullNotification(Label title, MaterialDesignIconView iconTitle, Collection<JFXButton> commands, Label message, EventHandler defCancelBtnHandler, EventHandler defOkBtnHandler, EventHandler<ActionEvent> defCancelActionBtnHandler, EventHandler<ActionEvent> defOkActionBtnHandler,String style) {
        super(title, iconTitle, commands, message, defCancelBtnHandler, defOkBtnHandler,defCancelActionBtnHandler,defOkActionBtnHandler,style);
    }
    
}
