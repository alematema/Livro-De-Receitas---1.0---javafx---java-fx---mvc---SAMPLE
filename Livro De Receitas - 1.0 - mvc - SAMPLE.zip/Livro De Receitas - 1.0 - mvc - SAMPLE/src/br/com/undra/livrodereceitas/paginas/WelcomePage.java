package br.com.undra.livrodereceitas.paginas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.menus.Menu;
import br.com.undra.livrodereceitas.pagenavigator.PageNavigator;
import br.com.undra.livrodereceitas.services.persistence.PersistenceService;
import br.com.undra.livrodereceitas.services.persistence.PersistenceServiceImpl_JDBC_SQLITE;
import br.com.undra.livrodereceitas.util.Fonts;
import br.com.undra.livrodereceitas.util.Helper;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 * A welcome page.
 *
 * @author alexandre
 */
public class WelcomePage extends Page {

    public static String MOSTRAR_NA_INICIALIZACAO = "MOSTRAR_NA_INICIALIZACAO";
    public static String NAO_MOSTRAR_NA_INICIALIZACAO = "NAO_MOSTRAR_NA_INICIALIZACAO";
    public static String MOSTRAR_WELCOME_PRONOUM_CHOOSER_NA_INICIALIZACAO = "MOSTRAR_WELCOME_PRONOUM_CHOOSER_NA_INICIALIZACAO";
    public static String NAO_MOSTRAR_WELCOME_PRONOUM_CHOOSER_NA_INICIALIZACAO = "NAO_MOSTRAR_WELCOME_PRONOUM_CHOOSER_NA_INICIALIZACAO";
    public static String BEM_VINDA = "Bem vinda";
    public static String BEM_VINDO = "Bem vindo";

    volatile private boolean mostrarNaInicializacao;
    volatile private boolean mostrarTrocadorDePronomeNaInicializacao;

    private Timer showTrocadorPronomeTimer;
    private Timer hideTrocadorPronomeTimer;

    private final PersistenceService persistenceService;

    private Menu menu;
    public double menuOriginalLayOutY;

    private AppContainer appContainer;

    @FXML
    private Pane welcomePageContainer;

    @FXML
    private MaterialDesignIconView menuAppIcon;

    @FXML
    private Text welcomeTitle;

    @FXML
    private JFXButton okWelcomeButton;

    @FXML
    private Text textP1;

    @FXML
    private Text textP1l2;

    @FXML
    private Pane mostraNaInicializacaoContainer;

    @FXML
    private JFXCheckBox checkMostrarInit;

    @FXML
    private Text txtP2;

    @FXML
    private MaterialDesignIconView scrollableListAddItemIconContainer;

    @FXML
    private Text txtP2_1;

    @FXML
    private Text txtP2l2;

    @FXML
    private Text txtP2l3;

    @FXML
    private Text txtP3;

    @FXML
    private Text menuLink;

    @FXML
    private Text txtBomApetite;

    @FXML
    private ImageView bookIcon;

    @FXML
    private Text welcomePronoum;

    @FXML
    private Pane welcomePronoumControlOuterContainer;

    @FXML
    private MaterialIconView contextMenuPointer;

    @FXML
    private Pane welcomePronoumControlContainer;

    @FXML
    private Text vocePodeTrocarPronomeText;

    @FXML
    private JFXButton closeWelcomePronoumContainer;

    @FXML
    private JFXButton changeWelcomePronoumButton;

    @FXML
    private JFXCheckBox checkMostrarInitBemVindo;

    @FXML
    private Text developer;

    private Tooltip vocePodeTrocarPronomeToolTip = new Tooltip(BEM_VINDA);
    private Tooltip restaurarWelcomePageToolTip = new Tooltip(Util.PROPERTIES.getProperty("restaurar.welcome.page.tool.tip"));

    Font toolTipsFont = Font.font(12);

    private NotificationPage notificationPage;

    private volatile static Page lastPage;

    private final ListChangeListener childrenChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {
            while (change.next()) {

                if (change.wasAdded()) {
                    for (Object o : change.getAddedSubList()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = (NotificationPage) o;
                        }
                    }
                }

                if (change.wasRemoved()) {
                    for (Object o : change.getRemoved()) {
                        if (o instanceof NotificationPage) {
                            notificationPage = null;
                        }
                    }
                }
            }
        }
    };

    /**
     * Usado para ajuda contextualizada
     *
     * @see br.com.undra.livrodereceitas.util.Helper
     */
    EventHandler<? super Event> onMouseMoveHandler;

    /**
     * A welcome page.
     *
     * @author alexandre
     */
    public WelcomePage() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLWelcomePage.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        persistenceService = PersistenceServiceImpl_JDBC_SQLITE.getInstace();
        vocePodeTrocarPronomeToolTip.setFont(toolTipsFont);
        restaurarWelcomePageToolTip.setFont(toolTipsFont);
        checkMostrarInit.setTooltip(restaurarWelcomePageToolTip);

        getChildren().addListener(childrenChangedListener);

        textP1.setFont(Fonts.APP_FONT);
        textP1l2.setFont(Fonts.APP_FONT);
        txtP2.setFont(Fonts.APP_FONT);
        txtP2_1.setFont(Fonts.APP_FONT);
        txtP2l2.setFont(Fonts.APP_FONT);
        txtP2l3.setFont(Fonts.APP_FONT);
        txtP3.setFont(Fonts.APP_FONT);
        txtBomApetite.setFont(Fonts.APP_FONT);
        menuLink.setFont(Fonts.APP_FONT);
        welcomePronoum.setFont(Fonts.APP_FONT_MEDIUM);
        welcomeTitle.setFont(Fonts.APP_FONT_MEDIUM);
    }

    /**
     * A welcome page.
     *
     * @author alexandre
     * @param appContainer
     */
    public WelcomePage(AppContainer appContainer) {
        this();

        getStylesheets().add(getClass().getResource("/resources/css/glass-theme_squared.css").toExternalForm());
        this.appContainer = appContainer;

        menu = Menu.getInstance(appContainer);
        menu.setVisible(false);

        //getChildren().add(menu);
        setMostrarNaInicializacao();

        
        
        /**
         * Usado para ajuda contextualizada
         *
         * @see br.com.undra.livrodereceitas.util.Helper
         */
        onMouseMoveHandler = Helper.getMouseEventIdentifiedHandler(appContainer,this);
        setOnMouseMoved(onMouseMoveHandler);
        welcomePronoumControlContainer.setOnMouseMoved(onMouseMoveHandler);
        welcomePronoum.setOnMouseMoved(onMouseMoveHandler);

        welcomeTitle.setText(String.format(" ao %s", Util.PROPERTIES.getProperty("title")));

        developer.setText(Util.getDeveloperAndContact());

    }

    ChangeListener<Number> widthChangeListener;
    ChangeListener<Number> heightChangeListener;

    @Override
    public void setUp(FullVerticalScrollableListWrapperImpl verticalFullScroller) {

        prefWidthProperty().bind(getScene().widthProperty().subtract(verticalFullScroller.widthProperty()));
        prefHeightProperty().bind(getScene().heightProperty());

        okWelcomeButton.setLayoutY(getPrefHeight() - okWelcomeButton.getPrefHeight() - 20);
        okWelcomeButton.setLayoutX(getPrefWidth() - okWelcomeButton.getPrefWidth() - 20);
        mostraNaInicializacaoContainer.setLayoutY(getPrefHeight() - 80);
        mostraNaInicializacaoContainer.setLayoutX(90);

        developer.setLayoutY(getPrefHeight() - 10);

        menuAppIcon.setLayoutX(getWidth() - Double.parseDouble(menuAppIcon.getSize()) - 10);
        menu.setLayoutX(menuAppIcon.getLayoutX() - menu.getPrefWidth() + 10);

        menuAppIcon.setLayoutY(Double.parseDouble(menuAppIcon.getSize()) + 25);
        menu.setLayoutY(menuAppIcon.getLayoutY() + 5);

        try {
            heightProperty().removeListener(heightChangeListener);
        } catch (Exception e) {
        }
        heightChangeListener = (observable, oldValue, newValue) -> {

            menuAppIcon.setLayoutY(Double.parseDouble(menuAppIcon.getSize()) + 25);
            appContainer.ensureVisibility();
            menu.setLayoutY(menuAppIcon.getLayoutY() + 5);

            okWelcomeButton.setLayoutY(newValue.doubleValue() - okWelcomeButton.getPrefHeight() - 20);

            mostraNaInicializacaoContainer.setLayoutY(newValue.doubleValue() - 80);
            developer.setLayoutY(newValue.doubleValue() - 10);
        };
        heightProperty().addListener(heightChangeListener);

        try {
            widthProperty().removeListener(widthChangeListener);
        } catch (Exception e) {
        }

        widthChangeListener = (observable, oldValue, newValue) -> {

            setLayoutX(verticalFullScroller.getWidth());
            menuAppIcon.setLayoutX(getWidth() - Double.parseDouble(menuAppIcon.getSize()) - 10);
            menu.setLayoutX(menuAppIcon.getLayoutX() - menu.getPrefWidth() + 10);

            okWelcomeButton.setLayoutX(newValue.doubleValue() - okWelcomeButton.getPrefWidth() - 150);

            bookIcon.setLayoutX(newValue.doubleValue() / 22);
            welcomePronoum.setLayoutX(bookIcon.getLayoutX() + 120);
            welcomeTitle.setLayoutX(welcomePronoum.getLayoutX() + 185);
//            bookIcon.setLayoutX(newValue.doubleValue() / 11);
//            welcomeTitle.setLayoutX(bookIcon.getLayoutX() + 80);

            appContainer.ensureVisibility();
        };

        widthProperty().addListener(widthChangeListener);

        menuOriginalLayOutY = menuAppIcon.getLayoutY();

        if (!getChildren().contains(menu)) {
            getChildren().add(menu);
            Tooltip.install(menuAppIcon, menu.getMenuTooltip());
        }

        menu.setUp(this);

    }

    private void setMostrarNaInicializacao() {

        welcomePronoumControlOuterContainer.setVisible(false);

        try {
            if (!persistenceService.getShowWelcomePageAtInitialization()) {
                mostrarNaInicializacao = false;
                setVisible(false);
                checkMostrarInit.setSelected(false);
            } else {
                mostrarNaInicializacao = true;
                checkMostrarInit.setSelected(true);
            }

            setUpPronoumAndPronoumChooser();

            if (persistenceService.getShowPronoumChooserAtInitialization()) {
                mostrarTrocadorDePronomeNaInicializacao = true;
                checkMostrarInitBemVindo.setSelected(true);
                if (mostrarNaInicializacao) {
                    handleShowHideTrocadorPronome();
                }
            } else {
                mostrarTrocadorDePronomeNaInicializacao = false;
                welcomePronoumControlOuterContainer.setVisible(false);
                checkMostrarInitBemVindo.setSelected(false);
            }

        } catch (Exception ex) {
            Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void setUpPronoumAndPronoumChooser() throws Exception {
        if (persistenceService.getWelcomePronoum().equals(BEM_VINDA)) {
            welcomePronoum.setText(BEM_VINDA);
            vocePodeTrocarPronomeText.setText(Util.PROPERTIES.getProperty("voce.pode.trocar.pronome.para.bem.vindo"));
            Tooltip.uninstall(welcomePronoum, vocePodeTrocarPronomeToolTip);
            vocePodeTrocarPronomeToolTip.setText("Clique para trocar para " + BEM_VINDO.toUpperCase());
            Tooltip.install(welcomePronoum, vocePodeTrocarPronomeToolTip);
        } else {
            welcomePronoum.setText(BEM_VINDO);
            vocePodeTrocarPronomeText.setText(Util.PROPERTIES.getProperty("voce.pode.trocar.pronome.para.bem.vinda"));
            Tooltip.uninstall(welcomePronoum, vocePodeTrocarPronomeToolTip);
            vocePodeTrocarPronomeToolTip.setText("Clique para trocar para " + BEM_VINDA.toUpperCase());
            Tooltip.install(welcomePronoum, vocePodeTrocarPronomeToolTip);
        }

    }

    private void handleShowHideTrocadorPronome() {
        new Thread(() -> {

            while (!appContainer.loadingsDone()) {
            }

            cancelTimers();

            showTrocadorPronomeTimer = new Timer();
            TimerTask showTask = new TimerTask() {
                @Override
                public void run() {
                    Platform.runLater(() -> {
                        welcomePronoumControlOuterContainer.setVisible(true);
                    });
                }
            };
            int showAfter = 11500;
            showTrocadorPronomeTimer.schedule(showTask, showAfter);
            hideTrocadorPronomeTimer = new Timer();
            TimerTask hideTask = new TimerTask() {
                @Override
                public void run() {
                    Platform.runLater(() -> {
                        welcomePronoumControlOuterContainer.setVisible(false);
                        showTrocadorPronomeTimer.cancel();
                        hideTrocadorPronomeTimer.cancel();
                    });
                }
            };
            hideTrocadorPronomeTimer.schedule(hideTask, showAfter + 13500);

        }).start();
    }

    @Override
    public void closeMenu() {
        menu.setVisible(false);
    }

    @Override
    public NotificationPage getNotificationPage() {
        return notificationPage;
    }

    @FXML
    public void handleMenuMouseClicked(MouseEvent event) {
        menu.handleMouseClicked();
    }

    @FXML
    void handleOkWelcomeButtonMouseClicked(MouseEvent event) {

        if (lastPage == null) {
            PageNavigator.goToPageSmoothly(appContainer, appContainer.getNenhumaReceitaSelecionada());
        } else {
            PageNavigator.goToPageSmoothly(appContainer, lastPage);
        }
        appContainer.handleOpenningMessage();
    }

    @FXML
    void handleAddItemMouseClicked(MouseEvent event) {
        appContainer.getListaDeReceitas().getView().handleAddItemMouseClicked(null);
    }

    @FXML
    void handleMenuLinkClicked(MouseEvent event) {
        menu.handleMouseClicked();
    }

    @FXML
    void checkMostrarInitClicked(MouseEvent event) {

        try {
            if (persistenceService.getShowWelcomePageAtInitialization()) {
                persistenceService.updateShowWelcomePageAtInitialization(false);
                mostrarNaInicializacao = false;
            } else {
                persistenceService.updateShowWelcomePageAtInitialization(true);
                mostrarNaInicializacao = true;
            }
        } catch (Exception ex) {
            Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    void handleChangeWelcomePronoumMouseClicked(MouseEvent event) {

        try {
            if (persistenceService.getWelcomePronoum().equals(BEM_VINDA)) {
                persistenceService.updateWelcomePronoum(BEM_VINDO);
            } else {
                persistenceService.updateWelcomePronoum(BEM_VINDA);
            }

            new Thread(() -> {
                cancelTimers();
            }).start();
            setUpPronoumAndPronoumChooser();

        } catch (Exception ex) {
            Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void handleCloseWelcomePronoumContainerMouseClicked(MouseEvent event) {
        welcomePronoumControlOuterContainer.setVisible(false);
    }

    @FXML
    void handleOpenWelcomePronoumContainerMouseClicked(MouseEvent event) {
        welcomePronoumControlOuterContainer.setVisible(true);
    }

    @FXML
    void checkMostrarInitBemVindoClicked(MouseEvent event) {
        try {
            if (persistenceService.getShowPronoumChooserAtInitialization()) {
                persistenceService.updateShowPronoumChooserAtInitialization(false);
                mostrarTrocadorDePronomeNaInicializacao = false;
            } else {
                persistenceService.updateShowPronoumChooserAtInitialization(true);
                mostrarTrocadorDePronomeNaInicializacao = true;
            }
        } catch (Exception ex) {
            Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Menu getMenu() {
        return menu;
    }

    public boolean isMostrarNaInicializacao() {
        return mostrarNaInicializacao;
    }

    public boolean isMostrarTrocadorDePronomeNaInicializacao() {
        return mostrarTrocadorDePronomeNaInicializacao;
    }

    public void restaurar() {

        try {

            lastPage = appContainer.getCurrentPage();
            persistenceService.updateShowWelcomePageAtInitialization(true);
            persistenceService.updateShowPronoumChooserAtInitialization(true);
            persistenceService.updateWelcomePronoum(BEM_VINDA);
            Platform.runLater(() -> {
                setMostrarNaInicializacao();
                PageNavigator.goToPageSmoothly(appContainer, this);
            });
        } catch (Exception ex) {
            Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private synchronized void cancelTimers() {

        if (showTrocadorPronomeTimer != null) {
            showTrocadorPronomeTimer.cancel();
        }
        if (hideTrocadorPronomeTimer != null) {
            hideTrocadorPronomeTimer.cancel();
        }
    }

    /**
     * Before shutDown hook.
     */
    @Override
    public void beforeShutDown() {
        cancelTimers();
    }

    @Override
    public void disableMenuIcon() {
        try {
            menuAppIcon.setVisible(false);
            menuAppIcon.setDisable(true);
        } catch (Exception e) {
        }
    }

}
