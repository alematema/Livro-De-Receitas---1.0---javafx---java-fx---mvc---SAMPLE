package br.com.undra.livrodereceitas.paginas;

import com.jfoenix.controls.JFXButton;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.util.Collection;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;

/**
 *
 * @author alexandre
 */
public class Notification {
    
    private final Label title;
    private final MaterialDesignIconView iconTitle; 
    private final Collection<JFXButton> commands;
    private final Label message;
    private final EventHandler<? super Event> defCancelBtnHandler;
    private final EventHandler<? super Event> defOkBtnHandler;
    //FOR FIRE PROGRAMMATICALLY 
    private final EventHandler<ActionEvent> defCancelActionBtnHandler;
    private final EventHandler<ActionEvent> defOkActionBtnHandler;
    
    //Style
    private final String style;

    public Notification(Label title, MaterialDesignIconView iconTitle, Collection<JFXButton> commands, Label message, EventHandler<? super Event> defCancelBtnHandler, EventHandler<? super Event> defOkBtnHandler, EventHandler<ActionEvent> defCancelActionBtnHandler, EventHandler<ActionEvent> defOkActionBtnHandler, String style) {
        this.title = title;
        this.iconTitle = iconTitle;
        this.commands = commands;
        this.message = message;
        this.defCancelBtnHandler = defCancelBtnHandler;
        this.defOkBtnHandler = defOkBtnHandler;
        this.defCancelActionBtnHandler = defCancelActionBtnHandler;
        this.defOkActionBtnHandler = defOkActionBtnHandler;
        this.style = style;
    }

    
    public Label getTitle() {
        return title;
    }

    public MaterialDesignIconView getIconTitle() {
        return iconTitle;
    }

    public Collection<JFXButton> getCommands() {
        return commands;
    }

    public Label getMessage() {
        return message;
    }

    public EventHandler<? super Event> getDefCancelBtnHandler() {
        return defCancelBtnHandler;
    }

    public EventHandler<? super Event> getDefOkBtnHandler() {
        return defOkBtnHandler;
    }

    public EventHandler<ActionEvent> getDefCancelActionBtnHandler() {
        return defCancelActionBtnHandler;
    }

    public EventHandler<ActionEvent> getDefOkActionBtnHandler() {
        return defOkActionBtnHandler;
    }

    public String getStyle() {
        return style;
    }
    
}
