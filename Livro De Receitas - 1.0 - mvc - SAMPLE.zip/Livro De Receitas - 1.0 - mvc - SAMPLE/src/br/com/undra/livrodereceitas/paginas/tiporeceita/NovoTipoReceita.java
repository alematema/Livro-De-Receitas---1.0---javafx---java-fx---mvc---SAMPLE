package br.com.undra.livrodereceitas.paginas.tiporeceita;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.paginas.DetalhesReceita;
import br.com.undra.livrodereceitas.paginas.NovaReceita;
import br.com.undra.livrodereceitas.util.Notificator;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * Um modal para adicionar novos tipos de receita, como por exemplo:
 * <br> VEGETARIANA, PÃO, TORTA, CARNE, SALADA.
 *
 * @author alexandre
 */
public class NovoTipoReceita extends Pane {

    
    static public volatile boolean isVisible = false;
    
    @FXML
    private JFXButton salvarTipoReceita;

    @FXML
    private JFXButton cancelarSalvarTipoReceita;

    @FXML
    private Label tipoLabel;

    @FXML
    private Text developer;

    @FXML
    private JFXTextField nomeTipoTextField;

    private NovaReceita novaReceita;
    private DetalhesReceita detalhesReceita;
    private VerticalScrollableListWrapper controller;

    
    
    public NovoTipoReceita(NovaReceita novaReceita) {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLNovoTipoReceita.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        getStylesheets().add(getClass().getResource("/resources/css/novo-tipo-receita.css").toExternalForm());

        this.novaReceita = novaReceita;

        salvarTipoReceita.toFront();
        cancelarSalvarTipoReceita.toFront();

        setOnKeyPressed((e) -> {

            if (e.getCode().equals(KeyCode.ESCAPE)) {

                //CANCELA COM ESC NOVA TIPO RECEITA
                if (isVisible()) {
                    handlecancelarSalvarTipoReceitaMouseClicked(null);
                }

            } else if (e.getCode().equals(KeyCode.ENTER)) {

                //CONFIRMA SALVAR O NOVo TIPO RECEITA
                if (isVisible()) {
                    handleSalvarTipoReceitaMouseClicked(null);
                }
            }

        });

        developer.setText(Util.getDeveloperAndContact());

    }

    public NovoTipoReceita(DetalhesReceita detalhesReceita) {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLNovoTipoReceita.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        getStylesheets().add(getClass().getResource("/resources/css/novo-tipo-receita.css").toExternalForm());

        this.detalhesReceita = detalhesReceita;

        salvarTipoReceita.toFront();
        cancelarSalvarTipoReceita.toFront();

        setOnKeyPressed((e) -> {

            if (e.getCode().equals(KeyCode.ESCAPE)) {

                //CANCELA COM ESC NOVA TIPO RECEITA
                if (isVisible()) {
                    handlecancelarSalvarTipoReceitaMouseClicked(null);
                }

            } else if (e.getCode().equals(KeyCode.ENTER)) {

                //CONFIRMA SALVAR O NOVo TIPO RECEITA
                if (isVisible()) {
                    handleSalvarTipoReceitaMouseClicked(null);
                }

            }

        });

    }

    @FXML
    public void handleSalvarTipoReceitaMouseClicked(MouseEvent event) {

        Platform.runLater(() -> {

            if (nomeTipoTextField.getText().trim().equals("")) {
                try {
                    Notificator.notificateError(novaReceita.getAppContainer(), "ESCREVA ALGUM TIPO DE COMIDA NO CAMPO TEXTO :(", 2500);
                } catch (Exception e) {
                }
                try {
                    Notificator.notificateError(detalhesReceita.getAppContainer(), "ESCREVA ALGUM TIPO DE COMIDA NO CAMPO TEXTO :(", 2500);
                } catch (Exception e) {
                }
                setVisible(false);
                setVisible(true);
                return;
            }

            if (controller instanceof ListaTiposCalorias) {

                if (nomeTipoTextField.getText().contains("-")) {
                    try {
                        Notificator.notificateError(novaReceita.getAppContainer(), "NÃO É PERMITIDO O CARACTERE - NO NOME DO TIPO CALÓRICO", 2500);
                    } catch (Exception e) {
                    }
                    try {
                        Notificator.notificateError(detalhesReceita.getAppContainer(), "NÃO É PERMITIDO O CARACTERE - NO NOME DO TIPO CALÓRICO", 2500);
                    } catch (Exception e) {
                    }
                    setVisible(false);
                    setVisible(true);
                    return;
                }

            }

            controller.addAndSelect(nomeTipoTextField.getText());

        });
    }

    @FXML
    public void handlecancelarSalvarTipoReceitaMouseClicked(MouseEvent event) {

        Platform.runLater(() -> {
            cleanUp();
            setVisible(false);
            controller.ON_ADDITION().setValue(ScrollableListContainerSimple.ADDING_CANCELED);
            controller.getView().requestFocus();
        });

    }

    public JFXButton getSalvarTipoReceita() {
        return salvarTipoReceita;
    }

    public JFXButton getCancelarSalvarTipoReceita() {
        return cancelarSalvarTipoReceita;
    }

    public Label getTipoLabel() {
        return tipoLabel;
    }

    public JFXTextField getNomeTipoTextField() {
        return nomeTipoTextField;
    }

    public void cleanUp() {
        nomeTipoTextField.setText("");
    }

    public void setTitle(String message) {
        tipoLabel.setText(message);
    }

    public void setScroller(VerticalScrollableListWrapper controller) {
        developer.setLayoutY(getPrefHeight() - 15);
        this.controller = controller;
    }
    
    
}
