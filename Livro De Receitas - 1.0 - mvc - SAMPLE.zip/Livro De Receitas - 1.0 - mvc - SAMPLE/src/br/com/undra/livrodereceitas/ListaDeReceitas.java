package br.com.undra.livrodereceitas;

import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.FullVerticalScrollableListWrapperImpl;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.scrollablelist.util.Selector;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoBebida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoComida;
import br.com.undra.livrodereceitas.paginas.tiporeceita.TipoReceita;
import br.com.undra.livrodereceitas.util.Helper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;

/**
 * Modela a lista de receitas.
 *
 * @author alexandre
 */
public class ListaDeReceitas extends FullVerticalScrollableListWrapperImpl {

    private final AppContainer appContainer;

    private String currentAdding;
    private Receita receitaCurrentAdding;
    private Receita receitaCurrentOldEdited;
    private Receita receitaCurrentEdited;
    private Receita receitaCurrentImporting;

    private final Collection<Item> excludables = new ArrayList<>();
    private final Collection<Item> UNexcludables = new ArrayList<>();
    private Collection<Receita> bulkImporting;
    private Collection<Receita> bulkUnImporting;

    volatile private boolean hasBeenNotificatedOnDeletion = false;

    /**
     * Usado para ajuda contextualizada
     *
     * @see
     * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
     */
    EventHandler<? super Event> onMouseMoveIdentifiedHandler;

    public ListaDeReceitas(AppContainer appContainer) {
        this.appContainer = appContainer;
        /**
         * Usado para ajuda contextualizada
         *
         * @see
         * br.com.undra.livrodereceitas.util.Helper#setCurrentContext(javafx.scene.Node)
         */
        onMouseMoveIdentifiedHandler = Helper.getMouseEventIdentifiedHandler(appContainer, this);
        super.getEmptyListPage().getEmptyListLabel().setText(Util.getPROPERTIES(this).getProperty("mensagemListaVazia"));
        setOnMouseMoved(onMouseMoveIdentifiedHandler);
    }

    @Override
    public boolean isRemovingMultiselection() {
        return super.getView().isRemovingMultiselection();
    }

    @Override
    public void setIsRemovingMultiselection(boolean isRemovingMultiselection) {
        super.getView().setIsRemovingMultiselection(isRemovingMultiselection);
    }

    @Override
    public void setUpAfterImporting() {
        super.setUpAfterImporting();
        try {
            appContainer.reloadTiposReceitas();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
        }
    }

    @Override
    public boolean isRemovingMultiSelectionCanceled() {
        return super.getView().isRemovingMultiSelectionCanceled();
    }

    @Override
    public void setIsRemovingMultiSelectionCanceled(boolean isRemoveMultiSelectionCanceled) {
        super.getView().setIsRemovingMultiSelectionCanceled(isRemoveMultiSelectionCanceled);
    }

    @Override
    public void executeClientHookAdditionLogic() throws Exception {
        appContainer.save(receitaCurrentAdding);
    }

    @Override
    public void executeClientHookEditionLogic() throws Exception {
        appContainer.update(receitaCurrentOldEdited, receitaCurrentEdited);
    }

    @Override
    public void executeClientHookDeletionLogic() throws Exception {
        if (appContainer.canExecuteClientHookDeletionLogic(getCurrentRemoving().getDescricao())) {
            appContainer.delete(getCurrentRemoving().getDescricao());
        } else {
            throw new Exception("Não é permitido remover " + getCurrentRemoving().getDescricao());
        }
    }

    /**
     * Executa lógica de deleção.<br>
     * É a super classe responsável por habilitar a colecao bulk para GC.
     *
     * @param bulk
     * @throws Exception
     */
    @Override
    public void executeClientHookBulkDeletionLogic(Collection<Item> bulk) throws Exception {
        String[] ids = Util.toIds(bulk);
        appContainer.deleteByIds(ids);
        ids = null;
        if (appContainer.isPreEditing()) {
            Platform.runLater(() -> {
                appContainer.cancelPreEditing();
            });
        }
    }

    @Override
    public void executeClientHookBulkUnImportingLogic(Collection<Item> clean) throws Exception {
        appContainer.delete(bulkUnImporting);
        bulkUnImporting.clear();
    }

    @Override
    public void executeClientHookImportingLogic() throws Exception {
        appContainer.save(receitaCurrentImporting);
    }

    @Override
    public void executeClientHookExportingLogic() throws Exception {
        appContainer.exportSelected();
    }

    @Override
    public void executeClientHookPrintingLogic() throws Exception {
        appContainer.printSelected();
    }

    @Override
    public void executeClientHookBulkImportingLogic(Collection<Item> itens) throws Exception {
        //GARANTE OBJETOS TIPORECEITA NA BASE DE DADOS 
        //PARA QUE OS RELACIONAMENTOS ENTRE ELES E RECEITAS SEJAM CRIADOS.
        Collection<TipoReceita> tiposReceita = new TreeSet<>();
        bulkImporting.forEach((receita) -> {
            if (receita.getTipoCaloria() != null) {
                tiposReceita.add(receita.getTipoCaloria());
            }
            if (receita.getTiposComida() != null && !receita.getTiposComida().isEmpty()) {
                for (TipoComida tc : receita.getTiposComida()) {
                    tiposReceita.add(tc);
                }
            }
            if (receita.getTiposBebida() != null && !receita.getTiposBebida().isEmpty()) {
                for (TipoBebida tb : receita.getTiposBebida()) {
                    tiposReceita.add(tb);
                }
            }
        });

        Collection<TipoReceita> tiposReceitaMissing = new ArrayList<>();

        //GARANTE OBJETOS TIPORECEITA NA BASE DE DADOS 
        //PARA QUE OS RELACIONAMENTOS ENTRE ELES E RECEITAS SEJAM CRIADOS.
        tiposReceita.forEach((t) -> {
            try {
                //NAO HAVIA NA BASE TIPO RECEITA COM ESSE ID.
                if (appContainer.getTipoReceitaById(t.getClass(), t.getNome()) == null) {
                    tiposReceitaMissing.add(t);
                }
            } catch (Exception ex) {
                Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        tiposReceita.clear();

        //GARANTE OBJETOS TIPORECEITA NA BASE DE DADOS 
        //PARA QUE OS RELACIONAMENTOS ENTRE ELES E RECEITAS SEJAM CRIADOS.
        if (!tiposReceitaMissing.isEmpty()) {
            appContainer.createTiposReceita(tiposReceitaMissing);
        }

        tiposReceitaMissing.clear();

        appContainer.save(bulkImporting);
    }

    @Override
    public boolean canExecuteClientHookDeletionLogicAt(Item item) throws Exception {
        return appContainer.canExecuteClientHookDeletionLogic(item.getDescricao());
    }

    @Override
    public boolean hasBeenNotificatedOnDeletion() {
        return hasBeenNotificatedOnDeletion;
    }

    @Override
    public void setHasBeenNotificatedOnDeletion(boolean hasBeenNotificatedOnDeletion) {
        this.hasBeenNotificatedOnDeletion = hasBeenNotificatedOnDeletion;
    }

    public void add(Receita novaReceita) throws Exception {
        receitaCurrentAdding = novaReceita;
        currentAdding = novaReceita.getNome();
        super.add(novaReceita.getNome());
    }

    public void edit(Receita old, Receita neW) {
        receitaCurrentOldEdited = old;
        receitaCurrentEdited = neW;
        super.edit(old.getNome(), neW.getNome());
    }

    public Receita getReceitaCurrentEdited() {
        return receitaCurrentEdited;
    }

    public void importar(Receita receita) throws Exception {
        receitaCurrentImporting = receita;
        super.imporT(Item.newInstance(receita.getNome(), getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
    }

    public void importar(Collection<Receita> receitas) throws Exception {
        List<Item> itens = new ArrayList<>();
        try {
            receitas.stream().forEach((receita) -> {
                itens.add(Item.newInstance(receita.getNome(), getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
            });
            bulkImporting = receitas;
        } catch (Exception ex) {
            Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
        }

        super.imporT(itens);
    }

    public void desimportar(Receita receita) {
        super.unimport(Item.newInstance(receita.getNome(), getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
    }

    public void desimportar(Collection<Receita> receitas) throws Exception {
        List<Item> itens = new ArrayList<>();
        try {
            receitas.stream().forEach((receita) -> {
                itens.add(Item.newInstance(receita.getNome(), getView(), ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
            });
            bulkUnImporting = receitas;
        } catch (Exception ex) {
            Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
        }
        //A COLEÇAO DE ITENS É LIBERADA PARA GC NA SUPERCLASSE.
        super.unimport(itens);
    }

    List<String> names = new ArrayList<>();

    volatile private boolean unselectingDone = true;

    public void unselect() {
        new Thread(() -> {

            try {
                unselectingDone = false;
                if (getView().getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {
                    Platform.runLater(() -> {
                        if (appContainer.getDetalhesReceita().getCurrent() != null) {
                            unselect(appContainer.getDetalhesReceita().getCurrent().getNome());
                        }
                        unselectingDone = true;
                    });
                } else {
                    names.clear();
                    if (appContainer.getDetalhesReceita().getCurrent() != null) {
                        names.add(appContainer.getDetalhesReceita().getCurrent().getNome());
                    }
                    Platform.runLater(() -> {
                        unselectMulti(names);
                        unselectingDone = true;
                    });
                }
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
            }

        }).start();

    }

    public boolean isUnselectingDone() {
        return unselectingDone;
    }

    @Override
    public Collection<Item> getExcludables(Collection<Item> selection) {
        excludables.clear();

        selection.parallelStream().forEach((item) -> {
            try {
                if (canExecuteClientHookDeletionLogicAt(item)) {
                    excludables.add(item);
                }
            } catch (Exception ex) {
                Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        return excludables;
    }

    @Override
    public Collection<Item> getUNexcludables(Collection<Item> selection) {

        UNexcludables.clear();

        selection.parallelStream().forEach((item) -> {
            try {
                if (!canExecuteClientHookDeletionLogicAt(item)) {
                    UNexcludables.add(item);
                }
            } catch (Exception ex) {
                Logger.getLogger(ListaDeReceitas.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        return UNexcludables;
    }

    @Override
    public String getAppCurrentItemSelected() {

        String item = null;

        if (appContainer.isPreEditing() || appContainer.isEditing()) {
            item = appContainer.getDetalhesReceita().getCurrent().getNome();
        }

        return item;

    }

    @Override
    public void requestFocus() {
        super.getView().requestFocus();
    }

}
