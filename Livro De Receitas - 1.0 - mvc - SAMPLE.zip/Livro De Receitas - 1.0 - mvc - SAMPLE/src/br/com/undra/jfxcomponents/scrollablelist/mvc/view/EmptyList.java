package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.util.Util;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

/**
 * Um Empty List Mensagem
 *
 * @author alexandre
 */
public class EmptyList extends Pane {
    
    @FXML
    private MaterialDesignIconView emptyListIcon;

    @FXML
    private Label emptyListLabel;

    public EmptyList() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLEmptyList.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        
        emptyListLabel.setText(Util.PROPERTIES.getProperty("mensagemListaVazia"));
        emptyListIcon.setGlyphName("FLASK_EMPTY_OUTLINE");
        emptyListLabel.setPrefWidth(getPrefWidth()*0.33);
               
    }

    public MaterialDesignIconView getEmptyListIcon() {
        return emptyListIcon;
    }

    public Label getEmptyListLabel() {
        return emptyListLabel;
    }
    
}
