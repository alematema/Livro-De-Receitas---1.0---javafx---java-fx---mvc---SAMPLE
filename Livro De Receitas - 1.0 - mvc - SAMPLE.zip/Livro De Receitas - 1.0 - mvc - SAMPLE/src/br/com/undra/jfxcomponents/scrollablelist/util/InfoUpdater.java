package br.com.undra.jfxcomponents.scrollablelist.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerFull;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import javafx.scene.control.Tooltip;

/**
 * An info updater helper.<br>
 *
 * @author alexandre
 */
public class InfoUpdater {

    static public synchronized void updateAfterAddition(ScrollableListContainerSimple container, Item newItem) {

        //updates list label info
        updateListInfoLabelAfterAddition(container, newItem);

        //updates list tool tips spread over updateListInfoLabelAfterAddition(container, newItem)
    }

    static public synchronized void updateAfterDeletion(ScrollableListContainerSimple container, Item deletedItem) {

//        if(container.ON_DELETION().getValue().equals(REMOVING_MULTI_SELECTION)){
//            
//             //HA VARIOS OBJETOS SELECIONADOS
//            updateMultiSelectedItensInfo(container);
//            updateMultiSelectionItensTooltips(container);
//            
//            return;
//        }
        //updates list label info
        updateListSizeAfterDeletion(container, deletedItem);

        //updates list tool tips
        updateListSizeInfoTooltips(container);
    }

    static public synchronized void update(ScrollableListContainerSimple container) {

        if (container.getSelector().getSTATE().getValue().equals(Selector.NO_SELECTION)) {

            //ZERO OBJETO SELECIONADO
            updateListSizeInfo(container);
            updateListSizeInfoTooltips(container);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {

            //HA APENAS 1 OBJETO SELECIONADO
            updateSingleItemCheckInfo(container);
            updateSingleItemCheckedTooltips(container, container.getSelector().getCurrent());

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.MULTI_SELECTION)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SELECTED_ALL)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.INVERTED_SELECTION_READY)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        }

    }

    public static synchronized void updateAfterSelected(ScrollableListContainerSimple container, Item item) {

        if (container.getSelector().getSTATE().getValue().equals(Selector.NO_SELECTION)) {

            //ZERO OBJETO SELECIONADO
            updateListSizeInfo(container);
            updateListSizeInfoTooltips(container);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {

            //HA APENAS 1 OBJETO SELECIONADO
            updateSingleItemCheckInfo(container);
            updateSingleItemCheckedTooltips(container, item);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.MULTI_SELECTION)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SELECTED_ALL)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.INVERTED_SELECTION_READY)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        }

    }

    public static synchronized void updateAfterAllSelected(ScrollableListContainerSimple container) {

        updateMultiSelectedItensInfo(container);
        updateMultiSelectionItensTooltips(container);

    }

    public static synchronized void updateAfterAllUnSelected(ScrollableListContainerSimple container) {
        //ZERO OBJETO SELECIONADO
        updateListSizeInfo(container);
        updateListSizeInfoTooltips(container);

    }

    private static void updateListInfoLabelAfterAddition(ScrollableListContainerSimple container, Item newItem) {
        updateListInfo(container);
    }

    public static synchronized void updateAfterSearching(ScrollableListContainerSimple container) {
        InfoUpdater.updateListSizeInfo(container);
        updateListSizeInfoTooltips(container);
    }

    //NOT tool tips
    private static void updateListInfo(ScrollableListContainerSimple container) {
        if (container.getSelector().getSTATE().getValue().equals(Selector.NO_SELECTION)) {

            //ZERO OBJETO SELECIONADO
            updateListSizeInfo(container);
            updateListSizeInfoTooltips(container);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {

            //HA APENAS 1 OBJETO SELECIONADO
            updateSingleItemCheckInfo(container);
            updateSingleItemCheckedTooltips(container);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.MULTI_SELECTION)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        }
    }

    static public synchronized void updateListSizeInfo(ScrollableListContainerSimple container, String newValue) {
        container.getScrollableListInfoLabelContainer().setText(newValue);
        doInfoLabelAdjustments(container);
    }

    private static void updateListSizeInfo(ScrollableListContainerSimple container, Item newItem) {
        container.getScrollableListInfoLabelContainer()
                .setText(Integer.toString(getNewSize(container)));
        doInfoLabelAdjustments(container);
        if (getNewSize(container) != 0) {
            container.getScrollableListInfoIconContainer().setGlyphName("FORMAT_LIST_NUMBERS");
        } else {
            container.getScrollableListInfoIconContainer().setGlyphName("FLASK_EMPTY_OUTLINE");
        }
    }

    private static void updateListSizeInfo(ScrollableListContainerSimple container) {
        container.getScrollableListInfoLabelContainer()
                .setText(Integer.toString(getNewSize(container)));
        doInfoLabelAdjustments(container);
        if (getNewSize(container) != 0) {

            container.getScrollableListInfoIconContainer().setGlyphName("FORMAT_LIST_NUMBERS");
        } else {

            container.getScrollableListInfoIconContainer().setGlyphName("FLASK_EMPTY_OUTLINE");
        }
    }

    private static void updateListSizeAfterDeletion(ScrollableListContainerSimple container, Item deletedItem) {
        updateListSizeInfo(container, deletedItem);
    }

    private static int getNewSize(ScrollableListContainerSimple container) {
        return container.getTotalItensNaLista();
    }

    public static synchronized void doInfoLabelAdjustments(ScrollableListContainerSimple container) {

        int charCount = container.getScrollableListInfoLabelContainer().getText().length();
        double spacing = getSpacingByCharCount(charCount);
        if (charCount > 14) {
            container.getScrollableListInfoLabelContainer().setText("OVERFLOW-MAX-SIZE");
            spacing = 6.5 * 14;
        }

        container.getScrollableListInfoLabelContainer().setLayoutX(container.getHeader().getWidth() - 1.5 * spacing);
        int spacing2 = charCount == 0 ? 10 : 30;//para ajustar ambos icones quando nao houver nada para informar
        container.getScrollableListInfoIconContainer().setLayoutX(container.getScrollableListInfoLabelContainer().getLayoutX() - 0.8 * spacing2);

    }

    private static double getSpacingByCharCount(int charCount) {

        double spacing = 0;

        if (charCount == 0) {
            return 30;
        }
        if (charCount == 1) {
            return 10;
        }

        if (charCount <= 4) {
            spacing = 7 * charCount;
        } else if (charCount <= 9) {
            spacing = 5.5 * charCount;
        } else if (charCount <= 14) {
            spacing = 5.5 * charCount;
        }

        return spacing;

    }

    //SELECTION UPDATES
    private static void updateSingleItemCheckInfo(ScrollableListContainerSimple container) {
        try {
            updateSingleItemCheckInfo(container, container.getSelection().get(0));
        } catch (Exception e) {
            
        }
    }

    private static void updateSingleItemCheckInfo(ScrollableListContainerSimple container, Item item) {

        container.getScrollableListInfoIconContainer().setGlyphName("PLAYLIST_CHECK");

        int n = container.getIndexOf(item) + 1;
        String nSelected = "" + n;
        container.getScrollableListInfoLabelContainer().setText(nSelected);
        doInfoLabelAdjustments(container);

    }

    private static void updateMultiSelectedItensInfo(ScrollableListContainerSimple container) {
        container.getScrollableListInfoIconContainer().setGlyphName("PLAYLIST_CHECK");
        int n = container.getSelection().size();
        int m = getNewSize(container);
        String nDemSelection = n + "/" + m;
        container.getScrollableListInfoLabelContainer().setText(nDemSelection);
        doInfoLabelAdjustments(container);
    }
//TOOL TIPS UPDATES

    private static void updateListInfoToolTip(ScrollableListContainerSimple container, String newValue) {
        Tooltip.uninstall(container.getScrollableListInfoIconContainer(), container.getElementsListInfoToolTip());
        container.getElementsListInfoToolTip().setText(newValue);
        Tooltip.install(container.getScrollableListInfoIconContainer(), container.getElementsListInfoToolTip());
    }

    private static void updateListSizeInfoTooltips(ScrollableListContainerSimple container) {
        if (container.getVBox().getChildren().isEmpty()) {
            updateListInfoToolTip(container, Util.getPROPERTIES(container.getWrapper()).getProperty("mensagemListaVazia"));
        } else {
            updateListInfoToolTip(container, Util.getPROPERTIES(container.getWrapper()).getProperty("totalElementsToolTip") + Integer.toString(getNewSize(container)));
        }
    }

    private static void updateSingleItemCheckedTooltips(ScrollableListContainerSimple container) {
        updateListInfoToolTip(container, Integer.toString(getNewSize(container)) + "" + Util.getPROPERTIES(container.getWrapper()).getProperty("currentSelectedElementToolTip") + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("singleItemCheckedTooltips"));
    }

    private static void updateSingleItemCheckedTooltips(ScrollableListContainerSimple container, Item item) {
        updateListInfoToolTip(container, (container.getIndexOf(item) + 1) + "" + Util.getPROPERTIES(container.getWrapper()).getProperty("currentSelectedElementToolTip") + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("singleItemCheckedTooltips"));
    }

    private static void updateMultiSelectionItensTooltips(ScrollableListContainerSimple container) {
        updateListInfoToolTip(container, container.getSelection().size() + " DE " + Integer.toString(getNewSize(container)) + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("multiSelectionItensTooltips"));
    }

    public static void updateAfterBulkDeletion(ScrollableListContainerSimple aThis) {
        updateAfterDeletion(aThis, null);
    }

    public static void updateBeforeSearching(ScrollableListContainerSimple aThis) {

    }

    public static void updateAfterInvertSelection(ScrollableListContainerSimple container, Item item) {
        if (container.getSelector().getSTATE().getValue().equals(Selector.NO_SELECTION)) {

            //ZERO OBJETO SELECIONADO
            updateListSizeInfo(container);
            updateListSizeInfoTooltips(container);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SINGLE_SELECTION)) {

            //HA APENAS 1 OBJETO SELECIONADO
            updateSingleItemCheckInfo(container);
            updateSingleItemCheckedTooltips(container, item);

        } else if (container.getSelector().getSTATE().getValue().equals(Selector.MULTI_SELECTION)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.SELECTED_ALL)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        } else if (container.getSelector().getSTATE().getValue().equals(Selector.INVERTED_SELECTION_READY)) {

            //HA VARIOS OBJETOS SELECIONADOS
            updateMultiSelectedItensInfo(container);
            updateMultiSelectionItensTooltips(container);
        }
    }

}
