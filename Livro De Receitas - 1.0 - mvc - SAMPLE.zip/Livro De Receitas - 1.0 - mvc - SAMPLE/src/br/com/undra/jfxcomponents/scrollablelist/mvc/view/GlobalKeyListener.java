package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javafx.application.Platform;
import javafx.scene.Node;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

public class GlobalKeyListener implements NativeKeyListener {

    public volatile long now = System.currentTimeMillis();
    private final Node container;

    public GlobalKeyListener(Node container) {
        this.container = container;
    }

    private volatile boolean isCtrlKey = false;
    private volatile boolean isShiftKey = false;
    private volatile boolean isArrowDonw = false;
    private volatile boolean isArrowUp = false;

    @Override
    public void nativeKeyPressed(NativeKeyEvent e) {

        if (isSelectable(container)) {

            ScrollableListContainerSimple selectableContainer = (ScrollableListContainerSimple) container;

            if (selectableContainer.isFocused()) {

                if (e.getKeyCode() == NativeKeyEvent.VC_ESCAPE) {
                    handle_ESCAPE_KEY(selectableContainer, e);
                    return;
                }

                if (isCtrlKey && e.getKeyCode() == NativeKeyEvent.VC_A) {
                    handle_A_KEY(selectableContainer);
                    return;
                }

                //Para criar nova receita usando CTRL + N
                if (isCtrlKey && e.getKeyCode() == NativeKeyEvent.VC_N) {
                    handle_N_KEY(selectableContainer);
                    return;
                }
                //Para focar pesquisa  usando CTRL + F
                if (isCtrlKey && e.getKeyCode() == NativeKeyEvent.VC_F) {
                    handle_F_KEY();
                    return;
                }
                //Para abrir menu aparencia e pesquisa 
                if (isCtrlKey && e.getKeyCode() == NativeKeyEvent.VC_Q) {
                    handle_Q_KEY(selectableContainer);
                    return;
                }

                switch (e.getKeyCode()) {
                    case NativeKeyEvent.VC_CONTROL_R:
                        isCtrlKey = true;
                        break;
                    case NativeKeyEvent.VC_CONTROL_L:
                        isCtrlKey = true;
                        break;
                    case NativeKeyEvent.VC_SHIFT_R:
                        isShiftKey = true;
                        break;
                    case NativeKeyEvent.VC_SHIFT_L:
                        isShiftKey = true;
                        break;
                    case NativeKeyEvent.VC_DELETE:
                        selectableContainer.removeAllSelected();
                        break;
                    case NativeKeyEvent.VC_PAGE_DOWN:
                        Platform.runLater(() -> {
                            VScroller.handleScrolling(selectableContainer, 240);
                            selectableContainer.requestFocus();
                        });
                        break;
                    case NativeKeyEvent.VC_PAGE_UP:
                        Platform.runLater(() -> {
                            VScroller.handleScrolling(selectableContainer, -240);
                            selectableContainer.requestFocus();
                        });
                        break;
                    case NativeKeyEvent.VC_DOWN:
                        if (isShiftKey) {
                            handle_ARROW_DOWN_MULTI_SELECTION(selectableContainer);
                        } else {
                            handle_ARROW_DOWN(selectableContainer);
                        }
                        break;
                    case NativeKeyEvent.VC_UP:
                        if (isShiftKey) {
                            handle_ARROW_UP_MULTI_SELECTION(selectableContainer);
                        } else {
                            handle_ARROW_UP(selectableContainer);
                        }
                        break;
                    case NativeKeyEvent.VC_HOME:
                        Platform.runLater(() -> {
                            VScroller.home(selectableContainer);
                            selectableContainer.requestFocus();
                        });
                        break;
                    case NativeKeyEvent.VC_END:
                        Platform.runLater(() -> {
                            VScroller.end(selectableContainer);
                            selectableContainer.requestFocus();
                        });
                        break;
                    default:
                        break;
                }

            } else {
                switch (e.getKeyCode()) {

                    case NativeKeyEvent.VC_SHIFT_R:
                        isShiftKey = true;
                        break;
                    case NativeKeyEvent.VC_SHIFT_L:
                        isShiftKey = true;
                        break;

                    case NativeKeyEvent.VC_DOWN:

                        if (isShiftKey) {
                            handle_ARROW_DOWN_MULTI_SELECTION(selectableContainer);
                        } else {
                            handle_ARROW_DOWN(null);
                        }

                        break;
                    case NativeKeyEvent.VC_UP:

                        if (isShiftKey) {
                            handle_ARROW_UP_MULTI_SELECTION(selectableContainer);
                        } else {
                            handle_ARROW_UP(null);
                        }

                        break;

                    default:
                        break;
                }
            }

        }

    }

    /**
     * Scrolla lista para CIMA.
     *
     * @param selectableContainer
     */
    private void handle_ARROW_UP(ScrollableListContainerSimple selectableContainer) {
        if (selectableContainer != null) {
            Platform.runLater(() -> {
                VScroller.handleScrolling(selectableContainer, -VScroller.POSITIVE_DELTA_Y_MIN);
                selectableContainer.requestFocus();

            });
        }
        if (container instanceof ScrollableListContainerFull) {
            if (((ScrollableListContainerFull) container).getSearcherField().isFocused()) {
                Platform.runLater(() -> {
                    VScroller.handleScrolling(((ScrollableListContainerFull) container), -VScroller.POSITIVE_DELTA_Y_MIN);
                    ((ScrollableListContainerFull) container).requestFocus();
                });
            }
        }
    }

    /**
     * Scrolla lista para BAIXO.
     *
     * @param selectableContainer
     */
    private void handle_ARROW_DOWN(ScrollableListContainerSimple selectableContainer) {

        //when container is focused
        if (selectableContainer != null) {
            Platform.runLater(() -> {
                VScroller.handleScrolling(selectableContainer, VScroller.POSITIVE_DELTA_Y_MIN);
                selectableContainer.requestFocus();

            });
        }

        if (container instanceof ScrollableListContainerFull) {
            if (((ScrollableListContainerFull) container).getSearcherField().isFocused()) {
                Platform.runLater(() -> {
                    VScroller.handleScrolling(((ScrollableListContainerFull) container), VScroller.POSITIVE_DELTA_Y_MIN);
                    ((ScrollableListContainerFull) container).requestFocus();
                });
            }
        }
    }

    /**
     * Ctrl + F : focuses the searcher.
     */
    private void handle_F_KEY() {
        isCtrlKey = false;
        Platform.runLater(() -> {
            //
            if (container instanceof ScrollableListContainerFull) {
                ScrollableListContainerFull selectableFullContainer = (ScrollableListContainerFull) container;
                selectableFullContainer.getSearcherContainer().getSearchField().requestFocus();
            }
        });
    }

    /**
     * Ctrl + Q : opens/closes configuration menu.
     */
    private void handle_Q_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        Platform.runLater(() -> {
            selectableContainer.handleSettingsMouseClicked(null);
        });
    }

    /**
     * Ctrl + N : New object.
     */
    private void handle_N_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        Platform.runLater(() -> {
            selectableContainer.handleAddItemMouseClicked(null);
        });
    }

    /**
     * Ctrl + A : All objects are selected, if container has focus.
     */
    private void handle_A_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        selectableContainer.selectAll();
    }

    /**
     * Esc key : ...
     */
    private void handle_ESCAPE_KEY(ScrollableListContainerSimple selectableContainer, NativeKeyEvent e) {
        selectableContainer.closeContextMenu();
        selectableContainer.closeMenu();
        Platform.runLater(() -> {

            if (container instanceof ScrollableListContainerFull) {
                /**
                 * Limpa campo de pesquisa do searcher container quando
                 * ESC(escape) event é capturada pelo global screen listener.
                 *
                 * @param event
                 */
                ScrollableListContainerFull selectableFullContainer = (ScrollableListContainerFull) container;
//                selectableFullContainer.getSearcherContainer().handleScapeFromGlobalScreenListener(e);

                selectableFullContainer.requestFocus();

                if (!selectableFullContainer.getSearcherField().isFocused()) {
                    selectableFullContainer.unSelectAll();
                }

                selectableFullContainer.requestFocus();

            } else {
                selectableContainer.unSelectAll();
                selectableContainer.requestFocus();
            }
        });
    }

    @Override
    public void nativeKeyReleased(NativeKeyEvent e) {
        //releases Shift.
        //releases Ctrl.Avoids ghost callings.
        switch (e.getKeyCode()) {
            case NativeKeyEvent.VC_CONTROL_R:
                isCtrlKey = false;
                break;
            case NativeKeyEvent.VC_CONTROL_L:
                isCtrlKey = false;
                break;
            case NativeKeyEvent.VC_SHIFT_L:
                isShiftKey = false;
                isArrowDonw = false;
                isArrowUp = false;
                lastModifiedItem = null;
                break;
            case NativeKeyEvent.VC_SHIFT_R:
                isShiftKey = false;
                lastModifiedItem = null;
                isArrowDonw = false;
                isArrowUp = false;
                break;
        }
    }

    private boolean isSelectable(Node container) {
        return container instanceof ScrollableListContainerSimple;
    }

    Collection<String> names = new ArrayList<>();

    ScrollableListItem lastModifiedItem;

    private void handle_ARROW_DOWN_MULTI_SELECTION(ScrollableListContainerSimple selectableContainer) {

        Platform.runLater(() -> {

            if (isArrowUp) {
                if (lastModifiedItem != null) {
                    selectableContainer.unselectMulti(lastModifiedItem.getName());
                }
                isArrowUp = false;
                return;
            }

            if (selectableContainer.getCurrentModel().size() == 0) {
                return;
            }

            selectableContainer.getSelector().prepareForShiftMultiSelection();

            Item current = selectableContainer.getSelector().getCurrent();
            ScrollableList<Item> currentModel = selectableContainer.getCurrentModel();

            if (current != null) {

                if (currentModel.hasNext(current)) {
                    selectableContainer.multiSelect(currentModel.getNext(current).getName());
                    current = selectableContainer.getSelector().getCurrent();
                    if (!currentModel.isVisible(current)) {
                        currentModel.scrollUp();
                    }
                }

            } else {
                current = currentModel.getTheMidleVisible();
                if (current != null) {
                    selectableContainer.multiSelect(current.getName());
                }
            }
            lastModifiedItem = current;
            isArrowDonw = true;
        });

    }

    private void handle_ARROW_UP_MULTI_SELECTION(ScrollableListContainerSimple selectableContainer) {

        Platform.runLater(() -> {

            if (isArrowDonw) {
                if (lastModifiedItem != null) {
                    selectableContainer.multiSelect(lastModifiedItem.getName());
                }
                isArrowDonw = false;
                return;
            }

            if (selectableContainer.getCurrentModel().size() == 0) {
                return;
            }

            selectableContainer.getSelector().prepareForShiftMultiSelection();

            Item current = selectableContainer.getSelector().getCurrent();
            ScrollableList<Item> currentModel = selectableContainer.getCurrentModel();

            if (current != null) {
                if (currentModel.hasBefore(current)) {
                    selectableContainer.multiSelect(currentModel.getBefore(current).getName());
                    current = selectableContainer.getSelector().getCurrent();
                    if (!currentModel.isVisible(current)) {
                        currentModel.scrollDown();
                    }
                }
            } else {
                current = currentModel.getTheMidleVisible();
                if (current != null) {
                    selectableContainer.multiSelect(current.getName());
                }
            }
            lastModifiedItem = current;
            isArrowUp = true;
        });

    }

    /**
     *
     * @param e
     */
    @Override
    public void nativeKeyTyped(NativeKeyEvent e) {
    }

}
