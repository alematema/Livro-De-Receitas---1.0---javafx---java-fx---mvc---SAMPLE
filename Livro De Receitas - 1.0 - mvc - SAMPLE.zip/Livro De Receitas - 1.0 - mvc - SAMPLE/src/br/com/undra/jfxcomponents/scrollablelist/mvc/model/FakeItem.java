
package br.com.undra.jfxcomponents.scrollablelist.mvc.model;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListItem;
import java.util.Objects;

/**
 *
 * @author alexandre
 */
public class FakeItem implements Comparable<FakeItem>, ScrollableListItem{
    
    private String descricao;
    
    public FakeItem(String descricao) {
        this.descricao = descricao;
        try {
            Thread.sleep(0);
        } catch (Exception e) {
        }
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.descricao);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FakeItem other = (FakeItem) obj;
        if (!Objects.equals(this.descricao, other.getDescricao())) {
            return false;
        }
        return true;
    }
    
    @Override
    public int compareTo(FakeItem o) {
        return getDescricao().compareTo(o.getDescricao());
    }

    @Override
    public String getName() {
        return descricao;
    }

    @Override
    public void setName(String newValue) {
        descricao = newValue;
    }
    
}
