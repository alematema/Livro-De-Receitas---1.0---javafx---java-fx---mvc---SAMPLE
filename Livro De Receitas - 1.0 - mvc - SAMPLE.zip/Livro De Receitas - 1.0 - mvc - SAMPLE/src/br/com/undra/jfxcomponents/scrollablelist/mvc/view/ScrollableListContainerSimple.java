package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import br.com.undra.jfxcomponents.menus.Menu;
import br.com.undra.jfxcomponents.menus.context.ContextMenu;
import br.com.undra.jfxcomponents.menus.context.ContextMenuArrowDown;
import br.com.undra.jfxcomponents.scrollablelist.util.InfoUpdater;
import br.com.undra.jfxcomponents.scrollablelist.util.Selector;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.livrodereceitas.paginas.Notifications;
import br.com.undra.livrodereceitas.util.Notificator;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * Uma VBox Scrollavel.
 *
 * @author alexandre
 */
public class ScrollableListContainerSimple extends Pane {

    private final StringProperty ON_ADDING = new SimpleStringProperty("NOT_ADDED");
    public static String ON_ADD_REQUEST = "ON_ADD_REQUEST";
    public static String ADDING_REQUEST_REFUSED = "ADDING_REQUEST_REFUSED";
    public static String ADDED = "ON_ADDED";
    public static String ADDING_CANCELED = "ADDING_CANCELED";
    public static String ADDING_FAILED_DUPLICATE_ENTRY = "ADDING_FAILED_DUPLICATE_ENTRY";
    public static String ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC = "ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC";

    public static String IMPORTING_FAILED_DUPLICATE_ENTRY = "IMPORTING_FAILED_DUPLICATE_ENTRY";
    public static String IMPORTING_FAILED_EXECUTING_CLIENT_HOOK_IMPORTING_LOGIC = "IMPORTING_FAILED_EXECUTING_CLIENT_HOOK_IMPORTING_LOGIC";

    public volatile StringProperty VBOX_STATE = new SimpleStringProperty("UPDATED_VBOX");
    public static String UPDATING_VBOX = "UPDATING_VBOX";
    public static String UPDATED_VBOX = "UPDATED_VBOX";

    public static String NO_SELECTION = "NO_SELECTION";
    public static String MULTI_SELECTION_REMOVED = "MULTI_SELECTION_REMOVED";
    public static String REMOVING_MULTI_SELECTION = "REMOVING_MULTI_SELECTION";
    public static String REMOVING_MULTI_SELECTION_FAILURE = "REMOVING_MULTI_SELECTION_FAILURE";
    public static String MULTI_SELECTION_DELETION_COMPLETED = "MULTI_SELECTION_DELETION_COMPLETED";
    public static String MULTI_SELECTION_DELETION_STARTED = "MULTI_SELECTION_DELETION_STARTED";
    public static String SINGLE_SELECTION_REMOVED = "SINGLE_SELECTION_REMOVED";
    public static String REMOVING_SINGLE_SELECTION = "REMOVING_SINGLE_SELECTION";
    public static String DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC = "DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC";
    final StringProperty ON_DELETION = new SimpleStringProperty(NO_SELECTION);

    private final StringProperty ON_EDITION = new SimpleStringProperty("NOT_EDITING");
    public static String ON_EDITION_REQUEST = "ON_EDITION_REQUEST";
    public static String EDITED = "EDITED";
    public static String EDITING_CANCELED = "EDITING_CANCELED";
    public static String EDITING_FAILED_EXECUTING_CLIENT_HOOK_EDITING_LOGIC = "EDITING_FAILED_EXECUTING_CLIENT_HOOK_EDITING_LOGIC";
    public static String EDITING_FAILED_NO_MATCHING_FOUND = "EDITING_FAILED_NO_MATCHING_FOUND";

    private final StringProperty ON_IMPORTING = new SimpleStringProperty("NOT_IMPORTING");
    public static String IMPORTING_STARTED = "IMPORTING_STARTED";
    public static String IMPORTING_FAILED = "IMPORTING_FAILED";
    public static String IMPORTED = "IMPORTED";

    private final StringProperty ON_UN_IMPORTING = new SimpleStringProperty("NOT_UN_IMPORTING");

    public static String UN_IMPORTING_STARTED = "UN_IMPORTING_STARTED";
    public static String UN_IMPORTING_FAILED = "UN_IMPORTING_FAILED";
    public static String UN_IMPORTED = "UN_IMPORTED";

    public static int MIN_WINDOW_HEIGHT = 580;
    public static int MIDLE_WINDOW_HEIGHT = 700;

    private int adjust = 13;
//    Selector 
    Selector selector = new Selector();
    ObservableList<Item> selection = FXCollections.observableArrayList();

    private double from;
    private double to;
    EmptyList emptyList;
    Menu menu;
    ContextMenu contextMenu;
    ContextMenuArrowDown contextMenuArrowDown;
    ContextMenu contextMenuUpArrow;

    Font toolTipsFont = Font.font(12);
    private Tooltip elementsListInfoToolTip = new Tooltip();
    Tooltip settingsTooltip;

    private FXMLLoader fxmlLoader;
    final ScrollableList<Item> model = new ScrollableList<>();
    ScrollableList<Item> currentModel;

    private VerticalScrollableListWrapper wrapper;

    private volatile boolean isRemovingSingleSelection = true;
    private String singleRemoved;
    private Set<String> multiSelectionRemoved = new HashSet<>();

    /**
     * The extra NODES, in witch,for instace,<br>
     * will be css applyied.
     *
     */
    private List<Node> extras;

    boolean compactedList = false;
    @FXML
    private VBox vBox;
    @FXML
    private Group scrollableContainerGroup;
    @FXML
    Pane scrollableContainerHeader;
    @FXML
    private MaterialDesignIconView scrollableListInfoIconContainer;
    @FXML
    private Label scrollableListInfoLabelContainer;
    @FXML
    MaterialDesignIconView scrollableListAddItemIconContainer;
    @FXML
    MaterialDesignIconView settingsIcon;
    @FXML
    private Pane statusBar;
    @FXML
    private Label statusMessageLbl;
    private double statusBarMaxWidth;
    private Item currentAdding;
    private Item currentRemoving;
    private Item currentEditing;
    private Item clickedItem;

    public double getStatusBarMaxWidth() {
        statusBarMaxWidth = scrollableContainerHeader.getPrefWidth();
        return statusBarMaxWidth;
    }

    private final ListChangeListener vBoxChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {
            while (change.next()) {
                if (change.wasAdded()) {
                    for (Object o : change.getAddedSubList()) {
                        if (o instanceof Item) {
                            InfoUpdater.updateAfterAddition((ScrollableListContainerSimple) fxmlLoader.getRoot(), (Item) o);
                        }
                    }
                }
                if (change.wasRemoved()) {
                    for (Object o : change.getRemoved()) {
                        if (o instanceof Item) {
                            InfoUpdater.updateAfterDeletion((ScrollableListContainerSimple) fxmlLoader.getRoot(), (Item) o);
                        }
                    }
                }
            }
            try {
                showHideEmptyListScreen();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    };

    private void showHideEmptyListScreen() {

        if (currentModelIsEmpty()) {

            if (!getChildren().contains(emptyList)) {
                removeVBoxAddEmptyList();
            }

        } else {

            if (!getChildren().contains(vBox)) {
                removeEmptyListAddVbox();
            }

        }

    }

    private boolean currentModelIsEmpty() {
        return currentModel.size() == 0;
    }

    private void removeEmptyListAddVbox() {

        FadeTransition fadeOutEmptyList = new FadeTransition(Duration.seconds(0.5), emptyList);
        fadeOutEmptyList.setFromValue(1);
        fadeOutEmptyList.setToValue(0);
        fadeOutEmptyList.setOnFinished((event) -> {
            getChildren().remove(emptyList);
            if (!getChildren().contains(vBox)) {
                getChildren().add(vBox);
            }
            emptyList.setOpacity(1);
            emptyList.setVisible(false);
            FadeTransition fadeInVBox = new FadeTransition(Duration.seconds(0.5), vBox);
            fadeInVBox.setFromValue(0);
            fadeInVBox.setToValue(1);
            fadeInVBox.setOnFinished((e) -> {
                vBox.setOpacity(1);
                vBox.setVisible(true);
                vBox.toBack();
            });
            fadeInVBox.play();

        });
        fadeOutEmptyList.play();

    }

    private void removeVBoxAddEmptyList() {
        getChildren().add(emptyList);
        FadeTransition fadeOutVBox = new FadeTransition(Duration.seconds(0.5), vBox);
        fadeOutVBox.setFromValue(1);
        fadeOutVBox.setToValue(0);
        fadeOutVBox.setOnFinished((event) -> {

            getChildren().remove(vBox);
            vBox.setVisible(false);
            vBox.setOpacity(1);
            FadeTransition fadeInEmptyList = new FadeTransition(Duration.seconds(0.5), emptyList);
            fadeInEmptyList.setFromValue(0);
            fadeInEmptyList.setToValue(1);
            fadeInEmptyList.setOnFinished((e) -> {
                emptyList.setVisible(true);
                emptyList.setOpacity(1);
            });
            fadeInEmptyList.play();

        });
        fadeOutVBox.play();

    }
    private final ListChangeListener selectionChangedListener = new ListChangeListener() {

        @Override
        public void onChanged(javafx.collections.ListChangeListener.Change change) {
            if (selection.isEmpty()) {
//                    System.out.println("SELECTION IS EMPTY "+System.currentTimeMillis());
            }
        }
    };

    @SuppressWarnings("empty-statement")
    ChangeListener<String> ADD_REMOVE_SCROLL_UP_AND_DOWN_ITEM_LISTENER = (observable, oldValue, newValue) -> {

        if (newValue.equals(ScrollableList.ADDED_SINGLE_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.REMOVED_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.SCROLLING_UP_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.SCROLLING_UP_FAILED)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                wrapper.shake();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.SCROLLING_DOWN_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.SCROLLING_DOWN_FAILED)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                wrapper.shake();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.ADDED_FAST_UPDATE_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.ADDED_LAST_VISIBLE_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.REMOVED_BULK_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.REMOVED_AS_UN_IMPORTING_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.ADDED_AS_SEARCHING_RESULT_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.ADDED_AS_IMPORTING_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        } else if (newValue.equals(ScrollableList.EDITED_READY)) {
            new Thread(() -> {
                while (VBOX_STATE.getValue().equals(UPDATING_VBOX));
                updateVBox();
                Platform.runLater(() -> {
                    InfoUpdater.update(this);
                });
            }).start();
        }
    };
    public ScrollableListKeyListener keyListener;

    public ScrollableListContainerSimple(String fxml, VerticalScrollableListWrapper wrapper) {

        fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        statusMessageLbl.setText("");

        currentModel = model;

        menu = new Menu(this);
        menu.setVisible(false);
        menu.toBack();
        menu.setLayoutY(13);
        menu.setLayoutX(scrollableContainerHeader.widthProperty().doubleValue());
        extras = new ArrayList<>();

        scrollableContainerHeader.getChildren().add(menu);
        scrollableContainerHeader.setId("scrollableContainerSimpleHeader");

        doBindingsAndListenings();

        Tooltip toolTipAddItem = new Tooltip(String.format(Util.getPROPERTIES(wrapper).getProperty("toolTipAddItemScrollableListContainer"), Util.PROPERTIES.getProperty("create.new.shortcut")));
        toolTipAddItem.setFont(toolTipsFont);
        Tooltip.install(scrollableListAddItemIconContainer, toolTipAddItem);

        elementsListInfoToolTip.setFont(toolTipsFont);
        elementsListInfoToolTip.setText(Util.getPROPERTIES(wrapper).getProperty("mensagemListaVazia"));
        Tooltip.install(scrollableListInfoIconContainer, elementsListInfoToolTip);
        Tooltip.install(scrollableListInfoLabelContainer, elementsListInfoToolTip);

        settingsTooltip = new Tooltip(Util.getPROPERTIES(wrapper).getProperty("settingsSimpleTooltip"));
        settingsTooltip.setFont(toolTipsFont);
        Tooltip.install(settingsIcon, settingsTooltip);

        emptyList = new EmptyList();

        showHideEmptyListScreen();
        emptyList.setLayoutY(60);
        emptyList.toBack();

        settingsTooltip = new Tooltip(Util.getPROPERTIES(wrapper).getProperty("settingsSimpleTooltip"));

        contextMenuUpArrow = new ContextMenu(this);
        setUpContextMenu(contextMenuUpArrow);
        contextMenuArrowDown = new ContextMenuArrowDown(this);

        vBox.getChildren().addListener(vBoxChangedListener);

        InfoUpdater.updateListSizeInfo(this, "0");

        VScroller.doVBoxLayOutYTopStraightAdjust(this);

        VBOX_STATE.setValue(UPDATED_VBOX);

        statusBar.setPrefWidth(0);

        scrollableListAddItemIconContainer.setGlyphName(Util.PROPERTIES.getProperty("add.icon.glyph.name"));

    }
    private volatile boolean lastShiftKeyValue = false;

    private void doBindingsAndListenings() {

        ScrollableListKeyListener keyListener = new ScrollableListKeyListener(this);

        setOnKeyPressed(keyListener);
        setOnKeyReleased((e) -> {
            switch (e.getCode()) {
                case CONTROL:
                    keyListener.isCtrlKey = false;
                    break;
                case SHIFT:
                    keyListener.isShiftKey = false;
                    if (keyListener.lastModifiedItem == null) {
                        keyListener.isArrowDonw = false;
                        keyListener.isArrowUp = false;
                    }
                    break;
            }

        });

        focusedProperty().addListener((observable, oldValue, focused) -> {
            if (oldValue == true && focused == false) {
                lastShiftKeyValue = keyListener.isShiftKey;
            } else if (oldValue == false && focused == true) {
                keyListener.isShiftKey = lastShiftKeyValue;
            }
        });

        scrollableContainerHeader.prefWidthProperty().bind(vBox.prefWidthProperty());
        scrollableContainerHeader.prefWidthProperty().addListener((observable, oldValue, newValue) -> {
            settingsIcon.setLayoutX(scrollableContainerHeader.getWidth() - Double.parseDouble(settingsIcon.getSize()) - 5);
            InfoUpdater.doInfoLabelAdjustments(this);
            menu.setLayoutX(newValue.doubleValue() - Double.parseDouble(settingsIcon.getSize()) - menu.getPrefWidth() - 3);
        });

        heightProperty().addListener((observable, oldValue, newValue) -> {
            Platform.runLater(() -> {
                if (compactedList) {
                    setCompactList(newValue);
                } else {
                    setNOTCompactList(newValue);
                }
                if (newValue.doubleValue() <= 640) {
                    emptyList.getEmptyListIcon().setLayoutY(Double.parseDouble(emptyList.getEmptyListIcon().getSize()) * 0.9);
                    emptyList.getEmptyListLabel().setLayoutY(Double.parseDouble(emptyList.getEmptyListIcon().getSize()));
                } else {
                    emptyList.getEmptyListIcon().setLayoutY(Double.parseDouble(emptyList.getEmptyListIcon().getSize()));
                    emptyList.getEmptyListLabel().setLayoutY(Double.parseDouble(emptyList.getEmptyListIcon().getSize()) + 20);
                }
            });
        });

        widthProperty().addListener((observable, oldValue, newValue) -> {
            emptyList.setPrefWidth(newValue.doubleValue());
            emptyList.getEmptyListIcon().setLayoutX((newValue.doubleValue() - Double.parseDouble(emptyList.getEmptyListIcon().getSize())) / 2);
            emptyList.getEmptyListLabel().setLayoutX((newValue.doubleValue() - emptyList.getEmptyListLabel().getPrefWidth()) / 2);
        });

        currentModel.getSTATE().addListener(ADD_REMOVE_SCROLL_UP_AND_DOWN_ITEM_LISTENER);

        selector.getSTATE().addListener((observable, oldValue, STATE) -> {
            InfoUpdater.update(this);
        });

    }

    public void setCompactList(Number newValue) {
        if (newValue.doubleValue() < MIN_WINDOW_HEIGHT) {
            currentModel.setVisibleElementsMaxNum(14);
            VScroller.setAdjust(this, 14);
        } else if (newValue.doubleValue() < MIDLE_WINDOW_HEIGHT) {
            VScroller.setAdjust(this, 22);
            currentModel.setVisibleElementsMaxNum(22);
        } else {
            VScroller.setAdjust(this, 24);
            currentModel.setVisibleElementsMaxNum(25);
        }
        updateVBox();
        VScroller.doVBoxLayOutYTopAdjust(this);
        VScroller.doVBoxLayOutYBottonAdjust(this);
        compactedList = true;
        getMenu().getOnOffListaCompactaIcon().setGlyphName("TOGGLE_ON");
        getMenu().getOnOffListaCompactaIcon().setFill(Paint.valueOf("white"));
    }

    public void setNOTCompactList(Number newValue) {
        if (newValue.doubleValue() < MIN_WINDOW_HEIGHT) {
            currentModel.setVisibleElementsMaxNum(8);
            VScroller.setAdjust(this, 7);
        } else if (newValue.doubleValue() < MIDLE_WINDOW_HEIGHT) {
            VScroller.setAdjust(this, 10);
            currentModel.setVisibleElementsMaxNum(10);
        } else {
            VScroller.setAdjust(this, 13);
            currentModel.setVisibleElementsMaxNum(13);
        }
        updateVBox();
        VScroller.doVBoxLayOutYTopAdjust(this);
        VScroller.doVBoxLayOutYBottonAdjust(this);
        compactedList = false;
        getMenu().getOnOffListaCompactaIcon().setGlyphName("TOGGLE_OFF");
        getMenu().getOnOffListaCompactaIcon().setFill(Paint.valueOf("white"));
    }

    void setUpContextMenu(ContextMenu contextMenu) {
        if (getChildren().contains(this.contextMenu)) {
            getChildren().remove(this.contextMenu);
        }
        this.contextMenu = contextMenu;
        getChildren().add(contextMenu);
        contextMenu.setVisible(false);
//        contextMenu.toFront();
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public void setUp(double height, String cssTheme) {
        Text currentTema = new Text();
        currentTema.setId(Util.getPROPERTIES(wrapper).getProperty(cssTheme).split(",")[1] + "Text");
        menu.changeCss(currentTema);
        if (compactedList) {
            setCompactList(height);
        } else {
            setNOTCompactList(height);
        }
    }

    public void setUp(String cssTheme) {
        Text currentTema = new Text();
        currentTema.setId(Util.getPROPERTIES(wrapper).getProperty(cssTheme).split(",")[1] + "Text");
        menu.changeCss(currentTema);
    }

    public void setSelection(ObservableList<Item> selection) {
        this.selection = selection;
    }

    public void setAdjust(int adjust) {
        this.adjust = adjust;
    }

    public void setCena(Scene cena) {
        this.cena = cena;
    }

    /**
     * Sets The extra NODES, in witch,for instace,<br>
     * will be css applyied.
     *
     * @param extras the extra nodes.
     */
    public void setExtras(List<Node> extras) {
        this.extras = extras;
    }

    public void setWrapper(VerticalScrollableListWrapper wrapper) {
        this.wrapper = wrapper;
    }

    public void setProgressValue(double newValue) {
        if (newValue >= 0 && newValue <= 1) {
            statusBar.setPrefWidth(getStatusBarMaxWidth() * newValue);
        }
    }

    public void setStatusMessage(String newMessage) {
        this.statusMessageLbl.setText(newMessage);
    }

    public void setCompactedList(boolean compactedList) {
        this.compactedList = compactedList;
    }

    public void setRoundCorner(boolean roundCorner) {
        if (roundCorner) {
            getMenu().getOnOffBordaRedonda().setGlyphName("TOGGLE_OFF");
        } else {
            getMenu().getOnOffBordaRedonda().setGlyphName("TOGGLE_ON");
        }
        getMenu().toggleRoundCorner(getMenu().getOnOffBordaRedonda());
    }

    @FXML
    void handelMouseReleased(MouseEvent event) {
        to = event.getSceneY();
        VScroller.handleScrolling(this, to - from);
    }

    @FXML
    void handelMousePressed(MouseEvent event) {
        from = event.getSceneY();
    }

    @FXML
    void handleScrolling(ScrollEvent event) {
        if (event.isControlDown()) {
            return;
        }
        VScroller.handleScrolling(this, event.getDeltaY());
    }

    @FXML
    void handleScrollingFinished(ScrollEvent event) {
    }

    @FXML
    void handleScrollingStarted(ScrollEvent event) {
    }

    @FXML
    void handleMouseClidked(MouseEvent event) {
        requestFocus();
        if (MouseButton.SECONDARY.equals(event.getButton())) {
            if (clickedItem != null) {
                openContextMenu(event);
            }
        }
    }

    @FXML
    public void handleAddItemMouseClicked(MouseEvent event) {

        if (ON_ADDING.getValue().equals(ON_ADD_REQUEST)) {
            wrapper.shake();
            return;
        }

        ON_ADDING.setValue(ON_ADD_REQUEST);

////        String[] descricoes = {"1", "2",
////            "3", "4 ", "5", "6", "7",
////            "Carina Carona", "Czak é rei", "Dai a cesar algo", "Dar a cesar o que é dele", "Elefantes sao legais", "Fulana e beltrana",
////            "Gasolina amanadeika", "Hoje é depois de ontem", "Imanencia é transcendente", "Ja que é nao será", "KWV Brasil", "Larga a porta do mundo",
////            "Manada em movimento", "Navios estao no ceu hoje", "Oracao é desejar", "Padres ou urubus ?", "Quando voce vai voltar",
////            "Rosnar e mostrar os dentes é bom", "Sao sebastiao é irmao de sabao", "Tulipas na janela", "Ubuntu é legal", "Vaidade ou ignorancia",
////            "XGB um antro", "Zumba da zabumba"
////        };
//        String[] descricoes = {"Quem estao deslocadas", "Receitas da Babel",
//            "Zuminkanga Ape", "Gaia é aqui ", "Por que vai ser assim", "Agora ou nunca é proverbial", "Balzac pela bulakxa",
//            "Carina Carona", "Czak é rei", "Dai a cesar algo", "Dar a cesar o que é dele", "Elefantes sao legais", "Fulana e beltrana",
//            "Gasolina amanadeika", "Hoje é depois de ontem", "Imanencia é transcendente", "Ja que é nao será", "KWV Brasil", "Larga a porta do mundo",
//            "Manada em movimento", "Navios estao no ceu hoje", "Oracao é desejar", "Padres ou urubus ?", "Quando voce vai voltar",
//            "Rosnar e mostrar os dentes é bom", "Sao sebastiao é irmao de sabao", "Tulipas na janela", "Ubuntu é legal", "Vaidade ou ignorancia",
//            "XGB um antro", "Zumba da zabumba", "Abracadabra é aqui e lá", "Meu irmão celestial.", "Daqui pouco é tarde demais", "Em breve já não terá mais ecumenismo", "O ascecla cantou baiao",
//            "XBX versao nao original", "XBOX versao original", "Xangai ou singapore", "Zenite puckts", "Desejo exibir uma mensagem", "aleatória de um arquivo.txt sem"
//        };
//
////        String[] descricoes = new String[100];
////        
////        new Thread(() -> {
////            for (int i = 0; i < 1000; i++) {
////
//////            try {
//////                Thread.sleep(50);
//////            } catch (InterruptedException ex) {
//////                Logger.getLogger(ScrollableListContainerSimple.class.getName()).log(Level.SEVERE, null, ex);
//////            }
////                Item item = Item.newInstance("[" + i + "] : " + Long.toString(System.nanoTime()), this, i, Item.NO_IMAGE_PATH);
////                Platform.runLater(() -> {addAndSelect(item);
////                });
////
////            }
////        }
////        ).start();
//        String[] imgPaths = {"/resources/img/arrozBranco.jpeg", "/resources/img/saladaAlmeirao.jpeg", "/resources/img/1.png", "/resources/img/2.png", "/resources/img/3.png", "/resources/img/4.png", "/resources/img/5.png"};
//
//        Random r = new Random();
//        Random imgPathsRandom = new Random();
//
//        int nextId = getNewSize() + 1;
//        String[] ii = Integer.toString(r.nextInt(descricoes.length)).split("");
//        String descricao = "";
//        for (int i = 0; i < ii.length; i++) {
//            descricao += ii[i] + ";";
//        }
//        Item item = Item.newInstance(descricoes[r.nextInt(descricoes.length)], this, nextId, Item.NO_IMAGE_PATH);
//        addAndSelect(item);
    }

    @FXML
    void handleMouseEnteredSettingIcon(MouseEvent event) {
//        RotateTransition rt = new RotateTransition(Duration.millis(100), settingsIcon);
//        rt.setByAngle(45);
//        rt.setAutoReverse(true);
//        rt.play();
    }

    @FXML
    void handleMouseExitedSettingIcon(MouseEvent event) {
//        RotateTransition rt = new RotateTransition(Duration.millis(100), settingsIcon);
//        rt.setByAngle(-45);
//        rt.setAutoReverse(true);
//        rt.play();
    }

    @FXML
    public void handleSettingsMouseClicked(MouseEvent event) {

        if (menu.isVisible()) {
            menu.setVisible(false);
        } else {
            menu.setVisible(true);
            menu.toFront();
            emptyList.toBack();
        }

        this.requestFocus();
    }

    public StringProperty ON_ADDITION() {
        return ON_ADDING;
    }

    public void add() {
        handleAddItemMouseClicked(null);
    }

    boolean selected = false;
    MouseEvent event = new MouseEvent(null, 0, 0, 0, 0, MouseButton.NONE, 0, selected, false, selected, selected, selected, selected, selected, selected, selected, true, null);

    public void addAndSelect(Item item) {

        currentAdding = item;
        new Thread(() -> {
            Platform.runLater(() -> {
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ScrollableListContainerSimple.class.getName()).log(Level.SEVERE, null, ex);
                }
                Collection<Item> exactModel = currentModel.getExactModel();
                if (exactModel.contains(item)) {
                    exactModel.clear();
                    ON_ADDING.setValue(ADDING_FAILED_DUPLICATE_ENTRY);
                    return;
                }
                try {
                    wrapper.executeClientHookAdditionLogic();
                } catch (Exception e) {
                    Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO ADICIONAR " + item.getDescricao(), e);
                    ON_ADDING.setValue(ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC);
                    return;
                }
                currentModel.addAndUpdateVisibleElements(item);
                item.click();
                ON_ADDING.setValue(ADDED);
                this.requestFocus();
            });
        }).start();

    }

    volatile private boolean errorAdding = false;
    volatile private boolean blocked = false;

    public void add(Item item) throws Exception {

        currentAdding = item;
        ON_ADDING.setValue("ADDING");
        Collection<Item> exactModel = currentModel.getExactModel();
        if (exactModel.contains(item)) {
            exactModel.clear();
            ON_ADDING.setValue(ADDING_FAILED_DUPLICATE_ENTRY);
            throw new Exception(ADDING_FAILED_DUPLICATE_ENTRY);
        }

        try {
            wrapper.executeClientHookAdditionLogic();
        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO ADICIONAR " + item.getDescricao(), e);
            ON_ADDING.setValue(ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC);
            throw new Exception(e);
        }

        currentModel.addAndUpdateVisibleElements(item);
        ON_ADDING.setValue(ADDED);

        Platform.runLater(() -> {
            this.requestFocus();
        });

    }

    public void load(Collection<Item> allItem) {
        currentModel.load(allItem);
    }

    @Deprecated
    public void load(Item item) {
        if (!currentModel.getChangefulModel().contains(item)) {
            currentModel.load(item);
        }
    }

    private List<Item> itens = new ArrayList<>();

    public int getTotalItensNaLista() {
        return currentModel.getChangefulModel().size();
    }

    public Tooltip getElementsListInfoToolTip() {
        return elementsListInfoToolTip;
    }

    public Label getScrollableListInfoLabelContainer() {
        return scrollableListInfoLabelContainer;
    }

    public MaterialDesignIconView getScrollableListInfoIconContainer() {
        return scrollableListInfoIconContainer;
    }

    public VBox getVBox() {
        return vBox;
    }

    public Pane getHeader() {
        return scrollableContainerHeader;
    }

    public ObservableList<Item> getSelection() {
        return selection;
    }

    public Selector getSelector() {
        return selector;
    }

    public MaterialDesignIconView getSettingsIcon() {
        return settingsIcon;
    }

    public ScrollableList<Item> getCurrentModel() {
        return currentModel;
    }

    public ScrollableList<Item> getModel() {
        return model;
    }

    public Pane getScrollableContainerHeader() {
        return scrollableContainerHeader;
    }

    private int getNewSize() {
        int newSize = vBox.getChildren().size() + 1;
        return newSize / 2;
    }

    public int getAdjust() {
        return adjust;
    }

    public Menu getMenu() {
        return menu;
    }

    private Scene cena;

    public Scene getCena() {
        if (getScene() == null) {
            return cena;
        } else {
            return getScene();
        }
    }

    public EmptyList getEmptyListPage() {
        return emptyList;
    }

    /**
     * Gets The extra NODES, in witch,for instace,<br>
     * will be css applyied.
     *
     * @return the extra nodes.
     */
    public List<Node> getExtras() {
        return extras;
    }

    public MaterialDesignIconView getAddItemIcon() {
        return scrollableListAddItemIconContainer;
    }

    public String getSingleRemoved() {
        return singleRemoved;
    }

    public Set<String> getMultiSelectionRemoved() {
        return multiSelectionRemoved;
    }

    public Item getCurrentSelected() {
        return selector.getCurrent();
    }

    public Item getCurrentUnselected() {
        return selector.getCurrentUnselected();
    }

    public VerticalScrollableListWrapper getWrapper() {
        return wrapper;
    }

    public Font getToolTipsFont() {
        return toolTipsFont;
    }

    public Item getCurrentAdding() {
        return currentAdding;
    }

    public Item getCurrentRemoving() {
        return currentRemoving;
    }

    public Label getStatusMessageLbl() {
        return statusMessageLbl;
    }

    public Item getCurrentEditing() {
        return currentEditing;
    }

    public ContextMenuArrowDown getContextMenuArrowDown() {
        return contextMenuArrowDown;
    }

    public ContextMenu getContextMenuUpArrow() {
        return contextMenuUpArrow;
    }

    public boolean isCompactedList() {
        return compactedList;
    }

    public boolean isRoundCorner() {
        return getMenu().getOnOffBordaRedonda().getGlyphName().equals("TOGGLE_ON");
    }

    public StringProperty ON_DELETION() {
        return ON_DELETION;
    }

    @Deprecated
    public synchronized void remove(Item item) throws Exception {
        currentRemoving = item;
        if (isRemovingSingleSelection) {
            Platform.runLater(() -> {
                ON_DELETION.setValue(REMOVING_SINGLE_SELECTION);
            });
        }
        try {
            wrapper.executeClientHookDeletionLogic();
        } catch (Exception e) {
            wrapper.setHasBeenNotificatedOnDeletion(false);
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO REMOVER " + currentRemoving.getDescricao(), e);
            Platform.runLater(() -> {
                ON_DELETION.setValue(DELETING_FAILED_EXECUTING_CLIENT_HOOK_DELETION_LOGIC);
            });
            selector.setHasHandledDeletion(false);
            throw e;
        }
        currentModel.removeAndUpdateVisibleElements(item);
        singleRemoved = item.getDescricao();
        selector.handleDeletion(this, item);
        VScroller.doLayOutYAdjustAfterRemoving(this);
        if (isRemovingSingleSelection) {
            Platform.runLater(() -> {
                ON_DELETION.setValue(SINGLE_SELECTION_REMOVED);
            });
        }
    }

    private Thread removeMultiSeletionBulkThread;
    volatile private boolean isRemovingMultiselection = false;

    public boolean isRemovingMultiselection() {
        return isRemovingMultiselection;
    }

    public void setIsRemovingMultiselection(boolean isRemovingMultiselection) {
        this.isRemovingMultiselection = isRemovingMultiselection;
    }

    volatile private boolean isRemoveMultiSelectionCanceled = false;

    public boolean isRemovingMultiSelectionCanceled() {
        return isRemoveMultiSelectionCanceled;
    }

    public void setIsRemovingMultiSelectionCanceled(boolean isRemoveMultiSelectionCanceled) {
        this.isRemoveMultiSelectionCanceled = isRemoveMultiSelectionCanceled;
    }

    @Deprecated
    public void removeMultiSelection() {

        if (selection.size() > 0) {

            removeMultiSeletionBulkThread = new Thread(() -> {

                isRemovingMultiselection = true;

                int intervalFromOneDeletionAndAnother = Util.getIntervalFromOneIterationAndAnother(currentModel.getChangefulModel().size());

                Platform.runLater(() -> {
                    wrapper.setUpBeforeRemoveMultiSelection();
                    ON_DELETION.setValue(MULTI_SELECTION_DELETION_STARTED);
                });

                block();

                List<Item> selectionLocal = new ArrayList(selection);
                Item last = selectionLocal.get(selectionLocal.size() - 1);
                // selectionLocal.remove(selectionLocal.size()-1);
                multiSelectionRemoved.clear();
                double i = 0;
                int n = selection.size();

                for (Item item : selectionLocal) {

                    if (isRemoveMultiSelectionCanceled) {
                        break;
                    }
                    try {

                        isRemovingSingleSelection = false;
                        Platform.runLater(() -> {
                            //Para atualizar a cada iteracao. Já que pode estar concorrendo com escritas de pesquisar, por exemplo.
                            wrapper.setUpBeforeRemoveMultiSelection();
                            ON_DELETION.setValue(REMOVING_MULTI_SELECTION);
                        });
                        remove(item);
                        i++;
                        setProgressValue(i / n);
                        Platform.runLater(() -> {
                            VScroller.doLayOutYAdjustAfterRemoving(this);
                            InfoUpdater.updateAfterDeletion(this, item);
                        });
                        while (!selector.hasHandledDeletion()) {
                        }
                        multiSelectionRemoved.add(item.getDescricao());
                        Platform.runLater(() -> {
                            ON_DELETION.setValue(MULTI_SELECTION_REMOVED);
                        });
                        isRemovingSingleSelection = true;
//                        try {
//                            Thread.sleep(intervalFromOneDeletionAndAnother);
//                        } catch (Exception e) {
//                        }
                    } catch (Exception ex) {
                        ON_DELETION.setValue(REMOVING_MULTI_SELECTION_FAILURE);
                        Logger.getLogger(ScrollableListContainerSimple.class.getName()).log(Level.SEVERE, "ERRO AO REMOVER " + currentRemoving.getDescricao(), ex);
                        while (!wrapper.hasBeenNotificatedOnDeletion()) {
                        }
                    }
                }

                try {
                    Thread.sleep(400);
                } catch (Exception e) {
                }

                Platform.runLater(() -> {
                    ON_DELETION.setValue(MULTI_SELECTION_DELETION_COMPLETED);
                    wrapper.setUpAfterRemoveMultiSelection();
                    isRemovingMultiselection = false;
                });

                unblock();

            });

            removeMultiSeletionBulkThread.start();

        }
    }

    private synchronized Collection<String> itensToStringList(List<Item> itens) {
        Collection<String> itensToStringList = new ArrayList<>();
        itens.forEach((t) -> {
            itensToStringList.add(t.getDescricao());
        });
        return itensToStringList;

    }

    public void removeMultiSelectionBulk() {

        if (selection.size() > 0) {

            removeMultiSeletionBulkThread = new Thread(() -> {

                isRemoving = true;

                multiSelectionRemoved.clear();
                isRemovingMultiselection = true;
                isRemoveMultiSelectionCanceled = false;

                int intervalFromOneDeletionAndAnother = Util.getIntervalFromOneIterationAndAnother(selection.size());

                Platform.runLater(() -> {
                    wrapper.setUpBeforeRemoveMultiSelection();
                    ON_DELETION.setValue(MULTI_SELECTION_DELETION_STARTED);
                });

                block();

                List<Item> selectionLocal = new ArrayList(selection);
                Item last = selectionLocal.get(selectionLocal.size() - 1);

                int removeBulkSize = Util.getRemoveBulkSize(selection.size());

                double i = 0;

                int n = selection.size();

                Collection<List<Item>> batchedItens = Util.batchItens(selectionLocal, removeBulkSize);
                Collection<String> itensToString = null;
                main:
                for (List<Item> batchItem : batchedItens) {

                    //Para atualizar a cada iteracao. Já que pode estar concorrendo com escritas de pesquisar, por exemplo.
                    Platform.runLater(() -> {
                        wrapper.setUpBeforeRemoveMultiSelection();
                    });

                    if (isRemoveMultiSelectionCanceled) {
                        if (itensToString != null) {
                            itensToString.clear();
                        }
                        break;
                    }

                    //avoiding concurrent modification exception
                    List<Item> bulk = new ArrayList(batchItem);
                    //remove UNexcludables
                    List<Item> UNExcludables = (List<Item>) wrapper.getUNexcludables(batchItem);
                    //buld contem apenas REMOVÍVEIS
                    UNExcludables.forEach((t) -> {
                        bulk.remove(t);
                    });
                    n -= UNExcludables.size();

                    try {
                        //Bulk contem APENAS os REMOVIVEIS, segundo criterios do CLIENTE.
                        removeBulk(bulk);
                        while (!isBulkRemovalCompleted && !selector.hasHandledDeletion()) {
                            if (isRemoveMultiSelectionCanceled) {
                                bulk.clear();
                                UNExcludables.clear();
                                if (itensToString != null) {
                                    itensToString.clear();
                                }
                                break main;
                            }
                        }

                        itensToString = itensToStringList(bulk);

                        //ESTA LISTA DEVE SER LIMPA POR OUTRO OBJETO, CASO SE QUEIRA INFORMAÇOES SOBRE OS ITENS BULK REMOVIDOS.
                        multiSelectionRemoved.addAll(itensToString);

                        i++;
                        if (n != 0) {
                            setProgressValue((i * removeBulkSize) / n);
                        } else {
                            setProgressValue(0);
                        }

                    } catch (Exception e) {
                        Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage());
                        bulk.clear();
                        UNExcludables.clear();
                        if (itensToString != null) {
                            itensToString.clear();
                        }
                    }
                    bulk.clear();
                    UNExcludables.clear();
                    if (itensToString != null) {
                        itensToString.clear();
                    }
                }

                selectionLocal.clear();
                batchedItens.forEach((batchItens) -> {
                    batchItens.clear();
                });
                batchedItens.clear();

                Util.GC();

                Platform.runLater(() -> {
                    ON_DELETION.setValue(MULTI_SELECTION_DELETION_COMPLETED);
                    wrapper.setUpAfterRemoveMultiSelection();
                    isRemovingMultiselection = false;
                });

                unblock();
                isRemoving = false;

            });

            removeMultiSeletionBulkThread.start();
        }
    }

    volatile private boolean isBulkRemovalCompleted = false;

    /**
     * O bulk DEVE conter apenas REMOVÍVEIS.
     *
     * @param bulk o batch de itens a ser removido
     */
    public void removeBulk(Collection<Item> bulk) {

        try {
            isBulkRemovalCompleted = false;
            wrapper.executeClientHookBulkDeletionLogic(bulk);
            selector.handleDeletionSilently(this, bulk);
            currentModel.doBulkRemove(bulk);
            isBulkRemovalCompleted = true;
            Platform.runLater(() -> {
                VScroller.doLayOutYAdjustAfterRemoving(this);
                InfoUpdater.updateAfterBulkDeletion(this);
            });
            Util.GC();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }

    }

    volatile private boolean isRemoving = false;

    public boolean isRemoving() {
        return isRemoving;
    }

    public int getIndexOf(Item item) {
        return currentModel.indexOf(item);
    }

    void updateVBox() {

        Platform.runLater(() -> {

            VBOX_STATE.setValue(UPDATING_VBOX);
            try {

                vBox.getChildren().clear();

                currentModel.getVisibleElements().forEach((item) -> {
                    if (item != null) {

                        int nextId = getNewSize() + 1;
                        if (nextId == 1) {
                            vBox.getChildren().add(item);
                        } else {
                            vBox.getChildren().add(new Separator());
                            vBox.getChildren().add(item);
                        }
                    }
                });
                VScroller.doAdjustments(this);

            } catch (Exception e) {
//                System.out.println("@ vbox updating  " + e.getCause() + ", " + e.getMessage());
//                e.printStackTrace();
            }

            VBOX_STATE.setValue(UPDATED_VBOX);
        });

    }

    String style;
    int offHeights;

    public void openContextMenu(MouseEvent event) {

        double contextMenuHeight = contextMenu.getPrefHeight();

        //ajusta para context menu ficar sempre visivel
        if (getPrefHeight() - event.getY() > contextMenuHeight) {
            contextMenu.setVisible(false);
            setUpContextMenu(contextMenuUpArrow);
        } else {
            contextMenu.setVisible(false);
            setUpContextMenu(contextMenuArrowDown);
        }
        if (contextMenu.isOpened()) {
            contextMenu.setVisible(false);
            return;
        }

        if (selector.noneSelected(this)) {
            selector.handleSelection(this, event, clickedItem);
            InfoUpdater.updateAfterSelected(this, clickedItem);
        }

        contextMenu.setVisible(true);
        contextMenu.setLayoutX(getWidth() / 5);
        if (contextMenu instanceof ContextMenuArrowDown) {
            contextMenu.setLayoutY(event.getY() - contextMenuHeight);
        } else {
            contextMenu.setLayoutY(event.getY());
        }
        clickedItem = null;
    }

    public void removeAllSelected() {
        Item anySelected = getAnySelected();
        if (anySelected != null) {

            Collection<Item> UNexcludables = wrapper.getUNexcludables(selection);
            //NAO PODE REMOVER O UNICO SELECIONADO
            if (selection.size() == 1 && UNexcludables.size() == 1 && getCurrentModel().size() > 1) {
                Platform.runLater(() -> {
                    Notificator.showNotificationPage(Notifications.get(Notifications.CANNOT_REMOVE_SINGLE_SELECTEC, wrapper), wrapper);
                });
                UNexcludables.clear();
                return;
            }
            //NAO PODE REMOVER O UNICO SELECIONADO
            if (selection.size() == 1 && UNexcludables.size() == 1 && getCurrentModel().size() == 1) {
                Platform.runLater(() -> {
                    Notificator.showNotificationPage(Notifications.get(Notifications.CANNOT_REMOVE_SINGLE_SELECTEC, wrapper), wrapper);
                });
                UNexcludables.clear();
                return;
            }
            // PODE REMOVER O UNICO SELECIONADO
            if (selection.size() == 1 && UNexcludables.isEmpty()) {
                Platform.runLater(() -> {
                    Notificator.showNotificationPage(Notifications.get(Notifications.CAN_REMOVE_SINGLE_SELECTEC, wrapper), wrapper);
                });
                UNexcludables.clear();
                return;
            }

            Platform.runLater(() -> {
                Notificator.showNotificationPage(Notifications.get(Notifications.MULTI_SELECTION_DELETION, wrapper), wrapper);
            });
            UNexcludables.clear();
        }
    }

    private Item getAnySelected() {
        Item anySelected = null;
        Collection<Item> exactModel = currentModel.getExactModel();
        for (Item i : exactModel) {
            if (i.isSelected()) {
                anySelected = i;
                break;
            }
        }
        exactModel.clear();
        return anySelected;
    }

    public void closeContextMenu() {
        contextMenu.setVisible(false);
    }

    public void closeMenu() {
        menu.setVisible(false);
    }

    public void unSelectAll() {
        isSelecting = true;
        selector.unSelectAll(this);
        isSelecting = false;
    }

    public boolean isSelecting() {
        return isSelecting;
    }

    public boolean isAddItemIcon(Node icon) {
        if (icon != null) {
            return icon.getClass().equals(MaterialDesignIconView.class) && icon.getId().equals(getAddItemIcon().getId());
        } else {
            return false;
        }
    }

    public double getSelectionProgress() {
        return selector.getSelectionProgress();
    }

    volatile private boolean isSelecting = false;

    public void selectAll() {
        new Thread(() -> {
            isSelecting = true;
            block();
            selector.selectAll(this);
            unblock();
            isSelecting = false;
        }).start();
    }

    public void invertSelection() {
        new Thread(() -> {
            isSelecting = true;
            block();
            selector.invertSelection(this);
            unblock();
            isSelecting = false;
        }).start();
    }

    Comparator<Item> c = (o1, o2) -> {
        return o1.getDescricao().compareTo(o2.getDescricao());
    };
    Item key = new Item("");

    public void selectSingle(String name) {
        key.setDescricao(name);
        List<Item> exactModel = currentModel.getExactModel();
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            selectSingle(exactModel.get(index));
        }
        exactModel.clear();
    }

    public void selectSingle(Item item) {
        isSelecting = true;
        item.clickSingleSelection();
        isSelecting = false;
    }

    public void reverseSingleSelection(Item item) {
        isSelecting = true;
        selector.reverseSingleSelection(this, item);
        isSelecting = false;
    }

    public void multiSelect(List<String> names) {
        isSelecting = true;
        List<Item> exactModel = currentModel.getExactModel();
        for (String name : names) {
            key.setDescricao(name);
            int index = Collections.binarySearch(exactModel, key, c);
            if (index >= 0) {
                exactModel.get(index).clickMultiSelection();
            }
        }
        exactModel.clear();
        isSelecting = false;
    }

    public void multiSelect(String name) {
        isSelecting = true;
        List<Item> exactModel = currentModel.getExactModel();
        key.setDescricao(name);
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            exactModel.get(index).clickMultiSelection();
        }
        exactModel.clear();
        isSelecting = false;
    }

    public void unselect(String name) {
        key.setDescricao(name);
        List<Item> exactModel = currentModel.getExactModel();
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            Item i = exactModel.get(index);
            if (i.isSelected()) {
                isSelecting = true;
                i.clickSingleSelection();
                isSelecting = false;
            }
        }
        exactModel.clear();
    }

    public void unselectMulti(List<String> names) {
        isSelecting = true;
        List<Item> exactModel = currentModel.getExactModel();
        for (String name : names) {
            key.setDescricao(name);
            int index = Collections.binarySearch(exactModel, key, c);
            if (index >= 0) {
                Item i = exactModel.get(index);
                if (i.isSelected()) {
                    i.clickMultiSelection();
                }
            }
        }
        exactModel.clear();
        isSelecting = false;
    }

    public void unselectMulti(String name) {
        isSelecting = true;
        List<Item> exactModel = currentModel.getExactModel();
        key.setDescricao(name);
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            Item i = exactModel.get(index);
            if (i.isSelected()) {
                i.clickMultiSelection();
            }
        }
        exactModel.clear();
        isSelecting = false;
    }

    public void shake() {
        Node node = null;
        if (getChildren().contains(vBox)) {
            node = vBox;
        } else if (getChildren().contains(emptyList)) {
            node = emptyList;
        }

        FadeTransition ft = new FadeTransition(Duration.seconds(0.30), node);
        ft.setFromValue(0.0);
        ft.setToValue(1.0);
        ft.setOnFinished((e) -> {
            Node nodeRot = null;
            if (getChildren().contains(vBox)) {
                nodeRot = vBox;
            } else if (getChildren().contains(emptyList)) {
                nodeRot = emptyList;
            }
            RotateTransition rt = new RotateTransition(Duration.millis(100), nodeRot);
            rt.setAutoReverse(true);
            rt.setCycleCount(2);
            rt.setFromAngle(1);
            rt.setToAngle(-1);
            rt.setOnFinished((ee) -> {
                Node nodeRotF = null;
                if (getChildren().contains(vBox)) {
                    nodeRotF = vBox;
                } else if (getChildren().contains(emptyList)) {
                    nodeRotF = emptyList;
                }
                nodeRotF.setRotate(0);
            });
            rt.play();

        });
        ft.play();
    }

    public void block() {
        wrapper.block();
    }

    public void unblock() {
        wrapper.unblock();
    }

    public ContextMenu getContextMenu() {
        return contextMenu;
    }

    public StringProperty ON_EDITION() {
        return ON_EDITION;
    }

    public StringProperty ON_IMPORTING() {
        return ON_IMPORTING;
    }

    public StringProperty ON_UN_IMPORTING() {
        return ON_UN_IMPORTING;
    }

    public void edit(String oldValue, String newValue) {

        key.setDescricao(oldValue);
        List<Item> exactModel = currentModel.getExactModel();
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            edit(exactModel.get(index), newValue);
        } else {
            ON_EDITION.setValue(EDITING_FAILED_NO_MATCHING_FOUND);
        }
        exactModel.clear();

    }

    private void edit(Item item, String newValue) {

        new Thread(() -> {

            currentEditing = item;

            Platform.runLater(() -> {
                try {
                    wrapper.executeClientHookEditionLogic();
                } catch (Exception e) {
                    Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO EDITAR " + item.getDescricao(), e);
                    ON_EDITION.setValue(EDITING_FAILED_EXECUTING_CLIENT_HOOK_EDITING_LOGIC);
                    return;
                }

                currentModel.edit(item, newValue);

                ON_EDITION.setValue(EDITED);
            });
        }).start();

    }

    public void unimport(Item item) {

        key.setDescricao(item.getDescricao());
        List<Item> exactModel = currentModel.getExactModel();
        int index = Collections.binarySearch(exactModel, key, c);

        Platform.runLater(() -> {
            ON_UN_IMPORTING.setValue(UN_IMPORTING_STARTED);
        });

        if (index >= 0) {
            currentRemoving = item;
            try {
                wrapper.executeClientHookDeletionLogic();
            } catch (Exception e) {
                Platform.runLater(() -> {
                    ON_UN_IMPORTING.setValue(UN_IMPORTING_FAILED);
                });
                exactModel.clear();
                return;
            }
            currentModel.removeAndUpdateVisibleElements(item);
            singleRemoved = item.getDescricao();
            selector.handleDeletion(this, item);
            VScroller.doLayOutYAdjustAfterRemoving(this);
            Platform.runLater(() -> {
                ON_UN_IMPORTING.setValue(UN_IMPORTED);
            });
            exactModel.clear();
        }
    }

    volatile private boolean isImportingDone = false;

    public void imporT(Item item) throws Exception {

        isImportingDone = false;

        Platform.runLater(() -> {
            ON_IMPORTING.setValue(IMPORTING_STARTED);
        });

        key.setDescricao(item.getDescricao());
        List<Item> exactModel = currentModel.getExactModel();
        int index = Collections.binarySearch(exactModel, key, c);
        if (index >= 0) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO IMPORTAR:IMPORTING_FAILED_DUPLICATE_ENTRY:{0}", item.getDescricao());
            isImportingDone = true;
            Platform.runLater(() -> {
                ON_IMPORTING.setValue(IMPORTING_FAILED);
            });
            exactModel.clear();
            throw new Exception("Importing error:IMPORTING_FAILED_DUPLICATE_ENTRY:" + item.getDescricao());
        }

        try {
            wrapper.executeClientHookImportingLogic();
        } catch (Exception e) {
            isImportingDone = true;
            Platform.runLater(() -> {
                ON_IMPORTING.setValue(IMPORTING_FAILED);
            });
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO IMPORTAR:IMPORTING_FAILED_EXECUTING_CLIENT_HOOK_IMPORTING_LOGIC:" + item.getDescricao(), e);
            throw new Exception("Importing error:IMPORTING_FAILED_EXECUTING_CLIENT_HOOK_IMPORTING_LOGIC:" + item.getDescricao());
        }

        Platform.runLater(() -> {
            currentModel.addAndUpdateVisibleElements(item);
            isImportingDone = true;
            ON_IMPORTING.setValue(IMPORTED);
        });

    }

    /**
     * DES importa a coleção de itens.<br>
     * A colecao é liberada para GC neste método.
     *
     * @param itens
     * @throws Exception
     */
    public void unimport(Collection<Item> itens) throws Exception {

        Platform.runLater(() -> {
            ON_UN_IMPORTING.setValue(UN_IMPORTING_STARTED);
        });

        try {
            wrapper.executeClientHookBulkUnImportingLogic(itens);
        } catch (Exception e) {
            itens.clear();
            Util.GC();
            Platform.runLater(() -> {
                ON_UN_IMPORTING.setValue(UN_IMPORTING_FAILED);
            });
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO DES-IMPORTAR:UN_IMPORTING_FAILED_EXECUTING_CLIENT_BULK_HOOK_UN_IMPORTING_LOGIC:size" + itens.size(), e);
            throw new Exception("Importing error:UN_IMPORTING_FAILED_EXECUTING_CLIENT_BULK_HOOK_UN_IMPORTING_LOGIC:size" + itens.size());
        }

        Platform.runLater(() -> {
            currentModel.doBulkUnImporting(itens);
            ON_UN_IMPORTING.setValue(UN_IMPORTED);
            itens.clear();
            Util.GC();
        });

    }

    /**
     * Importa a coleção de itens.<br>
     * A colecao é liberada para GC neste método.
     *
     * @param itens
     * @throws Exception
     */
    public void imporT(Collection<Item> itens) throws Exception {

        isImportingDone = false;

        Platform.runLater(() -> {
            ON_IMPORTING.setValue(IMPORTING_STARTED);
        });

        try {
            wrapper.executeClientHookBulkImportingLogic(itens);
        } catch (Exception e) {
            isImportingDone = true;
            itens.clear();
            Util.GC();
            Platform.runLater(() -> {
                ON_IMPORTING.setValue(IMPORTING_FAILED);
            });
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "ERRO AO IMPORTAR:IMPORTING_FAILED_EXECUTING_CLIENT_BULK_HOOK_IMPORTING_LOGIC:size" + itens.size(), e);
            throw new Exception("Importing error:IMPORTING_FAILED_EXECUTING_CLIENT_BULK_HOOK_IMPORTING_LOGIC:size" + itens.size());
        }

        Platform.runLater(() -> {
            currentModel.doBulkImporting(itens);
            isImportingDone = true;
            itens.clear();
            Util.GC();
            ON_IMPORTING.setValue(IMPORTED);
        });

    }

    public boolean isImportingDone() {
        return isImportingDone;
    }

    public void exportSelected() {
        if (!selection.isEmpty()) {
            try {
                wrapper.executeClientHookExportingLogic();
            } catch (Exception ex) {
                Logger.getLogger(ScrollableListContainerSimple.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void printSelected() {
        if (!selection.isEmpty()) {
            try {
                wrapper.executeClientHookPrintingLogic();
            } catch (Exception ex) {
                Logger.getLogger(ScrollableListContainerSimple.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void setClickedItem(Item aThis) {
        this.clickedItem = aThis;
    }

}
