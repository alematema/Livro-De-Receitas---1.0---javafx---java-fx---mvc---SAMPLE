package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import javafx.scene.Group;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * A simple scrollable list. 
 * <br>
 * No header, no searching power.
 * @author alexandre
 */
public class ScrollableListContainer extends ScrollableListContainerSimple{
    
    public ScrollableListContainer(VerticalScrollableListWrapper wrapper) {
        super("FXMLScrollableVBox.fxml",wrapper);
        ((Group)getChildren().get(1)).getChildren().remove(getHeader());
        getHeader().setVisible(false);
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
        add();
    }
    
//
    
}
