package br.com.undra.jfxcomponents.scrollablelist.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.input.MouseEvent;

/**
 * Modela um seletor de itens.<br>
 * MODES :
 * <br>NO SELECTION MODE<br>
 * SINGLE SELECTION MODE<br>
 * MULTI SELECTION MODE
 *
 * @author alexandre
 */
@Deprecated
public class SelectorOld {

    static String NO_SELECTION = "NO_SELECTION";
    static public String SINGLE_SELECTION = "SINGLE_SELECTION";
    static public String MULTI_SELECTION = "MULTI_SELECTION";
    private String currentMode = SINGLE_SELECTION;

    public static boolean allSelected;

    public void handleSelection(ScrollableListContainerSimple container, MouseEvent event, Item item) {

        if (!event.isControlDown()) {

            handleSingleSelection(container, item);

        } else {

            handleMultiSelection(container, item);

        }

    }

    private void handleMultiSelection(ScrollableListContainerSimple container, Item item) {

        if (currentMode.equals(SINGLE_SELECTION) && !container.getSelection().isEmpty()) {

            currentMode = MULTI_SELECTION;

            item.setSelected(true);
            container.getSelection().add(item);
            container.getSelection().get(0).setSelected(false);
            container.getSelection().remove(0);

        } else {

            item.setSelected(true);
            container.getSelection().add(item);
            currentMode = MULTI_SELECTION;

        }
    }

    private final List<Item> tmpSelection = new ArrayList<>();

    private void handleSingleSelection(ScrollableListContainerSimple container, Item item) {
        //recupera ultimo selecionado, caso exista
        if (!container.getSelection().isEmpty()) {

            if (container.getSelection().size() > 1) {//MULTISELECTION ANTERIOR. SERA DESFEITA

                container.getSelection().forEach((e) -> {
                    e.setSelected(false);
                });
                item.setSelected(true);
                container.getSelection().add(item);
                tmpSelection.clear();
                tmpSelection.addAll(container.getSelection());
                tmpSelection.parallelStream().filter((selected) -> (!selected.equals(item))).forEachOrdered((selected) -> {
                    container.getSelection().remove(selected);
                });
                currentMode = SINGLE_SELECTION;

            } else {

                item.setSelected(true);
                container.getSelection().add(item);
                container.getSelection().get(0).setSelected(false);
                container.getSelection().remove(0);

                currentMode = SINGLE_SELECTION;

            }

        } else {//NAO HAVIA ALGUM SELECIONADO

            item.setSelected(true);
            container.getSelection().add(item);
            currentMode = SINGLE_SELECTION;

        }
    }

    public void selectAll(ScrollableListContainerSimple container) {

        currentMode = MULTI_SELECTION;

        if (container.getSelection().isEmpty()) {

            container.getCurrentModel().getChangefulModel().forEach(i -> i.clickSelectingOnly());
            container.getSelection().addAll(container.getCurrentModel().getChangefulModel());

        } else {

            container.getCurrentModel().getChangefulModel().forEach(i -> {

                if (!container.getSelection().contains(i)) {
                    i.clickSelectingOnly();
                    container.getSelection().add(i);
                }

            });
        }

        InfoUpdater.updateAfterAllSelected(container);

    }

    public String getCurrentMode() {
        return currentMode;
    }
    
    public void unSelectAll(ScrollableListContainerSimple container) {
        currentMode = SINGLE_SELECTION;
        container.getSelection().clear();
        container.getCurrentModel().getChangefulModel().forEach(i -> i.clickUnSelectingOnly());
        InfoUpdater.updateAfterAllUnSelected(container);
    }

    public boolean isAllSelected(ScrollableListContainerSimple container) {
        return container.getSelection().size() == container.getCurrentModel().size();
    }

    public boolean noneSelected(ScrollableListContainerSimple container) {
        return container.getSelection().isEmpty();
    }
}
