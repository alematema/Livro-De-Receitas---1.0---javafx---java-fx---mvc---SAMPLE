package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import java.util.ArrayList;
import java.util.Collection;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import static javafx.scene.input.KeyCode.CONTROL;
import javafx.scene.input.KeyEvent;

/**
 * The scrollable list's key listener
 *
 * @author alexandre
 */
public class ScrollableListKeyListener implements EventHandler<KeyEvent> {

    private final Node container;

    public ScrollableListKeyListener(Node container) {
        this.container = container;
    }

    public volatile boolean isCtrlKey = false;
    public volatile boolean isShiftKey = false;
    public volatile boolean isArrowDonw = false;
    public volatile boolean isArrowUp = false;

    @Override
    public void handle(KeyEvent e) {

        System.err.println(e);
        
        ScrollableListContainerSimple notFullContainer = (ScrollableListContainerSimple) container;

        if (e.getCode() == KeyCode.ESCAPE) {
            handle_ESCAPE_KEY(notFullContainer, e);
            return;
        }

        if (isCtrlKey && e.getCode() == KeyCode.A) {
            handle_A_KEY(notFullContainer);
            return;
        }

        //Para criar nova receita usando CTRL + N
        if (isCtrlKey && e.getCode() == KeyCode.N) {
            handle_N_KEY(notFullContainer);
            return;
        }
        //Para focar pesquisa  usando CTRL + F
        if (isCtrlKey && e.getCode() == KeyCode.F) {
            handle_F_KEY();
            return;
        }
        //Para abrir menu aparencia e pesquisa 
        if (isCtrlKey && e.getCode() == KeyCode.Q) {
            handle_Q_KEY(notFullContainer);
            return;
        }

        switch (e.getCode()) {
            case CONTROL:
                isCtrlKey = true;
                break;

            case SHIFT:
                isShiftKey = true;
                break;
            case DELETE:
                notFullContainer.removeAllSelected();
                break;
            case PAGE_DOWN:
                Platform.runLater(() -> {
                    VScroller.handleScrolling(notFullContainer, 240);
                    notFullContainer.requestFocus();
                });
                break;
            case PAGE_UP:
                Platform.runLater(() -> {
                    VScroller.handleScrolling(notFullContainer, -240);
                    notFullContainer.requestFocus();
                });
                break;
            case DOWN:
                if (isShiftKey) {
                    handle_ARROW_DOWN_MULTI_SELECTION(notFullContainer);
                } else {
                    handle_ARROW_DOWN(notFullContainer);
                }
                break;
            case UP:
                if (isShiftKey) {
                    handle_ARROW_UP_MULTI_SELECTION(notFullContainer);
                } else {
                    handle_ARROW_UP(notFullContainer);
                }
                break;
            case HOME:
                Platform.runLater(() -> {
                    VScroller.home(notFullContainer);
                    notFullContainer.requestFocus();
                });
                break;
            case END:
                Platform.runLater(() -> {
                    VScroller.end(notFullContainer);
                    notFullContainer.requestFocus();
                });
                break;

            default:
                break;
        }
    }

    /**
     * Scrolla lista para CIMA.
     *
     * @param selectableContainer
     */
    private void handle_ARROW_UP(ScrollableListContainerSimple selectableContainer) {
        if (selectableContainer != null) {
            Platform.runLater(() -> {
                VScroller.handleScrolling(selectableContainer, -VScroller.POSITIVE_DELTA_Y_MIN);
                selectableContainer.requestFocus();

            });
        }
        if (container instanceof ScrollableListContainerFull) {
            if (((ScrollableListContainerFull) container).getSearcherField().isFocused()) {
                Platform.runLater(() -> {
                    VScroller.handleScrolling(((ScrollableListContainerFull) container), -VScroller.POSITIVE_DELTA_Y_MIN);
                    ((ScrollableListContainerFull) container).requestFocus();
                });
            }
        }
    }

    /**
     * Scrolla lista para BAIXO.
     *
     * @param selectableContainer
     */
    private void handle_ARROW_DOWN(ScrollableListContainerSimple selectableContainer) {

        //when container is focused
        if (selectableContainer != null) {
            Platform.runLater(() -> {
                VScroller.handleScrolling(selectableContainer, VScroller.POSITIVE_DELTA_Y_MIN);
                selectableContainer.requestFocus();

            });
        }

        if (container instanceof ScrollableListContainerFull) {
            if (((ScrollableListContainerFull) container).getSearcherField().isFocused()) {
                Platform.runLater(() -> {
                    VScroller.handleScrolling(((ScrollableListContainerFull) container), VScroller.POSITIVE_DELTA_Y_MIN);
                    ((ScrollableListContainerFull) container).requestFocus();
                });
            }
        }
    }

    /**
     * Ctrl + F : focuses the searcher.
     */
    private void handle_F_KEY() {
        isCtrlKey = false;
        Platform.runLater(() -> {
            //
            if (container instanceof ScrollableListContainerFull) {
                ScrollableListContainerFull selectableFullContainer = (ScrollableListContainerFull) container;
                selectableFullContainer.getSearcherContainer().getSearchField().requestFocus();
            }
        });
    }

    /**
     * Ctrl + Q : opens/closes configuration menu.
     */
    private void handle_Q_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        Platform.runLater(() -> {
            selectableContainer.handleSettingsMouseClicked(null);
        });
    }

    /**
     * Ctrl + N : New object.
     */
    private void handle_N_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        Platform.runLater(() -> {
            selectableContainer.handleAddItemMouseClicked(null);
        });
    }

    /**
     * Ctrl + A : All objects are selected, if container has focus.
     */
    private void handle_A_KEY(ScrollableListContainerSimple selectableContainer) {
        isCtrlKey = false;
        selectableContainer.selectAll();
    }

    /**
     * Esc key : ...
     */
    private void handle_ESCAPE_KEY(ScrollableListContainerSimple selectableContainer, KeyEvent e) {
        selectableContainer.closeContextMenu();
        selectableContainer.closeMenu();
        Platform.runLater(() -> {

            if (container instanceof ScrollableListContainerFull) {
                /**
                 * Limpa campo de pesquisa do searcher container quando
                 * ESC(escape) event é capturada pelo global screen listener.
                 *
                 * @param event
                 */
                ScrollableListContainerFull selectableFullContainer = (ScrollableListContainerFull) container;
                selectableFullContainer.getSearcherContainer().handleScapeFromGlobalScreenListener(e);

                selectableFullContainer.requestFocus();

                if (!selectableFullContainer.getSearcherField().isFocused()) {
                    selectableFullContainer.unSelectAll();
                }

                selectableFullContainer.requestFocus();

            } else {
                selectableContainer.unSelectAll();
                selectableContainer.requestFocus();
            }
        });
    }

    Collection<String> names = new ArrayList<>();

    public volatile ScrollableListItem lastModifiedItem;
    private volatile boolean ARROW_UP = false;

    private void handle_ARROW_DOWN_MULTI_SELECTION(ScrollableListContainerSimple selectableContainer) {

        Platform.runLater(() -> {

            if (isArrowUp) {
                handleOppositeDirectionBefore(selectableContainer);
                isArrowUp = false;
                return;
            }

            if (selectableContainer.getCurrentModel().size() == 0) {
                return;
            }
            ARROW_UP = false;
            Item current = handleMultiSelection(selectableContainer, ARROW_UP);
            lastModifiedItem = current;
            isArrowDonw = true;
        }
        );

    }

    private Item handleMultiSelection(ScrollableListContainerSimple selectableContainer, boolean ARROW_UP) {
        selectableContainer.getSelector().prepareForShiftMultiSelection();
        Item current = selectableContainer.getSelector().getCurrent();
        ScrollableList<Item> currentModel = selectableContainer.getCurrentModel();
        if (current != null) {

            if (ARROW_UP) {

                if (currentModel.hasBefore(current)) {
                    selectableContainer.multiSelect(currentModel.getBefore(current).getName());
                    current = selectableContainer.getSelector().getCurrent();
                    if (!currentModel.isVisible(current)) {
                        currentModel.scrollDown();
                    }
                }

            } else {
                
                if (currentModel.hasNext(current)) {
                    selectableContainer.multiSelect(currentModel.getNext(current).getName());
                    current = selectableContainer.getSelector().getCurrent();
                    if (!currentModel.isVisible(current)) {
                        currentModel.scrollUp();
                    }
                }
            }

        } else {
            current = currentModel.getTheMidleVisible();
            if (current != null) {
                selectableContainer.multiSelect(current.getName());
            }
        }
        if (container instanceof ScrollableListContainerFull) {
            ((ScrollableListContainerFull) container).requestFocus();
        }
        return current;
    }

    private void handle_ARROW_UP_MULTI_SELECTION(ScrollableListContainerSimple selectableContainer) {

        Platform.runLater(() -> {

            if (isArrowDonw) {
                handleOppositeDirectionBefore(selectableContainer);
                isArrowDonw = false;
                return;
            }

            if (selectableContainer.getCurrentModel().size() == 0) {
                return;
            }

            ARROW_UP = true;
            lastModifiedItem = handleMultiSelection(selectableContainer, ARROW_UP);
            isArrowUp = true;
        });

    }

    private void handleOppositeDirectionBefore(ScrollableListContainerSimple selectableContainer) {
        if (lastModifiedItem != null) {
            selectableContainer.unselectMulti(lastModifiedItem.getName());
        }
        if (container instanceof ScrollableListContainerFull) {
            ((ScrollableListContainerFull) container).requestFocus();
        }
    }

}
