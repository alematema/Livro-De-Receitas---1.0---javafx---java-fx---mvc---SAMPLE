package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import br.com.undra.jfxcomponents.menus.SearchingMenu;
import br.com.undra.jfxcomponents.menus.context.ContextMenu;
import br.com.undra.jfxcomponents.menus.context.ContextMenuArrowDown;
import static br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple.MIDLE_WINDOW_HEIGHT;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.searcher.Criteria;
import br.com.undra.jfxcomponents.searcher.Searcher;
import br.com.undra.jfxcomponents.searcher.SearcherContainer;
import br.com.undra.jfxcomponents.scrollablelist.util.InfoUpdater;
import br.com.undra.jfxcomponents.util.Util;
import java.util.Collection;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.text.Text;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * A scrollable list with searching power and a header.
 *
 * @author alexandre
 */
public class ScrollableListContainerFull extends ScrollableListContainerSimple {

    private final SearcherContainer searcherContainer;

    private final ScrollableList<Item> searchingResultModel = new ScrollableList<>();

    private ChangeListener scrollableFullWidthListener;

    public ScrollableListContainerFull(SearcherContainer searcherContainer, VerticalScrollableListWrapper wrapper) {

        super("FXMLScrollableFull.fxml", wrapper);

        this.searcherContainer = searcherContainer;
//        searcherContainer.setScrollableListContainer(this);

        scrollableContainerHeader.getChildren().remove(menu);
        scrollableContainerHeader.setId("scrollableContainerHeader");

        menu = new SearchingMenu(this);
        searcherContainer.getChildren().add(menu);
        menu.setVisible(false);
        
        menu.handleMouseClicked(event);
        
        //default look and feel
        menu.getOnOffBordaRedonda().setGlyphName("TOGGLE_OFF");
        Text currentTema = new Text();
        currentTema.setId(Util.PROPERTIES.getProperty("default-theme").split(",")[1] + "Text");
        menu.changeCss(currentTema);
        menu.getOnOffListaCompactaIcon().setGlyphName("TOGGLE_ON");
        menu.toggleCompactList(menu.getOnOffListaCompactaIcon());
                     
//        menu.toBack();
        menu.setLayoutY(13);
        menu.setLayoutX(scrollableContainerHeader.widthProperty().doubleValue() + 10);

        contextMenuUpArrow = new ContextMenu(this);
        getChildren().remove(contextMenu);
        setUpContextMenu(contextMenuUpArrow);
        contextMenuArrowDown = new ContextMenuArrowDown(this);

        scrollableContainerHeader.getChildren().remove(settingsIcon);

        scrollableContainerHeader.setVisible(true);
        searcherContainer.getChildren().add(settingsIcon);

        Tooltip.uninstall(settingsIcon, settingsTooltip);
        settingsTooltip = new Tooltip(String.format(Util.getPROPERTIES(wrapper).getProperty("settingsFullTooltip"),Util.PROPERTIES.getProperty("settings.menu.shortcut")));
        Tooltip.install(settingsIcon, settingsTooltip);
        settingsTooltip.setFont(toolTipsFont);

        VScroller.doVBoxLayOutYTopStraightAdjust(this);

        searcherContainer.getSearcher().setCriteria(Criteria.SIMPLE_SEARCH);

        offHeights = 40;

        doBindingsAndListenings(searcherContainer);

    }

    Item stationaryItem;

    private void doBindingsAndListenings(SearcherContainer searcherContainer1) {

        scrollableFullWidthListener = (observable, oldValue, newValue) -> {
            menu.setLayoutX((Double) newValue - Double.parseDouble(settingsIcon.getSize()) - menu.getPrefWidth() - 5);
            InfoUpdater.doInfoLabelAdjustments(this);
            settingsIcon.setLayoutX(searcherContainer.getWidth() - Double.parseDouble(settingsIcon.getSize()) - 5);
        };

        getHeader().widthProperty().removeListener(scrollableFullWidthListener);
        getHeader().widthProperty().addListener(scrollableFullWidthListener);

        searcherContainer.getSearcher().getState().addListener((observable, oldValue, newValue) -> {
            if (newValue.equals(Searcher.SEARCHING_DONE)) {
                handle_SEARCHING_DONE();
            } else if (newValue.equals(Searcher.SEARCHING_CANCELED)) {
                handle_SEARCHING_CANCELED();
            } else if (newValue.equals(Searcher.SETUP_BEFORE_SEARCHING)) {
                handle_SETUP_BEFORE_SEARCHING();
            }
        });

        searcherContainer.heightProperty().addListener((observable, oldValue, newValue) -> {
            settingsIcon.setLayoutY((searcherContainer.getHeight() + Double.parseDouble(settingsIcon.getSize())) / 2 - 2);
        });

        heightProperty().addListener((observable, oldValue, newValue) -> {
            emptyList.setPrefHeight(newValue.doubleValue() - searcherContainer.getPrefHeight() - scrollableContainerHeader.getPrefHeight());
            emptyList.setLayoutY(scrollableContainerHeader.getPrefHeight());
        });

    }

    private void handle_SETUP_BEFORE_SEARCHING() {
        searcherContainer.getSearcher().setSearchingSpace(getCurrentModel().getSearchingSpace());
        setUpBeforeSearching();
    }

    private void handle_SEARCHING_CANCELED() {
        setUpAfterSearching();
        currentModel.firstVisible();
        stationaryItem = null;
        if (getWrapper().getAppCurrentItemSelected() != null) {
            key.setDescricao(getWrapper().getAppCurrentItemSelected());
            int index = Collections.binarySearch(currentModel.get(), key, c);
            if (index >= 0) {
                stationaryItem = currentModel.get(index);
            }
        }
        if (stationaryItem == null) {
            stationaryItem = getCurrentSelected();
        }
        if (stationaryItem != null) {

            InfoUpdater.updateAfterSelected(this, stationaryItem);

            new Thread(() -> {

                try {
                    int sleep = 100;
                    while (currentModel.isBefore(currentModel.getVisibleElements().get(0), stationaryItem)) {

                        currentModel.scrollUp();

                        if (currentModel.isAfter(getCurrentSelected(), currentModel.getLastVisibleElement())) {
                            updateVBox();
                        } else {
                            Thread.sleep(sleep);
                            Platform.runLater(() -> {
                                updateVBox();
                                requestFocus();

                            });
                            sleep += 20;
                        }
                    }
                } catch (InterruptedException ex) {
                    Logger.getLogger(ScrollableListContainerFull.class.getName()).log(Level.SEVERE, null, ex);
                }

            }).start();
        }
    }

    private void handle_SEARCHING_DONE() {
        addAsSearchingResult(searcherContainer.getSearcher().getSearchingResult());
        if (searcherContainer.getSearcher().getSearchingResult().isEmpty()) {
            updateVBox();
        }
    }

    @Override
    public void closeMenu() {
        menu.setVisible(false);
    }

//    @Override
//    public void remove(Item item) throws Exception {
//        super.remove(item);
//        searchingResultModel.removeAndUpdateVisibleElements(item);
//        VScroller.doLayOutYAdjustAfterRemoving(this);
//    }
    public void setUpBeforeSearching() {
        getWrapper().setUpBeforeSearching();
        scrollableListAddItemIconContainer.setDisable(true);
        scrollableListAddItemIconContainer.setOpacity(0.01);
        VScroller.doLayOutYAdjustAfterRemoving(this);
    }

    public void setUpAfterSearching() {
        getWrapper().setUpAfterSearching();
        scrollableListAddItemIconContainer.setDisable(false);
        scrollableListAddItemIconContainer.setOpacity(1);
        VScroller.doLayOutYAdjustAfterRemoving(this);
    }

    public void setSimpleSearchingCriteria() {
        searcherContainer.getSearcher().setCriteria(Criteria.SIMPLE_SEARCH);
        searcherContainer.handleSearching();
    }

    public void setExactWordMatchingCriteria() {
        searcherContainer.getSearcher().setCriteria(Criteria.EXACT_WORD_MATCH_SEARCH);
        searcherContainer.handleSearching();
    }

    public ScrollableList<Item> getSearchingResultModel() {
        return searchingResultModel;
    }

    public void addAsSearchingResult(Collection<Item> list) {

        currentModel.addAsSearchingResult(list);
        InfoUpdater.updateAfterSearching(this);

    }

    TextField getSearcherField() {
        return searcherContainer.getSearchField();
    }

    public SearcherContainer getSearcherContainer() {
        return searcherContainer;
    }

    
}
