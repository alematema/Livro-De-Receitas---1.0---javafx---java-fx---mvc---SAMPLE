package br.com.undra.jfxcomponents.scrollablelist.mvc.controller;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;

/**
 * Blocks a scroller, disabling key events and mouse events.
 * @author alexandre
 */
public class Blocker extends Pane{

    public Blocker() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLBlocker.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }
}
