package br.com.undra.jfxcomponents.scrollablelist.mvc.controller;

import br.com.undra.jfxcomponents.menus.context.ContextMenu;
import br.com.undra.jfxcomponents.menus.context.ContextMenuArrowDown;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.EmptyList;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerFull;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.searcher.SearcherContainer;
import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.services.persistence.PersistenceService;
import br.com.undra.livrodereceitas.services.persistence.PersistenceServiceImpl_JDBC_SQLITE;
import java.util.Collection;
import java.util.List;
import java.util.Properties;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.property.StringProperty;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventTarget;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

/**
 * A full scroller:with searching power and header.
 *
 * @author alexandre
 */
public class FullVerticalScrollableListWrapperImpl extends Pane implements VerticalScrollableListWrapper {

    public static int nextId = 0;

    final SearcherContainer<Item> searcherContainer;
    ScrollableListContainerFull container;
    public final Blocker blocker;

    PersistenceService<Receita> persistenceService;

    ScaleTransition scaleTransition;

    EventHandler<? super Event> onMouseClickHandler = (event) -> {

        try {

            EventTarget target = event.getTarget();
            Pane header = (Pane) event.getTarget();
            String headerId = "scrollableContainerHeader";
            if (header.getId().equals(headerId)) {
                if (scaleTransition != null) {
                    scaleTransition.play();
                }
            } else {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, "Esperado id=" + headerId + " mas, veio " + header.getId());
            }
        } catch (Exception e) {

        } finally {

        }

    };

    public FullVerticalScrollableListWrapperImpl() {
        registre();

        persistenceService = PersistenceServiceImpl_JDBC_SQLITE.getInstace();

        searcherContainer = new SearcherContainer<>();
        container = new ScrollableListContainerFull(searcherContainer, this);
        container.setWrapper(this);
        searcherContainer.setScrollableContainer(container);
        searcherContainer.getCancelSearchingIconTooltip().setFont(container.getToolTipsFont());

        blocker = new Blocker();
        blocker.setVisible(false);

        getChildren().add(searcherContainer);
        getChildren().add(container);
        getChildren().add(blocker);

        prefWidthProperty().addListener((observable, oldValue, newValue) -> {
            blocker.setPrefWidth(newValue.doubleValue());
        });
        prefHeightProperty().addListener(((observable, oldValue, newValue) -> {
//            blocker.setPrefHeight(newValue.doubleValue());
            blocker.setPrefHeight(newValue.doubleValue() + searcherContainer.getPrefHeight());
        }));

        scaleTransition = new ScaleTransition(Duration.seconds(0.15), this);
        scaleTransition.setAutoReverse(true);
        scaleTransition.setCycleCount(2);
        scaleTransition.setFromX(1.0);
        scaleTransition.setToX(0.98);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToY(0.998);
        scaleTransition.setOnFinished((event) -> {
            scaleTransition.pause();
        });

        container.getStatusMessageLbl().setVisible(false);

        setOnMouseClicked(onMouseClickHandler);
        
    }

    @Override
    public void unSelectAll() {
        container.unSelectAll();
    }

    @Override
    public void setCena(Scene scene) {
        container.setCena(scene);
    }

    @Override
    public void setUp(Object parent) {

        prefWidthProperty().bind(((Scene) parent).widthProperty().divide(4));
        prefHeightProperty().bind(((Scene) parent).heightProperty());

        VBox lista = container.getVBox();
        lista.prefWidthProperty().bind(this.widthProperty());
        lista.prefHeightProperty().bind(this.heightProperty());

        container.prefWidthProperty().bind(this.widthProperty());
        container.prefHeightProperty().bind(this.heightProperty());
        searcherContainer.prefWidthProperty().bind(this.widthProperty());

        container.getMenu().getOnOffBordaRedonda().setGlyphName("TOGGLE_OFF");
        container.setUp(((Scene) parent).getWindow().getHeight(), "glass-theme");
//        container.setCompactList(((Scene) parent).getWindow().getHeight());;

        container.setLayoutY(searcherContainer.getHeight());
        searcherContainer.toFront();
        container.requestFocus();
    }

    @Override
    public void setUpBeforeLoading() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("loadingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("loadingObjects"));
        container.getCurrentModel().cleanBeforeLoading();
    }

    @Override
    public void setUpAfterLoading() {
        container.getCurrentModel().loadingDone();
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("loadingObjects"));
    }

    @Override
    public void setUpBeforeSelectingAll() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("selectingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("selectingObjects"));
    }

    @Override
    public void setUpAfterSelectingAll() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("selectingObjects"));
    }

    @Override
    public void setUpBeforeInvertSelection() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("inverting.selection"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("inverting.selection"));
    }

    @Override
    public void setUpAfterInvertSelection() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("inverting.selection"));
    }

    @Override
    public void setUpBeforeRemoveMultiSelection() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("removingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("removingObjects"));
    }

    @Override
    public void setUpAfterRemoveMultiSelection() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("removingObjects"));
    }

    @Override
    public void setUpBeforeImporting() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("importingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("importingObjects"));
    }

    @Override
    public void setUpAfterImporting() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("importingObjects"));
    }

    @Override
    public void setUpBeforeUnImporting() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("unimportingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("unimportingObjects"));
    }

    @Override
    public void setUpAfterUnImporting() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("unimportingObjects"));
    }

    @Override
    public void setUpBeforeExporting() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("exporingObjects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("exporingObjects"));
    }

    @Override
    public void setUpAfterExporting() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("exporingObjects"));
    }

    @Override
    public void setUpBeforePrinting() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSelectingAllOrLoading(false);
        container.getAddItemIcon().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("printingPreparingObjects"));
    }

    @Override
    public void setUpAfterPrinting() {
        setProgressValue(0);
        container.getSearcherContainer().setForSelectingAllOrLoading(true);
        container.getAddItemIcon().setVisible(true);
        container.getStatusMessageLbl().setVisible(false);
        container.setStatusMessage("");
    }

    @Override
    public void setUpBeforeSearching() {
        container.getAddItemIcon().setVisible(false);
        container.getSearcherContainer().setForSearching(false);
        container.getScrollableListInfoIconContainer().setVisible(false);
        container.getScrollableListInfoLabelContainer().setVisible(false);
        container.getStatusMessageLbl().setVisible(true);
//        container.setStatusMessage(Util.getPROPERTIES(this).getProperty("searching.objects"));
        Util.buildAndSetStatusMessage(container, Util.getPROPERTIES(this).getProperty("searching.objects"));
    }

    @Override
    public void setUpAfterSearching() {
        container.getAddItemIcon().setVisible(true);
        container.getSearcherContainer().setForSearching(true);
//        container.getStatusMessageLbl().setVisible(false);
        Util.destroyMessageAtStatusMessage(container, Util.getPROPERTIES(this).getProperty("searching.objects"));
        container.getScrollableListInfoIconContainer().setVisible(true);
        container.getScrollableListInfoLabelContainer().setVisible(true);
    }

    @Override
    public SearcherContainer<Item> getSearcherContainer() {
        return searcherContainer;
    }

    @Override
    public ScrollableListContainerFull getView() {
        return container;
    }

    @Override
    public Collection<String> getMultiSelectionRemoved() {
        return container.getMultiSelectionRemoved();
    }

    @Override
    public String getSingleRemoved() {
        return container.getSingleRemoved();
    }

    @Override
    public Item getCurrentSelected() {
        return container.getCurrentSelected();
    }

    @Override
    public Item getCurrentUnselected() {
        return container.getCurrentUnselected();
    }

    @Override
    public Item getCurrentAdding() {
        return container.getCurrentAdding();
    }

    @Override
    public Item getCurrentRemoving() {
        return container.getCurrentRemoving();
    }

    @Override
    public Item getCurrentEdited() {
        return container.getCurrentEditing();
    }

    @Override
    public ContextMenuArrowDown getContextMenuArrowDown() {
        return container.getContextMenuArrowDown();
    }

    @Override
    public ContextMenu getContextMenuUpArrow() {
        return container.getContextMenuUpArrow();
    }

    @Override
    public Collection<Item> getExcludables(Collection<Item> selection) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Item> getUNexcludables(Collection<Item> selection) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Gets The extra NODES, in witch,for instace,<br>
     * will be css applyied.
     *
     * @return the extra nodes.
     */
    @Override
    public List<Node> getExtras() {
        return container.getExtras();
    }

    public EmptyList getEmptyListPage() {
        return container.getEmptyListPage();
    }

    @Override
    public String getAppCurrentItemSelected() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * A property that listens to adding events.<br>
     * It decouples clients from this component by letting them<br>
     * listen to events and take properly actions.<br>
     * An event can be :<br>
     * <br><b> ON_ADD_REQUEST</b>, triggered when icon ⊕ is clicked, or by CTRL
     * + N shortcut.
     * <br> <b>ADDED</b>, triggered when a new item is add to the component's
     * list.
     * <br> <b>ADDING_CANCELED</b>, triggered by the client when client cancels
     * addind.
     * <br> <b>ADDING_FAILED_DUPLICATE_ENTRY</b>, triggered when a client
     * attempts to add a duplicated item into the components's list<br>
     * ie, an item wich description field is equals to some item's description
     * in the list.
     * <br> <b>ADDING_FAILED_EXECUTING_CLIENT_HOOK_ADDING_LOGIC</b>, triggered
     * when an adding logic client hook fails.
     * <br> <b>ADDING_FAILED_EXECUTING_DELETION_LOGIC_CLIENT_HOOK</b>, triggered
     * when a deleting logic client hook fails.
     *
     * @return a string representing the occured adding event.
     */
    @Override
    public StringProperty ON_ADDITION() {
        return container.ON_ADDITION();
    }

    /**
     * A property that listens to item's deletion events.<br>
     * It decouples clients from this component by letting them<br>
     * listen to events and take properly actions.<br>
     * An event can be :<br>
     * <br><b> REMOVING_SINGLE_SELECTION</b>, triggered when a single item is
     * about to removed.
     * <br> <b>SINGLE_SELECTION_REMOVED</b>, triggered when a single item was
     * removed.
     * <br> <b>REMOVING_MULTI_SELECTION</b>, triggered when one or more
     * itens(item) are(is) about to be removed.
     * <br> These itens(item) were(was) previously selected through CTRL + CLICK
     * ou CTRL + A or by CONTEXT MENU select all option.
     * <br> <b>MULTI_SELECTION_REMOVED</b>,triggered when an item was
     * removed.<br>
     * The item was previously selected through CTRL + CLICK or CTRL + A or by
     * CONTEXT MENU select all option.
     * <br><b> MULTI_SELECTION_DELETION_STARTED</b>, triggered when a bulk
     * deletion has started.
     * <br><b> MULTI_SELECTION_DELETION_COMPLETED</b>, triggered a bulk deletion
     * has completed.
     *
     * @return a string representing the occured deletion event.
     */
    @Override
    public StringProperty ON_DELETION() {
        return container.ON_DELETION();
    }

    /**
     * A property that listens to item's selection events.<br>
     * It decouples clients from this component by letting them<br>
     * listen to events and take properly actions.<br>
     * An event can be :<br>
     * <br><b> NO_SELECTION</b>, triggered when no item is selected.
     * <br> <b>SINGLE_SELECTION</b>, triggered when a single item is selected,
     * by simple clicking it.
     * <br> <b>SINGLE_SELECTION_CHANGED</b>, triggered when previous selected
     * item is unselected.
     * <br> <b>SINGLE_SELECTION_REMOVED</b>, triggered when CLICK a selected
     * item.
     * <br> <b>MULTI_SELECTION</b>, triggered after CTRL + CLICK in any
     * UNselected item.
     * <br><b> MULTI_SELECTION_ADDED</b>, triggered when CTRL + CLICK in any
     * UNselected item..
     * <br><b> MULTI_SELECTION_REMOVED</b>, triggered when CRTL + CLICK at a
     * previous multi selected item OR a item was DELETE from a multi selection.
     * <br><b> MULTI_SELECTION_CHANGED</b>, triggered when CTRL + CLICK at a non
     * selected item, and there was at least one multi selected.
     * <br><b> SINGLE_TO_MULTI_SELECTION_CHANGED</b>, triggered when CTRL +
     * CLICK at a single selected item.
     * <br> <b>SELECTING_ALL</b>, triggered after CRTL + A, or by CONTEXT MENU
     * select all option.
     * <br> <b>SELECTED_ALL</b>, triggered after all itens selected by
     * combination CTRL + A ou by CONTEXT MENU select all option.
     * <br> <b>UNSELECTED_ALL</b>, triggered after all itens have been
     * UNSELECTED.
     *
     * @return a string representing the occured selection event.
     */
    @Override
    public StringProperty ON_SELECTION() {
        return container.getSelector().getSTATE();
    }

    /**
     *
     * A property that listens to editing events.<br>
     * It decouples clients from this component by letting them<br>
     * listen to events and take properly actions.<br>
     * An event can be :<br>
     * <br><b>ON_EDITION_REQUEST</b>, triggered when client requests editing an
     * item.
     * <br> <b>EDITED</b>, triggered when a new item was edited.
     * <br> <b>EDITING_CANCELED</b>, triggered by the client when it cancels
     * editing.
     * <br><b>EDITING_FAILED_EXECUTING_CLIENT_HOOK_EDITING_LOGIC</b>, triggered
     * when a client hook editing logic fails.
     * <br><b>EDITING_FAILED_NO_MATCHING_FOUND</b>, triggered when an edition
     * was requested but no item was found to be updated.
     *
     * @return a string representing the occured editing event.
     */
    @Override
    public StringProperty ON_EDITION() {
        return container.ON_EDITION();
    }

    @Override
    public StringProperty ON_IMPORTING() {
        return container.ON_IMPORTING();
    }

    @Override
    public StringProperty ON_UN_IMPORTING() {
        return container.ON_UN_IMPORTING();
    }

    @Override
    public void addAndSelect(String nomeItem) {
        container.addAndSelect(Item.newInstance(nomeItem, container, ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
    }

    @Override
    public void add(String nomeItem) throws Exception {
        container.add(Item.newInstance(nomeItem, container, ++FullVerticalScrollableListWrapperImpl.nextId, Item.IMAGELESS));
    }

    @Override
    public void edit(String oldName, String newName) {
        container.edit(oldName, newName);
    }

    @Override
    public void shake() {
        container.shake();
    }

    /**
     * Sets The extra NODES, in witch,for instace,<br>
     * will be css applyied.
     *
     * @param extras the extra nodes.
     */
    @Override
    public void setExtras(List<Node> extras) {
        container.setExtras(extras);
    }

    @Override
    public final void registre() {

        Properties PROPERTIES = new Properties();

        Handler handler = new Handler() {
            @Override
            public void publish(LogRecord record) {

//                System.err.println("publishin " + record.getMessage());
            }

            @Override
            public void flush() {

//                System.err.println("FLUSHING ");
            }

            @Override
            public void close() throws SecurityException {
//                System.err.println("CLOSING ");
            }
        };
        Logger.getLogger(FullVerticalScrollableListWrapperImpl.class.getName()).addHandler(handler);

        Logger.getLogger(FullVerticalScrollableListWrapperImpl.class.getName()).log(Level.INFO, "Registrando /resources/properties/{0}.properties", getClass().getSimpleName());
        try {
            PROPERTIES.load(Class.forName(getClass().getName()).getClass().getResourceAsStream("/resources/properties/" + getClass().getSimpleName() + ".properties"));
            Util.SCROLLERS_PROPERTIES_MAP.put(this, PROPERTIES);
        } catch (Exception ex) {
            Logger.getLogger(FullVerticalScrollableListWrapperImpl.class.getName()).log(Level.SEVERE, "Nao foi poss\u00edvel encontrar o recurso : /resources/properties/{0}.properties", getClass().getSimpleName());
            Logger.getLogger(FullVerticalScrollableListWrapperImpl.class.getName()).log(Level.SEVERE, null, ex);
            Platform.exit();
        }
    }

    @Override
    public void unregistre() {
        Util.SCROLLERS_PROPERTIES_MAP.remove(this);
    }

    @Override
    public boolean isSelecting() {
        return container.isSelecting();
    }

    @Override
    public double getSelectionProgress() {
        return container.getSelectionProgress();
    }

    @Override
    public boolean isRemoving() {
        return container.isRemoving();
    }

    @Override
    public double getRemovingProgress() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isRemovingMultiselection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setIsRemovingMultiselection(boolean isRemovingMultiselection) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isRemovingMultiSelectionCanceled() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setIsRemovingMultiSelectionCanceled(boolean isRemoveMultiSelectionCanceled) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookAdditionLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookDeletionLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookBulkDeletionLogic(Collection<Item> bulk) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookEditionLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookImportingLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookBulkImportingLogic(Collection<Item> clean) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookExportingLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void executeClientHookPrintingLogic() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean canExecuteClientHookDeletionLogicAt(Item item) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean hasBeenNotificatedOnDeletion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setHasBeenNotificatedOnDeletion(boolean hasBeenNotificatedOnDeletion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void load(Collection<Item> allItens) {
        container.getWrapper().setUpBeforeLoading();
        container.load(allItens);
        container.getWrapper().setUpAfterLoading();
    }

    @Override
    @Deprecated
    public void load(Item item) {
        container.load(item);
    }

    @Override
    public void loadBulk(Collection<Item> bulk) {
        container.load(bulk);
    }

    @Override
    public int size() {
        return container.getModel().size();
    }

    @Override
    public void block() {
        Platform.runLater(() -> {
            blocker.setVisible(true);
            blocker.toFront();
            blocker.setCursor(Cursor.WAIT);
            blocker.requestFocus();
        });
    }

    @Override
    public void unblock() {
        Platform.runLater(() -> {
            blocker.setVisible(false);
            blocker.toBack();
            blocker.setCursor(Cursor.DEFAULT);
            container.requestFocus();
        });
    }

    @Override
    public void setProgressValue(double newValue) {
        container.setProgressValue(newValue);
    }

    @Override
    public void selectSingle(String name) {
        container.selectSingle(name);
    }

    @Override
    public void selectSingle(Item item) {
        container.selectSingle(item);
    }

    @Override
    public void multiSelect(List<String> names) {
        container.multiSelect(names);
    }

    @Override
    public void unselect(String name) {
        container.unselect(name);
    }

    @Override
    public void unselectMulti(List<String> names) {
        container.unselectMulti(names);
    }

    public void imporT(Item item) throws Exception {
        container.imporT(item);
    }

    /**
     * Importa a coleção de itens.<br>
     * A colecao é liberada para GC na superclasse.
     *
     * @param itens
     * @throws Exception
     */
    public void imporT(Collection<Item> itens) throws Exception {
        container.imporT(itens);
    }

    public void unimport(Item item) {
        container.unimport(item);
    }

    /**
     * DES importa a coleção de itens.<br>
     * A colecao é liberada para GC na SUPER CLASSE
     *
     * @param itens
     * @throws Exception
     */
    public void unimport(List<Item> itens) throws Exception {
        container.unimport(itens);
    }

    public boolean isImportingDone() {
        return container.isImportingDone();
    }

    @Override
    public void reverseSingleSelection(Item item) {
        container.reverseSingleSelection(item);
    }

    @Override
    public void executeClientHookBulkUnImportingLogic(Collection<Item> clean) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void restoreLookAndFeel() {
        try {

            LookAndFeel lookAndFeel = persistenceService.getLookAndFeel(getClass().getSimpleName());
            if (lookAndFeel != null) {
                container.setCompactedList(lookAndFeel.isCompactList());
                container.setUp(getPrefHeight(), lookAndFeel.getCssTheme());
                container.setRoundCorner(lookAndFeel.isRoundCorner());
            }

        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void saveLookAndFeel() {
        try {
            persistenceService.saveOrUpdateLookAndFeel(newLookAndFeel());
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void restoreLookAndFeel(String id) {
        try {

            LookAndFeel lookAndFeel = persistenceService.getLookAndFeel(getClass().getSimpleName() + "_" + id);
            if (lookAndFeel != null) {
                Logger.getLogger(getClass().getName()).log(Level.INFO, "RESTORED {0}", lookAndFeel);
                container.setCompactedList(lookAndFeel.isCompactList());
                container.setUp(getPrefHeight(), lookAndFeel.getCssTheme());
                container.setRoundCorner(lookAndFeel.isRoundCorner());
            }

        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
        }
    }

    private volatile boolean lookAndFeelSaved = false;
    @Override
    public synchronized void saveLookAndFeel(String id) {
        lookAndFeelSaved = false;
        new Thread(() -> {
            while (isRemoving()) {
            };
            LookAndFeel lookAndFeel = newLookAndFeel(id);
            try {
                persistenceService.saveOrUpdateLookAndFeel(lookAndFeel);
                System.err.println("INFORMAÇÕES: " + getClass().getSimpleName() + ".saveLookAndFeel() : SAVED " + lookAndFeel);
                Logger.getLogger(getClass().getName()).log(Level.INFO, "SAVED {0}", lookAndFeel);
                lookAndFeelSaved = true;
            } catch (Exception e) {
                String msg = "SAVING FAILED " + lookAndFeel + " " + e.getMessage() + " RETRYING...";
                System.err.println("SEVERE: " + getClass().getSimpleName() + ".saveLookAndFeel() : " + msg);
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, msg);
                saveLookAndFeel(id);
            }
        }).start();
        while(!lookAndFeelSaved){};
    }

    private LookAndFeel newLookAndFeel() {
        return new LookAndFeel(this.getClass().getSimpleName(), container.getMenu().getCssTheme(), container.isCompactedList(), container.isRoundCorner());
    }

    private LookAndFeel newLookAndFeel(String id) {
        return new LookAndFeel(this.getClass().getSimpleName() + "_" + id, container.getMenu().getCssTheme(), container.isCompactedList(), container.isRoundCorner());
    }

}
