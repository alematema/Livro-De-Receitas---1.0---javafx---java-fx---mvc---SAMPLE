
package br.com.undra.jfxcomponents.scrollablelist.util;

/**
 *
 * @author alexandre
 */
public class CRUDItemHelper {
    
    
    
}
