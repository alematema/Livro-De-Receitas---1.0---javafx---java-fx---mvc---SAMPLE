package br.com.undra.jfxcomponents.scrollablelist.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import javafx.scene.input.MouseEvent;

/**
 * Modela um deseletor de itens.
 * @author alexandre
 */
@Deprecated
public class Unselector {
    
    static public synchronized void handleUnselection(ScrollableListContainerSimple container,MouseEvent event, Item item){
        
        if( !event.isControlDown() ){
            
            handleSingleUnselection(container,item);
            
        }else{
            
            handleMultiUnselection(container,item);
            
        }
        
    }

    private static void handleSingleUnselection(ScrollableListContainerSimple container,Item item) {
        
        container.getSelection().forEach((e) -> {e.setSelected(false);});
        container.getSelection().clear();
        
    }

    private static void handleMultiUnselection(ScrollableListContainerSimple container,Item item) {

        container.getSelection().remove(item);
        item.setSelected(false);

    }
    
}
