package br.com.undra.jfxcomponents.scrollablelist.mvc.model;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListItem;
import br.com.undra.livrodereceitas.util.Fonts;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 * O componente item da lista.
 *
 * @author alexandre
 */
public class Item extends Pane implements Comparable<Item>, ScrollableListItem {

    public static final String IMAGELESS = null;
    public static Image DELETE_IMAGE;
    public static Image CHECK_IMAGE;

    public static Item newInstance(String descricao, ScrollableListContainerSimple aThis, int id, String imagePath) {
        return new Item(descricao, aThis, id, imagePath);
    }

    //non-static properties
    private String descricao;
    private VBox lista;
    private ScrollableListContainerSimple container;
    private Integer id;
    private String imagePath;
    private boolean selected;

    @FXML
    private Pane itemContainer;

    @FXML
    private Label descricaoItemLabel;

    @FXML
    private StackPane imgPane;

    @FXML
    private ImageView imgItem;

    private Item(String descricao, ScrollableListContainerSimple container, int id, String imagePath) {

        doLoadings();

        this.descricao = descricao;
        this.container = container;
        DELETE_IMAGE = new Image(Util.getPROPERTIES(container.getWrapper()).getProperty("deleteImage"));
        CHECK_IMAGE = new Image(Util.getPROPERTIES(container.getWrapper()).getProperty("checkImage"));
        this.lista = container.getVBox();
        this.id = id;
        this.imagePath = imagePath;

        descricaoItemLabel.setText(descricao);
        
        minHeight(100);
        maxHeight(150);

        doBindings();

        descricaoItemLabel.setTooltip(new Tooltip(descricao));

    }

    public Item(String descricao) {

        descricaoItemLabel = new Label(descricao);

        minHeight(100);
        maxHeight(150);

        descricaoItemLabel.setTooltip(new Tooltip(descricao));

    }

    private void doLoadings() throws RuntimeException {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLItem.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

    }

    private String lastStyle;

    @FXML
    public void handleItemContainerClicked(MouseEvent event) {

        if (MouseButton.SECONDARY.equals(event.getButton())) {
            container.setClickedItem(this);
            return;
        }

        container.closeContextMenu();
        container.closeMenu();

        container.getSelector().handleSelection(container, event, this);

    }

//    @FXML
//    public void handleRemoveIconClicked(MouseEvent event) {
//
//        if (isRemovingMultiSelection()) {
//
//            Optional confirmarRemover = showConfirmarRemoverMultiSelection();
//
//            if (confirmarRemover.get().equals(ButtonType.YES)) {
//
//                fadeOutMultiSelectionDaListaERemover();
//
//            } else {
//
//                //fadeInNaoRemover();
//            }
//
//        } else {
//
//            Optional confirmarRemover = showConfirmarRemover();
//
//            if (confirmarRemover.get().equals(ButtonType.YES)) {
//
//                fadeOutItemDaListaERemover();
//
//            } else {
//
//                //fadeInNaoRemover();
//            }
//
//        }
//
//    }
    private void fadeInNaoRemover() {
        Notifications cancelDeletionNotification = Notifications.create()
                .hideAfter(Duration.seconds(1.8))
                .graphic(new ImageView(CHECK_IMAGE))
                .position(Pos.TOP_RIGHT)
                .title(Util.getPROPERTIES(container.getWrapper()).getProperty("tituloNotificacaoNaoItemRemovido"))
                .text(descricao + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("tituloNotificacaoNaoItemRemovido"));

        cancelDeletionNotification.showInformation();
    }

    private void fadeOutItemDaListaERemover() {
        setStyle("-fx-background-color: darksalmon");
        FadeTransition fadeOutItem = new FadeTransition(Duration.seconds(1.2), this);
        fadeOutItem.setFromValue(1);
        fadeOutItem.setToValue(0);
        fadeOutItem.setOnFinished((e) -> {

            removeSingle();

        });
        fadeOutItem.play();
    }

//    private void fadeOutMultiSelectionDaListaERemover() {
//
//        for (Item item : container.getSelection()) {
//
//            item.setStyle("-fx-background-color: darksalmon");
//            FadeTransition fadeOutItem = new FadeTransition(Duration.seconds(1.2), item);
//            fadeOutItem.setFromValue(1);
//            fadeOutItem.setToValue(0);
//            fadeOutItem.play();
//
//        }
//
//        new Thread(() -> {
//
//            try {
//                Thread.sleep(1300);
//            } catch (InterruptedException ex) {
//                Logger.getLogger(Item.class.getName()).log(Level.SEVERE, null, ex);
//            }
//            Platform.runLater(() -> {
//                removeMultiSelection();
//            });
//
//        }).start();
//
//    }
    private Optional showConfirmarRemover() {
        Alert alert = new Alert(AlertType.CONFIRMATION, this.descricao + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("tituloNotificacaoRemover"), ButtonType.YES, ButtonType.NO);
        alert.setGraphic(new ImageView(DELETE_IMAGE));
        alert.setTitle(Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoRemover"));
        alert.setHeaderText("Confirmar " + Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoRemover"));
        alert.initStyle(StageStyle.UNDECORATED);
        //Deactivate Defaultbehavior for yes-Button:
        Button yesButton = (Button) alert.getDialogPane().lookupButton(ButtonType.YES);
        yesButton.setDefaultButton(false);
        //Activate Defaultbehavior for no-Button:
        Button noButton = (Button) alert.getDialogPane().lookupButton(ButtonType.NO);
        noButton.setDefaultButton(true);
        Optional confirmarRemover = alert.showAndWait();
        return confirmarRemover;
    }

    private Optional showConfirmarRemoverMultiSelection() {

        Alert alert = new Alert(AlertType.CONFIRMATION, container.getSelection().size() + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("tituloNotificacaoRemoverMultiSelecao"), ButtonType.YES, ButtonType.NO);
        alert.setGraphic(new ImageView(DELETE_IMAGE));
        alert.setTitle(Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoRemover"));

        alert.setHeaderText("Confirmar " + Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoRemover"));
        alert.initStyle(StageStyle.UNDECORATED);
        //Deactivate Defaultbehavior for yes-Button:
        Button yesButton = (Button) alert.getDialogPane().lookupButton(ButtonType.YES);
        yesButton.setDefaultButton(false);
        //Activate Defaultbehavior for no-Button:
        Button noButton = (Button) alert.getDialogPane().lookupButton(ButtonType.NO);
        noButton.setDefaultButton(true);
        Optional confirmarRemover = alert.showAndWait();
        return confirmarRemover;

    }

    @Override
    public String toString() {
        return descricao;
    }

    private void doBindings() {

        //bindings section
        prefWidthProperty().bind(lista.prefWidthProperty());

        if (imagePath != IMAGELESS) {

            imgPane.prefHeightProperty().bind(heightProperty().subtract(20));
            imgPane.prefWidthProperty().bind(imgPane.prefHeightProperty());
            imgPane.setLayoutY(10);
            imgPane.layoutXProperty().bind(widthProperty().subtract(imgPane.widthProperty()).subtract(10));

            imgItem.setImage(new Image(imagePath));
            imgItem.setPreserveRatio(false);

            imgPane.heightProperty().addListener((observable, oldValue, newValue) -> {
                imgItem.setFitHeight(newValue.doubleValue() - 10);
                imgItem.setFitWidth(newValue.doubleValue() - 10);
            });

            widthProperty().addListener((observable, oldValue, newValue) -> {
                descricaoItemLabel.setPrefWidth(getWidth() - 35.0 - imgPane.getWidth());
            });

        } else {

            getChildren().remove(imgPane);

            widthProperty().addListener((observable, oldValue, newValue) -> {
                descricaoItemLabel.setPrefWidth(getWidth() - 35.0);
            });
        }

        descricaoItemLabel.layoutYProperty().bind(heightProperty().subtract(descricaoItemLabel.heightProperty()).divide(2.0));

    }

    private double getSeparatorHeight(int id) {

        double height = 0;
        Separator s = null;
        for (Node n : lista.getChildren()) {
            if (n instanceof Separator) {
                Integer sepId = Integer.parseInt(((Separator) n).getId());
                if (sepId.equals(id)) {
                    s = (Separator) n;
                    height = s.getHeight();
                    break;
                }
            }
        }
        return height;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
        descricaoItemLabel.setText(descricao);
    }

    @Override
    public String getName() {
        return descricao;
    }

    @Override
    public void setName(String newValue) {
        setDescricao(newValue);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.descricao);
        hash = 89 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Item other = (Item) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Item o) {
        return getDescricao().compareTo(o.getDescricao());
    }

//    
//    Integer i1 = Integer.parseInt(o.getDescricao());
//        Integer i2 = Integer.parseInt(descricao);
//        Integer i1 = Integer.parseInt(other.getDescricao());
//        Integer i2 = Integer.parseInt(descricao);
//        if (!Objects.equals(i1, i2)) {
//            return false;
//        }
//    private String getHoverBackground() {
//
//        String css = "";
//
//        for (String cSS : getScene().getStylesheets()) {
//            css = cSS;
//            System.out.println("css " + css);
//        }
//
//        Path p = Paths.get(css);
//        System.out.println(p.getFileName());
//        System.out.println(p.getParent());
//
//        Scanner s = null;
//        s = new Scanner(getClass().getResourceAsStream("/resources/css/" + p.getFileName()));
//        while (s.hasNext()) {
//            System.err.println(s.nextLine());
//        }
//        s = new Scanner(getClass().getResourceAsStream("/resources/css/" + p.getFileName()));
    //DO HARD PARSING
//        while (s.hasNext()) {
//            String line = s.nextLine();
//            line = line.trim();
//            if (line.startsWith("#")) {//inicia classe
//
//                System.err.print("#");
//                int index = line.indexOf("{");
//                if (index != -1) {
//                    System.err.println(line.substring(1, index) + "{");
//                    if (index + 1 == line.length()) {//fim linha.muda lnha
//                        line = s.nextLine();
//                        line = line.trim();
//                        String[] styles = line.split(";");
//                        for (String style : styles) {
//                            System.err.println(style);
//                        }
//                        while (!line.contains("}")) {
//                            line = s.nextLine();
//                            line = line.trim();
//                            styles = line.split(";");
//                            for (String style : styles) {
//                                System.err.println(style);
//                            }
//                        }
//                        System.err.println("}");
//                    }
//                }
//            }
//        }
//
//        System.out.println("style " + getScene());
//
//        return null;
//    }
    public void applyHoverStyle() {

        String hoverStyle = getSelectedStyle();
        setStyle(hoverStyle.split(";")[0]);
        descricaoItemLabel.setStyle(hoverStyle.split(";")[1]);
    }

    public void setLastStyle(String lastStyle) {
        this.lastStyle = lastStyle;
    }

    public void setDescricaoItemLastStyle(String descricaoItemLastStyle) {
        this.descricaoItemLastStyle = descricaoItemLastStyle;
    }

    public String getLastStyle() {
        return lastStyle;
    }

    public String getDescricaoItemLastStyle() {
        return descricaoItemLastStyle;
    }

    public Label getDescricaoItemLabel() {
        return descricaoItemLabel;
    }

    List<String> css = new ArrayList();

    String lastSelectedStyle;
    String lastCss;

    private String getSelectedStyle() {

        String selectedBackgroundStartColor = "-fx-background-color:black";
        String selectedTextFillStartColor = "-fx-text-fill:black";
        String selectedBackground = "";
        String selectedrTextFill = "";

        css.clear();

        for (String cSS : container.getStylesheets()) {
            css.add(cSS);
        }

        if (lastCss != null) {
            if (css.contains(lastCss)) {
                return lastSelectedStyle;
            }
        }

        for (String cSS : css) {
            try {

                Scanner s = new Scanner(getClass().getResourceAsStream("/resources/css/" + Paths.get(cSS).getFileName()));
                StringBuilder sb = new StringBuilder();
                while (s.hasNext()) {
                    sb.append(s.nextLine());
                }
                String cssAsString = sb.toString();
                String[] cssClasses = cssAsString.split("}");
                main:
                for (String cssClass : cssClasses) {

                    String classeAnalisada = cssClass.trim().replaceAll(" ", "");

                    if (classeAnalisada.contains("itemSelected{")) {

                        classeAnalisada = Util.removeCssComments(classeAnalisada);

                        String[] styles = classeAnalisada.split(";");
                        for (String style : styles) {
                            if (style.contains("-fx-background-color")) {
                                String[] splits = style.split(":");
                                selectedBackground = splits[splits.length - 1];
                                selectedBackground = "-fx-background-color:" + selectedBackground;
                                if (!selectedBackground.equals("") && !selectedrTextFill.equals("")) {
                                    break main;
                                }
                            }
                        }
                    }

                    if (classeAnalisada.contains("itemSelected{")) {

                        classeAnalisada = Util.removeCssComments(classeAnalisada);

                        String[] styles = classeAnalisada.split(";");
                        for (String style : styles) {
                            if (style.contains("-fx-text-fill")) {
                                String[] splits = style.split(":");
                                selectedrTextFill = splits[splits.length - 1];
                                selectedrTextFill = "-fx-text-fill:" + selectedrTextFill;
                                if (!selectedBackground.equals("") && !selectedrTextFill.equals("")) {
                                    break main;
                                }
                            }
                        }
                    }
                }

            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
                selectedBackground = selectedBackgroundStartColor;
                selectedrTextFill = selectedTextFillStartColor;
            }

            lastCss = cSS;
        }

        lastSelectedStyle = selectedBackground + ";" + selectedrTextFill;
        return selectedBackground + ";" + selectedrTextFill;

    }

    public boolean isSelected() {
        return selected;
    }

    public void click() {
        handleItemContainerClicked(new MouseEvent(null, 0, 0, 0, 0, MouseButton.NONE, 0, selected, selected, selected, selected, selected, selected, selected, selected, selected, true, null));
    }

    public void clickSingleSelection() {
        handleItemContainerClicked(new MouseEvent(null, 0, 0, 0, 0, MouseButton.NONE, 0, selected, false, selected, selected, selected, selected, selected, selected, selected, true, null));
    }

    public void clickMultiSelection() {
        handleItemContainerClicked(new MouseEvent(null, 0, 0, 0, 0, MouseButton.NONE, 0, selected, true, selected, selected, selected, selected, selected, selected, selected, true, null));
    }

    private MouseEvent mouseEvent = new MouseEvent(null, 0, 0, 0, 0, MouseButton.NONE, 0, selected, true, selected, selected, selected, selected, selected, selected, selected, true, null);

    public void clickSelectingOnly() {
        setSelected(true);
    }

    public void clickUnSelectingOnly() {
        if (selected) {
            setSelected(false);
        }
    }

    String descricaoItemLastStyle;

    public void setSelected(boolean selected) {

        if (!this.selected) {

            String hoverStyle = getSelectedStyle();

            lastStyle = getStyle();
            descricaoItemLastStyle = descricaoItemLabel.getStyle();

            setStyle(hoverStyle.split(";")[0]);
            descricaoItemLabel.setStyle(hoverStyle.split(";")[1]);

        } else {

            setStyle(lastStyle);
            descricaoItemLabel.setStyle(descricaoItemLastStyle);

        }

        this.selected = selected;

    }

    private void removeSingle() {

        try {
            container.remove(this);
        } catch (Exception ex) {
            Logger.getLogger(Item.class.getName()).log(Level.SEVERE, null, ex);
        }

        Notifications successDeletionNotification = Notifications.create().hideAfter(Duration.seconds(1.5))
                .graphic(new ImageView(CHECK_IMAGE))
                .position(Pos.TOP_RIGHT)
                .hideCloseButton()
                .text(toString() + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoItemRemovido"));

        container.getStylesheets().stream().filter((css) -> (css.contains("dark-theme.css") || css.contains("medium-theme.css"))).forEachOrdered((_item) -> {
            successDeletionNotification.darkStyle();
        });

//        successDeletionNotification.show();
    }

//    private void removeMultiSelection() {
//
//        int multiSelection = container.getSelection().size();
//
//        container.removeMultiSelection();
//
//        Notifications successDeletionNotification = Notifications.create().hideAfter(Duration.seconds(1.5))
//                .graphic(new ImageView(CHECK_IMAGE))
//                .position(Pos.TOP_RIGHT)
//                .hideCloseButton()
//                .text(multiSelection + " " + Util.getPROPERTIES(container.getWrapper()).getProperty("textoNotificacaoMultiSelecaoRemovida"));
//
//        container.getStylesheets().stream().filter((css) -> (css.contains("dark-theme.css") || css.contains("medium-theme.css"))).forEachOrdered((_item) -> {
//            successDeletionNotification.darkStyle();
//        });
//
////        successDeletionNotification.show();
//    }
    private boolean isRemovingMultiSelection() {
        return container.getSelection().contains(this) && container.getSelection().size() > 1;
    }

}
