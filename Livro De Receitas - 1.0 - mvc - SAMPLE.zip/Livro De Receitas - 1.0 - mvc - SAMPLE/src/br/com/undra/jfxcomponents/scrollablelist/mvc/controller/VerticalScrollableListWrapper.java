package br.com.undra.jfxcomponents.scrollablelist.mvc.controller;

import br.com.undra.jfxcomponents.menus.context.ContextMenu;
import br.com.undra.jfxcomponents.menus.context.ContextMenuArrowDown;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.searcher.SearcherContainer;
import java.util.Collection;
import java.util.List;
import javafx.beans.property.StringProperty;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;

/**
 * A scroller inteface.
 * @author alexandre
 */
public interface VerticalScrollableListWrapper {
     ScrollableListContainerSimple getView(); 
     void unSelectAll();
     void selectSingle(String name);
     void selectSingle(Item item);
     void reverseSingleSelection(Item item);
     void multiSelect(List<String> names);
     void unselect(String name);
     void unselectMulti(List<String> names);
    
     void setCena(Scene scene);
     void setUp(Object parent);
     void setUpBeforeLoading();
     void setUpAfterLoading();
     void setUpBeforeSelectingAll();
     void setUpAfterSelectingAll();
     void setUpBeforeRemoveMultiSelection();
     void setUpAfterRemoveMultiSelection();
     void setUpBeforeImporting();
     void setUpAfterImporting();
     void setUpBeforeUnImporting();
     void setUpAfterUnImporting();
     void setUpBeforeExporting();
     void setUpAfterExporting();
     void setUpBeforePrinting();
     void setUpAfterPrinting();
     void setUpBeforeSearching();
     void setUpAfterSearching();
     void setUpBeforeInvertSelection();
     void setUpAfterInvertSelection();
    
     SearcherContainer<Item> getSearcherContainer();
     String getSingleRemoved();
     Collection<String> getMultiSelectionRemoved();
     Item getCurrentSelected();
     Item getCurrentUnselected();
     Item getCurrentAdding(); 
     Item getCurrentRemoving();
     Item getCurrentEdited();
     Collection<Item> getExcludables(Collection<Item> selection);
     Collection<Item> getUNexcludables(Collection<Item> selection);
     List<Node> getExtras();
     ContextMenuArrowDown getContextMenuArrowDown();
     ContextMenu getContextMenuUpArrow();
     String getAppCurrentItemSelected();
    
     StringProperty ON_DELETION();
     StringProperty ON_SELECTION();
     StringProperty ON_ADDITION();
     StringProperty ON_EDITION();
     StringProperty ON_IMPORTING();
     StringProperty ON_UN_IMPORTING();
    
     boolean hasBeenNotificatedOnDeletion();
     void setHasBeenNotificatedOnDeletion(boolean hasBeenNotificatedOnDeletion);
    
     void addAndSelect(String nomeItem);
     void add(String nomeItem) throws Exception;
     void edit(String oldName,String newName);
     void load(Collection<Item> allItens);
     void load(Item item);
     void loadBulk(Collection<Item> bulk);
     void shake();
     void block();
     void unblock();
     void setExtras(List<Node> extras);
     void registre();
     void unregistre();
     void requestFocus();
     void setCursor(Cursor cursor);
    
     boolean isSelecting();
     double getSelectionProgress();
     boolean isRemoving();
     double getRemovingProgress();

    
     boolean isRemovingMultiselection();
     void setIsRemovingMultiselection(boolean isRemovingMultiselection);
    
     boolean isRemovingMultiSelectionCanceled();
     void setIsRemovingMultiSelectionCanceled(boolean isRemoveMultiSelectionCanceled);
    
     void executeClientHookAdditionLogic() throws Exception;
     void executeClientHookDeletionLogic() throws Exception;
     void executeClientHookBulkDeletionLogic(Collection<Item> bulk) throws Exception;
     void executeClientHookEditionLogic() throws Exception;
     void executeClientHookExportingLogic() throws Exception;
     void executeClientHookPrintingLogic() throws Exception;
     void executeClientHookImportingLogic() throws Exception;
     void executeClientHookBulkImportingLogic(Collection<Item> clean) throws Exception;
     void executeClientHookBulkUnImportingLogic(Collection<Item> clean) throws Exception;
     boolean canExecuteClientHookDeletionLogicAt(Item item) throws Exception;
    
     int size();
     void setProgressValue(double newValue);
     
     void restoreLookAndFeel();
     void restoreLookAndFeel(String id);
     void saveLookAndFeel();
     void saveLookAndFeel(String id);
}
