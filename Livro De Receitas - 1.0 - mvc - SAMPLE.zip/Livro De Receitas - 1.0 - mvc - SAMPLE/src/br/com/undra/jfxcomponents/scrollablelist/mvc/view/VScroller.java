package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.TransparentItem;
import javafx.scene.Node;
import javafx.scene.control.Separator;

/**
 * A Full Vertical Scroller.
 *
 * @author alexandre
 * @param <T>
 */
public class VScroller<T> {
    
    public static int POSITIVE_DELTA_Y_MIN = 40;

//    public static ScrollableListContainerSimple container;

    public static synchronized void handleScrolling(ScrollableListContainerSimple container,double deltaY) {

        if (isScrollingUp(deltaY)) {
            handleScrollingUp(container,deltaY);
        } else {
            handleScrollingDown(container,deltaY);
        }

        doVBoxLayOutYTopAdjust(container);
    }

    private static boolean isScrollingUp(double deltaY) {
        return deltaY < 0;
    }

    private static synchronized  void handleScrollingUp(ScrollableListContainerSimple container,double deltaY) {
        scrollUp(container,deltaY);
    }

    private static synchronized void scrollUp(ScrollableListContainerSimple container,double deltaY) {

        int howManyItensMustGoUp = getHowManyScrollsByDeltaY(deltaY);
        for (int i = 1; i <= howManyItensMustGoUp; i++) {
            try {
                container.getCurrentModel().scrollUp();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
    
    private static synchronized void handleScrollingDown(ScrollableListContainerSimple container,double deltaY) {
        scrollDown(container,deltaY);
    }

//    public static void scroll(double deltaY) {
//        container.getVBox().setLayoutY(deltaY + container.getVBox().getLayoutY());
//        doVBoxLayOutYTopAdjust();
//        doVBoxLayOutYBottonAdjust();
//        if (Selector.selection.isEmpty()) {
//            InfoUpdater.updateAfterScrolling(container);
//        }
//    }

    private static int getHowManyScrollsByDeltaY(double deltaY) {
        if (Math.abs(deltaY) < POSITIVE_DELTA_Y_MIN) {
            return 0;
        }
        return (int) Math.abs(deltaY) / 40;
    }

    private static void scrollDown(ScrollableListContainerSimple container,double deltaY) {

        int howManyItensMustGoDown = getHowManyScrollsByDeltaY(deltaY);
        for (int i = 1; i <= howManyItensMustGoDown; i++) {
            try {
                container.getCurrentModel().scrollDown();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public static synchronized void doVBoxLayOutYTopStraightAdjust(ScrollableListContainerSimple container) {
        container.getVBox().setLayoutY(container.getScrollableContainerHeader().getHeight());
    }

    public static void putOnTop(Item item) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static synchronized double[] getElementsStackHeight(ScrollableListContainerSimple container) {

        double totalHeight = 0;
        double totalItensHeight = 0;
        double totalSeparatorsHeight = 0;

        Item item;
        Separator separator;

        for (Node node : container.getVBox().getChildren()) {

            //itens height
            if (node instanceof Item) {
                item = (Item) node;
                totalItensHeight += item.getHeight();
                totalHeight += item.getHeight();
            }
            //separators height
            if (node instanceof Separator) {
                separator = (Separator) node;
                totalSeparatorsHeight += separator.getHeight();
                totalHeight += separator.getHeight();
            }

        }

        double[] total = {totalItensHeight, totalSeparatorsHeight, totalHeight};
        return total;
    }

    

    public static synchronized void setAdjust(ScrollableListContainerSimple container,int adjust) {
        container.setAdjust(adjust);
    }

    public static synchronized void doAdjustments(ScrollableListContainerSimple container) {
        //nenhum ajuste a fazer
        if (container.getVBox().getChildren().isEmpty()) {
            return;
        }

        for (int i = getTotalItens(container); i <= container.getAdjust(); i++) {
            container.getVBox().getChildren().add(new TransparentItem());
        }
    }

    private static synchronized int getTotalItens(ScrollableListContainerSimple container) {
        int total = 0;
        Item item;
        total = container.getVBox().getChildren().stream().filter((node) -> (node instanceof Item)).map((_item) -> 1).reduce(total, Integer::sum);
        return total;
    }

    public static synchronized void doLayOutYAdjustAfterRemoving(ScrollableListContainerSimple container) {
        doVBoxLayOutYTopAdjust(container);
        doVBoxLayOutYBottonAdjust(container);
    }

    public static synchronized void doVBoxLayOutYTopAdjust(ScrollableListContainerSimple container) {
        container.getVBox().setLayoutY(container.getScrollableContainerHeader().getHeight() + 3);
    }

    public static synchronized void doVBoxLayOutYBottonAdjust(ScrollableListContainerSimple container) {

        try {

            double bottomItemHeight = ((Item) container.getVBox().getChildren().get(container.getVBox().getChildren().size() - 1)).getHeight();

            double elementsStackHeight = getElementsStackHeight(container)[2];

            if (container.getVBox().getLayoutY() < -(elementsStackHeight - bottomItemHeight - container.getScrollableContainerHeader().getHeight())) {
                container.getVBox().setLayoutY(-elementsStackHeight + bottomItemHeight + container.getScrollableContainerHeader().getHeight());
            }

        } catch (Exception e) {
        }

    }

    static synchronized void home(ScrollableListContainerSimple container) {
        container.getCurrentModel().firstVisible();
    }

    static void end(ScrollableListContainerSimple container) {
        container.getCurrentModel().lastVisible();
    }

}
