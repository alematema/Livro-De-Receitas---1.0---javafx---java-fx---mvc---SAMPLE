package br.com.undra.jfxcomponents.scrollablelist.mvc.model;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListItem;
import br.com.undra.livrodereceitas.AppContainer;
import br.com.undra.livrodereceitas.Receita;
import br.com.undra.livrodereceitas.services.persistence.PersistenceService;
import br.com.undra.livrodereceitas.services.persistence.PersistenceServiceImpl_JDBC_SQLITE;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * A model for list scrolling.
 *
 * @author alexandre
 * @param <T>
 */
public class ScrollableList<T> {

    public static String ADDED_SINGLE_READY = "ADDED_SINGLE_READY";
    public static String ADDING_SINGLE = "ADDING_SINGLE";
    public static String ADDED_LAST_VISIBLE_READY = "ADDED_LAST_VISIBLE_READY";
    public static String ADDING_LAST_VISIBLE = "ADDING_LAST_VISIBLE";
    public static String ADDED_FAST_UPDATE_READY = "ADDED_FAST_UPDATE_READY";
    public static String ADDING_FAST_UPDATE = "ADDING_FAST_UPDATE";
    public static String EDITED_READY = "EDITED_READY";
    public static String EDITING = "EDITING";
    public static String ADDED_AS_SEARCHING_RESULT_READY = "ADDED_AS_SEARCHING_RESULT_READY";
    public static String ADDING_AS_SEARCHING_RESULT = "ADDING_AS_SEARCHING_RESULT";
    public static String ADDED_AS_IMPORTING_READY = "ADDED_AS_IMPORTING_READY";
    public static String ADDING_AS_IMPORTING = "ADDING_AS_IMPORTING";
    public static String REMOVED_AS_UN_IMPORTING_READY = "REMOVED_AS_UN_IMPORTING_READY";
    public static String REMOVING_AS_UN_IMPORTING = "REMOVING_AS_UN_IMPORTING";
    public static String REMOVED_BULK_READY = "REMOVED_BULK_READY";
    public static String REMOVING_BULK = "REMOVING_BULK";
    public static String REMOVED_READY = "REMOVED_READY";
    public static String REMOVING = "REMOVING";
    public static String SCROLLING_UP = "SCROLLING_UP";
    public static String SCROLLING_UP_READY = "SCROLLING_UP_READY";
    public static String SCROLLING_UP_FAILED = "SCROLLING_UP_FAILED";
    public static String SCROLLING_DOWN = "SCROLLING_DOWN";
    public static String SCROLLING_DOWN_READY = "SCROLLING_DOWN_READY";
    public static String SCROLLING_DOWN_FAILED = "SCROLLING_DOWN_FAILED";
    public static String SEARCHING_RESULT_EMPTY = "SEARCHING_RESULT_EMPTY";

    private final List<T> model = new ArrayList<>();
    private final Set<T> temp = new TreeSet<>();
    private final Stack<T> INVISIBLE_ELEMENTS_BOTTOM_STACK = new Stack();
    private final Stack<T> INVISIBLE_ELEMENTS_TOP_STACK = new Stack();
    private volatile List<T> visibleElements = new LinkedList<>();
    private final IntegerProperty VISIBLE_ELEMENTS_MAX_NUM = new SimpleIntegerProperty(15);

    private final StringProperty STATE = new SimpleStringProperty("WAITING");

    private final Integer TOP_MOST = 0;
    private final Integer MIDDLE = 1;
    private final Integer BOTTOM_MOST = 2;
    private final Integer PREF_VISIBLE_POSITION;

    private T lastAdded;
    private T lastRemoved;

    public ScrollableList() {
        PREF_VISIBLE_POSITION = TOP_MOST;
        temp.clear();
    }

//    public boolean add(T t) {
//        return model.add(t);
//    }
    public synchronized void addAsBulk(T e) {
        if (e == null) {
            return;
        }
        if (!model.contains(e)) {
            return;
        }
        temp.add(e);
        doFastUpdate();
        makeFirstVisible(e);
    }

    /**
     * If model <b>does not</b> contain e, e will be added and made visible.<br>
     * If model <b>does not</b> contain e, sets the STATE from <code>ADDING_SINGLE</code> to
     * <code>ADDED_SINGLE_READY</code>.<br>
     * If model <b>contains e</b>, returns.
     *
     * @param e
     */
    public synchronized void addAndUpdateVisibleElements(T e) {

        if (e == null) {
            return;
        }

        if (model.contains(e)) {
            return;
        }

        STATE.setValue(ADDING_SINGLE);
        addAndUpdateVisibleElementsSilently(e);
        STATE.setValue(ADDED_SINGLE_READY);

    }

    /**
     * If model <b>does not</b> contain e, e will be added and made visible.<br>
     * <b>Does not</b>' change the <code>STATE</code>.<br>
     * If model <b>does not</b> contain e, does the work silently, meaning the LISTENERS CAN'T hear what is
     * going on.<br>
     * If model <b>contains e</b>, returns.
     *
     * @param e
     */
    public synchronized void addAndUpdateVisibleElementsSilently(T e) {

        if (e == null) {
            return;
        }

        if (model.contains(e)) {
            return;
        }

        //descobre posicao correta para e; coloca e nela
        temp.add(e);
        model.clear();
        model.addAll(temp);

        //t está na posicao correta
        //ajusta elementos visiveis e INVISIVEIS
        if (model.size() > VISIBLE_ELEMENTS_MAX_NUM.getValue()) {

            insertInListAndAdjustInvisibleElements(model.indexOf(e), e);

        } else {

            visibleElements.clear();
            visibleElements.addAll(model);
            INVISIBLE_ELEMENTS_TOP_STACK.clear();
            INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();

        }

        makeTopMostVisible(e);

        if (model.size() >= VISIBLE_ELEMENTS_MAX_NUM.getValue()) {
        }
        lastAdded = e;

    }

    private void insertInListAndAdjustInvisibleElements(int index, T e) {
        if (VISIBLE_ELEMENTS_MAX_NUM.equals(0)) {

        } else {

            if (isBeforeFirstVisibleElement(index)) {

                //INSERE ANTES DO PRIMEIRO ELEMENTO VISIVEL
                //INSERE NO INICIO DA LISTA DOS VISIVEIS E EMPILHA NA PILHA DE BAIXO O OVERFLOW
                insertBefore(e);

            } else if (isAfterLastVisibleElement(index)) {

                //INSERE DEPOIS DO ULTIMO ELEMENTO VISIVEL
                //INSERE NO FIM DA LISTA DO VISIVEIS E EMPILHA NA PILHA DE CIMA O OVERFLOW
                insertAfter(e);

            } else {

                insertInBetween(e);

            }
        }
    }

    private void insertInBetween(T e) {
        //is in between

        //        while( l(0) < e ){
        //            scrollUpPrivate()
        //        }
        //
        //        //l(0) >= e
        //        s = l(0)
        //        add(0,e)
        //        if( l.size > VISIBLE_ELEMENTS_MAX_NUM )
        //            BStack.push(l( l.size -1 ))
        while (isBefore(visibleElements.get(0), e)) {
            scrollUpPrivate();
        }
        visibleElements.add(0, e);
        if (visibleElements.size() > VISIBLE_ELEMENTS_MAX_NUM.getValue()) {

            INVISIBLE_ELEMENTS_BOTTOM_STACK.push(visibleElements.get(visibleElements.size() - 1));
            visibleElements.remove(visibleElements.size() - 1);
        }

    }

    private void insertAfter(T e) {
        //se e > l( l.size-1 )
        //
        //           l.add(e)
        //           TStack.push(l(0))
        //           l.remove(l(0))

        try {

            while (isBefore(INVISIBLE_ELEMENTS_BOTTOM_STACK.peek(), e)) {
                scrollUpPrivate();
            }
        } catch (Exception ex) {
//            Logger.getLogger(getClass().getName()).log(Level.INFO, ex.getMessage());
        }

        visibleElements.add(e);
        INVISIBLE_ELEMENTS_TOP_STACK.push(visibleElements.get(0));
        visibleElements.remove(0);
    }

    private void insertBefore(T e) {

        //se e < l(0)
        //
        //      l.add(0,e)
        //      BStack.push(l( l.size -1 ))
        //      l.remove( l.size-1 )
        try {

            while (isBefore(e, INVISIBLE_ELEMENTS_TOP_STACK.peek())) {
                scrollDownPrivate();
            }

        } catch (Exception ex) {
//            Logger.getLogger(getClass().getName()).log(Level.INFO, ex.getMessage());
        }
        visibleElements.add(0, e);
        if (visibleElements.size() > VISIBLE_ELEMENTS_MAX_NUM.getValue()) {
            INVISIBLE_ELEMENTS_BOTTOM_STACK.push(visibleElements.get(visibleElements.size() - 1));
            visibleElements.remove(visibleElements.size() - 1);

        }
    }

    public synchronized boolean scrollUp() {

        STATE.set(SCROLLING_UP);

        boolean scrolled = scrollUpPrivate();

        if (scrolled) {
            STATE.setValue(SCROLLING_UP_READY);
        } else {
            STATE.setValue(SCROLLING_UP_FAILED);
        }

        return scrolled;

    }

    public synchronized boolean scrollDown() {

        STATE.set(SCROLLING_DOWN);

        boolean scrolled = scrollDownPrivate();

        if (scrolled) {
            STATE.setValue(SCROLLING_DOWN_READY);
        } else {
            STATE.setValue(SCROLLING_DOWN_FAILED);
        }

        return scrolled;

    }

    /**
     * Scrolls up SILENTLY,eg,LISTENERS CAN'T hear what is going on.
     *
     * @return
     */
    private boolean scrollUpPrivate() {

        if (visibleElements.size() > 1) {

            T topMostVisible = visibleElements.get(0);
            //goes invisible
            INVISIBLE_ELEMENTS_TOP_STACK.push(topMostVisible);
            //left shifting
            visibleElements.remove(topMostVisible);
            //brings to visibility bottom most invisible
            if (!INVISIBLE_ELEMENTS_BOTTOM_STACK.isEmpty()) {
                T bottomMostInvisible = INVISIBLE_ELEMENTS_BOTTOM_STACK.pop();
                visibleElements.add(bottomMostInvisible);
            }

        }
        return visibleElements.size() > 1;
    }

    /**
     * Scrolls down SILENTLY,eg,LISTENERS CAN'T hear what is going on.
     *
     * @return
     */
    private boolean scrollDownPrivate() {

        if (!INVISIBLE_ELEMENTS_TOP_STACK.isEmpty()) {

            T topInvisible = INVISIBLE_ELEMENTS_TOP_STACK.pop();
            //turns it VISIBLE
            //right shifting
            visibleElements.add(0, topInvisible);
            //OVERFLOW ?
            if (visibleElements.size() > VISIBLE_ELEMENTS_MAX_NUM.getValue()) {//OVERFLOW

                T bottomMostVisible = visibleElements.get(visibleElements.size() - 1);
                // turns it INVISIBLE
                INVISIBLE_ELEMENTS_BOTTOM_STACK.push(bottomMostVisible);
                //make it disappear
                visibleElements.remove(bottomMostVisible);

            } else {

            }
        }

        return !INVISIBLE_ELEMENTS_TOP_STACK.isEmpty();
    }

//    public void add(int index, T t) {
//        model.add(index, t);
//    }
//
//    public boolean addAll(Collection<T> itens) {
//        return model.addAll(itens);
//    }
//
//    public boolean addAll(T... itens) {
//        return model.addAll(itens);
//    }
//
//    public T get(int index) {
//        return model.get(index);
//    }
//
//    public boolean remove(T t) {
//        return model.remove(t);
//    }
    public synchronized void removeAsBulk(T e) {
        if (e == null) {
            return;
        }
        if (!model.contains(e)) {
            return;
        }
        temp.remove(e);
        doFastUpdate();
    }

    /**
     * If model <b>does</b> contain e, e will be removed.<br>
     * If model <b>does</b> contain e,sets the <code>STATE</code> from <code>REMOVING</code> to
     * <code>REMOVED_READY</code>.
     *
     * @param e
     */
    @Deprecated
    public synchronized void removeAndUpdateVisibleElements(T e) {

        if (model.contains(e)) {
            STATE.setValue(REMOVING);
            removeAndUpdateVisibleElementsSilently(e);
            STATE.setValue(REMOVED_READY);
        }

    }

     /**
     * If model <b>does</b> contain e, e will be removed.<br>
     * <b>Does not</b> change the <code>STATE</code>.<br>
     * Does the work silently, meaning the LISTENERS CAN'T hear what is
     * going on.
     *
     * @param e
     */
    @Deprecated
    public synchronized void removeAndUpdateVisibleElementsSilently(T e) {

        if (model.contains(e)) {

            //compares if index of e is lesser than index of visibleElements.get(0) 
            if (isBefore(e, visibleElements.get(0))) {

                deleteBefore(e);

                //compares if index of e is greater than index of visibleElements.get(vibisbleElements.size()-1) 
            } else if (isAfter(e, visibleElements.get(visibleElements.size() - 1))) {

                deleteAfter(e);

            } else {// is in between

                deleteInBetween(e);
            }
        }

        model.remove(e);

        temp.remove(e);

        lastRemoved = e;

    }

    private void deleteBefore(T e) {

//                TStack.removeElement(e)
//                while( TStack NOT Empty AND l.size() < VISIBLE_ELEMENTS_MAX_NUM )
//                    scrollDownPrivate()
        INVISIBLE_ELEMENTS_TOP_STACK.remove(e);
        while (!INVISIBLE_ELEMENTS_TOP_STACK.isEmpty() && visibleElements.size() < VISIBLE_ELEMENTS_MAX_NUM.getValue()) {
            scrollDownPrivate();
        }
    }

    private void deleteAfter(T e) {

//        BStack.removeElement(e)
        INVISIBLE_ELEMENTS_BOTTOM_STACK.remove(e);
    }

    private void deleteInBetween(T e) {
//                while( l(0) <= e ){
//                    scrollUpPrivate()
//                    if (l.size() == 1 && l.get(0).equals(e)) 
//                       T topMostVisible = l.get(0)
//                       TStack.push(topMostVisible)
//                       l.remove(topMostVisible)
//                       deleteBefore(e)
//                       model.remove(e)
//                       return
//                }
//
//                removeAndUpdateVisibleElements(e)

        //compares if index of visibleElements.get(0) is lesser or equals than index of e  
        while (isBeforeOrEquals(visibleElements.get(0), e))//do this with the purpose of putting e at TopStack and then apply removeBefore
        {
            scrollUpPrivate();

            if (visibleElements.size() == 1 && visibleElements.get(0).equals(e)) {
                T topMostVisible = visibleElements.get(0);
                //goes invisible
                INVISIBLE_ELEMENTS_TOP_STACK.push(topMostVisible);
                //left shifting
                visibleElements.remove(topMostVisible);
                deleteBefore(e);
                model.remove(e);
                return;
            }
        }

        removeAndUpdateVisibleElements(e);
    }

//    public T remove(int index) {
//        return model.remove(index);
//    }
    public IntegerProperty getVisibleElementsMaxNum() {
        return VISIBLE_ELEMENTS_MAX_NUM;
    }

    public List<T> get() {
        return model;
    }

    /**
     * Sets the visible elements max num.<br>
     * Makes visible the newValue firsts elements.
     * @param newValue 
     */
    public void setVisibleElementsMaxNum(int newValue) {
        VISIBLE_ELEMENTS_MAX_NUM.setValue(newValue);
        doFastUpdateSylently();
    }

    public List<T> getVisibleElements() {
        return new ArrayList(visibleElements);
    }

    /**
     * The CHANGEFUL collection of itens.<br>
     * The <code>ScrollableList</code> sometimes may show subsets of the
     * collection of all itens it holds.<br>
     * The changeful <code>model</code> may varies its size because sometimes
     * holds searching results, and other times, holds the total collection of
     * itens.
     *
     * @see #getExactModel()
     * @return
     */
    public List<T> getChangefulModel() {
        return model;
    }

    /**
     * The list that reflects the exact total collection of itens held by the
     * <code>ScrollableList</code>. Means the UNCHANGED collection of itens.<br>
     * Even though the <code>ScrollableList</code> sometimes may show subsets of
     * the collection of all itens it holds, the <code>exactModel</code> remains
     * UNCHANGED, in contrast with the CHANGEFUL model collection that may
     * change its size while holding searching results,for instance.
     *
     * @see #getChangefulModel()
     * @return
     */
    public List<T> getExactModel() {
        return new ArrayList<>(temp);
    }

    public Stack<T> getInvisibleTopStack() {

        //TODO make unmodifiable 
        return INVISIBLE_ELEMENTS_TOP_STACK;
    }

    public Stack<T> getInvisibleBottomStack() {
        //TODO make unmodifiable 
        return INVISIBLE_ELEMENTS_BOTTOM_STACK;
    }

    /**
     * The <code>ScrollableList's STATE</code><br>
     * @see #ADDED_AS_IMPORTING_READY
     * @see #ADDED_AS_SEARCHING_RESULT_READY
     * @see #ADDED_FAST_UPDATE_READY
     * @see #ADDED_LAST_VISIBLE_READY
     * @see #ADDING_AS_IMPORTING
     * @see #ADDING_AS_SEARCHING_RESULT
     * @see #ADDING_LAST_VISIBLE
     * @see #ADDING_FAST_UPDATE
     * @see #ADDING_SINGLE
     * @return The <code>ScrollableList's STATE</code>
     */
    public StringProperty getSTATE() {
        return STATE;
    }

    public T get(T e) {
        return model.get(model.indexOf(e));
    }

    public T get(int index) {
        return model.get(index);
    }

    /**
     * The current model size of the <code>ScrollableList</code>.
     * @see #getChangefulModel() 
     * @see #getExactModel() 
     * @return 
     * 
     */
    public int size() {
        return model.size();
    }

    public void clear() {
        model.clear();
    }

    /**
     * Returns the index( an >=0 integer ) of element in model list.<br>
     * Returns -1 if element is not in model.
     *
     * @param element
     * @return
     */
    public int indexOf(T element) {
        return model.indexOf(element);
    }

    public T getLastAdded() {
        return lastAdded;
    }

    public T getLastRemoved() {
        return lastRemoved;
    }

    public T getLastVisibleElement() {
        return visibleElements.get(visibleElements.size() - 1);
    }

    public T getFirstVisibleElement() {
        return visibleElements.get(0);
    }

    public Collection getSearchingSpace() {
        return temp;
    }

    /**
     * Compares if index is lesser than index first visible element.
     *
     * @param index
     * @return true, if only if, index lesser than index of
     * visibleElements.get(0).
     */
    private boolean isBeforeFirstVisibleElement(int index) {
        return index < model.indexOf(visibleElements.get(0));
    }

    /**
     * Compares if index of e1 is lesser than index of e2
     * <br> If true, then it means that e1 is BEFORE e2, at list model.
     *
     * @param e1
     * @param e2
     * @return true, if only if, index of e1 is lesser than index of e2, at list
     * model.
     */
    public boolean isBefore(T e1, T e2) {
        return model.indexOf(e1) < model.indexOf(e2);
    }

    /**
     * Compares if index of e1 is lesser or equals than index of e2
     * <br> If true, then it means that e1 is BEFORE e2, at list model.
     * <br> Or it means e1 and e2 point to the same element.
     *
     * @param e1
     * @param e2
     * @return true, if only if, index of e1 is lesser or equals than index of
     * e2, at list model.
     */
    private boolean isBeforeOrEquals(T e1, T e2) {
        return model.indexOf(e1) <= model.indexOf(e2);
    }

    /**
     * Compares if index of is greater than the index of the last visible
     * element.
     *
     * @param index
     * @return true, if only if, index > index of last visible element.
     */
    private boolean isAfterLastVisibleElement(int index) {
        return index > model.indexOf(visibleElements.get(visibleElements.size() - 1));
    }

    /**
     * Compares if index is greater than index of e.
     * <br> If true, then it means that index points to an element AFTER the e
     * element, at list model.
     *
     * @param index
     * @param e
     * @return true, if only if, index > index of e, at list model.
     */
    private boolean isAfter(int index, T e) {
        return index > model.indexOf(e);
    }

    /**
     * Compares if index of e1 is greater than index of e2.
     * <br> If true, then it means that e1 is AFTER e2, at list model.
     *
     * @param e1
     * @param e2
     * @return true, if only if, index of e1 > index of e2, at list model.
     */
    public boolean isAfter(T e1, T e2) {
        return model.indexOf(e1) > model.indexOf(e2);
    }

    private synchronized void makeTopMostVisible(T e) {
        while (isBefore(visibleElements.get(0), e)) {
            scrollUpPrivate();
        }
    }

    /**
     * Makes the first element visible.
     */
    public void firstVisible() {
        doFastUpdate();
    }

    /**
     * Makes e first visible.
     * @param e 
     */
    public void makeFirstVisible(T e) {
        makeTopMostVisible(e);
    }

    /**
     * Affects the<code> model, the changeful model</code> but not the <code>exactModel</code>.<br>
     * Makes first models element visible.<br>
     * Changes <code>STATE</code> from <code>ADDING_AS_SEARCHING_RESULT</code> to <code>ADDED_AS_SEARCHING_RESULT_READY</code>.
     * @see #getChangefulModel() 
     * @see #getExactModel() 
     * @param searchingResult 
     */
    public void addAsSearchingResult(Collection<T> searchingResult) {

        STATE.setValue(ADDING_AS_SEARCHING_RESULT);

        model.clear();

        searchingResult.stream().forEach((t) -> {
            try {

                if (t != null) {
                    if (!model.contains(t)) {
                        model.add(t);
                    }
                }
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.INFO, null, e);
            }
        });

        doFastUpdateAfterSearching();

        STATE.setValue(ADDED_AS_SEARCHING_RESULT_READY);

    }

    public void setUpBeforeSearching() {
        model.clear();
    }

    /**
     * Makes <code>ScrollableList</code>'s last element visible.<br>
     * Changes STATE from <code>ADDING_LAST_VISIBLE</code> to <code>ADDED_LAST_VISIBLE_READY</code>.
     */
    @SuppressWarnings("empty-statement")
    public void lastVisible() {
        model.clear();
        model.addAll(temp);
        INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
        INVISIBLE_ELEMENTS_TOP_STACK.clear();

        STATE.setValue(ADDING_LAST_VISIBLE);
        if (model.size() > 0) {

            visibleElements.clear();

            if (model.size() > VISIBLE_ELEMENTS_MAX_NUM.intValue()) {

                int j;

                for (j = 0; j < model.size() - VISIBLE_ELEMENTS_MAX_NUM.intValue(); j++) {
                    INVISIBLE_ELEMENTS_TOP_STACK.push(model.get(j));
                }

                for (int i = j; i < model.size(); i++) {
                    visibleElements.add(model.get(i));
                }

            } else {
                visibleElements.addAll(model);
                INVISIBLE_ELEMENTS_TOP_STACK.clear();
                INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
            }

            while (scrollUp());
            lastAdded = model.get(model.size() - 1);
        }
        STATE.setValue(ADDED_LAST_VISIBLE_READY);

    }

    private boolean isDirty = true;

    public void cleanBeforeLoading() {
        temp.clear();
        isDirty = false;
    }

    @Deprecated
    public void load(T e) {
        if (!isDirty) {
            //descobre posicao correta para e; coloca e nela
            //(coloca na ordem natural de elementos e)
            temp.add(e);
        }
    }

    public void load(Collection<T> ts) {
        ts.forEach((t) -> {

            if (t != null) {
                //descobre posicao correta para e; coloca e nela
                //(coloca na ordem natural de elementos e)
                temp.add(t);
            }

        });
    }

    /**
     *
     */
    public void loadingDone() {
        isDirty = true;
        doFastUpdate();
    }

    /**
     * Changes STATE to REMOVED_BULK_READY and removes bulk and updates model.
     *
     * @param bulk
     */
    public void doBulkRemove(Collection<T> bulk) {
        STATE.setValue(REMOVING_BULK);
        doBulkRemoveSilently(bulk);
        STATE.setValue(REMOVED_BULK_READY);
    }

    /**
     * Does the work silently, meaning LISTENERS CAN'T hear whats going on.<br>
     * Doesnot change STATE to REMOVED_BULK_READY and removes bulk and updates
     * model.
     *
     * @param bulk
     */
    public void doBulkRemoveSilently(Collection<T> bulk) {

        bulk.stream().forEach((t) -> {
            try {

                if (t != null) {
                    temp.remove(t);
                }
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.INFO, null, e);
            }
        });

        doFastUpdateSylently();

    }

    /**
     * Does the work silently, meaning LISTENERS CAN'T hear whats going on.<br>
     *
     * @param bulk
     */
    public void doBulkAdd(Collection<T> bulk) {

        bulk.stream().forEach((t) -> {
            try {

                if (t != null) {
                    temp.add(t);
                }
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.INFO, null, e);
            }
        });

        doFastUpdateSylently();

    }

    /**
     * Removes from exactModel the itens in bulk.<br>
     * Sets the <code>STATE</code> from <code>REMOVING_AS_UN_IMPORTING</code> to
     * <code>REMOVED_AS_UN_IMPORTING_READY</code>.
     * @param bulk the bulk itens
     */
    public void doBulkUnImporting(Collection<T> bulk) {
        STATE.setValue(REMOVING_AS_UN_IMPORTING);
        doBulkRemove(bulk);
        STATE.setValue(REMOVED_AS_UN_IMPORTING_READY);
    }

    /**
     * Adds to exactModel the itens in bulk.<br>
     * Sets the <code>STATE</code> from <code>ADDING_AS_IMPORTING</code> to
     * <code>ADDED_AS_IMPORTING_READY</code>.
     * @param bulk the bulk itens
     */
    public void doBulkImporting(Collection<T> bulk) {
        STATE.setValue(ADDING_AS_IMPORTING);
        doBulkAdd(bulk);
        STATE.setValue(ADDED_AS_IMPORTING_READY);
    }

    /**
     * Edits the list.<br>
     *
     * @param old the old value to be removed from.
     * @param neW the new value to be added at.
     */
    public void edit(T old, T neW) {
        STATE.setValue(EDITING);
        temp.remove(old);
        temp.add(neW);
        doFastUpdateSylently();
        STATE.setValue(EDITED_READY);
    }

//    Comparator<ScrollableListItem> c = (o1, o2) -> {
//        return o1.getName().compareTo(o2.getName());
//    };
//    ScrollableListItem key = new Item("");
//    /**
//     * Edits the list item.<br>
//     *
//     * @param oldName the old value to be updated.
//     * @param newName the new value.
//     */
//    public void edit(String oldName, String newName) {
//        
//        key.setName(oldName);
//        List<ScrollableListItem> tempList = new ArrayList<>((Collection<ScrollableListItem>) (temp));
//        int index = Collections.binarySearch(tempList, key, c);
//        
//        if (index >= 0) {
//            STATE.setValue(EDITING);
//            List<T> tempLst = new ArrayList<>(temp);
//            T sli = tempLst.get(index);
//            temp.remove(sli);
//            ((ScrollableListItem) sli).setName(newName);
//            temp.add(sli);
//            doFastUpdateSylently();
//            tempLst.clear();
//            STATE.setValue(EDITED_READY);
//        }
//        tempList.clear();
//        
//    }
    /**
     * Edits the list item.<br>
     *
     * @param old the old value to be updated.
     * @param newName the new value.
     */
    public void edit(T old, String newName) {
        STATE.setValue(EDITING);
        temp.remove(old);
        ((ScrollableListItem) old).setName(newName);
        temp.add(old);
        doFastUpdateSylently();
        STATE.setValue(EDITED_READY);
    }

    /**
     * Does change STATE to ADDED_FAST_UPDATE_READY and makes visible the first
     * element.<br>
     * It does it in a fastest fashion way... contrasting using the scrollUp
     * method<br>
     * that is the slowest mechanism to achieve the same result.
     */
    private synchronized void doFastUpdate() {
        STATE.setValue(ADDING_FAST_UPDATE);
        doFastUpdateSylently();
        STATE.setValue(ADDED_FAST_UPDATE_READY);
    }

    /**
     * Does the work silently, meaning LISTENERS CAN'T hear whats going on.<br>
     * Doesnot change STATE and makes visible the first element.<br>
     * It does it in a fastest fashion way... contrasting using the scrollUp
     * method<br>
     * that is the slowest mechanism to achieve the same result.
     */
    private synchronized void doFastUpdateSylently() {
        model.clear();
        model.addAll(temp);
        visibleElements.clear();
        INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
        INVISIBLE_ELEMENTS_TOP_STACK.clear();

        if (model.size() > 0) {

            if (model.size() > VISIBLE_ELEMENTS_MAX_NUM.intValue()) {

                int j;
                for (j = 1; j < VISIBLE_ELEMENTS_MAX_NUM.intValue(); j++) {
                    visibleElements.add(model.get(j));
                }

                for (int i = model.size() - 1; i >= j; i--) {
                    INVISIBLE_ELEMENTS_BOTTOM_STACK.push(model.get(i));
                }

                //t está na posicao correta
                //ajusta elementos visiveis e INVISIVEIS
                insertInListAndAdjustInvisibleElements(0, model.get(0));

                lastAdded = model.get(0);

            } else {
                visibleElements.addAll(model);
                INVISIBLE_ELEMENTS_TOP_STACK.clear();
                INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
            }

            lastAdded = model.get(0);
        }
    }

    /**
     * Does the work silently, meaning LISTENERS CAN'T hear whats going on.<br>
     */
    private synchronized void doFastUpdateAfterSearching() {

        INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
        INVISIBLE_ELEMENTS_TOP_STACK.clear();
        visibleElements.clear();

        if (model.size() > 0) {

            if (model.size() > VISIBLE_ELEMENTS_MAX_NUM.intValue()) {

                int j;
                for (j = 1; j < VISIBLE_ELEMENTS_MAX_NUM.intValue(); j++) {
                    visibleElements.add(model.get(j));
                }

                for (int i = model.size() - 1; i >= j; i--) {
                    INVISIBLE_ELEMENTS_BOTTOM_STACK.push(model.get(i));
                }

                //t está na posicao correta
                //ajusta elementos visiveis e INVISIVEIS
                insertInListAndAdjustInvisibleElements(0, model.get(0));

                lastAdded = model.get(0);

            } else {
                visibleElements.addAll(model);
                INVISIBLE_ELEMENTS_TOP_STACK.clear();
                INVISIBLE_ELEMENTS_BOTTOM_STACK.clear();
            }

            lastAdded = model.get(0);
        }
    }

    /**
     * Tells if has any element after the reference.
     *
     * @param reference
     * @return true, if reference is not at the end of the model, a list
     * implementation.<br>
     * false, if reference points to the end of the list.
     */
    public boolean hasNext(T reference) {
        return indexOf(reference) != model.size() - 1;
    }

    /**
     * Checks first if has any next element after the reference. If so, returns
     * the next element in the model list,<br>
     * such as the index of the next is +1 greather than the index of the
     * referece.<br>
     * If has not a next element, returns null.
     *
     * @param reference
     * @return
     */
    public T getNext(T reference) {
        if (hasNext(reference)) {
            return model.get(indexOf(reference) + 1);
        } else {
            return null;
        }
    }

    /**
     * Tells if has any element before the reference.
     *
     * @param reference
     * @return true, if reference is not at the beggining of the model, a list
     * implementation.<br>
     * false, if reference points to the beggining of the list.
     */
    public boolean hasBefore(T reference) {
        if (indexOf(reference) == -1) {
            return false;
        }
        return indexOf(reference) != 0;
    }

    /**
     * Checks first if has any element before reference. If so, returns the
     * before element in the model list,<br>
     * such as the index of the before is -1 lesser than the index of the
     * referece.<br>
     * If has not a before element, returns null.
     *
     * @param reference
     * @return
     */
    public T getBefore(T reference) {
        if (hasBefore(reference)) {
            return model.get(indexOf(reference) - 1);
        } else {
            return null;
        }
    }

    /**
     * Tells if e is in visible elements.
     *
     * @param e
     * @return
     */
    public boolean isVisible(T e) {
        return visibleElements.contains(e);
    }

    /**
     * If has at least 1 visible element, returns the element in the midle of
     * the list.<br>
     * Otherwise, returns null;
     *
     * @return
     */
    public T getTheMidleVisible() {
        if (visibleElements.isEmpty()) {
            return null;
        } else {
            int midle = visibleElements.size() / 2;
            return visibleElements.get(midle);
        }
    }

    public static void main(String[] args) {

        //STRESSING TESTE
        PersistenceService persistenceService = PersistenceServiceImpl_JDBC_SQLITE.getInstace();
        Collection<Receita> receitas = new ArrayList<>();

        try {
            receitas = persistenceService.getAll();
        } catch (Exception ex) {
            Logger.getLogger(AppContainer.class.getName()).log(Level.SEVERE, null, ex);
        }

        double i = 1;
        if (receitas.isEmpty()) {

        } else {

            ScrollableList<FakeItem> scrollableList = new ScrollableList<>();

//            scrollableList.setVisibleElementsMaxNum(8000);
            for (Receita receita : receitas) {

                FakeItem item = new FakeItem(receita.getNome());

                System.out.println("added " + receita.getNome() + " " + ((int) (i)) + "/" + receitas.size());

                scrollableList.addAndUpdateVisibleElements(item);

                i++;

            }
        }
    }

    /**
     * Tells if CONSNTANT MODEL is empty.
     * @return 
     */
    public boolean isEmpty() {
        return temp.isEmpty();
    }

}
