package br.com.undra.jfxcomponents.scrollablelist.mvc.model;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;

/**
 * A VBox placeholder.
 * @author alexandre
 */
public class TransparentItem extends Pane{

    public TransparentItem() {
        
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLTransparentItem.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        
    }
    
    
    
}
