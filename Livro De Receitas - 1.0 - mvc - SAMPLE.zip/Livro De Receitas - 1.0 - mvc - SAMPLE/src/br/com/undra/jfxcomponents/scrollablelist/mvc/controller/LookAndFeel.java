package br.com.undra.jfxcomponents.scrollablelist.mvc.controller;

/**
 * A look and feel bean for Full Scrollers modeling.
 * @author alexandre
 */
public class LookAndFeel {
    
    private String id;
    private String cssTheme;
    private boolean compactList;
    private boolean roundCorner;

    public LookAndFeel(String id, String cssTheme, boolean compactList, boolean roundCorner) {
        this.id = id;
        this.cssTheme = cssTheme;
        this.compactList = compactList;
        this.roundCorner = roundCorner;
    }

    public String getId() {
        return id;
    }

    public String getCssTheme() {
        return cssTheme;
    }

    public boolean isCompactList() {
        return compactList;
    }

    public boolean isRoundCorner() {
        return roundCorner;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName()+" "+"id="+id+", cssTheme="+cssTheme+", isCompactList="+compactList+", isRoundCorner="+roundCorner;
    }
    
    
    
}
