package br.com.undra.jfxcomponents.scrollablelist.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import static br.com.undra.jfxcomponents.scrollablelist.util.Selector.MULTI_SELECTION;
import static br.com.undra.jfxcomponents.scrollablelist.util.Selector.SINGLE_SELECTION;
import br.com.undra.jfxcomponents.util.Util;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.input.MouseEvent;

/**
 * Modela um seletor de itens.<br>
 * STATES :
 * <br>NO SELECTION STATE<br>
 * SINGLE SELECTION STATE<br>
 * SINGLE SELECTION CHANGED STATE<br>
 * SINGLE_SELECTION_REMOVED STATE<br>
 * SINGLE SELECTION ADDED STATE<br>
 * MULTI SELECTION STATE<br>
 * MULTI SELECTION ADDED STATE<br>
 * MULTI SELECTION REMOVED STATE<br>
 * MULTI SELECTION CHANGED STATE<br>
 * SELECTING ALL STATE<br>
 * SELECTING ALL ADDED ONE STATE<br>
 * SELECTED ALL STATE<br>
 * SINGLE TO MULTI SELECTION CHANGED STATE<br>
 *
 * @author alexandre
 */
public class Selector {

    //THE SELECTOR'S STATES
    static public String SILENCE = "SILENCE";
    static public String NO_SELECTION = "NO_SELECTION";
    static public String SINGLE_SELECTION = "SINGLE_SELECTION";
    static public String SINGLE_SELECTION_CHANGED = "SINGLE_SELECTION_CHANGED";
    static public String SINGLE_SELECTION_REMOVED = "SINGLE_SELECTION_REMOVED";
    static public String SINGLE_SELECTION_ADDED = "SINGLE_SELECTION_ADDED";
    static public String SINGLE_SELECTION_REVERSAL_STARTED = "SINGLE_SELECTION_REVERSAL_STARTED";
    static public String SINGLE_SELECTION_REVERSAL_DONE = "SINGLE_SELECTION_REVERSAL_DONE";
    static public String MULTI_SELECTION = "MULTI_SELECTION";
    static public String MULTI_SELECTION_ADDED = "MULTI_SELECTION_ADDED";
    static public String MULTI_SELECTION_REMOVED = "MULTI_SELECTION_REMOVED";
    static public String MULTI_SELECTION_CHANGED = "MULTI_SELECTION_CHANGED";
    static public String SELECTING_ALL = "SELECTING_ALL";
    static public String SELECTING_ALL_ADDED_ONE = "SELECTING_ALL_ADDED_ONE";
    static public String SELECTED_ALL = "SELECTED_ALL";
    static public String UNSELECTING_ALL = "UNSELECTING_ALL";
    static public String UNSELECTED_ALL = "UNSELECTED_ALL";
    static public String SINGLE_TO_MULTI_SELECTION_CHANGED = "SINGLE_TO_MULTI_SELECTION_CHANGED";
    static public String INVERTING_SELECTION = "INVERTING_SELECTION";
    static public String INVERTED_SELECTION_READY = "INVERTED_SELECTION_READY";

    private final StringProperty STATE = new SimpleStringProperty(NO_SELECTION);

    private final List<Item> tmpSelection = new ArrayList<>();
    private final List<Item> tmpModel = new ArrayList<>();

    private Item current;
    private Item currentUnselected;
    private Item lastSelectectBeforeMultSelection;

    private volatile boolean hasHandledDeletion = false;
    private volatile double selectionProgress = 0;

    public void handleSelection(ScrollableListContainerSimple container, MouseEvent event, Item item) {

        current = item;

        if (isNoSelectionState()) {
            handleNoSelectionState(container, event, item);
        } else if (isSingleSelectionState()) {
            handleSingleSelectionState(container, event, item);
        } else if (isMultiSelectionState()) {
            handleMultiSelectionState(container, event, item);
        } else if (isSelectedAllState()) {
            handleSelectedAllState(container, event, item);
        } else if (isInvertedSelectionState(container, event, item)) {
            handleInvertedSelectionState(container, event, item);
        }

    }

    public StringProperty getSTATE() {
        return STATE;
    }

    public Item getCurrent() {
        return current;
    }

    public Item getCurrentUnselected() {
        return currentUnselected;
    }

    private boolean isNoSelectionState() {
        return STATE.getValue().equals(NO_SELECTION);
    }

    private boolean isSingleSelectionState() {
        return STATE.getValue().equals(SINGLE_SELECTION);
    }

    private boolean isMultiSelectionState() {
        return STATE.getValue().equals(MULTI_SELECTION);
    }

    private boolean isSelectedAllState() {
        return STATE.getValue().equals(SELECTED_ALL);
    }

    private boolean isInvertedSelectionState(ScrollableListContainerSimple container, MouseEvent event, Item item) {
        return STATE.getValue().equals(INVERTED_SELECTION_READY);
    }

    private boolean isSingleDeletionState() {
        return STATE.getValue().equals(SINGLE_SELECTION);
    }

    private boolean isMultiDelectionState() {
        return STATE.getValue().equals(MULTI_SELECTION);
    }

    /**
     * O estado do seletor é NO_SELECTION e ocorreu algum evento de seleção ou
     * DEseleção.<br>
     * Seleciona o item. Adiciona o item à lista de selecionados do
     * containier.<br>
     * E muda o estado do SELECTOR para SINGLE_SELECTION ou MULTI_SELECTION.
     *
     * @param container
     * @param event
     * @param item
     */
    private void handleNoSelectionState(ScrollableListContainerSimple container, MouseEvent event, Item item) {

        if (isSingleSelection(event)) {

            if (!isSelected(container, item)) {
                item.setSelected(true);
                STATE.setValue(SINGLE_SELECTION_CHANGED);
                container.getSelection().add(item);
                STATE.setValue(SINGLE_SELECTION_ADDED);
                STATE.setValue(SINGLE_SELECTION);
                current = item;
            }

        } else if (isMultiSelection(event)) {

            if (!isSelected(container, item)) {
                item.setSelected(true);
                STATE.setValue(MULTI_SELECTION_CHANGED);
                container.getSelection().add(item);
                STATE.setValue(MULTI_SELECTION_ADDED);
                STATE.setValue(MULTI_SELECTION);
                current = item;
                lastSelectectBeforeMultSelection = item;
            }

        }

    }

    /**
     * O estado do seletor é SINGLE_SELECTION e ocorreu algum evento de seleção
     * ou DEseleção.<br>
     * Se apenas click no item,
     * <br>*** Caso esteja SELECIONADO, DEseleciona-o,remove-o da selecao e muda
     * STATE para NO_SELECTION. <br>
     * *** Caso NAO esteja selecionado, SELECIONA o item, adiona-o à selecao,
     * remove o anterior da seleção<br>
     * *** e DEseleciona o anterior e reseta STATE para SINGLE_SELECTION.<br>
     * Se CTRL + click no item,
     * <br>*** Caso esteja SELECIONADO, DEseleciona-o,remove-o da selecao e muda
     * STATE para NO_SELECTION <br>
     * *** caso NAO esteja SELECIONADO, SELECIONA o item, adiona-o à selecao,
     * remove o anterior da seleção<br>
     * *** e DEseleciona o anterior e MUDA STATE para MULTI_SELECTION.
     *
     * @param container
     * @param event
     * @param item
     */
    private void handleSingleSelectionState(ScrollableListContainerSimple container, MouseEvent event, Item item) {

        if (isSingleSelection(event)) {

            //click em si mesmo selecionado
            if (item.isSelected()) {
                //apenas deseleciona e remove da selecao e muda state para no selection
                item.setSelected(false);
                STATE.setValue(SINGLE_SELECTION_CHANGED);
                container.getSelection().remove(0);
                STATE.setValue(SINGLE_SELECTION_REMOVED);
                current = null;
                currentUnselected = item;
                STATE.setValue(NO_SELECTION);

            } else {//click num outro item
                //seleciona item, adiciona à selecao, DEseleciona anterior e remove anterior da selecao
                container.getSelection().get(0).setSelected(false);
                currentUnselected = container.getSelection().get(0);
                STATE.setValue(SINGLE_SELECTION_CHANGED);
                container.getSelection().remove(0);
                STATE.setValue(SINGLE_SELECTION_REMOVED);
                if (!isSelected(container, item)) {
                    item.setSelected(true);
                    STATE.setValue(SINGLE_SELECTION_CHANGED);
                    container.getSelection().add(item);
                    STATE.setValue(SINGLE_SELECTION_ADDED);
                    current = item;
                }

                STATE.setValue(SINGLE_SELECTION);
            }

        } else if (isMultiSelection(event)) {
            //ctrl + click : clicado em si mesmo já selecionado, 
            //apena DEseleciona e remove-o da selecao e muda state para no selection 
            if (item.isSelected()) {
                STATE.setValue(SINGLE_TO_MULTI_SELECTION_CHANGED);
//                item.setSelected(false);
//                container.getSelection().remove(0);
//                STATE.setValue(NO_SELECTION);
                STATE.setValue(MULTI_SELECTION);
            } else {//ctrl + click : seleciona item, 
                //adiciona à selecao, DEseleciona anterior e remove anterior da selecao
                container.getSelection().get(0).setSelected(false);
                currentUnselected = container.getSelection().get(0);
                STATE.setValue(MULTI_SELECTION_CHANGED);
                container.getSelection().remove(0);
                STATE.setValue(MULTI_SELECTION_REMOVED);
                item.setSelected(true);
                current = item;
                STATE.setValue(MULTI_SELECTION_CHANGED);

                container.getSelection().add(item);
                STATE.setValue(MULTI_SELECTION_ADDED);
                STATE.setValue(MULTI_SELECTION);
            }

        }

    }

    /**
     * O estado do seletor é MULTI_SELECTION e ocorreu algum evento de seleção
     * ou DEseleção.<br>
     * Se apenas click no item,
     * <br>*** Caso esteja SELECIONADO, DEseleciona todos os outros itens,remove
     * <br>***todos os outros itens da selecao e muda STATE para
     * SINGLE_SELECTION. <br>
     * *** Caso NAO esteja selecionado, SELECIONA o item, adiona-o à selecao,
     * <br>*** DEseleciona todos os outros itens,remove todos os outros itens da
     * selecao<br>
     * ***e muda STATE para SINGLE_SELECTION. <br>
     * Se CTRL + click no item,
     * <br>*** Caso esteja SELECIONADO, DEseleciona-o,remove-o da selecao e caso
     * lista selecao is empty,<br>
     * ***muda STATE para NO_SELECTION <br>
     * *** Caso NAO esteja SELECIONADO, SELECIONA o item, adiona-o à
     * selecao,<br>
     * ***e reseta STATE para MULTI_SELECTION.
     *
     * @param container
     * @param event
     * @param item
     */
    private void handleMultiSelectionState(ScrollableListContainerSimple container, MouseEvent event, Item item) {
        //apena click : limpara multiselecao. Selecionara ou nao o item clicado.
        if (isSingleSelection(event)) {
            //click em si mesmo
            //LIMPARÁ multi selecao
            if (item.isSelected()) {
                //click em si mesmo já selecionado.DEselecionara todos outros.
                //Mantera este item selecionado, cancelando MULTI selecao e indo para STATE SINGLE_SELECTION

                unselectAllAndRemoveAllFromSelectionButThis(container, item);
                STATE.setValue(SINGLE_SELECTION_CHANGED);

            } else {//click em algum fora da multi selecao:limpa selecao;
                //deseleciona todos antes selecionados, seleciona item, adiciona-o à selecao
                //e muda STATE para SINGLE_SELECTION 

                if (!isSelected(container, item)) {
                    item.setSelected(true);
                    container.getSelection().add(item);
                    unselectAllAndRemoveAllFromSelectionButThis(container, item);
                    STATE.setValue(SINGLE_SELECTION_CHANGED);
                }

            }

            STATE.setValue(SINGLE_SELECTION);

            current = item;

        } else if (isMultiSelection(event)) {//CTRL + click : OU AUMENTARÁ OU DIMINUIŔA selecionados.

            if (item.isSelected()) {//DIMINUI DE 1 OS SELECIONADOS, DESELECIONANDO O item

                item.setSelected(false);
                currentUnselected = item;
                STATE.setValue(MULTI_SELECTION_CHANGED);
                container.getSelection().remove(item);
                STATE.setValue(MULTI_SELECTION_REMOVED);

                current = item;

                if (container.getSelection().isEmpty()) {
                    STATE.setValue(NO_SELECTION);
                } else {
                    STATE.setValue(MULTI_SELECTION);
                }
            } else {//AUMENTA SELECIONADOS

                if (!isSelected(container, item)) {
                    item.setSelected(true);
                    STATE.setValue(MULTI_SELECTION_CHANGED);
                    container.getSelection().add(item);
                    STATE.setValue(MULTI_SELECTION_ADDED);
                    STATE.setValue(MULTI_SELECTION);
                    current = item;
                }
            }
        }
    }

    /**
     * O estado do seletor é SELECTED_ALL e ocorreu algum evento de seleção ou
     * DEseleção.<br>
     * Se apenas click no item
     * <br>*** DEseleciona todos os outros itens,remove
     * <br>todos os outros itens da selecao e muda STATE para SINGLE_SELECTION.
     * <br>
     * Se CTRL + click no item,
     * <br>***DEseleciona-o,remove-o da selecao e caso lista selecao is empty,
     * muda STATE para NO_SELECTION, se não,<br>
     * muda STATE para MULTI_SELECTION.
     *
     * @param container
     * @param event
     * @param item
     */
    private void handleSelectedAllState(ScrollableListContainerSimple container, MouseEvent event, Item item) {
        handleMultiSelectionState(container, event, item);
    }
    
    /**
     * O estado do seletor é  INVERTED_SELECTION_READY e ocorreu algum evento de seleção ou
     * DEseleção.<br>
     * Se apenas click no item
     * <br>*** DEseleciona todos os outros itens,remove
     * <br>todos os outros itens da selecao e muda STATE para SINGLE_SELECTION.
     * <br>
     * Se CTRL + click no item,
     * <br>***DEseleciona-o,remove-o da selecao e caso lista selecao is empty,
     * muda STATE para NO_SELECTION, se não,<br>
     * muda STATE para MULTI_SELECTION.
     *
     * @param container
     * @param event
     * @param item
     */
    private void handleInvertedSelectionState(ScrollableListContainerSimple container, MouseEvent event, Item item) {
        handleMultiSelectionState(container, event, item);
    }

    /**
     * Deselecionará todos itens e removerá todos itens da lista de seleção,
     * exceto o {@code item}.
     *
     * @param container o container da lista de seleção.
     * @param item o item contra o qual se checará deseleção e remoção da lista
     * selection.
     */
    private void unselectAllAndRemoveAllFromSelectionButThis(ScrollableListContainerSimple container, Item item) {

        tmpSelection.clear();
        tmpSelection.addAll(container.getSelection());
        tmpSelection.parallelStream().filter((selected) -> (!selected.equals(item))).forEachOrdered((selected) -> {
            selected.setSelected(false);
            container.getSelection().remove(selected);
        });
    }

    private boolean isSingleSelection(MouseEvent event) {
        return !event.isControlDown();
    }

    private boolean isMultiSelection(MouseEvent event) {
        return event.isControlDown();
    }

    public double getSelectionProgress() {
        return selectionProgress;
    }

    /**
     * Seleciona todos itens do currentModel do container e adiciona<br>
     * todos itens do currentModel do container à lista de selecao.<br>
     * Muda STATE para SELECTED_ALL.
     *
     * @param container o container da lista de seleção.
     */
    public synchronized void selectAll(ScrollableListContainerSimple container) {

        tmpModel.clear();
        selectionProgress = 0;

        Platform.runLater(() -> {
            container.getWrapper().setUpBeforeSelectingAll();
            STATE.setValue(SELECTING_ALL);
        });

        tmpModel.addAll(container.getCurrentModel().getChangefulModel());

        double i = 0;
        int modelSize = container.getCurrentModel().getChangefulModel().size() - container.getSelection().size();
        container.setProgressValue(0);

        for (Item item : tmpModel) {
            if (!isSelected(container, item)) {
                try {
                    item.clickSelectingOnly();
                } catch (ConcurrentModificationException e) {
                    try {
                        Thread.sleep(200);
                    } catch (Exception ex) {
                    }
                    container.getCurrentModel().get(item).clickSelectingOnly();
                }
                container.getSelection().add(item);
                Platform.runLater(() -> {
                    InfoUpdater.updateAfterSelected(container, item);
                });
                i++;
                double selectionProgress = i / modelSize;
                container.setProgressValue(selectionProgress);
                this.selectionProgress = selectionProgress;
            }
        }

        container.setProgressValue(0);
        tmpModel.clear();
        Util.GC();

        Platform.runLater(() -> {

            container.getWrapper().setUpAfterSelectingAll();
            if (container.getSelection().isEmpty()) {
                STATE.setValue(NO_SELECTION);
            } else {
                STATE.setValue(SELECTED_ALL);
            }
            Util.GC();
        });
    }

    /**
     * Informa se o item já está na coleção selection do container.
     * <br> Se estiver seu estilo é de selectionado.Se nao, de DE-Selecionado.
     *
     * @param container o container.
     * @param item o item a checar.
     * @return true, se e só se, o item está na colecao selection do container.
     */
    private static boolean isSelected(ScrollableListContainerSimple container, Item item) {
        return container.getSelection().contains(item);
    }

    /**
     * Deseleciona todos itens e remove todos itens da lista de selecao.<br>
     * Muda STATE para UNSELECTED_ALL e depois para NO_SELECTION.
     *
     * @param container o container da lista de seleção.
     */
    public synchronized void unSelectAll(ScrollableListContainerSimple container) {

        tmpSelection.clear();
        tmpSelection.addAll(container.getSelection());
        tmpSelection.forEach(i -> i.clickUnSelectingOnly());
        container.getSelection().clear();
        Platform.runLater(() -> {
            STATE.setValue(UNSELECTED_ALL);
            STATE.setValue(NO_SELECTION);
            tmpSelection.clear();
        });
        current = null;
    }

    /**
     * Inverte seleção.<br>
     * Muda STATE para MULTI_SELECTION ou para NO_SELECTION, apropriadamente.
     *
     * @param container o container da lista de seleção.
     */
    public void invertSelection(ScrollableListContainerSimple container) {

        Platform.runLater(() -> {
            container.getWrapper().setUpBeforeInvertSelection();
            STATE.setValue(INVERTING_SELECTION);
        });

        tmpSelection.clear();
        tmpSelection.addAll(container.getCurrentModel().getChangefulModel());

        double i = 0;
        int modelSize = container.getCurrentModel().getChangefulModel().size();
        container.setProgressValue(0);

        for (Item item : tmpSelection) {
            if (item != null) {
                if (item.isSelected()) {
                    item.clickUnSelectingOnly();
                    container.getSelection().remove(item);
                } else {
                    item.clickSelectingOnly();
                    container.getSelection().add(item);
                }
            }

            Platform.runLater(() -> {
                if (STATE.getValue().equals(NO_SELECTION)) {

                    if (container.getSelection().isEmpty()) {
                        STATE.setValue(NO_SELECTION);
                    } else {
                        STATE.setValue(MULTI_SELECTION);
                    }

                } else if (STATE.getValue().equals(SINGLE_SELECTION)) {

                    if (container.getSelection().isEmpty()) {
                        STATE.setValue(NO_SELECTION);
                    } else {
                        if (container.getSelection().size() > 1) {
                            STATE.setValue(MULTI_SELECTION);
                        }
                    }

                } else if (STATE.getValue().equals(MULTI_SELECTION)) {
                    if (container.getSelection().isEmpty()) {
                        STATE.setValue(NO_SELECTION);
                    } else {
                        STATE.setValue(MULTI_SELECTION);
                    }
                }
                InfoUpdater.updateAfterInvertSelection(container, item);
            });
            i++;
            double selectionProgress = i / modelSize;
            container.setProgressValue(selectionProgress);
            this.selectionProgress = selectionProgress;
        }

        container.setProgressValue(0);
        Util.GC();

        Platform.runLater(() -> {
            container.getWrapper().setUpAfterInvertSelection();
            STATE.setValue(SILENCE);

            if (container.getSelection().isEmpty()) {
                STATE.setValue(NO_SELECTION);
            } else {
                STATE.setValue(INVERTED_SELECTION_READY);
            }

            tmpSelection.clear();
        });

    }

    public boolean isAllSelected(ScrollableListContainerSimple container) {
        return container.getSelection().size() == container.getCurrentModel().size();
    }

    public boolean noneSelected(ScrollableListContainerSimple container) {
        return container.getSelection().isEmpty();
    }

    /**
     * Remove o item da selecao e o DEseleciona.<br>
     * Se STATE = SINGLE SELECTION, reseta STATE para NO SELECTION.<br>
     * Se STATE = MULTI_SELECTION, reseta STATE para NO SELECTION ou
     * MULTI_SELECTION, apropriadamente.
     *
     * @param container
     * @param item
     */
    public void handleDeletion(ScrollableListContainerSimple container, Item item) {

        Platform.runLater(() -> {

            hasHandledDeletion = false;

            if (isSingleDeletionState()) {

                item.setSelected(false);
                STATE.setValue(SINGLE_SELECTION_CHANGED);
                container.getSelection().remove(item);
                STATE.setValue(SINGLE_SELECTION_REMOVED);

                STATE.setValue(NO_SELECTION);

            } else if (isMultiDelectionState() || isSelectedAllState()) {

                item.setSelected(false);
                STATE.setValue(MULTI_SELECTION_CHANGED);
                container.getSelection().remove(item);

                STATE.setValue(MULTI_SELECTION_REMOVED);

                if (container.getSelection().isEmpty()) {
                    STATE.setValue(NO_SELECTION);
                } else {
                    STATE.setValue(MULTI_SELECTION);
                }

            }
            hasHandledDeletion = true;
        });
    }

    /**
     * Remove o bulk de itens da selecao e o DEseleciona.<br>
     * Muda STATE para NO_SELECTION,se nao restar objeto selecionado.
     *
     * @param container
     * @param bulk
     */
    public void handleDeletionSilently(ScrollableListContainerSimple container, Collection<Item> bulk) {

        //AVOIDING CONCURRENT MODIFICATION EXCEPTION
        Collection<Item> bulkL = new ArrayList<>(bulk);

        hasHandledDeletion = false;

        for (Item item : bulkL) {
            item.setSelected(false);
            container.getSelection().remove(item);
        }

        Platform.runLater(() -> {
            if (container.getSelection().isEmpty()) {
                STATE.setValue(NO_SELECTION);
            }
        });

        bulkL.clear();
        hasHandledDeletion = true;

    }

    public boolean hasHandledDeletion() {
        return hasHandledDeletion;
    }

    public void setHasHandledDeletion(boolean hasHandledDeletion) {
        this.hasHandledDeletion = hasHandledDeletion;
    }

    Comparator<Item> c = (o1, o2) -> {
        return o1.getDescricao().compareTo(o2.getDescricao());
    };
    Item key = new Item("");

    public void reverseSingleSelection(ScrollableListContainerSimple container, Item item) {

        try {

            Platform.runLater(() -> {

                if (STATE.getValue().equals(SINGLE_SELECTION)) {

                    key.setDescricao(item.getDescricao());

                    int index = Collections.binarySearch(container.getCurrentModel().get(), key, c);

                    if (index >= 0) {

                        STATE.setValue(SINGLE_SELECTION_REVERSAL_STARTED);
                        container.getSelection().get(0).setSelected(false);
                        currentUnselected = container.getSelection().get(0);
                        container.getSelection().remove(0);
                        current = container.getCurrentModel().get(index);
                        current.setSelected(true);
                        container.getSelection().add(current);
                        STATE.setValue(SINGLE_SELECTION_REVERSAL_DONE);
                        STATE.setValue(SINGLE_SELECTION);
                    }
                }
            });

        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.WARNING, e.getMessage());
        }
    }

    public void prepareForShiftMultiSelection() {

        STATE.setValue(SILENCE);
        STATE.setValue(MULTI_SELECTION);

    }

}
