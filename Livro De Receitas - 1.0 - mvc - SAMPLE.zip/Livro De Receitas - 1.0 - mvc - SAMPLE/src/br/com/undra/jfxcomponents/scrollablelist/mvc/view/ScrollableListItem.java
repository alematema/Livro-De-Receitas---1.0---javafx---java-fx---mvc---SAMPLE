package br.com.undra.jfxcomponents.scrollablelist.mvc.view;

/**
 * An item that composes the scrollable list.
 * @author alexandre
 */
public interface ScrollableListItem {
    
    String getName();
    void setName(String newValue);
    
}
