package br.com.undra.jfxcomponents.menus.themechooser;



import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author alexandre
 */
public class ChooserRunner extends Application{

    public ChooserRunner() {
        System.err.println("ChooserRunner");
    }
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        Pane root = new Pane();

        root.getChildren().add(new ThemeChooser());
        
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
