package br.com.undra.jfxcomponents.menus.context;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

/**
 * Um context menu.
 *
 * @author alexandre
 */
public class ContextMenuArrowDown extends ContextMenu {
// #07a2e3 BCK

    private ScrollableListContainerSimple container;

    @FXML
    private Pane contextMenuOuterContainer;

    @FXML
    private MaterialIconView contextMenuPointer;

    @FXML
    private Pane contextMenuInnerContainer;

    @FXML
    private Text selecionar;

    @FXML
    private Text deselecionar;

    @FXML
    private Text inverterSelecao;
    @FXML
    private Text deletar;

    @FXML
    private Text exportar;

    @FXML
    private Text imprimir;

    @FXML
    private MaterialDesignIconView exportIcon;

    @FXML
    private MaterialDesignIconView printerIcon;

    private boolean allSelected;
    private boolean allUnselected;

    public ContextMenuArrowDown() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLContextMenuArrowDown.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        getStylesheets().add(getClass().getResource("/resources/css/context-menu.css").toExternalForm());
    }

    public ContextMenuArrowDown(ScrollableListContainerSimple container) {

        this();
        this.container = container;
    }

    @FXML
    @Override
    void handleDeletar(MouseEvent event) {
        setVisible(false);
        container.removeAllSelected();
    }

    @FXML
    @Override
    void handleDeselecionar(MouseEvent event) {
        container.unSelectAll();
        setVisible(false);
    }

    @FXML
    @Override
    void handleSelecionar(MouseEvent event) {
        new Thread(() -> {
            Platform.runLater(() -> {
                setVisible(false);
            });
        }).start();
        new Thread(() -> {
            Platform.runLater(() -> {
                container.selectAll();
            });
        }).start();
    }

    @FXML
    @Override
    void handleMouseClicked(MouseEvent event) {
        setVisible(false);
    }

    @FXML
    @Override
    void handleKeyPressed(KeyEvent event) {
        System.err.println("key pressed " + event.getCode());
    }

    @FXML
    @Override
    void handleInverterSelecao(MouseEvent event) {
        new Thread(() -> {
            Platform.runLater(() -> {
                setVisible(false);
            });
        }).start();
        new Thread(() -> {
            Platform.runLater(() -> {
                container.invertSelection();
            });
        }).start();
    }

    @FXML
    @Override
    void handleImprimir(MouseEvent event) {
        container.getContextMenu().setVisible(false);
        container.printSelected();
    }

    @Override
    public Text getSelecionar() {
        return selecionar;
    }

    @Override
    public boolean isOpened() {
        return isVisible();
    }

}
