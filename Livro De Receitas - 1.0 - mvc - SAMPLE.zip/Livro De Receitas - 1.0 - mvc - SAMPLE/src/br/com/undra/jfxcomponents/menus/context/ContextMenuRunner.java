package br.com.undra.jfxcomponents.menus.context;



import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author alexandre
 */
public class ContextMenuRunner extends Application{

    public ContextMenuRunner() {
        System.err.println("ContextMenuRunner");
    }
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        Pane root = new Pane();

        ContextMenu ctxMenu = new ContextMenu(true);
        
        root.getChildren().add(ctxMenu);
        
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        ctxMenu.prefWidth(100);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
