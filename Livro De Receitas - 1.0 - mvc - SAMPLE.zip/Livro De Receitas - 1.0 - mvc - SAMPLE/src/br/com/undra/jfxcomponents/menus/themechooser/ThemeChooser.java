package br.com.undra.jfxcomponents.menus.themechooser;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import java.io.IOException;
import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 * Um modelo para chooser
 *
 * @author alexandre
 */
public class ThemeChooser extends Pane {

    @FXML
    private VBox vBox;

    @FXML
    private Text temaVidroText;

    @FXML
    private Text temaClaroText;

    @FXML
    private Text temaMedioText;

    @FXML
    private Text temaEscuroText;

    private ScrollableListContainerSimple container;

    private Text currentSelected;

    public ThemeChooser() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLChooser.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    public ThemeChooser(ScrollableListContainerSimple container) {

        this();
        this.container = container;
    }

    @FXML
    public void handleMouseClicked(MouseEvent event) {

        if (canChangeCssTheme()) {

            changeCssTheme(event);

        } else {

            FadeTransition ft = new FadeTransition(Duration.seconds(0.30), container.getVBox());
            ft.setFromValue(0.0);
            ft.setToValue(1.0);
            ft.setOnFinished((e) -> {
                RotateTransition rt = new RotateTransition(Duration.millis(100), container.getVBox());
                rt.setAutoReverse(true);
                rt.setCycleCount(2);
                rt.setFromAngle(1);
                rt.setToAngle(-1);
                rt.setOnFinished((ee) -> {
                    container.getVBox().setRotate(0);
                });
                rt.play();

            });
            ft.play();
        }

        setVisible(false);

    }

    private void changeCssTheme(MouseEvent event) {
        fadeOutVBoxChangeCssAndFixItemStyles(event);
    }

    private void fixItemStylesAfterCssChange() {
        //fixes item select and unselected styles after theme changes
        String itemNotSelectedStyle = null;
        String itemDescriptionNotSelectedStyle = null;

        for (Node node : container.getVBox().getChildren()) {

            try {
                Item item = (Item) node;
                if (!item.isSelected()) {
                    itemNotSelectedStyle = item.getStyle();
                    itemDescriptionNotSelectedStyle = item.getDescricaoItemLabel().getStyle();
                    break;
                }
            } catch (Exception e) {
//                System.out.println(e.getCause());
            }

        }
        if (itemNotSelectedStyle != null) {

            for (Node node : container.getVBox().getChildren()) {

                try {
                    Item item = (Item) node;
                    if (item.isSelected()) {

                        item.setLastStyle(itemNotSelectedStyle);
                        item.setDescricaoItemLastStyle(itemDescriptionNotSelectedStyle);

                        item.applyHoverStyle();

                    }
                } catch (Exception e) {
                }

            }

        }
    }

    private void fadeOutVBoxChangeCssAndFixItemStyles(MouseEvent event) {

        try {

            Text tema = ((Text) event.getTarget());

            if (!container.getVBox().getChildren().isEmpty()) {
                FadeTransition ft = new FadeTransition(Duration.seconds(1.0), container.getVBox());
                ft.setFromValue(1.0);
                ft.setToValue(0.2);

                ft.setOnFinished((e) -> {

                    changeCss(tema);

                    fixItemStylesAfterCssChange();

                    FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1.0), container.getVBox());
                    fadeTransition.setFromValue(0.2);
                    fadeTransition.setToValue(1.0);
                    fadeTransition.play();

                });
                ft.play();
            } else {
                changeCss(tema);
            }

        } catch (Exception ex) {
//            ex.printStackTrace();
        }

    }

    private void changeCss(Text tema) {

        if (currentSelected != null) {
            currentSelected.setFill(Paint.valueOf("white"));
        }

        String fillTextColor = "#131635";
        String css="";

        if (tema.getId().equals("temaVidroText")) {
            currentSelected = temaVidroText;
            css = "/resources/css/glass-theme.css";
//            fillTextColor="white";
//            currentSelected.setStyle("-fx-fill:darkgrey");
        }
        if (tema.getId().equals("temaClaroText")) {
            currentSelected = temaClaroText;
            css = "/resources/css/light-theme.css";
        }
        if (tema.getId().equals("temaMedioText")) {
            currentSelected = temaMedioText;
            css = "/resources/css/medium-theme.css";
        }
        if (tema.getId().equals("temaEscuroText")) {
            currentSelected = temaEscuroText;
            css = "/resources/css/dark-theme.css";
        }
        
        container.getStylesheets().clear();
        container.getStylesheets().add(getClass().getResource(css).toExternalForm());
        currentSelected.setFill(Paint.valueOf(fillTextColor));
    }

    /**
     * Só pode trocar style se NEM todos itens estiverem selecionados<br>
     * OU quando a lista estiver vazia.
     * <br> No caso de lista nao vazia, deve haver ao menos um item nao
     * selecionado.
     *
     * @return true, se lista vazia OU se houver ao menos um elemento DEselecionado.<br>
     * false, caso contrario.
     */
    private boolean canChangeCssTheme() {

        boolean canChange = false;

        for (Node node : container.getVBox().getChildren()) {

            try {
                Item item = (Item) node;
                if (!item.isSelected()) {
                    canChange = true;
                    break;
                }
            } catch (Exception e) {
            }

        }

        return canChange || container.getVBox().getChildren().isEmpty();

    }

}
