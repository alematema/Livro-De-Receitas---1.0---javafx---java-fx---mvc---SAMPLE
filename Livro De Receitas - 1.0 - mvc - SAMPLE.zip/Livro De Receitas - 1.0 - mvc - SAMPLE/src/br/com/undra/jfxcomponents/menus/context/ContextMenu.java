package br.com.undra.jfxcomponents.menus.context;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.util.Util;
import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 * Um context menu.
 *
 * @author alexandre
 */
public class ContextMenu extends Pane {
// #07a2e3 BCK

    private ScrollableListContainerSimple container;

    @FXML
    private Pane contextMenuOuterContainer;

    @FXML
    private MaterialIconView contextMenuPointer;

    @FXML
    private Pane contextMenuInnerContainer;

    @FXML
    private Text selecionar;

    @FXML
    private Text deselecionar;

    @FXML
    private Text inverterSelecao;
    @FXML
    private Text deletar;

    @FXML
    private Text exportar;

    @FXML
    private Text imprimir;

    @FXML
    private MaterialDesignIconView exportIcon;

    @FXML
    private MaterialDesignIconView printerIcon;

    private Tooltip selecionarTodosTooltip;
    private Tooltip deselecionarTooltip;
    private Tooltip imprimirTooltip;
    private Tooltip exportarTooltip;
    private Tooltip deletarTooltip;
    private Font toolTipsFont = Font.font(12);

    public ContextMenu() {
    }

    public ContextMenu(boolean load) {
        if (load) {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLContextMenu.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);

            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }

            getStylesheets().add(getClass().getResource("/resources/css/context-menu.css").toExternalForm());

            setContextMenuActionsNamesAndToolTips();

        }
    }

    /**
     * Sets context menu actions names and their keyboard shortcuts tool tips.<br>
     * Actions like selecionar,deselecionar,inverterSelecao,imprimir,exportar,deletar etc.
     */
    private void setContextMenuActionsNamesAndToolTips() {
        selecionar.setText(Util.PROPERTIES.getProperty("contextMenuSelecionar"));
        deselecionar.setText(Util.PROPERTIES.getProperty("contextMenuDeselecionar"));
        inverterSelecao.setText(Util.PROPERTIES.getProperty("contextMenuInverterSelecao"));
        deletar.setText(Util.PROPERTIES.getProperty("contextMenuDeletar"));
        imprimir.setText(Util.PROPERTIES.getProperty("contextMenuImprimir"));
        exportar.setText(Util.PROPERTIES.getProperty("contextMenuExportar"));

        selecionarTodosTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("select.all.shortcut") + ")");
        selecionarTodosTooltip.setFont(toolTipsFont);
        Tooltip.install(selecionar, selecionarTodosTooltip);

        deselecionarTooltip = new Tooltip("(ESC)");
        deselecionarTooltip.setFont(toolTipsFont);
        Tooltip.install(deselecionar, deselecionarTooltip);

        deletarTooltip = new Tooltip("(DEL)");
        deletarTooltip.setFont(toolTipsFont);
        Tooltip.install(deletar, deletarTooltip);

        imprimirTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("print.selected.shortcut") + ")");
        imprimirTooltip.setFont(toolTipsFont);
        Tooltip.install(imprimir, imprimirTooltip);

        exportarTooltip = new Tooltip("(" + Util.PROPERTIES.getProperty("export.selected.shortcut") + ")");
        exportarTooltip.setFont(toolTipsFont);
        Tooltip.install(exportar, exportarTooltip);
    }

    public ContextMenu(ScrollableListContainerSimple container) {

        this(true);
        this.container = container;
    }

    @FXML
    void handleDeletar(MouseEvent event) {
        container.getContextMenu().setVisible(false);
        container.removeAllSelected();
    }

    @FXML
    void handleImprimir(MouseEvent event) {
        container.getContextMenu().setVisible(false);
        container.printSelected();
    }

    @FXML
    void handleDeselecionar(MouseEvent event) {
        container.getContextMenu().setVisible(false);
        container.unSelectAll();
    }

    @FXML
    void handleSelecionar(MouseEvent event) {
        new Thread(() -> {
            Platform.runLater(() -> {
                setVisible(false);
            });
        }).start();
        new Thread(() -> {
            Platform.runLater(() -> {
                container.selectAll();
            });
        }).start();
    }

    @FXML
    public void handleExportar(MouseEvent event) {
        if (!container.getSelection().isEmpty()) {
            container.exportSelected();
        }
    }

    @FXML
    void handleMouseClicked(MouseEvent event) {
        setVisible(false);
        container.getContextMenu().setVisible(false);
    }

    @FXML
    void handleKeyPressed(KeyEvent event) {
        System.err.println("key pressed " + event.getCode());
    }

    @FXML
    void handleInverterSelecao(MouseEvent event) {
        new Thread(() -> {
            Platform.runLater(() -> {
                setVisible(false);
            });
        }).start();
        new Thread(() -> {
            Platform.runLater(() -> {
                container.invertSelection();
            });
        }).start();

    }

    public Text getSelecionar() {
        return selecionar;
    }

    public boolean isOpened() {
        return isVisible();
    }

    public Text getDeletar() {
        return deletar;
    }

    public Text getDeselecionar() {
        return deselecionar;
    }

    public Text getExportar() {
        return exportar;
    }

    public Text getImprimir() {
        return imprimir;
    }

    public MaterialDesignIconView getExportIcon() {
        return exportIcon;
    }

    public MaterialDesignIconView getPrinterIcon() {
        return printerIcon;
    }

    public void setAsDisbled(Object... children) {
        if (children != null) {

        }
    }
}
