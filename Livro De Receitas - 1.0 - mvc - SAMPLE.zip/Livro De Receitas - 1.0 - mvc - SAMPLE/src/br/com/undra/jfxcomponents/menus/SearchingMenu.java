package br.com.undra.jfxcomponents.menus;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerFull;
import br.com.undra.jfxcomponents.util.Util;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;

/**
 * Um modelo para menu
 *
 * @author alexandre
 */
public class SearchingMenu extends Menu {

    @FXML
    private MaterialIconView menuPointer;

    public SearchingMenu() {

        super(false);

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLSearchingMenu.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        onOfTemaVidro.setVisible(false);
        onOfTemaClaro.setVisible(false);
        onOfTemaMedio.setVisible(false);
        onOfTemaEscuro.setVisible(false);

        temaVidroText.setText(Util.PROPERTIES.getProperty("menuTemaVidro"));
        temaClaroText.setText(Util.PROPERTIES.getProperty("menuTemaClaro"));
        temaMedioText.setText(Util.PROPERTIES.getProperty("menuTemaMedio"));
        temaEscuroText.setText(Util.PROPERTIES.getProperty("menuTemaEscuro"));

        listaCompactaLabel.setText(Util.PROPERTIES.getProperty("menuLayoutListaCompacta"));
        bordaRedondaLabel.setText(Util.PROPERTIES.getProperty("menuLayoutBordaRedonda"));

    }

    public SearchingMenu(ScrollableListContainerFull container) {

        this();
        this.container = container;
    }

    @FXML
    void handleMouseClickedOnOffPesquisaPalavraExata(MouseEvent event) {

        try {

            FontAwesomeIconView iconView = (FontAwesomeIconView) event.getTarget();

            if (iconView.getGlyphName().equals("TOGGLE_OFF")) {
                iconView.setGlyphName("TOGGLE_ON");
                iconView.setFill(Paint.valueOf("white"));
                ((ScrollableListContainerFull) container).setExactWordMatchingCriteria();
            } else {
                iconView.setGlyphName("TOGGLE_OFF");
                iconView.setFill(Paint.valueOf("white"));
                ((ScrollableListContainerFull) container).setSimpleSearchingCriteria();
            }

        } catch (Exception e) {
//            e.printStackTrace();
        }

    }

    public MaterialIconView getMenuPointer() {
        return menuPointer;
    }

}
