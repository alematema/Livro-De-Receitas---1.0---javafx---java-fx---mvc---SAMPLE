package br.com.undra.jfxcomponents.menus;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerFull;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.jfxcomponents.util.Util;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import java.io.IOException;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 * Um modelo para chooser
 *
 * @author alexandre
 */
public class Menu extends Pane {

    public static String DARK_THEME = "DARK-THEME".toLowerCase();
    public static String DARK_THEME_SQUARED = "DARK-THEME_SQUARED".toLowerCase();
    public static String LIGHT_THEME = "LIGHT-THEME".toLowerCase();
    public static String LIGHT_THEME_SQUARED = "LIGHT-THEME_SQUARED".toLowerCase();
    public static String MEDIUM_THEME = "MEDIUM-THEME".toLowerCase();
    public static String MEDIUM_THEME_SQUARED = "MEDIUM-THEME_SQUARED".toLowerCase();
    public static String GLASS_THEME = "GLASS-THEME".toLowerCase();
    public static String GLASS_THEME_SQUARED = "GLASS-THEME_SQUARED".toLowerCase();
    public static String DEFAULT_THEME = "DEFAULT-THEME".toLowerCase();
    public static String DEFAULT_THEME_SQUARED = "DEFAULT-THEME_SQUARED".toLowerCase();

    @FXML
    VBox vBox;

    @FXML
    Text temaVidroText;

    @FXML
    Text temaClaroText;

    @FXML
    Text temaMedioText;

    @FXML
    Text temaEscuroText;

    @FXML
    FontAwesomeIconView onOffListaCompactaIcon;
    @FXML
    FontAwesomeIconView onOffBordaRedonda;

    @FXML
    FontAwesomeIconView onOfTemaVidro;

    @FXML
    FontAwesomeIconView onOfTemaClaro;

    @FXML
    FontAwesomeIconView onOfTemaEscuro;

    @FXML
    FontAwesomeIconView onOfTemaMedio;

    @FXML
    Label listaCompactaLabel;

    @FXML
    Label bordaRedondaLabel;

    ScrollableListContainerSimple container;

    Text currentSelected;
    Text currentTema;
    FontAwesomeIconView currentThemeChecked;
    private String cssTheme;

    public Menu(boolean load) {

        if (load) {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLMenu.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);

            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
            onOfTemaVidro.setVisible(false);
            onOfTemaClaro.setVisible(false);
            onOfTemaMedio.setVisible(false);
            onOfTemaEscuro.setVisible(false);

            temaVidroText.setText(Util.PROPERTIES.getProperty("menuTemaVidro"));
            temaClaroText.setText(Util.PROPERTIES.getProperty("menuTemaClaro"));
            temaMedioText.setText(Util.PROPERTIES.getProperty("menuTemaMedio"));
            temaEscuroText.setText(Util.PROPERTIES.getProperty("menuTemaEscuro"));

            listaCompactaLabel.setText(Util.PROPERTIES.getProperty("menuLayoutListaCompacta"));
            bordaRedondaLabel.setText(Util.PROPERTIES.getProperty("menuLayoutBordaRedonda"));
        }

    }

    public Menu(ScrollableListContainerSimple container) {

        this(true);
        this.container = container;
    }

    @FXML
    void handleMouseClickedOnOffBorddaRedonda(MouseEvent event) {

        try {

            FontAwesomeIconView iconView = (FontAwesomeIconView) event.getTarget();

            toggleRoundCorner(iconView);

        } catch (Exception e) {
//            e.printStackTrace();
        }

    }

    public void toggleRoundCorner(FontAwesomeIconView iconView) {
        if (iconView.getGlyphName().equals("TOGGLE_OFF")) {
            iconView.setGlyphName("TOGGLE_ON");
            iconView.setFill(Paint.valueOf("white"));
        } else {
            iconView.setGlyphName("TOGGLE_OFF");
            iconView.setFill(Paint.valueOf("black"));
            iconView.setFill(Paint.valueOf("white"));
        }
        if (currentTema == null) {
            currentTema = new Text();
            currentTema.setId(Util.PROPERTIES.getProperty("temaInicialCssETemaInicialNomeCSV").split(",")[1] + "Text");
        }
        
        changeCss(currentTema);
    }

    @FXML
    void handleMouseClickedOnOffListaCompacta(MouseEvent event) {

        try {

            FontAwesomeIconView iconView = (FontAwesomeIconView) event.getTarget();
            toggleCompactList(iconView);

        } catch (Exception e) {
//            e.printStackTrace();
        }
    }

    public void toggleCompactList(FontAwesomeIconView iconView) {
        if (iconView.getGlyphName().equals("TOGGLE_OFF")) {
            iconView.setGlyphName("TOGGLE_ON");
            iconView.setFill(Paint.valueOf("white"));
            container.setCompactList(container.getPrefHeight());
        } else {
            iconView.setGlyphName("TOGGLE_ON");
            iconView.setFill(Paint.valueOf("white"));
            container.setNOTCompactList(container.getPrefHeight());
        }
    }

    @FXML
    public void handleMouseClicked(MouseEvent event) {

        try {

            FontAwesomeIconView icon = (FontAwesomeIconView) event.getTarget();

        } catch (Exception e) {

            try {
                Text text = (Text) event.getTarget();
                if (text.equals(temaClaroText) || text.equals(temaEscuroText) || text.equals(temaMedioText) || text.equals(temaVidroText)) {
                    doCssChange(event);
                }
            } catch (Exception ex) {
                setVisible(false);
            }
        }

    }

    @FXML
    void handleTemaClaroClicked(MouseEvent event) {

    }

    @FXML
    void handleTemaEscuroClicked(MouseEvent event) {

    }

    @FXML
    void handleTemaMedioClicked(MouseEvent event) {

    }

    @FXML
    void handleTemaVidroClicked(MouseEvent event) {

    }

    private void doCssChange(MouseEvent event) {
        if (canChangeCssTheme()) {

            changeCssTheme(event);

        } else {

            container.shake();
        }

        setVisible(false);
    }

    private void changeCssTheme(MouseEvent event) {
        fadeOutVBoxChangeCssAndFixItemStyles(event);
    }

    private void fixItemStylesAfterCssChange() {
        //fixes item select and unselected styles after theme changes
        String itemNotSelectedStyle = null;
        String itemDescriptionNotSelectedStyle = null;

        for (Node node : container.getModel().get()) {

            try {
                Item item = (Item) node;
                if (!item.isSelected()) {
                    itemNotSelectedStyle = item.getStyle();
                    itemDescriptionNotSelectedStyle = item.getDescricaoItemLabel().getStyle();
                    break;
                }
            } catch (Exception e) {
//                System.out.println(e.getCause());
            }

        }
        if (itemNotSelectedStyle != null) {

            for (Node node : container.getModel().get()) {

                try {
                    Item item = (Item) node;
                    if (item.isSelected()) {

                        item.setLastStyle(itemNotSelectedStyle);
                        item.setDescricaoItemLastStyle(itemDescriptionNotSelectedStyle);

                        item.applyHoverStyle();

                    }
                } catch (Exception e) {
                }

            }

        }
    }

    private void fadeOutVBoxChangeCssAndFixItemStyles(MouseEvent event) {

        try {

            Text tema = ((Text) event.getTarget());

            if (!container.getVBox().getChildren().isEmpty()) {
                FadeTransition ft = new FadeTransition(Duration.seconds(0.5), container.getVBox());
                ft.setFromValue(1.0);
                ft.setToValue(0.2);

                ft.setOnFinished((e) -> {

                    changeCss(tema);

                    fixItemStylesAfterCssChange();

                    FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.99), container.getVBox());
                    fadeTransition.setFromValue(0.2);
                    fadeTransition.setToValue(1.0);
                    fadeTransition.play();

                });
                ft.play();
            } else {
                changeCss(tema);
            }

        } catch (Exception ex) {
//            ex.printStackTrace();
        }

    }

    public void changeCss(Text tema) {
        try {

            if (currentSelected != null) {
                currentSelected.setFill(Paint.valueOf("white"));
                currentThemeChecked.setGlyphName("CIRCLE_THIN");
                currentThemeChecked.setVisible(false);
            }

            String fillTextColor = "#0bc3e3";
            String css = "";

            if (tema.getId().equals("temaVidroText")) {
                currentSelected = temaVidroText;
                currentThemeChecked = onOfTemaVidro;
                css = "/resources/css/glass-theme.css";
                cssTheme = GLASS_THEME;
                if (onOffBordaRedonda.getGlyphName().equals("TOGGLE_OFF")) {
                    css = "/resources/css/glass-theme_squared.css";
                    cssTheme = GLASS_THEME_SQUARED;
                }
            }
            if (tema.getId().equals("temaClaroText")) {
                currentSelected = temaClaroText;
                currentThemeChecked = onOfTemaClaro;
                css = "/resources/css/light-theme.css";
                cssTheme = LIGHT_THEME;
                if (onOffBordaRedonda.getGlyphName().equals("TOGGLE_OFF")) {
                    css = "/resources/css/light-theme_squared.css";
                    cssTheme = LIGHT_THEME_SQUARED;
                }
            }
            if (tema.getId().equals("temaMedioText")) {
                currentSelected = temaMedioText;
                currentThemeChecked = onOfTemaMedio;
                css = "/resources/css/medium-theme.css";
                cssTheme = MEDIUM_THEME;
                if (onOffBordaRedonda.getGlyphName().equals("TOGGLE_OFF")) {
                    css = "/resources/css/medium-theme_squared.css";
                    cssTheme = MEDIUM_THEME_SQUARED;
                }
            }
            if (tema.getId().equals("temaEscuroText")) {
                currentSelected = temaEscuroText;
                currentThemeChecked = onOfTemaEscuro;
                css = "/resources/css/dark-theme.css";
                cssTheme = DARK_THEME;
                if (onOffBordaRedonda.getGlyphName().equals("TOGGLE_OFF")) {
                    css = "/resources/css/dark-theme_squared.css";
                    cssTheme = DARK_THEME_SQUARED;
                }
            }

            if (tema.getId().equals("temaDefaultText")) {
                currentSelected = temaVidroText;
                currentThemeChecked = onOfTemaVidro;
                css = "/resources/css/default-theme.css";
                cssTheme = DEFAULT_THEME;
                if (onOffBordaRedonda.getGlyphName().equals("TOGGLE_OFF")) {
                    css = "/resources/css/default-theme_squared.css";
                    cssTheme = DEFAULT_THEME_SQUARED;
                }
            }

            container.getStylesheets().clear();
            container.getStylesheets().add(getClass().getResource(css).toExternalForm());
            if (container instanceof ScrollableListContainerFull) {
                ((ScrollableListContainerFull) container).getSearcherContainer().getStylesheets().clear();
                ((ScrollableListContainerFull) container).getSearcherContainer().getStylesheets().add(getClass().getResource(css).toExternalForm());
            }
            try {//if container has any extra Node, it will be css applyied
                for (Node extra : container.getExtras()) {

                    ((Pane)extra).getStylesheets().clear();
                    ((Pane)extra).getStylesheets().add(getClass().getResource(css).toExternalForm());
                
                }
            } catch (Exception e) {
            }
            getStylesheets().clear();
            getStylesheets().add(getClass().getResource(css).toExternalForm());
            currentSelected.setFill(Paint.valueOf(fillTextColor));
            currentThemeChecked.setGlyphName("CHECK_CIRCLE");
            currentThemeChecked.setVisible(true);

            currentTema = tema;

        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Só pode trocar style se NEM todos itens estiverem selecionados<br>
     * OU quando a lista estiver vazia.
     * <br> No caso de lista nao vazia, deve haver ao menos um item nao
     * selecionado.
     *
     * @return true, se lista vazia OU se houver ao menos um elemento
     * DEselecionado.<br>
     * false, caso contrario.
     */
    private boolean canChangeCssTheme() {

        boolean canChange = false;

        for (Node node : container.getModel().get()) {

            try {
                Item item = (Item) node;
                if (!item.isSelected()) {
                    canChange = true;
                    break;
                }
            } catch (Exception e) {
            }

        }

        return canChange || container.getVBox().getChildren().isEmpty();

    }

    public FontAwesomeIconView getOnOffBordaRedonda() {
        return onOffBordaRedonda;
    }

    public String getCssTheme() {
        return cssTheme;
    }

    public FontAwesomeIconView getOnOffListaCompactaIcon() {
        return onOffListaCompactaIcon;
    }

}
