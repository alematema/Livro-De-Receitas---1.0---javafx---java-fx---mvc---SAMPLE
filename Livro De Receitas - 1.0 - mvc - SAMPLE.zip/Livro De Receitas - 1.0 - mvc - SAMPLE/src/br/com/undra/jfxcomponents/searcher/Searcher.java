package br.com.undra.jfxcomponents.searcher;

import java.util.ArrayList;
import java.util.Collection;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * A searcher model.
 *
 * @author alexandre
 * @param <T>
 */
public class Searcher<T> {

    public static String SEARCHING_CANCELED = "SEARCHING_CANCELED";
    public static String SEARCHING_SPACE_SETUP = "SEARCHING_SPACE_SETUP";
    public static String SETUP_BEFORE_SEARCHING = "SETUP_BEFORE_SEARCHING";
    public static String SETUP_AFTER_SEARCHING = "SETUP_AFTER_SEARCHING";
    public static String SEARCHING_DONE = "SEARCHING_DONE";
    public static String SEARCHING = "SEARCHING";

    Collection<T> searchingSpace;
    Collection<T> searchingResult = new ArrayList();
    volatile StringProperty STATE = new SimpleStringProperty("INIT");

    Criteria criteria;

    public void setSearchingSpace(Collection<T> searchingSpace) {
        this.searchingSpace = searchingSpace;
    }

    public Collection<T> getSearchingSpace() {
        return searchingSpace;
    }

    public void onSetUpBeforeSearching() {
        searchingResult.clear();
        STATE.setValue(SETUP_BEFORE_SEARCHING);
    }

    public void doSearch(String value) {

        STATE.setValue(SEARCHING);
        
        searchingSpace.stream().forEach(e -> {

            test(e, value);

        });
        
        STATE.setValue(SEARCHING_DONE);

    }

    private void test(T e, String value) {
        criteria.check(e, this, value);
    }

    public void setUpAfterSearching() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void onSearchingCanceled() {
        searchingResult.clear();
        STATE.setValue(SEARCHING_CANCELED);
    }

    public Collection<T> getSearchingResult() {
        return searchingResult;
    }

    public StringProperty getState() {
        return STATE;
    }

    public void setCriteria(Criteria c) {
        this.criteria = c;
    }

    public void add(T t) {
        searchingResult.add(t);
    }

}
