package br.com.undra.jfxcomponents.searcher;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;

/**
 * A searching criteria.
 *
 * @author alexandre
 * @param <T>
 */
public interface Criteria<T> {

    void check(T t, Searcher<T> searcher, String value);
    
    Criteria<Item> EXACT_WORD_MATCH_SEARCH = (item, searcher, value) -> {
        if (item.getDescricao().contains(value)) {
            searcher.add(item);
        }
    };
    
    Criteria<Item> SIMPLE_SEARCH = (item, searcher, value) -> {
        
        String descricao = item.getDescricao().toLowerCase();
        String itemDescricaoAcentuacaoIgnorada = descricao.replaceAll("á", "a");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("é", "e");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("í", "i");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ó", "o");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ú", "u");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("à", "a");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ê", "e");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("â", "a");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ô", "o");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ã", "a");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("ẽ", "e");
        itemDescricaoAcentuacaoIgnorada = itemDescricaoAcentuacaoIgnorada.replaceAll("õ", "o");

        String valueAcentuacaoIgnorada = value.toLowerCase();
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("á", "a");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("é", "e");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("í", "i");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ó", "o");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ú", "u");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("à", "a");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ê", "e");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("â", "a");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ô", "o");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ã", "a");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("ẽ", "e");
        valueAcentuacaoIgnorada = valueAcentuacaoIgnorada.replaceAll("õ", "o");

        if (itemDescricaoAcentuacaoIgnorada.contains(valueAcentuacaoIgnorada)) {
            searcher.add(item);
        }
    };
}
