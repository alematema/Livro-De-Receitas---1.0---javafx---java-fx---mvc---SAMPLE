package br.com.undra.jfxcomponents.searcher;

import br.com.undra.jfxcomponents.scrollablelist.mvc.model.ScrollableList;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.util.Util;
import com.jfoenix.controls.JFXTextField;
import de.jensd.fx.glyphs.materialicons.MaterialIconView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import org.jnativehook.keyboard.NativeKeyEvent;

/**
 * Searcher container
 *
 * @author alexandre
 * @param <T>
 */
public class SearcherContainer<T> extends Pane {

    public static final String KEY_PRESSED = "KEY_PRESSED";
    public static final String KEY_RELEASED = "KEY_RELEASED";

    private volatile boolean isDirty = false;

    @FXML
    private Pane searcherContainer;

    @FXML
    private volatile JFXTextField searchField;

    @FXML
    private MaterialIconView searcherIcon;

    private ScrollableListContainerSimple scrollableContainer;

    private ObservableList<T> searchSpace = FXCollections.observableArrayList();
    private List<T> searchingResult = new ArrayList<>();

    private Tooltip cancelSearchingIconTooltip;

    private final Searcher<T> searcher = new Searcher();

    private final StringProperty STATE = new SimpleStringProperty();

    private KeyEvent keyEvent;

    ChangeListener<String> ADD_REMOVE_ITEM_LISTENER = new ChangeListener<String>() {
        @Override
        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            //REFARA PESQUISA CASO TENHA OCORRIDO ALGUMA EDICAO, ALGUMA REMOCAO OU ALGUMA ADICAO... E
            boolean condicoes
                    = newValue.equals(ScrollableList.ADDED_AS_IMPORTING_READY)
                    || newValue.equals(ScrollableList.ADDED_SINGLE_READY)
                    || newValue.equals(ScrollableList.REMOVED_READY)
                    || newValue.equals(ScrollableList.REMOVED_BULK_READY)
                    || newValue.equals(ScrollableList.REMOVED_AS_UN_IMPORTING_READY)
                    || newValue.equals(ScrollableList.EDITED_READY);
            //E ... AINDA A PESQUISA NAO TENHA SIDO CANCELADA.
            condicoes = condicoes && !searcher.getState().equals(Searcher.SEARCHING_CANCELED);

            if (condicoes) {

                searchingThread = new Thread(() -> {

                    while (searcher.getState().getValue().equals(Searcher.SEARCHING)) {
                    }

                    Platform.runLater(() -> {
                        handleSearching();
                    });
                });

                searchingThread.setDaemon(true);
                searchingThread.start();
            }
        }
    };

    public SearcherContainer() {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLSearcher.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        searcherIcon.setDisable(true);
        searcherIcon.setCursor(Cursor.TEXT);

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.trim().equals("")) {
                cleanUp();
            }
        });

        widthProperty().addListener((observable, oldValue, newValue) -> {
            searchField.setLayoutX(Double.parseDouble(searcherIcon.getSize()) + newValue.doubleValue() / 30);
            searchField.setPrefWidth(newValue.doubleValue() - 3 * Double.parseDouble(searcherIcon.getSize()));
        });

//        searchField.focusedProperty().addListener((observable, oldValue, newValue) -> {
//           if(newValue){
//               System.err.println("FOCUSED");
//               scrollableContainer.getAddItemIcon().setDisable(true);
//           } else{
////               scrollableContainer.getAddItemIcon().setDisable(false);
//               System.err.println("LOST FOCUS");
//               
//           }
//        });
    }

    public void setScrollableContainer(ScrollableListContainerSimple scrollableContainer) {
        this.scrollableContainer = scrollableContainer;
        cancelSearchingIconTooltip = new Tooltip(Util.getPROPERTIES(scrollableContainer.getWrapper()).getProperty("searcherCancelerToolTip"));
        cancelSearchingIconTooltip.setFont(Font.font(10));
        searchField.setPromptText(Util.getPROPERTIES(scrollableContainer.getWrapper()).getProperty("searcherPromptText"));
        scrollableContainer.getCurrentModel().getSTATE().removeListener(ADD_REMOVE_ITEM_LISTENER);
        scrollableContainer.getCurrentModel().getSTATE().addListener(ADD_REMOVE_ITEM_LISTENER);
    }

    public void setSearchSpace(ObservableList<T> searchSpace) {
        this.searchSpace = searchSpace;
    }

    @FXML
    void handleKeyPressed(KeyEvent event) {
        STATE.setValue(KEY_PRESSED);
        keyEvent = event;
    }

    Thread searchingThread = null;

    @FXML
    void handleKeyReleased(KeyEvent event) {

        STATE.setValue(KEY_RELEASED);
        keyEvent = event;

        if (event.getCode().equals(KeyCode.ESCAPE)) {
            cleanUp();
            return;
        }

        searchingThread = new Thread(() -> {

            while (searcher.getState().getValue().equals(Searcher.SEARCHING)) {
            }

            Platform.runLater(() -> {
                handleSearching();
            });
        });

        searchingThread.setDaemon(true);
        searchingThread.start();

    }

    /**
     * Limpa campo de pesquisa do searcher container quando ESC(escape) event é
     * capturada pelo global screen listener.
     *
     * @param event
     */
    @FXML
    public void handleScapeFromGlobalScreenListener(KeyEvent event) {

        KeyEvent scapeKeyEvent;

        STATE.setValue(KEY_RELEASED);

        cleanUp();

    }

    public void handleSearching() {

        if (!searchField.getText().trim().equals("")) {

            dirtyUp();
            searcher.onSetUpBeforeSearching();

            Thread t = new Thread(() -> {
                Platform.runLater(() -> {
//                    System.err.println("Searching key "+searchField.getText() + " ,Searching space "+searcher.getSearchingSpace());
                    searcher.doSearch(searchField.getText());
                });
                while (searcher.getState().getValue().equals(Searcher.SEARCHING) || searcher.getState().getValue().equals(Searcher.SETUP_BEFORE_SEARCHING)) {
                }
//                System.err.println("Searching result "+searcher.getSearchingResult());
                Platform.runLater(() -> {
                    scrollableContainer.getWrapper().setUpAfterSearching();
                });
            });
            t.setDaemon(true);
            t.start();

        } else {
            cleanUp();
        }
    }

    private void dirtyUp() {
        searcherIcon.setGlyphName("BACKSPACE");
        searcherIcon.setId("backspaceIcon");
        searcherIcon.setFill(Paint.valueOf(Util.getAtributeValueInCssSelector(scrollableContainer, "backspaceIcon", "-fx-fill")));
        searcherIcon.setRotate(180);
        searcherIcon.setDisable(false);
        searcherIcon.setCursor(Cursor.HAND);
        Tooltip.uninstall(this, cancelSearchingIconTooltip);
        Tooltip.install(searcherIcon, cancelSearchingIconTooltip);
        isDirty = true;
    }

    private void cleanUp() {
        searcherIcon.setId("searcherIcon");
        searcherIcon.setGlyphName("SEARCH");
        searcherIcon.setFill(Paint.valueOf(Util.getAtributeValueInCssSelector(scrollableContainer, "searcherIcon", "-fx-fill")));
        searcherIcon.setRotate(360);
        searchField.setText("");
        searcher.onSearchingCanceled();
        searcherIcon.setDisable(true);
        searcherIcon.setCursor(Cursor.TEXT);
        Tooltip.uninstall(searcherIcon, cancelSearchingIconTooltip);
        isDirty = false;
    }

    @FXML
    void handleOnInputTextChanged(InputMethodEvent event) {
    }

    @FXML
    void handleSearchFieldMouseClicked(MouseEvent event) {
        if (scrollableContainer != null) {
            scrollableContainer.closeContextMenu();
            scrollableContainer.closeMenu();
        }
    }

    @FXML
    void handleCancelSearchingMouseClicked(MouseEvent event) {
        cleanUp();
    }

    public Searcher getSearcher() {
        return searcher;
    }

    public StringProperty getState() {
        return STATE;
    }

    public KeyEvent getKeyEvent() {
        return keyEvent;
    }

    public JFXTextField getSearchField() {
        return searchField;
    }

    public Tooltip getCancelSearchingIconTooltip() {
        return cancelSearchingIconTooltip;
    }

    public void setForSelectingAllOrLoading(boolean newValue) {
        for (Node n : getChildren()) {
            if (n.getId().equals("settingsIcon")) {
                n.setVisible(newValue);
            }
        }
        if (searchField.getText().trim().equals("")) {
            searcherIcon.setVisible(newValue);
            searchField.setVisible(newValue);
        }else if(newValue){
            searcherIcon.setVisible(newValue);
            searchField.setVisible(newValue);
        }
    }

    public void setForSearching(boolean newValue) {
        for (Node n : getChildren()) {
            if (n.getId().equals("settingsIcon")) {
                n.setVisible(newValue);
            }
        }
    }

    public boolean isDirty() {
        return isDirty;
    }
}
