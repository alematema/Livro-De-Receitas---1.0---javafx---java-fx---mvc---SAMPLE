package br.com.undra.jfxcomponents.searcher;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author alexandre
 */
public class SearcherContainerRunner extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        Pane root = new Pane();

        SearcherContainer searcherContainer = new SearcherContainer();
        
        root.getChildren().add(searcherContainer);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        searcherContainer.prefWidthProperty().bind(primaryStage.widthProperty());
        
        
    }

        /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
