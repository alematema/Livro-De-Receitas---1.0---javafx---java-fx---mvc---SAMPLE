package br.com.undra.jfxcomponents.util;

import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerSimple;
import br.com.undra.jfxcomponents.scrollablelist.mvc.view.ScrollableListContainerFull;
import br.com.undra.jfxcomponents.scrollablelist.mvc.model.Item;
import br.com.undra.livrodereceitas.Receita;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.text.Font;
import br.com.undra.jfxcomponents.scrollablelist.mvc.controller.VerticalScrollableListWrapper;

/**
 * Uma utilitária.
 *
 * @author alexandre
 */
public class Util {

    public static final Properties PROPERTIES = new Properties();
    public static final Map<VerticalScrollableListWrapper, Properties> SCROLLERS_PROPERTIES_MAP = new HashMap<>();

    static {

        try {
            PROPERTIES.load(Class.forName("br.com.undra.jfxcomponents.util.Util").getClass().getResourceAsStream("/resources/properties/LivroReceitas.properties"));
        } catch (IOException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        }

//        System.out.println(String.format("%d/%d/%d %d:%d:%d", Calendar.getInstance().get(Calendar.DAY_OF_MONTH),Calendar.getInstance().get(Calendar.MONTH)+1,Calendar.getInstance().get(Calendar.YEAR),Calendar.getInstance().get(Calendar.HOUR_OF_DAY),Calendar.getInstance().get(Calendar.MINUTE),Calendar.getInstance().get(Calendar.SECOND)));
//        System.out.println(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+"/"+Calendar.getInstance().get(Calendar.MONTH)+"/"+Calendar.getInstance().get(Calendar.YEAR));
//        System.out.println(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)+":"+Calendar.getInstance().get(Calendar.MINUTE)+":"+Calendar.getInstance().get(Calendar.SECOND));
    }

    public static Properties getPROPERTIES(VerticalScrollableListWrapper s) {
        return SCROLLERS_PROPERTIES_MAP.get(s);
    }

    private static List<String> css = new ArrayList();
    private static String lastCss;
    private static String lastCssSelectorAtributeValue;

    /**
     * Gets the value of the atribute in the cssSelector.<br>
     * For instance, will return #000 for the atribute -fx-fill at
     * #backspaceIcon cssSelector <br>
     * #backspaceIcon{-fx-fill:#000;}
     *
     * @param container a app scrollable container
     * @param cssSelector a cssSelector
     * @param atribute a cssSelector's atribute.
     * @return
     */
    public static String getAtributeValueInCssSelector(ScrollableListContainerSimple container, String cssSelector, String atribute) {

        String cssSelectorAtributeValue = "";

        css.clear();

        for (String cSS : container.getStylesheets()) {
            css.add(cSS);
        }

        //little cache
        if (lastCss != null) {
            if (css.size() == 1) {
                if (css.get(0).equals(lastCss)) {
                    if (!lastCssSelectorAtributeValue.equals("")) {
                        return lastCssSelectorAtributeValue;
                    }
                }
            }
        }

        main:
        for (String cSS : css) {
            try {

                Scanner s = new Scanner(Class.forName(Util.class.getName()).getClass().getResourceAsStream("/resources/css/" + Paths.get(cSS).getFileName()));
                StringBuilder sb = new StringBuilder();
                while (s.hasNext()) {
                    sb.append(s.nextLine());
                }
                String cssAsString = sb.toString();
                String[] cssClasses = cssAsString.split("}");

                for (String cssClass : cssClasses) {

                    String classeAnalisada = cssClass.trim().replaceAll(" ", "");

                    if (classeAnalisada.contains(cssSelector + "{")) {

                        classeAnalisada = removeCssComments(classeAnalisada);

                        String[] styles = classeAnalisada.split(";");
                        for (String style : styles) {
                            if (style.contains(atribute)) {
                                String[] splits = style.split(":");
                                cssSelectorAtributeValue = splits[splits.length - 1];
                                break main;
                            }
                        }
                    }
                }

            } catch (ClassNotFoundException e) {
            }
            lastCss = cSS;

        }

        lastCssSelectorAtributeValue = cssSelectorAtributeValue;

        return cssSelectorAtributeValue;
    }

    /**
     * Removes css comments.
     *
     * @param classeAnalisada
     * @return
     */
    public static String removeCssComments(String classeAnalisada) {

        while (classeAnalisada.contains("/*")) {
            int i = classeAnalisada.indexOf("/*");
            int ii = classeAnalisada.indexOf("*/");
            CharSequence subSeq = classeAnalisada.subSequence(i, ii + 2);
            classeAnalisada = classeAnalisada.replace(subSeq, "");
        }

        return classeAnalisada;
    }

    public static synchronized int getIntervalFromOneIterationAndAnother(int size) {
        int intervalFromOneIterationAndAnother = 0;
        if (size > 2500) {
            intervalFromOneIterationAndAnother = 0;
        } else if (size > 800) {
            intervalFromOneIterationAndAnother = 0;
        } else if (size > 500) {
            intervalFromOneIterationAndAnother = 0;
        } else if (size > 200) {
            intervalFromOneIterationAndAnother = 0;
        } else if (size > 100) {
            intervalFromOneIterationAndAnother = 15;
        } else if (size > 80) {
            intervalFromOneIterationAndAnother = 20;
        } else if (size > 50) {
            intervalFromOneIterationAndAnother = 25;
        } else if (size > 20) {
            intervalFromOneIterationAndAnother = 30;
        } else if (size > 10) {
            intervalFromOneIterationAndAnother = 50;
        } else {
            intervalFromOneIterationAndAnother = 100;
        }
        return intervalFromOneIterationAndAnother;
    }

    public static synchronized int getintervalFromOneLoadAndAnother(int size) {
        int intervalFromOneLoadAndAnother = 0;
        if (size > 1000) {
            intervalFromOneLoadAndAnother = 0;
        } else if (size > 800) {
            intervalFromOneLoadAndAnother = 0;
        } else if (size > 500) {
            intervalFromOneLoadAndAnother = 0;
        } else if (size > 200) {
            intervalFromOneLoadAndAnother = 15;
        } else if (size > 100) {
            intervalFromOneLoadAndAnother = 30;
        } else if (size > 80) {
            intervalFromOneLoadAndAnother = 80;
        } else if (size > 50) {
            intervalFromOneLoadAndAnother = 95;
        } else if (size > 20) {
            intervalFromOneLoadAndAnother = 150;
        } else if (size > 10) {
            intervalFromOneLoadAndAnother = 130;
        } else {
            intervalFromOneLoadAndAnother = 100;
        }
        return intervalFromOneLoadAndAnother;
    }

    public static int getImportBulkSize(int size) {

        int importBulkSize = 0;
        if (size > 7000) {
            importBulkSize = 519;
        } else if (size > 5000) {
            importBulkSize = 438;
        } else if (size > 4000) {
            importBulkSize = 347;
        } else if (size > 2500) {
            importBulkSize = 239;
        } else if (size > 800) {
            importBulkSize = 80;
        } else if (size > 500) {
            importBulkSize = 53;
        } else if (size > 200) {
            importBulkSize = 47;
        } else if (size > 100) {
            importBulkSize = 37;
        } else if (size > 10) {
            importBulkSize = 17;
        } else {
            importBulkSize = 1;
        }
        return importBulkSize;
    }

    public static int getRemoveBulkSize(int size) {

        int removeBulkSize = 0;
        if (size > 7000) {
            removeBulkSize = 529;
        } else if (size > 5000) {
            removeBulkSize = 437;
        } else if (size > 4000) {
            removeBulkSize = 339;
        } else if (size > 2500) {
            removeBulkSize = 200;
        } else if (size > 800) {
            removeBulkSize = 80;
        } else if (size > 500) {
            removeBulkSize = 50;
        } else if (size > 200) {
            removeBulkSize = 40;
        } else if (size > 100) {
            removeBulkSize = 30;
        } else if (size > 10) {
            removeBulkSize = 10;
        } else {
            removeBulkSize = 1;
        }
        return removeBulkSize;
    }

    public static synchronized Collection<List<Item>> batchItens(List<Item> itens, int batchSize) {
        Collection<List<Item>> batchedItens = new ArrayList<>();

        int iterations = itens.size() / batchSize;
        int modulus = itens.size() % batchSize;
        int it = 0;
        for (it = 0; it < iterations; it++) {

            List<Item> batch = new ArrayList<>();

            //33 itens.size
            //10 batchSize
            //iterations 3
            //modulus 3
            // batch it 0 : 0...9 
            // batch it 1 : 10...19 
            // batch it 2 : 20...29
            // batch mod  : (it+1) ... (it+1)+modulus
            for (int i = 0; i < batchSize; i++) {
                batch.add(itens.get(it * batchSize + i));
            }

            batchedItens.add(batch);

        }

        if (modulus != 0) {

            List<Item> batch = new ArrayList<>();
            for (int i = 0; i < modulus; i++) {
                batch.add(itens.get(it * batchSize + i));
            }

            batchedItens.add(batch);
        }

        return batchedItens;
    }

    public static synchronized Collection<List<Receita>> batch(List<Receita> receitas, int batchSize) {
        Collection<List<Receita>> batchedReceitas = new ArrayList<>();

        int iterations = receitas.size() / batchSize;
        int modulus = receitas.size() % batchSize;
        int it = 0;
        for (it = 0; it < iterations; it++) {

            List<Receita> batch = new ArrayList<>();

            //33 receitas.size
            //10 batchSize
            //iterations 3
            //modulus 3
            // batch it 0 : 0...9 
            // batch it 1 : 10...19 
            // batch it 2 : 20...29
            // batch mod  : (it+1) ... (it+1)+modulus
            for (int i = 0; i < batchSize; i++) {
                batch.add(receitas.get(it * batchSize + i));
            }

            batchedReceitas.add(batch);

        }

        if (modulus != 0) {

            List<Receita> batch = new ArrayList<>();
            for (int i = 0; i < modulus; i++) {
                batch.add(receitas.get(it * batchSize + i));
            }

            batchedReceitas.add(batch);
        }

        return batchedReceitas;
    }

    public synchronized static String[] toIds(Collection<Item> itens) {
        String[] ids = new String[itens.size()];
        int i = 0;
        for (Item item : itens) {
            ids[i] = item.getDescricao();
            i++;
        }
        return ids;
    }

    static Comparator<Item> c = (o1, o2) -> {
        return o1.getDescricao().compareTo(o2.getDescricao());
    };
    static Item key = new Item("");

    /**
     * Cleaned são todos objetos que NÃO estão REPRESENTADOS no scroller.<br>
     * A representação é uma associação BIUNÍVOCA entre os atributos descricao,
     * dos objetos do scroller,<br>
     * e nome, nos objetos da colecao dirty.
     *
     * @param scroller scroller
     * @param dirty a colecao com objetos possivelmente duplicados.
     * @param cleaned a colecao de objetos que NÃO estao representados no
     * scroller. <br>
     * São novos objetos. São NAO duplicados.
     */
    public synchronized static void getImportaveis(VerticalScrollableListWrapper scroller, List<Receita> dirty, Collection<Receita> cleaned) {

        dirty.forEach((t) -> {

            key.setDescricao(t.getNome());
            int index = Collections.binarySearch(scroller.getView().getCurrentModel().getExactModel(), key, c);
            if (index >= 0) {
                //DUPLICADO : CONSIDERADO SUJEIRA : NÃO ENTRA EM CLEAN
            } else {
                //É COLOCADO EM CLEAN
                cleaned.add(t);
            }
        });
    }

    public static void GC() {
//        new Thread(() -> {
//            
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//        }).start();
//        new Thread(() -> {
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//            try {
//                Thread.sleep(300);
//            } catch (Exception e) {
//            }
//            System.gc();
//        }).start();
//    new Thread(() -> {
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
//    }).start();
        new Thread(() -> {
            System.gc();
            System.gc();
            System.gc();
        }).start();

//        System.gc();
//        System.gc();
//        System.gc();
//        System.gc();
    }

    private static final Font STATUS_MESSAGE_NORMAL_FONT = new Font(17);
    private static final Font STATUS_MESSAGE_MEDIUM_FONT = new Font(15);
    private static final Font STATUS_MESSAGE_SMALL_FONT = new Font(10);

    /**
     * Checks if message is not already contained in container's status
     * message.<br>
     * If not, apppends the message to the status message component.
     *
     * @param container
     * @param message the message
     */
    public synchronized static void buildAndSetStatusMessage(ScrollableListContainerSimple container, String message) {

        if (!container.getStatusMessageLbl().getText().trim().contains(message)) {

            StringBuilder newMessage = new StringBuilder(container.getStatusMessageLbl().getText());

            if (!container.getStatusMessageLbl().getText().trim().equals("")) {
                newMessage.append(" e ").append(message);
            } else {
                newMessage.append(message);
            }

            String[] currentMessages = newMessage.toString().split(" e ");
            switch (currentMessages.length) {
                case 1:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_NORMAL_FONT);
                    break;
                case 2:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_MEDIUM_FONT);
                    break;
                default:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_SMALL_FONT);
                    break;
            }
            container.getStatusMessageLbl().setText(newMessage.toString());
        }
    }

    /**
     * Removes message from the container's status message.<br>
     * If after that container's status message remains messageless, then sets
     * it INVISIBLE.
     *
     * @param container
     * @param message the message
     */
    public synchronized static void destroyMessageAtStatusMessage(ScrollableListContainerFull container, String message) {

        if (container.getStatusMessageLbl().getText().contains(message)) {

            StringBuilder newMessage = new StringBuilder();
            String[] currentMessages = container.getStatusMessageLbl().getText().split(" e ");
            String[] wantedMessages = new String[currentMessages.length - 1];
            int j = 0;
            for (int i = 0; i < currentMessages.length; i++) {
                if (!currentMessages[i].equals(message)) {
                    wantedMessages[j] = currentMessages[i];
                    j++;
                }
            }
            if (wantedMessages.length > 0) {
                for (int i = 0; i < wantedMessages.length - 1; i++) {
                    newMessage.append(wantedMessages[i]).append(" e ");
                }
                newMessage.append(wantedMessages[wantedMessages.length - 1]);
            }

            String[] currentWantedMessages = newMessage.toString().split(" e ");

            switch (currentWantedMessages.length) {
                case 1:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_NORMAL_FONT);
                    break;
                case 2:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_MEDIUM_FONT);
                    break;
                default:
                    container.getStatusMessageLbl().setFont(STATUS_MESSAGE_SMALL_FONT);
                    break;
            }
            container.getStatusMessageLbl().setText(newMessage.toString());
            if (newMessage.toString().trim().equals("")) {
                container.getStatusMessageLbl().setVisible(false);
            }
        }
    }

    public static String getDeveloperAndContact() {
        return String.format("%s %s", Util.getDeveloper(), Util.getDeveloperContact());
    }

    public static String getDeveloperContact() {
        return String.format("%s %s", PROPERTIES.getProperty("developer.celular"), PROPERTIES.getProperty("developer.email"));
    }

    public static String getDeveloper() {
        return String.format("%s", PROPERTIES.getProperty("developer"));
    }

}
