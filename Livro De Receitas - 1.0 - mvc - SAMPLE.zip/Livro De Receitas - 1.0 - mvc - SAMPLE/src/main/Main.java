package main;

import br.com.undra.jfxcomponents.util.Util;
import br.com.undra.livrodereceitas.App;
import br.com.undra.livrodereceitas.AppContainer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.stage.Stage;
import org.apache.commons.lang3.SystemUtils;

/**
 * Main entry point.
 *
 * @author alexandre
 */
public class Main extends Application {

    App app;

    final static private String DATABASE_FILE_NAME = "LivroDeReceitas.db";
    final static private String DATABASE_USER_DIR = "db";

    @Override
    public void start(Stage pStage) throws Exception {

        try {

            handleEmbeddedDatabaseCreation();

            if (isJava8()) {
                app = AppContainer.newInstance(Util.PROPERTIES.getProperty("title"));
                app.start(pStage);
            } else {
                showJava8NotFoundError();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, "NÃO FOI POSSÍVEL CRIAR O DIRETÓRIO db OU houve algum outro erro de escrita de arquivo. Habilite escrita no diretório home e tente novamente.");
            EmbeddedDatabaseCreationErrorForm.main(null);
        }

    }

    /**
     * Shows Java8 or higher not found window.
     */
    private void showJava8OrHigherNotFoundError() {
        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, "JAVA 8 OR HIGHER MISSING");
        Java8OrHigherNotFoundErrorForm.main(null);
    }

    /**
     * Shows Java8 not found window.
     */
    private void showJava8NotFoundError() {
        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, "JAVA 8 MISSING");
        Java8NotFoundErrorForm.main(null);
    }

    /**
     * Tells if system's java version is at least 8.
     *
     * @return true, if system's java version is at least 8<br>false, otherwise
     */
    private boolean isAtLeastJava8() {
        boolean isLowerThanJava8 = SystemUtils.IS_JAVA_1_1 || SystemUtils.IS_JAVA_1_2 || SystemUtils.IS_JAVA_1_3 || SystemUtils.IS_JAVA_1_4 || SystemUtils.IS_JAVA_1_5 || SystemUtils.IS_JAVA_1_6 || SystemUtils.IS_JAVA_1_7;
        return !isLowerThanJava8;
    }

    /**
     * Tells if system's java version is exactly 8.
     *
     * @return true, if system's java version is exactly 8<br>false, otherwise
     */
    private boolean isJava8() {
        return SystemUtils.IS_JAVA_1_8;
    }

    /**
     * Tries creating a database directory under user.home<br>
     * Then, tries writing a pristine,zeroed,defaulted data base file to the
     * newly created data base directory.<br>
     * If database directory already exists, skips recreating.<br>
     * If database file under database directory already existis, skips
     * replacing it whith the pristine,zeroed,defalted database file.
     *
     * @throws IOException If no READING/WRITING privilege was granted to
     * user.home and to the described resources at the documentation.
     */
    private void handleEmbeddedDatabaseCreation() throws IOException {
        if (!existsUserDir(DATABASE_USER_DIR)) {
            createUserDir(DATABASE_USER_DIR);
        }
        String userDataBaseFilePath = System.getProperty("user.home") + File.separator + DATABASE_USER_DIR + File.separator + DATABASE_FILE_NAME;
        File userDataBase = new File(userDataBaseFilePath);
        if (userDataBase.exists()) {
            Logger.getLogger(getClass().getName()).log(Level.INFO, "Database file {0} already exists. Skipping writing.", userDataBaseFilePath);
        } else {
            writeDatabaseFileToDatabaseUserDir(DATABASE_FILE_NAME, DATABASE_USER_DIR);
        }
    }

    /**
     * Tries writing a pristine,zeroed,defaulted data base file
     * <code>dbFileName</code>, to the newly created data base directory
     * <code>user.home/dbDir</code><br>
     *
     * @param dbFileName the pristine,zeroed,defaulted data base file name.
     * @param dbDir the newly data base directory created under
     * <code>user.home</code>
     * @throws IOException If no WRITING privilege was granted to
     * <code>user.home/dbDir</code>
     */
    private void writeDatabaseFileToDatabaseUserDir(String dbFileName, String dbDir) throws IOException {
        String resource = "/resources/pristinedatabasefile/" + dbFileName;
        InputStream input = Main.class.getResourceAsStream(resource);
        File outPutDb = new File(System.getProperty("user.home") + File.separator + dbDir + File.separator + dbFileName);
        String dataBaseFile = System.getProperty("user.home") + File.separator + dbDir + File.separator + dbFileName;
        Logger.getLogger(getClass().getName()).log(Level.INFO, "Writing database file to {0}", dataBaseFile);
        try (OutputStream out = new FileOutputStream(outPutDb)) {
            int read;
            byte[] bytes = new byte[1024];
            while ((read = input.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
        } catch (IOException ioE) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "Problens while writing database file to {0} : {1}", new Object[]{dataBaseFile, ioE.getMessage()});
            throw ioE;
        }
    }

    /**
     * Creates <code>dirName</code>, under
     * <b><code>System.getProperty("user.home")</code></b>
     *
     * @param dirName
     * @throws IOException If no WRITING privelege was granted to both
     * <b><code>System.getProperty("user.home")</code></b> and
     * <b><code>dirName</code></b>
     */
    private void createUserDir(final String dirName) throws IOException {

//        throw new IOException("Unable to I/O " + System.getProperty("user.home")+File.separator+dirName + " Please allow WRITING PRIVILEGE to that path :(");
        final File homeDir = new File(System.getProperty("user.home"));
        final File dir = new File(homeDir, dirName);
        if (!dir.exists() && !dir.mkdirs()) {
            Logger.getLogger(getClass().getName()).log(Level.INFO, "Unable to create " + System.getProperty("user.home") + File.separator + dir.getAbsolutePath() + " Please allow WRITING PRIVILEGE to that path :(");
            throw new IOException("Unable to I/O " + System.getProperty("user.home") + File.separator + dir.getAbsolutePath() + " Please allow WRITING PRIVILEGE to that path :(");
        }
    }

    /**
     * Tells if <code>dirName</code>, under
     * <b><code>System.getProperty("user.home")</code></b> exists.
     *
     * @param dirName
     * @throws IOException If no READING privelege was granted to both
     * <b><code>System.getProperty("user.home")</code></b> and
     * <b><code>dirName</code></b>
     */
    private boolean existsUserDir(final String dirName) throws IOException {

//        throw new IOException("Unable to I/O " + System.getProperty("user.home")+File.separator+dirName + " Please allow WRITING PRIVILEGE to that path :(");
        final File homeDir;
        final File dir;
        try {

            homeDir = new File(System.getProperty("user.home"));
            dir = new File(homeDir, dirName);
            return dir.exists();

        } catch (Exception e) {
            throw new IOException("Unable to I/O " + System.getProperty("user.home") + File.separator + dirName + " Please allow WRITING PRIVILEGE to that path :(");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void stop() throws Exception {

        System.err.println("stopping ...");
        if (app != null) {
            app.stop();
        } else {
            if (EmbeddedDatabaseCreationErrorForm.isVisible) {
                Logger.getLogger(Main.class.getName()).log(Level.INFO, "App was null when trying to stop it : REASON : EMBEDDED DATABASE CREATION FAILED, DUE TO NON WRITING PRIVILEGES, OR ANY OTHER WRITING FILE ERROR");
                throw new Exception("App was null when trying to stop it : REASON : EMBEDDED DATABASE CREATION FAILED, DUE TO NON WRITING PRIVILEGES, OR ANY OTHER WRITING FILE ERROR");
            }else if(Java8NotFoundErrorForm.isVisible){
                Logger.getLogger(Main.class.getName()).log(Level.INFO, "App was null when trying to stop it : REASON : JAVA 8 MISSING");
                throw new Exception("App was null when trying to stop it : REASON : JAVA 8 MISSING");
            }
        }
    }

}
